import { EditOutlined, ImageOutlined } from "@mui/icons-material";
import {
  Avatar,
  Box,
  Button,
  IconButton,
  TextField,
  Typography,
} from "@mui/material";
import { setGlobalState } from "actions";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authorizedFetch, GlobalState, setLoader, snackbar } from "utils";
import { AUTH_URL } from "utils/constants";

const CompanyDetails = () => {
  const { user, company } = useSelector((state: GlobalState) => state.global);
  const dispatch = useDispatch();
  const [isEditMode, setEditMode] = useState(false);

  const isAdmin = user?.permissions.includes("dashboard:*");

  const [input, setInput] = useState({
    phone: company?.phone || "",
    address: company?.address || "",
    gstNumber: company?.gstNumber || "",
    panNumber: company?.panNumber || "",
    cinNumber: company?.cinNumber || "",
  });

  const { phone, address, gstNumber, panNumber, cinNumber } = input;

  function handleChange(key: string, value: string) {
    setInput((prev) => ({ ...prev, [key]: value }));
  }

  function refetchCompany() {
    authorizedFetch(`${AUTH_URL}/company`).then((res) => {
      let { company } = res.data;
      if (company) {
        dispatch(setGlobalState({ company }));
      }
    });
  }

  function handleSubmit() {
    setLoader(true);
    authorizedFetch(`${AUTH_URL}/company/update`, {
      method: "POST",
      body: {
        phone,
        address,
        gstNumber,
        panNumber,
        cinNumber,
      },
      headers: {
        "Content-Type": "application/json",
      },
    }).then((res) => {
      setLoader(false);
      if (res.status >= 400) snackbar.error("An error occured");
      else {
        refetchCompany();
        setEditMode(false);
        snackbar.success("Saved changes");
      }
    });
  }

  return (
    <Box>
      <Box
        className="header"
        sx={{
          justifyContent: isEditMode ? "space-between" : "start",
        }}
      >
        <Typography className="heading">Company Details</Typography>
        {isEditMode ? (
          <Box display="grid" gridTemplateColumns="auto auto" gap={1}>
            <Button
              sx={{ height: 34 }}
              variant="contained"
              onClick={handleSubmit}
            >
              Save
            </Button>
            <Button
              sx={{ height: 34 }}
              variant="outlined"
              onClick={() => setEditMode(false)}
            >
              Cancel
            </Button>
          </Box>
        ) : (
          isAdmin && (
            <IconButton
              sx={{ ml: 2.25 }}
              size="small"
              color="primary"
              onClick={() => setEditMode(true)}
            >
              <EditOutlined />
            </IconButton>
          )
        )}
      </Box>
      <Box className="form">
        <Box>
          <Typography className="label">Company Name</Typography>
          {/* {isEditMode ? (
            <TextField
              size="small"
              fullWidth
              placeholder="Company Name"
              value={name}
              onChange={(e) => handleChange("name", e.target.value)}
            />
          ) : (
            <Typography className="value">{company?.name || "-"}</Typography>
            )} */}
          <Typography className="value">{company?.name || "-"}</Typography>
        </Box>
        <Box>
          <Typography className="label">Phone Number</Typography>
          {isEditMode ? (
            <TextField
              size="small"
              fullWidth
              placeholder="Phone Number"
              value={phone}
              onChange={(e) => handleChange("phone", e.target.value)}
            />
          ) : (
            <Typography className="value">{company?.phone || "-"}</Typography>
          )}
        </Box>
        <Box gridColumn="span 2">
          <Typography className="label">Address</Typography>
          {isEditMode ? (
            <TextField
              multiline
              minRows={3}
              size="small"
              fullWidth
              placeholder="Address"
              value={address}
              onChange={(e) => handleChange("address", e.target.value)}
            />
          ) : (
            <Typography
              mb={2}
              className="value"
              sx={{ whiteSpace: "pre-line" }}
            >
              {company?.address || "-"}
            </Typography>
          )}
        </Box>
        <Box>
          <Typography className="label">GST Number</Typography>
          {isEditMode ? (
            <TextField
              size="small"
              fullWidth
              placeholder="GST Number"
              value={gstNumber}
              onChange={(e) => handleChange("gstNumber", e.target.value)}
            />
          ) : (
            <Typography className="value">
              {company?.gstNumber || "-"}
            </Typography>
          )}
        </Box>
        <Box>
          <Typography className="label">PAN Number</Typography>
          {isEditMode ? (
            <TextField
              size="small"
              fullWidth
              placeholder="PAN Number"
              value={panNumber}
              onChange={(e) => handleChange("panNumber", e.target.value)}
            />
          ) : (
            <Typography className="value">
              {company?.panNumber || "-"}
            </Typography>
          )}
        </Box>
        <Box>
          <Typography className="label">CIN Number</Typography>
          {isEditMode ? (
            <TextField
              size="small"
              fullWidth
              placeholder="CIN Number"
              value={cinNumber}
              onChange={(e) => handleChange("cinNumber", e.target.value)}
            />
          ) : (
            <Typography className="value">
              {company?.cinNumber || "-"}
            </Typography>
          )}
        </Box>
        <Box gridColumn="span 2">
          <Typography className="label">Company Logo</Typography>
          <Box
            sx={{
              p: 3,
              pb: 2,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              border: "1px solid",
              borderColor: (theme) => theme.customColors.border,
              borderRadius: 1,
            }}
          >
            <Avatar
              variant="icon"
              sx={{
                mb: 2,
                color: "primary.main",
                borderColor: "#29CB971A",
                borderRadius: 2,
                height: 75,
                width: 95,
                fontSize: 38,
              }}
            >
              <ImageOutlined fontSize="inherit" />
            </Avatar>
            <Box display="flex" alignItems="center">
              <Typography fontSize={14}>Drag and drop image here or</Typography>
              <Button
                sx={{
                  textTransform: "none",
                  fontSize: 14,
                  fontWeight: 700,
                }}
                size="small"
              >
                Browse
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default CompanyDetails;
