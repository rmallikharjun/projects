import { EditOutlined } from "@mui/icons-material";
import { Box, Button, IconButton, TextField, Typography } from "@mui/material";
import { setGlobalState } from "actions";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authorizedFetch, GlobalState, setLoader, snackbar } from "utils";
import { AUTH_URL } from "utils/constants";

const UserDetails = () => {
  const { user } = useSelector((state: GlobalState) => state.global);
  const dispatch = useDispatch();
  const [isEditMode, setEditMode] = useState(false);

  const [input, setInput] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    address: user?.address || "",
    // phone: user?.phone || "",
    // email: user?.email || "",
  });

  // const { firstName, lastName, address, phone, email } = input;
  const { firstName, lastName, address } = input;

  function handleChange(key: string, value: string) {
    setInput((prev) => ({ ...prev, [key]: value }));
  }

  function refetchUser() {
    authorizedFetch(`${AUTH_URL}/user`).then((res) => {
      let { user } = res.data;
      if (user) {
        dispatch(setGlobalState({ user }));
      }
    });
  }

  function handleSubmit() {
    // console.log(input);
    setLoader(true);
    authorizedFetch(`${AUTH_URL}/user/update`, {
      method: "POST",
      body: {
        firstName,
        lastName,
        address,
        // phone,
        // email
      },
      headers: {
        "Content-Type": "application/json",
      },
    }).then((res) => {
      setLoader(false);
      refetchUser();
      if (res.status >= 400) snackbar.error("An error occured");
      else {
        setEditMode(false);
        snackbar.success("Saved changes");
      }
    });
  }

  return (
    <Box>
      <Box
        className="header"
        sx={{
          justifyContent: isEditMode ? "space-between" : "start",
        }}
      >
        <Typography className="heading">Your Profile</Typography>
        {isEditMode ? (
          <Box display="grid" gridTemplateColumns="auto auto" gap={1}>
            <Button
              sx={{ height: 34 }}
              variant="contained"
              onClick={handleSubmit}
            >
              Save
            </Button>
            <Button
              sx={{ height: 34 }}
              variant="outlined"
              onClick={() => setEditMode(false)}
            >
              Cancel
            </Button>
          </Box>
        ) : (
          <IconButton
            sx={{ ml: 2.25 }}
            size="small"
            color="primary"
            onClick={() => setEditMode(true)}
          >
            <EditOutlined />
          </IconButton>
        )}
      </Box>
      <Box className="form">
        <Box>
          <Typography className="label">First Name</Typography>
          {isEditMode ? (
            <TextField
              value={firstName}
              onChange={(e) => handleChange("firstName", e.target.value)}
              size="small"
              fullWidth
              placeholder="First Name"
            />
          ) : (
            <Typography className="value">{user?.firstName || "-"}</Typography>
          )}
        </Box>
        <Box>
          <Typography className="label">Last Name</Typography>
          {isEditMode ? (
            <TextField
              value={lastName}
              onChange={(e) => handleChange("lastName", e.target.value)}
              size="small"
              fullWidth
              placeholder="Last Name"
            />
          ) : (
            <Typography className="value">{user?.lastName || "-"}</Typography>
          )}
        </Box>
        <Box gridColumn="span 2">
          <Typography className="label">Address</Typography>
          {isEditMode ? (
            <TextField
              multiline
              minRows={3}
              value={address}
              onChange={(e) => handleChange("address", e.target.value)}
              size="small"
              fullWidth
              placeholder="Address"
            />
          ) : (
            <Typography
              mb={2}
              className="value"
              sx={{ whiteSpace: "pre-line" }}
            >
              {user?.address || "-"}
            </Typography>
          )}
        </Box>
        <Box>
          <Typography className="label">Phone Number</Typography>
          {/* {isEditMode ? (
            <TextField
              value={phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              size="small"
              fullWidth
              placeholder="Phone"
            />
          ) : (
            <Typography className="value">{user?.phone}</Typography>
          )} */}
          <Typography className="value">{user?.phone}</Typography>
        </Box>
        <Box>
          <Typography className="label">Email ID</Typography>
          {/* {isEditMode ? (
            <TextField
              value={email}
              onChange={(e) => handleChange("email", e.target.value)}
              size="small"
              fullWidth
              placeholder="Email"
            />
          ) : (
            <Typography className="value">{user?.email}</Typography>
            )} */}
          <Typography className="value">{user?.email}</Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default UserDetails;
