import { Notes, PersonOutline } from "@mui/icons-material";
import { Avatar, Box, Button, Paper, Typography } from "@mui/material";
import { useState } from "react";
import CompanyDetails from "./CompanyDetails";
import UserDetails from "./UserDetails";

const Account = () => {
  const views = [
    { label: "Your Profile", icon: <PersonOutline /> },
    { label: "Company Details", icon: <Notes /> },
  ];

  const [activeView, setActiveView] = useState(0);

  return (
    <Box height={1} display="flex" flexDirection="column">
      <Typography mt={1} mb={3} variant="h2">
        Account
      </Typography>
      <Paper
        sx={{
          flexGrow: 1,
          overflow: "hidden",
          p: 4,
          borderRadius: 2,
          boxShadow: "0 0 4px #15223214",
          display: "grid",
          gridTemplateColumns: "230px 1fr",
        }}
      >
        <Box
          sx={{
            height: 1,
            borderRight: "2px solid",
            borderColor: (theme) => theme.customColors.border,
          }}
        >
          {views.map(({ label, icon }, i) => (
            <Button
              sx={{
                mb: 2,
                justifyContent: "start",
                color: activeView === i ? "text.primary" : "text.secondary",
                textTransform: "none",
                fontSize: 16,
                fontWeight: activeView === i ? 700 : 500,
                "& .MuiButton-startIcon": { mr: 2 },
                "& .MuiAvatar-root": { height: 36, width: 36 },
              }}
              key={i}
              fullWidth
              disableRipple
              startIcon={<Avatar variant="icon" children={icon} />}
              onClick={() => setActiveView(i)}
            >
              {label}
            </Button>
          ))}
        </Box>
        <Box
          sx={{
            px: 4,
            overflow: "auto",
            "& > div": {
              maxWidth: 680,
            },
            "& .header": {
              mb: 2.5,
              display: "flex",
              alignItems: "center",
              "& .heading": {
                fontSize: 18,
                lineHeight: "21px",
                fontWeight: 700,
              },
            },
            "& .form": {
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              rowGap: 3,
              columnGap: 5,
              "& .value": { height: 40 },
            },
          }}
        >
          {activeView === 0 ? <UserDetails /> : <CompanyDetails />}
        </Box>
      </Paper>
    </Box>
  );
};

export default Account;
