import { InfoOutlined } from "@mui/icons-material";
import {
  Box,
  Paper,
  // Tab,
  // Tabs,
  IconButton,
  // Hidden,
  // useTheme,
  // useMediaQuery,
  // Avatar,
} from "@mui/material";
import Table from "components/Table";

import { useEffect, useState } from "react";
import { authorizedFetch, drawer, GlobalState } from "utils";
import DrawerContent from "./DrawerContent";

// import Filter from "../../../components/Filter";
import { DATAFEED_URL } from "utils/constants";
import { useQuery } from "react-query";
// import Search from "../../../components/Search";
import { useSelector } from "react-redux";
import moment from "moment";

const List = () => {
  // const { canWrite } = getPermissions("rental:vehicles");
  // const [tab, setTab] = useState(0);
  // const [selectedRows, setSelectedRows] = useState([]);

  // const [search, setSearch] = useState("");

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  // Filter

  // const [dropdownEntries, setDropdownEntries] = useState([
  //   {
  //     type: "heading",
  //     label: "CITY",
  //     searchable: true,
  //   },
  // ]);

  // const [filterList, setFilterList] = useState<string[]>([]);

  // array of cities to filter the select cities
  // const [cityListArr, setCityListArr] = useState<any>([]);

  // city search
  // const [citySearchDialog, setCitySearchDialog] = useState({
  //   open: false,
  //   input: "",
  // });
  // const [selectedCity, setSelectedCity] = useState<any>("");

  // const getDropdownData = (entry: any[]) => {
  //   setDropdownEntries([
  //     // { type: "heading", label: "AVAILABILTY", searchable: false },
  //     // { type: "name", name: "Available", count: 420 },
  //     // { type: "name", name: "Booked", count: 319 },
  //     // { type: "name", name: "Unavailable", count: 0 },
  //     {
  //       type: "heading",
  //       label: "CITY",
  //       searchable: true,
  //     },
  //     ...entry,
  //   ]);
  // };

  // useEffect(() => {
  //   if (filterList) {
  //     let newList: any = "";
  //     // eslint-disable-next-line
  //     filterList.map((el: any) => {
  //       if (cityListArr.includes(el)) {
  //         newList = newList + el + "_";
  //       }
  //     });
  //     // setSelectedCity(newList.slice(0, -1));
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [filterList]);

  // const cityUrl = `${BOLT_URL}/company/stats/city`;
  // const { data: cityData } = useQuery(["getCityStats"], () =>
  //   authorizedFetch(cityUrl)
  // );

  // const [cityList, setCityList] = useState<any>();

  // useEffect(() => {
  //   if (cityData && cityData?.data?.constructor === Array) {
  //     let cityList: any = [];
  //     // eslint-disable-next-line
  //     cityData?.data?.map((el: any) => {
  //       cityList.push({
  //         type: "name",
  //         name: el.city,
  //         count: el.totalVendors,
  //       });
  //     });
  //     cityList.sort((a: any, b: any) =>
  //       a.count < b.count ? 1 : b.count < a.count ? -1 : 0
  //     );
  //     setCityList(cityList);
  //   }
  // }, [cityData]);

  // useEffect(() => {
  //   if (cityList) {
  //     const list = cityList.map((el: any) => {
  //       return el.name;
  //     });
  //     setCityListArr(list);
  //     getDropdownData(cityList);
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [cityList]);

  // useEffect(() => {
  //   setPage(1);
  //   setPageSize(10);
  // }, [filterList]);

  // const theme = useTheme();
  // const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const companyId = useSelector(
    (state: GlobalState) => state.global.company.id
  );

  const tripsURL = `${DATAFEED_URL}/analytics/alltrips?token=1234&id=${companyId}&first=${pageSize}&skip=${
    pageSize * (page - 1)
  }`;

  const { isLoading: tripsLoading, data: tripsData } = useQuery(
    ["getTrips", page, pageSize],
    () => authorizedFetch(tripsURL)
  );

  return (
    <>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          {/* <Filter
            dropdownEntries={dropdownEntries}
            getDropdownData={getDropdownData}
            filterList={filterList}
            setFilterList={setFilterList}
            entrySearchDialog={citySearchDialog}
            setEntrySearchDialog={setCitySearchDialog}
            dropdownHeight={118}
            searchableEntryList={cityListArr}
            entryList={cityList}
            onClose={() => {
              setCitySearchDialog({ open: false, input: "" });
              getDropdownData(cityList);
            }}
            count={false}
          /> */}
          {/* <Box display="flex" width={1}>
            <Hidden mdDown>
              <Box ml="auto" mr={0}>
                <Search
                  handleSearch={(value) => {
                    // setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box> */}
        </Box>

        <Table
          rowCount={tripsData?.tripCount}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          // setSelectedRows={setSelectedRows}
          // selectedRows={selectedRows}
          // selectable={canWrite}
          // selectOnClick
          loading={tripsLoading}
          rows={tripsData?.trips || []}
          columns={[
            // {
            //   key: "tripId",
            //   label: "Trip Id",
            // },
            {
              key: "vin",
              label: "Vin",
            },
            {
              key: "startTime",
              label: "Start",
              format: (value) => moment(value).format("MMM DD, HH:mm"),
            },
            // {
            //   key: "endTime",
            //   label: "end",
            //   format: (value) => moment(value).format("MMM DD, HH:mm"),
            // },

            {
              key: "duration",
              label: "Duration",
              Render: (row) => {
                let duration: any = moment.duration(
                  moment(row.endTime).diff(moment(row.startTime))
                );
                return (
                  <Box>{`${
                    duration.asHours() >= 1
                      ? parseInt(duration.asHours()) + "h "
                      : ""
                  }${duration.minutes() > 0 ? duration.minutes() + "m " : ""}${
                    duration.seconds() > 0 ? duration.seconds() + "s" : ""
                  }`}</Box>
                );
              },
            },
            {
              key: "maxSpeed",
              label: "Max Speed",
              Render: (row) => {
                return (
                  <Box>{`${
                    row?.maxGpsSpeed && typeof row?.maxGpsSpeed === "number"
                      ? row?.maxGpsSpeed.toFixed(2)
                      : 0.0
                  } KMPH`}</Box>
                );
              },
            },
            {
              key: "avgSpeed",
              label: "Avg Speed",
              Render: (row) => {
                return (
                  <Box>{`${
                    row?.avgGpsSpeed ? row?.avgGpsSpeed.toFixed(2) : 0.0
                  }KMPH`}</Box>
                );
              },
            },
            {
              key: "startVoltage",
              label: "Start Voltage",
              Render: (row) => {
                let batteryStartAdc =
                  (row?.batteryVoltageAdc &&
                    row?.batteryVoltageAdc.length > 0 &&
                    row?.batteryVoltageAdc[row?.batteryVoltageAdc.length - 1]
                      .voltage) ||
                  0;
                return (
                  <Box>{`${
                    batteryStartAdc && typeof batteryStartAdc === "number"
                      ? batteryStartAdc.toFixed(2)
                      : 0.0
                  } V`}</Box>
                );
              },
            },
            {
              key: "endVoltage",
              label: "End Voltage",
              Render: (row) => {
                let batteryEndAdc =
                  (row?.batteryVoltageAdc &&
                    row?.batteryVoltageAdc.length > 0 &&
                    row?.batteryVoltageAdc[0].voltage) ||
                  0;
                return (
                  <Box>{`${
                    batteryEndAdc && typeof batteryEndAdc === "number"
                      ? batteryEndAdc.toFixed(2)
                      : 0.0
                  } V`}</Box>
                );
              },
            },

            {
              key: "distance",
              label: "Distance",
              Render: (row) => {
                return (
                  <Box>{`${
                    row?.distance && typeof row?.distance === "number"
                      ? (row?.distance / 1000).toFixed(2)
                      : 0.0
                  } km`}</Box>
                );
              },
            },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Box display="flex" alignItems="center">
                  <IconButton
                    size="small"
                    sx={{
                      ml: 0.5,
                      color: (theme) => theme.customColors.action,
                    }}
                    children={<InfoOutlined fontSize="small" />}
                    onClick={() =>
                      drawer.open(<DrawerContent key={row.id} trip={row} />)
                    }
                  />
                </Box>
              ),
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default List;
