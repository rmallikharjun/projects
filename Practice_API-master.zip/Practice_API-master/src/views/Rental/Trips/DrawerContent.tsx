import React, { useState, useRef, useEffect } from "react";
import { useSelector } from "react-redux";
import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  // Tab,
  // Tabs,
} from "@mui/material";
import {
  authorizedFetch,
  drawer,
  getDarkModePreference,
  GlobalState,
} from "utils";
import Map from "./Map";
import { useQuery } from "react-query";

import { DATAFEED_URL } from "utils/constants";
// import Table from "components/Table";
const io = require("socket.io-client/dist/socket.io");

const DrawerContent = ({ key, trip }: any) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  // const [tab, setTab] = useState(0);

  const { vin } = trip;

  const { company, token } = useSelector((state: GlobalState) => state.global);

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  const socketRef = useRef<any>(null);

  const [vehicleSnapshot, setVehicleSnapshot] = useState<any>(null);
  const [vehicleLogs, setVehicleLogs] = useState<any>(null);

  const { data: tripData } = useQuery(
    ["getTrip", trip?.tripId],
    () =>
      authorizedFetch(
        `${DATAFEED_URL}/tripV2?token=${token}&id=${company.id}&tripid=${trip?.tripId}&vin=${trip?.vin}`
      ),
    {
      enabled: trip !== null,
    }
  );

  useEffect(() => {
    if (trip) {
      socketRef.current?.close();
    } else if (socketRef.current === null) {
      socketRef.current = io(DATAFEED_URL, {
        path: "/mysocket",
        transports: ["websocket", "xhr-polling", "jsonp-polling", "polling"],
      });
      const socket = socketRef.current;
      socket.on("RESPONSE:VEHICLE_LOGS_V2", (data: any) => {
        // console.log("VEHICLE_LOGS", data.responseData);
        setVehicleLogs(data.responseData);
      });
      socket.on("RESPONSE:VEHICLE_SNAPSHOT_V2", (data: any) => {
        // console.log('VEHICLE_SNAPSHOT', data.responseData)
        // let rideSelected = false;
        // if (isLive || rideSelected) {
        setVehicleSnapshot(data.responseData);
        // }
      });
      getSocketData();
    }

    return () => {
      socketRef.current?.close();
    };
    // eslint-disable-next-line
  }, [trip]);

  function getSocketData() {
    const socket = socketRef.current;
    if (socket === null) return;
    // console.log('Getting data...')
    let search = {
      vin,
      startTime: "now-30m",
      endTime: "now",
    };
    socket.emit(
      "REQUEST:VEHICLE_LOGS_V2",
      JSON.stringify({
        companyId: company.id,
        search,
      })
    );
    socket.emit(
      "REQUEST:VEHICLE_SNAPSHOT_V2",
      JSON.stringify({
        companyId: company.id,
        vin,
      })
    );
  }

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {trip?.vin}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            {/* <IconButton
              children={<DeleteOutline />}
              color="inherit"
              size="small"
              onClick={() => setDeleteDialog(true)}
            /> */}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box mt={2}>
          <Box
            sx={{
              mx: 3,

              height: 50,
              mb: 2,
              backgroundColor: (theme) => theme.customColors.header,
              borderRadius: "10px",
              display: "flex",
              alignItems: "center",
            }}
          >
            <Typography sx={{ fontSize: 16, fontWeight: 600, ml: 2 }}>
              Trip History
            </Typography>
          </Box>
          <Map
            loading={[vehicleSnapshot].includes(null)}
            vehicleSnapshot={vehicleSnapshot}
            vehicleLogs={vehicleLogs}
            trip={trip}
            tripData={tripData}
            setVehicleSnapshot={setVehicleSnapshot}
          />
        </Box>
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
    </>
  );
};

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to DELETE:{" "}
        <span style={{ fontWeight: "bold" }}>Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DrawerContent;
