import { useEffect, useRef, useState } from "react";
import {
  Box,
  IconButton,
  MenuItem,
  Select,
  Skeleton,
  Slider,
  Typography,
} from "@mui/material";
import { Wrapper } from "@googlemaps/react-wrapper";
// import { GMAPS_API_KEY } from "utils/constants";
import VehiclePinIcon from "assets/images/vehicle-pin.svg";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";
import {
  PauseCircleOutline,
  PlayCircleOutline,
  Replay,
} from "@mui/icons-material";
import moment from "moment";
import useInterval from "use-interval";

function getBounds(path: any) {
  var bounds = new google.maps.LatLngBounds();
  path.getPath().forEach((el: any) => {
    bounds.extend(el);
  });
  return bounds;
}

function getCoordinates(lat: any, lng: any) {
  return {
    lat: parseFloat(lat),
    lng: parseFloat(lng),
  };
}

const VehicleMap = (props: any) => {
  const { loading, trip, tripData, setVehicleSnapshot } = props;

  useEffect(() => {
    if (tripData) {
      tripData?.location?.reverse();
    }
  }, [tripData]);

  const startTime = moment(tripData?.location[0]?.timestamp).valueOf();
  const endTime = moment(
    tripData?.location[tripData.location.length - 1]?.timestamp
  ).valueOf();

  const [playing, setPlaying] = useState<any>(false);
  const [speed, setSpeed] = useState<any>(5);
  const [activeTime, setActiveTime] = useState<any>(startTime);

  const interval = 100;

  useInterval(
    () => {
      const nextFrame = activeTime + speed * interval;
      if (nextFrame >= endTime) {
        setPlaying("ended");
        setActiveTime(endTime);
      } else {
        setActiveTime(nextFrame);
      }
    },
    playing === true ? interval : null
  );

  useEffect(() => {
    if (!tripData) return;

    function findClosest(array: any) {
      return array.reduce((a: any, b: any) => {
        return Math.abs(
          moment(b.timestamp).valueOf() - moment(activeTime).valueOf()
        ) <
          Math.abs(moment(a.timestamp).valueOf() - moment(activeTime).valueOf())
          ? b
          : a;
      });
    }
    const closestTimestamp = findClosest(tripData.ignition).timestamp;
    const index = tripData.location.findIndex(
      (el: any) => el.timestamp === closestTimestamp
    );
    const vehicleSnapshot = {
      ignition: tripData.ignition[index] || {},
      uart: tripData.uart[index] || {},
      location: tripData.location[index] || {},
      battery: tripData.battery[index] || {},
      alarm: tripData.alarm[index] || {},
    };

    setVehicleSnapshot(vehicleSnapshot);

    // eslint-disable-next-line
  }, [activeTime]);

  return (
    <Box
      sx={{
        position: "relative",
        height: 1,
        minHeight: 300,
        mx: 3,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 2,
        overflow: "hidden",
        border: 1,
        borderColor: (theme) => theme.customColors.border,
        boxShadow: (theme) => theme.customShadows.small,
      }}
    >
      {loading || (trip && !tripData) ? (
        <Skeleton
          variant="rectangular"
          width="100%"
          height="100%"
          animation="wave"
        />
      ) : (
        <Wrapper
          libraries={["visualization"]}
          apiKey={"AIzaSyBPPkwK8voLg73XR9xvR9xuoKqyfzu7Gac"}
        >
          <GoogleMap {...props} />
        </Wrapper>
      )}
      {trip && (
        <Box
          sx={{
            background: (theme) => theme.palette.background.paper,
            position: "absolute",
            bottom: 0,
            width: 1,
            p: 2,
            display: "flex",
            alignItems: "center",
          }}
        >
          <Typography variant="body2" sx={{ minWidth: 105 }}>
            {moment(activeTime).format("DD MMM YYYY hh:mm:ss a")}
          </Typography>
          <IconButton
            color="primary"
            onClick={() => {
              if (playing === "ended") {
                setActiveTime(startTime);
                setPlaying(true);
              } else setPlaying(!playing);
            }}
          >
            {playing === true ? (
              <PauseCircleOutline />
            ) : playing === false ? (
              <PlayCircleOutline />
            ) : (
              <Replay />
            )}
          </IconButton>
          <Slider
            sx={{ mx: 2 }}
            value={activeTime}
            onChange={(e, val) => setActiveTime(val)}
            size="small"
            min={startTime}
            max={endTime}
          />
          <Select
            sx={{ ml: 1 }}
            value={speed}
            onChange={(e) => setSpeed(e.target.value)}
            size="small"
          >
            <MenuItem value={1}>1x</MenuItem>
            <MenuItem value={5}>5x</MenuItem>
            <MenuItem value={10}>10x</MenuItem>
            <MenuItem value={25}>25x</MenuItem>
          </Select>
        </Box>
      )}
    </Box>
  );
};

const GoogleMap = ({ vehicleSnapshot, vehicleLogs, tripData, trip }: any) => {
  let { location } = vehicleSnapshot;
  const data = tripData?.location || [];
  let coordinates = data.map((cur: any) => ({
    ...getCoordinates(cur.latitude, cur.longitude),
  }));

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const ref = useRef<HTMLElement | null>(null);

  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [marker, setMarker] = useState<google.maps.Marker | null>(null);

  const [startPoint, setStartPoint] = useState<google.maps.Marker | null>(null);
  const [endPoint, setEndPoint] = useState<google.maps.Marker | null>(null);
  const [path, setPath] = useState<google.maps.Polyline | null>(null);

  useEffect(() => {
    setMap(
      new window.google.maps.Map(ref.current as HTMLElement, {
        mapId: isDarkMode ? "116bee00eb35c33a" : "a6ecf3b466dc84ee",
        center: {
          lat: location?.latitude || 0,
          lng: location?.longitude || 0,
        },
        zoom: 15,
        disableDefaultUI: true,
        // zoomControl: false,
        // streetViewControl: false,
        // fullscreenControl: false,
        // zoomControlOptions: {
        //   position: google.maps.ControlPosition.LEFT_BOTTOM,
        // },
      })
    );
    // eslint-disable-next-line
  }, [isDarkMode]);

  useEffect(() => {
    if (!map) return;

    if (marker && location)
      marker.setPosition({
        lat: location.latitude,
        lng: location.longitude,
      });
    else if (location)
      setMarker(
        new google.maps.Marker({
          position: {
            lat: location.latitude,
            lng: location.longitude,
          },
          icon: {
            url: VehiclePinIcon,
            anchor: new google.maps.Point(20, 48),
          },
          map,
        })
      );

    if (path) {
      path.setPath(coordinates);
      if (
        coordinates.length > 1 &&
        coordinates.find((el: any) => el.lat !== coordinates[0].lat)
      ) {
        map.fitBounds(getBounds(path));
      }
    } else if (data.length > 1) {
      setPath(
        new google.maps.Polyline({
          path: coordinates,
          strokeColor: "#0062FF",
          strokeOpacity: 1.0,
          strokeWeight: 4,
          map: map,
          zIndex: 2,
        })
      );
    }

    if (trip) {
      let start = getCoordinates(data[0].latitude, data[0].longitude);
      let end = getCoordinates(
        data[data.length - 1].latitude,
        data[data.length - 1].longitude
      );
      if (startPoint) {
        startPoint.setPosition(start);
        startPoint.setMap(map);
      } else
        setStartPoint(
          new google.maps.Marker({
            position: start,
            icon: {
              url: "http://maps.google.com/mapfiles/kml/paddle/go.png",
              scaledSize: new google.maps.Size(32, 32),
            },
            map: map,
            zIndex: 3,
          })
        );
      if (endPoint) {
        endPoint.setPosition(end);
        endPoint.setMap(map);
      } else
        setEndPoint(
          new google.maps.Marker({
            position: end,
            icon: {
              url: "http://maps.google.com/mapfiles/kml/paddle/stop.png",
              scaledSize: new google.maps.Size(32, 32),
            },
            map: map,
            zIndex: 3,
          })
        );
    } else {
      if (startPoint) startPoint.setMap(null);
      if (endPoint) endPoint.setMap(null);
    }
    // eslint-disable-next-line
  }, [map, location]);

  return (
    <Box
      ref={ref}
      sx={{ position: "absolute", width: 1, height: 1, color: "black" }}
    />
  );
};

export default VehicleMap;
