import { Box, Paper, Typography, Avatar, Skeleton } from "@mui/material";
import {
  DirectionsCarFilledOutlined,
  EventAvailableOutlined,
  TaskAlt,
} from "@mui/icons-material";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { LEASE_URL } from "utils/constants";

interface Props {}

const Loading = () => (
  <Box>
    <Skeleton width={38} height={38} variant="circular" />
    <Typography variant="h5" className="value">
      <Skeleton height={20} width="30%" />
    </Typography>
    <Typography variant="body2" className="title">
      <Skeleton width="60%" />
    </Typography>
  </Box>
);

const Total: React.FC<Props> = () => {
  const statsUrl = `${LEASE_URL}/company/vehicles/stats`;

  const { isLoading: statsLoading, data: statsData } = useQuery(
    "getVehicleStats",
    () => authorizedFetch(statsUrl)
  );

  console.log(statsData);

  return (
    <Paper
      sx={{
        height: "auto",
        p: 2,
        display: "grid",
        gap: 2,
        overflowX: "auto",

        gridColumn: { lg: "span 1", xs: "span 8" },
        gridTemplateColumns: {
          xs: "repeat(3, minmax(max-content, 1fr))",
          lg: "1fr",
        },
        "& > div": {
          p: 2,
          border: 1,
          borderColor: (theme) => theme.customColors.border,
          borderRadius: "4px",
          "& .icon": {
            mr: 2,
            width: 38,
            height: 38,
            borderRadius: 50,
          },
          "& .value": {
            fontWeight: 700,
            fontSize: 24,
            color: "text.primary",
            lineHeight: "1em",
            mb: 1,
            marginTop: 2,
            "& span": {
              fontWeight: 500,
              fontSize: 16,
            },
          },
          "& .title": {
            fontSize: 15,
            lineHeight: "20px",
            color: "text.secondary",
          },
        },
      }}
    >
      {statsLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <DirectionsCarFilledOutlined />
          </Avatar>
          <Typography className="value">
            {Number(statsData?.data[0]?.count).toLocaleString()}
          </Typography>
          <Typography className="title">Total Vehicles</Typography>
        </Box>
      )}
      {statsLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <TaskAlt />
          </Avatar>
          <Typography className="value">
            {Number(statsData?.data[2]?.count)?.toLocaleString()}
          </Typography>
          <Typography className="title">Total Available</Typography>
        </Box>
      )}
      {statsLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <EventAvailableOutlined />
          </Avatar>
          <Typography className="value">
            {Number(statsData?.data[1]?.count).toLocaleString()}
          </Typography>
          <Typography className="title">Total Booked</Typography>
        </Box>
      )}
    </Paper>
  );
};

export default Total;
