import { Box } from "@mui/system";
// import { useState } from "react";
import Total from "./Total";
import Deployment from "./Deployment";
// import Monitor from "./Monitor";

const Dashboard = () => {
  // const [tab, setTab] = useState(0);
  const tab = 0;
  return (
    <Box
      sx={{
        width: 1,
        gridColumn: { lg: "span 6" },

        display: "grid",
        gridTemplateColumns: { xs: "1fr", lg: "repeat(6, 1fr)" },
        gap: { xs: 2, md: 3 },
        "& > .MuiPaper-root": {
          borderRadius: 2,
          boxShadow: "0 0 4px #1C295A14",
        },
      }}
    >
      {/* <Box gridColumn={{ sm: "span 8" }}>
        <Box width={220}>
          <Tabs value={tab} onChange={(e, value) => setTab(value)}>
            <Tab label="Stats" />
            <Tab label="Monitor" />
          </Tabs>
        </Box>
      </Box> */}
      {tab === 0 && (
        <>
          <Total />
          <Deployment />
        </>
      )}
      {/* {tab === 1 && <Monitor />} */}
    </Box>
  );
};

export default Dashboard;
