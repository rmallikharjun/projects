import { useState } from "react";
import {
  Box,
  Button,
  ListItemIcon,
  Menu,
  MenuItem,
  Typography,
} from "@mui/material";
import {
  Add,
  Close,
  CurrencyRupee,
  DirectionsCarFilledOutlined,
  Settings,
} from "@mui/icons-material";
import Breadcrumbs from "../../../components/Breadcrumbs";
import ViewSelector, { View } from "components/ViewSelector";
import AddPricingDialog from "./AddPricingDialog";
import List from "./List";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";
import { getPermissions } from "utils";

import Dashboard from "./Dashboard";
import AddVehicleDialog from "./AddVehicleDialog";
import {
  Route,
  Switch,
  useHistory,
  useLocation,
  // useRouteMatch,
} from "react-router-dom";
// import SearchBox from "components/Search";
import VehicleView from "./VehicleView";
import VehicleSettings from "./VehicleSettings";

const Vehicles = () => {
  const { canWrite } = getPermissions("rental:vehicles");
  // const { isSuperAdmin } = getPermissions("rental:vehicles");
  const history = useHistory();
  const [view, setView] = useState<View>("grid");
  // const [search, setSearch] = useState("");
  // const [searchBox, setSearchBox] = useState(false);
  const [addPricingDialog, setAddPricingDialog] = useState(false);
  const [addVehicleDialog, setAddVehicleDialog] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const location = useLocation();
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const [vehicleData, setVehicleData] = useState<any>(null);

  const [vehicleSettingsDialog, setVehicleSettingsDialog] = useState({
    open: false,
    data: null,
  });

  // const match = useRouteMatch("/sold-vehicles/:vin");

  return (
    <>
      <Box
        width={1}
        mb={{ xs: view === "grid" ? 2 : 2, md: view === "grid" ? 3 : 3 }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs
          extra={() => {
            setView("list");
          }}
        />

        {location.pathname === "/vehicles" ? (
          <ViewSelector
            view={view}
            setView={setView}
            extras={
              canWrite || view === "grid"
                ? () => (
                    <>
                      {canWrite && (
                        <>
                          <Button
                            sx={{ mr: { xs: 1, md: 2 } }}
                            onClick={(e) => setAnchorEl(e.currentTarget)}
                          >
                            <Add />
                          </Button>
                          <Menu
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={() => setAnchorEl(null)}
                            anchorOrigin={{
                              vertical: "top",
                              horizontal: "center",
                            }}
                            transformOrigin={{
                              vertical: "top",
                              horizontal: "center",
                            }}
                          >
                            <MenuItem
                              onClick={() => {
                                setAddPricingDialog(true);
                                setAnchorEl(null);
                              }}
                            >
                              <ListItemIcon
                                children={
                                  <>
                                    <CurrencyRupee
                                      sx={{ color: "text.primary" }}
                                    />
                                    <Typography
                                      sx={{
                                        color: "text.primary",
                                        ml: -0.5,
                                        mt: -0.5,
                                      }}
                                    >
                                      +
                                    </Typography>
                                  </>
                                }
                              />
                              Pricing
                            </MenuItem>
                            <MenuItem
                              onClick={() => {
                                setAddVehicleDialog(true);
                                setAnchorEl(null);
                              }}
                            >
                              <ListItemIcon
                                children={
                                  <>
                                    <DirectionsCarFilledOutlined
                                      sx={{ color: "text.primary" }}
                                    />
                                    <Typography
                                      sx={{
                                        color: "text.primary",
                                        mt: -0.5,
                                        ml: -0.3,
                                      }}
                                    >
                                      +
                                    </Typography>
                                  </>
                                }
                              />
                              Vehicle
                            </MenuItem>
                          </Menu>
                        </>
                      )}
                    </>
                  )
                : undefined
            }
          />
        ) : (
          <Box>
            <Button
              sx={{
                minWidth: 40,
                height: 40,
                p: 0,
                border: 1,
                mr: 1,
                borderColor: (theme) => theme.customColors.border,
                bgcolor: isDarkMode ? "background.default" : "#fff",
              }}
              disabled={!vehicleData}
              onClick={() => {
                setVehicleSettingsDialog({
                  open: true,
                  data: vehicleData?.vehicles?.get,
                });
              }}
            >
              <Settings />
            </Button>
            <Button
              sx={{
                minWidth: 40,
                height: 40,
                p: 0,
                border: 1,
                borderColor: (theme) => theme.customColors.border,
                bgcolor: isDarkMode ? "background.default" : "#fff",
              }}
              onClick={() => {
                history.push("/vehicles");
                setView("list");
              }}
            >
              <Close />
            </Button>
          </Box>
        )}
        {/* {match && (
          <Button
            disabled={!vehicleData}
            onClick={() => {
              setVehicleSettingsDialog({
                open: true,
                data: vehicleData?.vehicles?.get,
              });
            }}
          >
            <Settings />
          </Button>
        )} */}
      </Box>
      {view === "grid" ? (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", lg: "repeat(6, 1fr)" },
            gap: { xs: 2, md: 3 },
            "& > .MuiPaper-root": {
              borderRadius: 2,
              boxShadow: "0 0 4px #1C295A14",
            },
          }}
        >
          {location.pathname === "/vehicles" ? <Dashboard /> : ""}
        </Box>
      ) : (
        <Switch>
          <Route
            exact
            path="/vehicles"
            render={(props) => {
              return <List />;
            }}
          />
        </Switch>
      )}
      <VehicleSettings
        open={vehicleSettingsDialog.open}
        vehicle={vehicleSettingsDialog.data}
        onClose={() => {
          setVehicleSettingsDialog((prev) => ({ ...prev, open: false }));
        }}
      />
      <Switch>
        <Route
          path="/vehicles/:vin"
          render={(props) => {
            return <VehicleView setVehicleData={setVehicleData} {...props} />;
          }}
        />
      </Switch>
      <AddPricingDialog
        open={addPricingDialog}
        handleClose={() => {
          setAddPricingDialog(false);
        }}
      />
      <AddVehicleDialog
        open={addVehicleDialog}
        handleClose={() => {
          setAddVehicleDialog(false);
        }}
      />
    </>
  );
};

export default Vehicles;
