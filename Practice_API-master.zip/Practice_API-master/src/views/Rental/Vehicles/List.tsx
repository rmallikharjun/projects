import { Box, Tabs, Tab, Paper, Button } from "@mui/material";

import Search from "components/Search";
import TableComponent from "components/Table";
// import moment from "moment";
import { useState } from "react";
import { useQuery } from "react-query";
// import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { authorizedFetch } from "utils";
import { LEASE_URL } from "utils/constants";
// import VehicleView from "./VehicleView";

const List = () => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  // const [search, setSearch] = useState("");

  const history = useHistory();

  const vehiclesUrl = `${LEASE_URL}/company/vehicles?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }`;

  const { data: vehiclesData, isLoading: vehiclesLoading } = useQuery(
    ["getVehicles", page, pageSize],
    () => authorizedFetch(vehiclesUrl)
  );

  return (
    <Paper
      sx={{
        width: 1,
        boxShadow: "0 0 4px #1C295A14",
        borderRadius: 2,
      }}
    >
      <Box
        sx={{
          width: 1,
          p: 3,
          pb: 2.75,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box width="fit-content">
          <Tabs className="dense" value={0}>
            <Tab
              label="All"
              className="hasCount"
              sx={{
                "&:after": {
                  content: `"${vehiclesData?.data?.totalVehicles || 0}"`,
                },
              }}
            />
          </Tabs>
        </Box>
        <Search
          handleSearch={(value) => {
            setPage(1);
            // setSearch(value);
          }}
          persist
          enableClear
        />
        {/* <FilterBy /> */}
      </Box>
      <TableComponent
        loading={vehiclesLoading}
        rowCount={vehiclesData?.data?.totalVehicles}
        rows={vehiclesData?.data?.vehicles || []}
        serverSidePagination
        activePage={page}
        activePageSize={pageSize}
        onPageChange={(value) => setPage(value)}
        onPageSizeChange={(value) => setPageSize(value)}
        columns={[
          { key: "vin", label: "VIN" },
          {
            key: "model",
            label: "Model",
            Render: (row) => row?.model?.name || "-",
          },
          {
            key: "protocol",
            label: "Protocol",
            Render: (row) => row?.model?.protocol || "-",
          },
          // {
          //   key: "updatedAt",
          //   label: "Updated At",
          //   format: (value) => moment(value).format("MMM DD, YYYY"),
          // },
          {
            key: "actions",
            label: "Actions",
            Render: (row) => (
              <Button
                variant="action"
                size="small"
                onClick={() => {
                  history.push("/vehicles/" + row.vin);
                }}
              >
                View
              </Button>
            ),
          },
        ]}
      />
    </Paper>
  );
};

export default List;
