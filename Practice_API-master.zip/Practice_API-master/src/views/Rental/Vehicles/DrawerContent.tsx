import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Tab,
  Tabs,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import {
  authorizedFetch,
  drawer,
  getDarkModePreference,
  GlobalState,
} from "utils";
import Table from "components/Table";
import { DATAFEED_URL } from "utils/constants";
import { useQuery } from "react-query";
import moment from "moment";

const DrawerContent = ({ vehicle }: any) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [tab, setTab] = useState(0);
  const [table, setTable] = useState([
    { header: "Basic Details" },
    { label: "Vin", value: "" },
    { label: "Model", value: "" },
    { label: "Protocol", value: "" },
    { label: "Driver", value: "" },
    { label: "Location", value: "" },
  ]);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(8);
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

  useEffect(() => {
    if (vehicle) {
      setTable([
        { header: "Basic Details" },
        { label: "Vin", value: vehicle.vin },
        { label: "Model", value: vehicle.model.name },
        { label: "Protocol", value: vehicle.model.protocol },
        { label: "Driver", value: vehicle.driver || "-" },
        { label: "Location", value: vehicle.location || "-" },
      ]);
    }
  }, [vehicle]);

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  let tripData: any = [];
  // eslint-disable-next-line
  [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].map((el: any) => {
    tripData.push({
      id: el,
      driver: "Jon Doe",
      location: "Bangalore",
      start: "1:00 pm",
      end: "1:30 pm",
    });
  });

  const tripsURL = `${DATAFEED_URL}/v1/vehicle/vin?token=1234&vin=${vehicle.vin}`;

  const { isLoading: tripsLoading, data: tripsData } = useQuery(
    ["getTrips", page, pageSize, vehicle],
    () => authorizedFetch(tripsURL)
  );

  console.log(tripsData);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {vehicle.vin}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            {/* <IconButton
              children={<DeleteOutline />}
              color="inherit"
              size="small"
              onClick={() => setDeleteDialog(true)}
            /> */}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box width={270} mt={2} ml={3}>
          <Tabs value={tab} onChange={(e: any, value) => setTab(value)}>
            <Tab label="Details" />
            <Tab label="Recent Trips" />
          </Tabs>
        </Box>
        {tab === 0 && (
          <Box flexGrow={1} overflow="auto">
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 2,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme) => theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& span": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 3,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  {table.map(({ header, label, value }, i) => {
                    const isFirst = table[i - 1]?.header;
                    const isLast = !table[i + 1] || table[i + 1].header;

                    return (
                      <tr
                        key={i}
                        className={
                          header
                            ? "header"
                            : `${isFirst ? "first" : ""} ${
                                isLast ? "last" : ""
                              }`
                        }
                      >
                        {header ? (
                          <td colSpan={2}>
                            <span>{header}</span>
                            {/* <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                          /> */}
                          </td>
                        ) : (
                          <>
                            <td className="bold">{label}</td>
                            <td>{value}</td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </Box>
          </Box>
        )}
        {tab === 1 && (
          <Box mt={3}>
            <Table
              rowCount={tripsData?.tripCount}
              serverSidePagination={true}
              activePage={page}
              activePageSize={pageSize}
              onPageChange={(value) => setPage(value)}
              onPageSizeChange={(value) => setPageSize(value)}
              px={isMdUp ? 3 : 2}
              height={510}
              rowsPerPage={8}
              small
              smallPagination
              loading={tripsLoading}
              rows={tripsData?.response?.leases || []}
              columns={[
                {
                  key: "user",
                  label: "User",
                  Render: (row) => (
                    <Box>
                      {row?.leasee?.user?.firstName}{" "}
                      {row?.leasee?.user?.lastName}
                    </Box>
                  ),
                },
                {
                  key: "bookingTime",
                  label: "Booking Time",
                  format: (value) => moment(value).format("MMM DD, HH:mm"),
                },
                {
                  key: "duration",
                  label: "Duration",
                  Render: (row) => {
                    let startTime = row?.startTime || row?.bookingTime;
                    let endTime = row?.endTime;
                    let duration: any = moment.duration(
                      moment(endTime).diff(moment(startTime))
                    );
                    return `${
                      duration.asHours() >= 1
                        ? parseInt(duration.asHours()) + "h "
                        : ""
                    }${
                      duration.minutes() > 0 ? duration.minutes() + "m " : ""
                    }${duration.seconds() > 0 ? duration.seconds() + "s" : ""}`;
                  },
                },
                {
                  key: "status",
                  label: "Status",
                },
                {
                  key: "payment",
                  label: "Payment",
                  Render: (row) => {
                    let info =
                      (row?.contract &&
                        row?.contract?.txInfo &&
                        row?.contract?.txInfo?.passbook &&
                        row?.contract?.txInfo?.passbook[0]) ||
                      {};
                    return (info && info?.status) || "N/A";
                  },
                },
                {
                  key: "amount",
                  label: "Amount",
                  Render: (row) => {
                    let info =
                      (row?.contract &&
                        row?.contract?.txInfo &&
                        row?.contract?.txInfo?.passbook &&
                        row?.contract?.txInfo?.passbook[0]) ||
                      {};
                    // eslint-disable-next-line
                    return "₹" + " " + ((info && info?.amount) || "0");
                  },
                },
              ]}
            />
          </Box>
        )}
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
    </>
  );
};

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to DELETE:{" "}
        <span style={{ fontWeight: "bold" }}>Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DrawerContent;
