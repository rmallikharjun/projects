// import { AddBoxOutlined } from "@mui/icons-material";
import { AddBoxOutlined } from "@mui/icons-material";
import {
  Box,
  Paper,
  Typography,
  useMediaQuery,
  useTheme,
  Tab,
  Tabs,
  Button,
  Avatar,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { useMutation, useQuery } from "react-query";
import { authorizedFetch, getPermissions, setLoader, snackbar } from "utils";
import { LEASE_URL } from "utils/constants";

const TopLocations = () => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const { canWrite } = getPermissions("rental:vehicles");
  const [selectedRows, setSelectedRows] = useState<any>([]);

  const [tab, setTab] = useState(0);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(6);

  const [deployDialog, setDeployDialog] = useState({
    open: false,
    data: "",
    tab: 0,
  });

  const vehiclesURL = `${LEASE_URL}/company/vehicles?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&orderby=createdAt_DESC&status=${
    tab === 0 ? "AVAILABLE" : tab === 1 ? "BOOKED" : "INSTOCK"
  }`;

  const {
    isLoading: vehiclesLoading,
    data: vehiclesData,
    refetch: refetchVehicles,
  } = useQuery(["getVehicle", page, pageSize, tab], () =>
    authorizedFetch(vehiclesURL)
  );

  useEffect(() => {
    setPage(1);
    setPageSize(6);
    setSelectedRows([]);
  }, [tab]);

  useEffect(() => {
    setSelectedRows([]);
  }, [page]);

  return (
    <Paper
      sx={{
        minWidth: 0,
        height: 510,
        p: 0,
        gridColumn: { lg: "span 5", xs: "span 6" },
      }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          mb: 2.5,
          mr: 3,
          justifyContent: "space-between",
        }}
      >
        <Typography
          variant="h6"
          p={{ xs: 2, md: 3 }}
          pb={{ xs: 0, md: 0 }}
          mt="2px"
        >
          Deployment
        </Typography>
        <Box width={340} ml={3} mt={1.5}>
          <Tabs
            sx={{ "& .MuiButtonBase-root": { fontSize: 12, mb: -5 } }}
            value={tab}
            onChange={(e: any, value) => setTab(value)}
          >
            <Tab label="Available" />
            <Tab label="Booked" />
            <Tab label="Instock" />
          </Tabs>
        </Box>
      </Box>

      <Table
        serverSidePagination
        activePage={page}
        activePageSize={pageSize}
        onPageChange={(value) => setPage(value)}
        onPageSizeChange={(value) => setPageSize(value)}
        rowCount={vehiclesData?.data?.totalVehicles}
        setSelectedRows={setSelectedRows}
        selectedRows={selectedRows}
        selectable={tab === 1 ? false : canWrite}
        px={isMdUp ? 3 : 2}
        height={380}
        rowsPerPage={6}
        small
        smallPagination
        loading={vehiclesLoading}
        rows={vehiclesData?.data?.vehicles || []}
        columns={[
          {
            key: "vin",
            label: "vin",
          },
          {
            key: "model",
            label: "Model",
            Render: (row) => {
              return <Box>{row?.model?.name || "-"}</Box>;
            },
          },
          {
            key: "protocol",
            label: "Protocol",
            Render: (row) => {
              return <Box>{row?.model?.protocol || "-"}</Box>;
            },
          },
          {
            key: "driver",
            label: "Driver",
          },
          {
            key: "location",
            label: "Location",
          },
          {
            key: "rentalStatus",
            label: "Rental Status",
            Render: (row) => {
              return <Avatar variant="status">{row?.rentalStatus}</Avatar>;
            },
          },
        ]}
        toolbar={() => (
          <>
            <Button
              sx={{ mr: 1.5 }}
              startIcon={<AddBoxOutlined />}
              onClick={() => {
                setDeployDialog({ open: true, data: selectedRows, tab: tab });
              }}
            >
              {tab === 0 ? "UNDEPLOY" : "DEPLOY"}
            </Button>
          </>
        )}
      />
      <DeployDialog
        open={deployDialog.open}
        selected={deployDialog.data}
        handleClose={() => {
          setDeployDialog({ ...deployDialog, open: false });
        }}
        tab={deployDialog.tab}
        refetchVehicles={refetchVehicles}
        setSelected={setSelectedRows}
      />
    </Paper>
  );
};

interface DeployDialogProps {
  open: boolean;
  handleClose: () => void;
  selected: any;
  tab: number;
  refetchVehicles: any;
  setSelected: React.Dispatch<any>;
}

const DeployDialog: React.FC<DeployDialogProps> = ({
  open,
  handleClose,
  selected,
  tab,
  refetchVehicles,
  setSelected,
}) => {
  const deployUrl = `https://bookings.dev.revos.in/company/vehicles/deploy
  `;

  const deployMutation = useMutation(
    `addVehicleBooking`,
    () =>
      authorizedFetch(deployUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          vehicles: selected,
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        refetchVehicles();
        setSelected([]);
        snackbar.success("Vehicle Deployed");
      },
      onError: () => {
        snackbar.error("Error deploying vehicle");
      },
    }
  );

  const undeployUrl = `https://bookings.dev.revos.in/company/vehicles/undeploy`;

  const undeployMutation = useMutation(
    `addVehicleBooking`,
    () =>
      authorizedFetch(undeployUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          vehicles: selected,
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        refetchVehicles();
        setSelected([]);
        snackbar.success("Vehicle Undeployed");
      },
      onError: () => {
        snackbar.error("Error undeploying vehicle");
      },
    }
  );

  const handleAction = () => {
    if (tab === 0) {
      undeployMutation.mutate();
      handleClose();
    } else {
      deployMutation.mutate();
      handleClose();
    }
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>
        {tab === 0 ? "Undeploy" : "Deploy"} Vehicle
        {selected?.length > 1 ? "s" : ""}?
      </DialogTitle>
      <DialogContent className="py-1">
        Are you sure you want to {tab === 0 ? "UNDEPLOY" : "DEPLOY"}{" "}
        <strong>{selected.length}</strong> Vehicles?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          onClick={handleAction}
          variant="contained"
          color="primary"
          disableElevation
        >
          {tab === 0 ? "Undeploy" : "Deploy"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default TopLocations;
