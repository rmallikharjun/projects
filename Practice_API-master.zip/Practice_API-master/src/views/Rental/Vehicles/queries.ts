import { gql } from "@apollo/client";

export const GET_VEHICLE = gql`
  query Vehicle($vin: String!) {
    vehicles {
      get(where: { vin: $vin }) {
        vin
        id
        status
        lastMarkedLatitude
        lastMarkedLongitude
        modelTag
        rentalStatus
        components {
          id
          UID
          prototype {
            name
            type
            id
            specs {
              key
              value
              unit
            }
          }
          warranty {
            id
            number
            expiry
            status
          }
        }
        model {
          name
          id
          protocol
          image
          config {
            speedLimit
            speedDivisor
            maxSpeed
            pickupControlLimit
            brakeRegenLimit
            zeroThrottleRegenLimit
            currentLimit
            overVoltageLimit
            underVoltageLimit
            batteryMinVoltage
            batteryMaxVoltage
            hillAssistStatus
            eabsStatus
          }
        }
        specs {
          id
          key
          value
          unit
          required
        }
        metrics {
          odometer
          trueOdometer
        }
        distributor {
          name
          id
        }
        device {
          firmware
        }
        peripheral {
          device {
            deviceId
            phone
            type
            key
            pin
          }
        }
        buyer {
          id
          firstName
          lastName
          email
          phone
          address
          aadharCard
          dateOfBirth
        }
        warranty {
          number
          expiry
          extendedMonths
        }
        invoice {
          number
        }
        currentRide {
          rider {
            firstName
            lastName
            phone
          }
          bookingTime
          startTime
          endTime
          startOdo
          endOdo
          rideStatus
          invoice {
            status
            passbook {
              amount
            }
          }
        }
      }
    }
  }
`;
