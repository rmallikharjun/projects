import { gql, useQuery, useMutation } from "@apollo/client";
import { EditOutlined, ErrorOutline, HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  FormGroup,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";
import { useState, useEffect } from "react";
import { setLoader, snackbar } from "utils";
import { queryClient } from "index";
import Map from "./Map";

interface Props {
  open: boolean;
  handleClose: () => void;
}

type inputData = {
  vin: string;
  model: string;
  iotDevice: string;
  macId: string;
  deviceId: string;
  devicePin: string;
  phoneNumber: number;
};

const GET_MODELS = gql`
  query GetAllModels {
    models {
      getAll {
        id
        type
        name
        key
        protocol
        image
        company {
          name
        }
      }
    }
  }
`;

const AddPricingDialog: React.FC<Props> = ({ open, handleClose }) => {
  const [step, setStep] = useState(0);
  const steps = ["Vehicle Info", "Finish"];
  const [modelList, setModelList] = useState<any>([]);
  const [markLocation, setMarkLocation] = useState(false);
  const [location, setLocation] = useState<google.maps.LatLng>();

  const [input, setInput] = useState<inputData>({
    vin: "",
    model: "",
    iotDevice: "",
    macId: "",
    deviceId: "",
    devicePin: "",
    phoneNumber: 0,
  });

  const { vin, model, iotDevice, deviceId, devicePin, phoneNumber, macId } =
    input;

  const iotDevices = [
    { id: "GPS_IOT", value: "GPS_IOT" },
    { id: "TELTONIKA", value: "TELTONIKA" },
    { id: "TBIT", value: "TBIT" },
    { id: "ICONCOX", value: "ICONCOX" },
    { id: "MT100", value: "MT100" },
    { id: "PT19H", value: "PT19H" },
    { id: "S112B", value: "S112B" },
    { id: "M558G", value: "M558G" },
    { id: "R11_GPS", value: "R11_GPS" },
  ];

  const { data } = useQuery(GET_MODELS, {
    onError: () => {
      snackbar.error("Error fetching models");
    },
  });

  useEffect(() => {
    if (data) {
      let arr: any = data?.models?.getAll
        ?.filter((model: any) => model?.protocol === "PNP")
        .map((model: any) => {
          return { id: model?.id, value: model?.name };
        });
      setModelList(arr);
    }
  }, [data]);

  console.log("modelList:", modelList);
  console.log("Input value is", data);

  function handleChange(key: string, value: string) {
    setInput((prevInput: inputData) => ({ ...prevInput, [key]: value }));
  }

  const ADD_VEHICLE = gql`
    mutation AddVehicle($data: CreatePnPInput!) {
      vehicles {
        createPnP(data: $data) {
          vehicle {
            id
          }
          deviceStatus
          oldDeviceVin
        }
      }
    }
  `;

  const [addVehicle] = useMutation(ADD_VEHICLE, {
    onCompleted: () => {
      ["getVehicleStats", "getVehicle"].forEach((query) => {
        queryClient.resetQueries(query, { exact: true });
      });
      setLoader(false);
      snackbar.success("Vendor created");
      handleClose();
    },
    onError: () => {
      setLoader(false);
      snackbar.error("Error creating vendor");
      // handleClose();
    },
  });

  const handleSave = () => {
    setLoader(true);
    addVehicle({
      variables: {
        data: {
          vin: vin,
          model: model,
          device: {
            deviceId: deviceId,
            phone: phoneNumber,
            key: phoneNumber,
            macId: macId,
            pin: devicePin || "1234",
            status: "ACTIVATED",
            type: iotDevice || "TBIT",
          },
          location: location?.toJSON() || "",
        },
      },
    });
  };

  function handleNext() {
    if (step === steps.length - 1) {
      handleSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![
          vin,
          model,
          iotDevice,
          deviceId,
          devicePin,
          phoneNumber,
        ].includes("");

      default:
        break;
    }
  }

  const disabled = [
    vin,
    model,
    iotDevice,
    deviceId,
    devicePin,
    phoneNumber,
  ].includes("");

  useEffect(() => {
    if (!open) {
      setInput({
        vin: "",
        model: "",
        iotDevice: "",
        macId: "",
        deviceId: "",
        devicePin: "",
        phoneNumber: 0,
      });
      setStep(0);
      setLocation(undefined);
      setMarkLocation(false);
    }
  }, [open]);

  const addedLocation: any = markLocation
    ? [
        {
          label: "Latitude",
          value: location?.toJSON().lat,
          required: true,
        },
        {
          label: "Longitude",
          value: location?.toJSON().lng,
          required: true,
        },
      ]
    : [];

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add Vehicle
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ my: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {step === 0 && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Vin</Typography>
              <TextField
                fullWidth
                size="small"
                value={vin}
                placeholder="Vin"
                onChange={(e) => {
                  handleChange("vin", e.target.value);
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Phone Number</Typography>
              <TextField
                type="number"
                fullWidth
                size="small"
                value={phoneNumber ? phoneNumber : "Phone Number"}
                placeholder="Phone Number"
                onInput={(e: any) => {
                  e.target.value = Math.max(0, parseInt(e.target.value))
                    .toString()
                    .slice(0, 10);
                }}
                onChange={(e: any) => {
                  handleChange("phoneNumber", e.target.value);
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start" sx={{ ml: 1 }}>
                      +91
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Model</Typography>
              <Select
                fullWidth
                value={model}
                onChange={(e: any) => {
                  handleChange("model", e.target.value);
                }}
                displayEmpty
              >
                <MenuItem disabled value="">
                  <em>Select</em>
                </MenuItem>
                {modelList?.map(({ id, value }: any) => (
                  <MenuItem key={id} value={id}>
                    {value}
                  </MenuItem>
                ))}
              </Select>
            </Box>
            <Box>
              <Typography className="label">IOT Device</Typography>
              <Select
                fullWidth
                value={iotDevice}
                onChange={(e: any) => {
                  handleChange("iotDevice", e.target.value);
                }}
                displayEmpty
              >
                <MenuItem disabled value="">
                  <em>Select</em>
                </MenuItem>
                {iotDevices.map(({ id, value }: any) => (
                  <MenuItem key={id} value={value}>
                    {value}
                  </MenuItem>
                ))}
              </Select>
            </Box>
            {iotDevice === "ICONCOX" ? (
              <Box sx={{ gridColumn: "span 2" }}>
                <Typography className="label">Mac Id</Typography>
                <TextField
                  fullWidth
                  size="small"
                  value={macId}
                  placeholder="Mac Id"
                  onChange={(e) => {
                    handleChange("macId", e.target.value);
                  }}
                />
              </Box>
            ) : (
              ""
            )}
            <Box>
              <Typography className="label">Device Id</Typography>
              <TextField
                fullWidth
                size="small"
                value={deviceId}
                placeholder="Device Id"
                onChange={(e) => {
                  handleChange("deviceId", e.target.value);
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Device Pin</Typography>
              <TextField
                fullWidth
                size="small"
                value={devicePin}
                placeholder="Device Pin"
                onChange={(e) => {
                  handleChange("devicePin", e.target.value);
                }}
              />
            </Box>
            <Box>
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      onChange={() => {
                        setMarkLocation(!markLocation);
                      }}
                    />
                  }
                  checked={markLocation}
                  label="Mark Location"
                />
              </FormGroup>
            </Box>
            {markLocation ? (
              <Box sx={{ gridColumn: "span 2" }}>
                <Map location={location} setLocation={setLocation} />
              </Box>
            ) : (
              ""
            )}
          </Box>
        )}
        {step === 1 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Pricing Info", onEdit: () => setStep(0) },
                  { label: "Vin", value: vin, required: true },
                  { label: "Phone Number", value: phoneNumber, required: true },
                  {
                    label: "Model",
                    value: model,
                    required: true,
                  },
                  {
                    label: "IOT Device",
                    value: iotDevice,
                    required: true,
                  },
                  ...[
                    iotDevice === "ICONCOX"
                      ? {
                          label: "Mac Id",
                          value: macId,
                          required: true,
                        }
                      : {},
                  ],
                  {
                    label: "Device ID",
                    value: deviceId,
                    required: true,
                  },
                  {
                    label: "Device Pin",
                    value: devicePin,
                    required: true,
                  },
                  ...addedLocation,
                ].map(({ header, onEdit, label, value, required }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td>{label}</td>
                          <td className="bold">
                            {value ||
                              (required && (
                                <Box display="flex" alignItems="center">
                                  <ErrorOutline
                                    fontSize="small"
                                    color="error"
                                    style={{ marginRight: 8 }}
                                  />
                                  Required
                                </Box>
                              ))}
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        {step === 0 && (
          <Button variant="outlined" onClick={handleClose}>
            Cancel
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant={
            isComplete(step) || step === steps.length - 1
              ? "contained"
              : "outlined"
          }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddPricingDialog;
