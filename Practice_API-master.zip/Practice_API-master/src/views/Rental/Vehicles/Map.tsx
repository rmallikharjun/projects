import { EffectCallback, useEffect, useRef, useState } from "react";
import { Wrapper } from "@googlemaps/react-wrapper";
import { createCustomEqual } from "fast-equals";
import { isLatLngLiteral } from "@googlemaps/typescript-guards";
import { Box } from "@mui/system";
import React from "react";
import { Autocomplete, TextField } from "@mui/material";

import usePlacesAutocomplete, {
  getGeocode,
  getLatLng,
} from "use-places-autocomplete";

interface Props {
  location: google.maps.LatLng | undefined;
  setLocation: React.Dispatch<
    React.SetStateAction<google.maps.LatLng | undefined>
  >;
}

const App: React.VFC<Props> = ({ location, setLocation }) => {
  const onClick = (e: google.maps.MapMouseEvent) => {
    setLocation(e.latLng!);
    console.log(e.latLng);
  };

  const [map, setMap] = useState<google.maps.Map>();

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: 500,
        width: "100%",
        position: "relative",
      }}
    >
      <Search map={map} setLocation={setLocation} />

      <Wrapper
        libraries={["visualization"]}
        apiKey={"AIzaSyBPPkwK8voLg73XR9xvR9xuoKqyfzu7Gac"}
      >
        <Map
          center={{
            lat: 12.9716,
            lng: 77.5946,
          }}
          onClick={onClick}
          zoom={12}
          style={{
            flexGrow: "1",
            height: "100%",
            width: "100%",
            borderRadius: "15px",
          }}
          map={map}
          setMap={setMap}
        >
          <Marker key={1} position={location} />
        </Map>
      </Wrapper>
    </Box>
  );
};

interface MapProps extends google.maps.MapOptions {
  style: { [key: string]: string };
  onClick?: (e: google.maps.MapMouseEvent) => void;
  map: google.maps.Map | undefined;
  setMap: React.Dispatch<React.SetStateAction<google.maps.Map | undefined>>;
}

const Map: React.FC<MapProps> = ({
  map,
  setMap,
  onClick,
  children,
  style,
  ...options
}) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (ref.current && !map) {
      setMap(
        new window.google.maps.Map(ref.current, {
          fullscreenControl: false,
          clickableIcons: false,
        })
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref, map]);

  useDeepCompareEffectForMaps(() => {
    if (map) {
      map.setOptions(options);
    }
  }, [map, options]);

  useEffect(() => {
    if (map) {
      ["click", "idle"].forEach((eventName) =>
        google.maps.event.clearListeners(map, eventName)
      );

      if (onClick) {
        map.addListener("click", onClick);
      }
    }
  }, [map, onClick]);

  return (
    <>
      <Box ref={ref} style={style} />
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, { map });
        }
      })}
    </>
  );
};

const Marker: React.FC<google.maps.MarkerOptions> = (options) => {
  const [marker, setMarker] = useState<google.maps.Marker>();

  useEffect(() => {
    if (!marker) {
      setMarker(new google.maps.Marker());
    }
    return () => {
      if (marker) {
        marker.setMap(null);
      }
    };
  }, [marker]);

  useEffect(() => {
    if (marker) {
      marker.setOptions(options);
    }
  }, [marker, options]);

  return null;
};

interface SearchProps {
  map: google.maps.Map | undefined;
  setLocation: React.Dispatch<
    React.SetStateAction<google.maps.LatLng | undefined>
  >;
}

const Search: React.FC<SearchProps> = ({ map, setLocation }) => {
  const {
    ready,
    value,
    setValue,
    suggestions: { status, data },
    clearSuggestions,
  } = usePlacesAutocomplete();

  return (
    <Autocomplete
      freeSolo
      id="free-solo-2-demo"
      disableClearable
      options={
        status === "OK" ? data.map((description: any) => description) : []
      }
      onChange={async (e: any, newValue: any) => {
        clearSuggestions();

        const address = newValue;
        const results = await getGeocode({ address });
        const { lat, lng } = await getLatLng(results[0]);
        const newLatLng = new google.maps.LatLng(lat, lng);
        if (lat && lng) {
          map?.setCenter({ lat, lng });
          setLocation(newLatLng);
        }
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder="Search a Place..."
          InputProps={{
            ...params.InputProps,
            type: "search",
          }}
          sx={{ "& .MuiOutlinedInput-input": { fontSize: 12 } }}
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
          }}
          disabled={!ready}
        />
      )}
      size="small"
      sx={{
        position: "absolute",
        right: 10,
        zIndex: 10,
        width: 250,
        pt: 1,
        borderRadius: 2,
      }}
    ></Autocomplete>
  );
};

const deepCompareEqualsForMaps = createCustomEqual(
  (deepEqual) => (a: any, b: any) => {
    if (
      isLatLngLiteral(a) ||
      a instanceof google.maps.LatLng ||
      isLatLngLiteral(b) ||
      b instanceof google.maps.LatLng
    ) {
      return new google.maps.LatLng(a).equals(new google.maps.LatLng(b));
    }
    return deepEqual(a, b);
  }
);

function useDeepCompareMemoize(value: any) {
  const ref = useRef();
  if (!deepCompareEqualsForMaps(value, ref.current)) {
    ref.current = value;
  }
  return ref.current;
}

function useDeepCompareEffectForMaps(
  callback: EffectCallback,
  dependencies: any[]
) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(callback, dependencies.map(useDeepCompareMemoize));
}

export default App;
