import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Paper,
  Typography,
} from "@mui/material";
import moment from "moment";
import { useEffect, useState } from "react";

const BasicDetails = ({ vehicle }: any) => {
  const [vehicleDetails, setVehicleDetails] = useState<any>({});

  useEffect(() => {
    let details = {
      "Basic Details": [
        { VIN: vehicle.vin },
        { "Vehicle Model": vehicle.model.name },
        { Protocol: vehicle.model.protocol },
        { "Vehicle Status": vehicle.rentalStatus },
        { Distributor: vehicle.distributor },
      ],
      "Vehicle Configuration": [
        { "Firmware Version": vehicle.device?.firmware || "Not Available" },
        { "Speed Limit": vehicle.model.config.speedLimit },
        { Pickup: vehicle.model.config.pickupControlLimit },
        { "Regeneration on Braking": vehicle.model.config.brakeRegenLimit },
        {
          "Regeneration on Zero Throttle":
            vehicle.model.config.zeroThrottleRegenLimit,
        },
        { "Current Limit": vehicle.model.config.currentLimit },
        {
          "Controller Over Voltage Limit":
            vehicle.model.config.overVoltageLimit,
        },
        {
          "Controller Under Voltage Limit":
            vehicle.model.config.underVoltageLimit,
        },
        {
          "Battery Minimum Voltage Limit":
            vehicle.model.config.batteryMinVoltage,
        },
        {
          "Battery Maximum Voltage Limit":
            vehicle.model.config.batteryMaxVoltage,
        },
      ],
      "Buyer Info": [
        { "First Name": vehicle.buyer?.firstName },
        { "Last Name": vehicle.buyer?.lastName },
        { Email: vehicle.buyer?.email },
        { Phone: vehicle.buyer?.phone },
        { Address: vehicle.buyer?.address },
        { "Aadhaar Card": vehicle.buyer?.aadharCard },
        { "Date of Birth": vehicle.buyer?.dateOfBirth },
      ],
      "Vehicle Warranty": [
        { Number: vehicle.warranty?.number },
        { Expiry: moment(vehicle.warranty?.expiry).format("MMM DD, YYYY") },
      ],
      Invoice: [{ "Invoice Number": vehicle.invoice?.number }],
      Peripherals:
        vehicle.peripheral?.device?.constructor === Array &&
        vehicle.peripheral.device.length > 0
          ? [
              { "Device ID": vehicle.peripheral.device[0].deviceId },
              { "Phone Number": vehicle.peripheral.device[0].phone },
              { Type: vehicle.peripheral.device[0].type },
            ]
          : [],
      Specs: vehicle.specs.map((cur: any) => ({ [cur.key]: cur.value })),
    };

    setVehicleDetails(details);
  }, [vehicle]);

  return (
    <Paper
      sx={{
        width: 1,
        boxShadow: "0 0 4px #1C295A14",
        borderRadius: 2,
        p: 3,
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 3,
        }}
      >
        {Object.keys(vehicleDetails).map((category: any, i: number) => (
          <Box key={i}>
            <Accordion disableGutters>
              <AccordionSummary>
                <Typography fontWeight={500}>{category}</Typography>
              </AccordionSummary>
              <AccordionDetails
                sx={{
                  "& table": {
                    borderCollapse: "collapse",
                    width: 1,
                    fontSize: 14,
                    lineHeight: "16px",
                    "& td": {
                      py: 1.25,
                      px: 0.5,
                    },
                    "& .bold": {
                      fontWeight: 500,
                    },
                  },
                }}
              >
                <table>
                  <tbody>
                    {vehicleDetails[category].map((cur: any, i: number) => (
                      <tr key={i}>
                        <td>{Object.keys(cur)[0]}</td>
                        <td className="bold">{cur[Object.keys(cur)[0]]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </AccordionDetails>
            </Accordion>
          </Box>
        ))}
      </Box>
    </Paper>
  );
};

export default BasicDetails;
