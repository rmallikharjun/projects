import { Box, Paper, Typography, useTheme } from "@mui/material";
import { Line } from "react-chartjs-2";
import { useEffect, useState } from "react";
import moment from "moment";

const Chart = ({ type, vehicleLogs }: any) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    if (type === "voltage" && vehicleLogs?.battery?.constructor === Array) {
      let chartData = vehicleLogs.battery
        .sort(
          (a: any, b: any) =>
            moment(a.timestamp).valueOf() - moment(b.timestamp).valueOf()
        )
        .map((el: any) => ({
          x: moment(el.timestamp).format("HH:mm"),
          y: el.batteryVoltageAdc,
        }));
      setData(chartData);
    } else if (
      type === "speed" &&
      vehicleLogs?.location?.constructor === Array
    ) {
      let chartData = vehicleLogs.location
        .sort(
          (a: any, b: any) =>
            moment(a.timestamp).valueOf() - moment(b.timestamp).valueOf()
        )
        .map((el: any) => ({
          x: moment(el.timestamp).format("HH:mm"),
          y: el.gpsSpeed,
        }));
      setData(chartData);
    }
  }, [type, vehicleLogs]);

  return (
    <Paper
      sx={{
        p: 2,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Typography mb={1} variant="h6">
        {type === "voltage" ? "Voltage (V)" : "Speed (km/h)"}
      </Typography>
      <LineChart data={data} type={type} />
    </Paper>
  );
};

const LineChart = ({ data, type }: any) => {
  const theme = useTheme();

  return (
    <Box
      sx={{
        width: 1,
        height: 200,
      }}
    >
      <Line
        data={(canvas) => {
          let color =
            type === "speed" ? "rgb(87, 184, 255)" : "rgb(41, 203, 151)";

          return {
            labels: data?.map((el: any) => el.x.split(",")[0]),
            datasets: [
              {
                data: data.map((el: any) => el.y),
                borderColor: color,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderWidth: 3,
              },
            ],
          };
        }}
        options={{
          scales: {
            xAxis: {
              // type: 'time',
              grid: {
                display: false,
                tickWidth: 0,
                tickLength: 16,
                drawBorder: false,
              },
              ticks: {
                color: theme.palette.text.secondary,
              },
            },
            yAxis: {
              ticks: {
                color: theme.palette.text.secondary,
              },
              ...(type === "speed" ? { min: 0 } : {}),
              // suggestedMin: 15,
              // suggestedMax: 30,
              grid: {
                borderDash: [4],
                tickWidth: 0,
                tickLength: 16,
                drawBorder: false,
              },
            },
          },
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              caretSize: 0,
              mode: "index",
              intersect: false,
              yAlign: "center",
              displayColors: false,
              caretPadding: 16,
              titleFont: {
                weight: "400",
              },
              bodyFont: {
                weight: "500",
              },
            },
          },
          interaction: {
            mode: "index",
            intersect: false,
          },
        }}
      />
    </Box>
  );
};

export default Chart;
