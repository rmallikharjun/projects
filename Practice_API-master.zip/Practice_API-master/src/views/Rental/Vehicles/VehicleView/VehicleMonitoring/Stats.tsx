import GaugeChart from "react-gauge-chart";
import {
  DeviceThermostatOutlined,
  WindPowerOutlined,
  SettingsOutlined,
  Height,
} from "@mui/icons-material";
import {
  Avatar,
  Box,
  Paper,
  Skeleton,
  Typography,
  useTheme,
} from "@mui/material";

const Loading = () => (
  <Box>
    <Skeleton width={38} height={38} variant="circular" />
    <Typography variant="h5" className="value">
      <Skeleton height={20} width="30%" />
    </Typography>
    <Typography variant="body2" className="title">
      <Skeleton width="60%" />
    </Typography>
  </Box>
);

const Stats = ({ vehicle, data }: any) => {
  const theme = useTheme();

  const isSmartVehicle = ["SMART", "SMART_PLUS"].includes(
    vehicle.model.protocol
  );
  const { vehicleSnapshot } = data;
  const loading = vehicleSnapshot === null;

  let speed = 0,
    maxSpeed = 0;

  if (vehicle?.model?.config) {
    maxSpeed = vehicle.model.config.maxSpeed;
    if (maxSpeed)
      speed = vehicleSnapshot?.location?.gpsSpeed
        ? vehicleSnapshot.location.gpsSpeed <= maxSpeed
          ? vehicleSnapshot.location.gpsSpeed
          : maxSpeed
        : 0;
    else speed = vehicleSnapshot?.location?.gpsSpeed || 0;
  }
  if (isSmartVehicle) {
    const speedDivisor = vehicle?.model?.config?.speedDivisor || 1;
    speed = parseFloat(vehicleSnapshot?.uart?.wheelRpm || 0) / speedDivisor;
  }

  return (
    <Box
      sx={{
        width: 1,
        display: "grid",
        gridTemplateColumns: "3fr 2fr",
        gap: 2,
      }}
    >
      <Paper
        sx={{
          p: 1.5,
          display: "grid",
          gap: 1.5,
          gridTemplateColumns: "1fr 1fr",
          "& > div": {
            p: 2,
            pb: 1,
            border: 1,
            borderColor: (theme) => theme.customColors.border,
            borderRadius: 1,
            "& .icon": {
              width: 38,
              height: 38,
              borderRadius: 50,
              mb: 2.5,
            },
            "& .value": {
              fontWeight: 700,
              fontSize: 24,
              color: "text.primary",
              lineHeight: "1em",
              mb: 1,
              mt: 2,
            },
            "& .title": {
              fontSize: 14,
              lineHeight: "18px",
              color: "text.secondary",
            },
          },
        }}
      >
        {loading ? (
          <Loading />
        ) : (
          <Box>
            <Avatar variant="icon" className="icon">
              <Height />
            </Avatar>
            <Typography className="value">
              {vehicleSnapshot?.location?.altitude
                ? parseInt(vehicleSnapshot.location.altitude) + "m"
                : "N/A"}
            </Typography>
            <Typography className="title">Altitude</Typography>
          </Box>
        )}
        {loading ? (
          <Loading />
        ) : (
          <Box>
            <Avatar variant="icon" className="icon">
              <DeviceThermostatOutlined />
            </Avatar>
            <Typography className="value">
              {isSmartVehicle
                ? vehicleSnapshot?.uart?.controllerTemperature
                  ? vehicleSnapshot.uart.controllerTemperature + "°C"
                  : "N/A"
                : vehicleSnapshot?.uart &&
                  vehicleSnapshot.uart[0] &&
                  vehicleSnapshot.uart[0].controllerTemperature
                ? vehicleSnapshot.uart[0].controllerTemperature + "°C"
                : "N/A"}
            </Typography>
            <Typography className="title">Temperature</Typography>
          </Box>
        )}
        {loading ? (
          <Loading />
        ) : (
          <Box>
            <Avatar variant="icon" className="icon">
              <WindPowerOutlined />
            </Avatar>
            <Typography className="value">N/A</Typography>
            <Typography className="title">Fan</Typography>
          </Box>
        )}
        {loading ? (
          <Loading />
        ) : (
          <Box>
            <Avatar variant="icon" className="icon">
              <SettingsOutlined />
            </Avatar>
            <Typography className="value">N/A</Typography>
            <Typography className="title">Motor</Typography>
          </Box>
        )}
      </Paper>
      <Paper
        sx={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box flexGrow={1}>
          <GaugeChart
            id="gauge-chart1"
            nrOfLevels={13}
            percent={speed / maxSpeed}
            animateDuration={2000}
            hideText
            arcPadding={0.12}
            cornerRadius={0}
            arcWidth={0.15}
            formatTextValue={(value) => `${value}%`}
            needleBaseColor={theme.customColors.green}
            needleColor={theme.customColors.green}
            colors={[theme.customColors.green + "20", theme.customColors.green]}
            style={{
              // height: 150,
              width: "100%",
              margin: "28px auto 0",
            }}
          />
        </Box>
        <Box
          sx={{
            margin: "0 auto",
            width: 1,
            maxWidth: "65%",
            display: "flex",
            justifyContent: "space-between",
            transform: "translateY(-16px) translateX(4px)",
          }}
        >
          <Typography>0</Typography>
          <Typography fontWeight={700}>{speed}</Typography>
          <Typography>{maxSpeed}</Typography>
        </Box>
        <Box
          sx={{
            m: 1.5,
            bgcolor: (theme) => theme.customColors.header,
            borderRadius: 1,
            p: 2.5,
            "& .value": {
              fontSize: 24,
              fontWeight: 700,
              lineHeight: "1em",
              color: "text.primary",
              "& span": {
                fontSize: "0.7em",
                fontWeight: 400,
                color: "text.primary",
              },
            },
          }}
        >
          <Typography mb={1} className="value">
            {isSmartVehicle ? (
              vehicleSnapshot?.uart?.odometer ? (
                <>
                  {(parseFloat(vehicleSnapshot.uart.odometer) / 1000).toFixed(
                    2
                  ) + " "}
                  <span>km</span>
                </>
              ) : (
                "N/A"
              )
            ) : vehicle.metrics && vehicle.metrics.odometer ? (
              <>
                {(parseFloat(vehicle.metrics.odometer) / 1000).toFixed(2) + " "}
                <span>km</span>
              </>
            ) : (
              "N/A"
            )}
          </Typography>
          <Typography color="textSecondary" lineHeight="1em">
            Range
          </Typography>
        </Box>
      </Paper>
    </Box>
  );
};

export default Stats;
