import { useEffect, useRef, useState } from "react";
import { Box, Skeleton } from "@mui/material";
import { Wrapper } from "@googlemaps/react-wrapper";
// import { GMAPS_API_KEY } from "utils/constants";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";

const TripsMap = (props: any) => {
  return (
    <Box
      sx={{
        position: "relative",
        height: 1,
        minHeight: 300,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 1.5,
        overflow: "hidden",
      }}
    >
      {props.loading ? (
        <Skeleton
          variant="rectangular"
          width="100%"
          height="100%"
          animation="wave"
        />
      ) : (
        <Wrapper
          libraries={["visualization"]}
          apiKey={"AIzaSyBPPkwK8voLg73XR9xvR9xuoKqyfzu7Gac"}
        >
          <GoogleMap {...props} />
        </Wrapper>
      )}
    </Box>
  );
};

const GoogleMap = ({ data }: { data: any[] }) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const ref = useRef<HTMLElement | null>(null);

  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [heatmap, setHeatmap] =
    useState<google.maps.visualization.HeatmapLayer | null>(null);

  useEffect(() => {
    setMap(
      new window.google.maps.Map(ref.current as HTMLElement, {
        mapId: isDarkMode ? "116bee00eb35c33a" : "a6ecf3b466dc84ee",
        center: { lat: 12.9716, lng: 77.5946 },
        zoom: 12,
        disableDefaultUI: true,
        // zoomControl: false,
        // streetViewControl: false,
        // fullscreenControl: false,
        // zoomControlOptions: {
        //   position: google.maps.ControlPosition.LEFT_BOTTOM,
        // },
      })
    );
    // eslint-disable-next-line
  }, [isDarkMode]);

  useEffect(() => {
    if (!map) return;

    let heatmapData = data.reduce((acc, cur, i) => {
      return [
        ...acc,
        ...cur.location.map(
          (coord: any) => new google.maps.LatLng(coord.lat, coord.lng)
        ),
      ];
    }, []);

    let bounds = new google.maps.LatLngBounds();
    heatmapData.forEach((latLng: any) => {
      bounds.extend(latLng);
    });

    if (heatmap) heatmap.setData(heatmapData);
    else
      setHeatmap(
        new google.maps.visualization.HeatmapLayer({ data: heatmapData, map })
      );

    map.setCenter(bounds.getCenter());
    map.fitBounds(bounds);
    // eslint-disable-next-line
  }, [map, data]);

  return (
    <Box
      ref={ref}
      sx={{ position: "absolute", width: 1, height: 1, color: "black" }}
    />
  );
};

export default TripsMap;
