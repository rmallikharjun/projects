import { Info } from "@mui/icons-material";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Paper,
  Tooltip,
} from "@mui/material";
import TableComponent from "components/Table";
import moment from "moment";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import { getDuration, GlobalState } from "utils";
import { DATAFEED_URL } from "utils/constants";
import TripsMap from "./VehicleMonitoring/TripsMap";

const RecentTrips = ({ vehicle, setTrip }: any) => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // const [driverInfoDialog, setDriverInfoDialog] = useState({
  //   open: false,
  //   data: null,
  // })

  const { vin } = vehicle;
  const { company } = useSelector((state: GlobalState) => state.global);

  const url = `${DATAFEED_URL}/v2/trips?token=${company.token}&id=${
    company.id
  }&vin=${vin}&first=${pageSize}&skip=${pageSize * (page - 1)}`;

  const { isLoading, data } = useQuery(
    ["getVehicleTrips", vin, page, pageSize],
    () => fetch(url).then((res) => res.json())
  );

  return (
    <Paper
      sx={{
        width: 1,
        boxShadow: "0 0 4px #1C295A14",
        borderRadius: 2,
        p: 3,
        display: "grid",
        gridTemplateColumns: "250px 1fr",
        gap: 2,
      }}
    >
      <TripsMap data={data?.trips || []} />
      <Box width={1} overflow="hidden">
        <TableComponent
          idKey="tripId"
          px={0}
          serverSidePagination
          rowCount={data?.tripCount || 0}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={isLoading}
          rows={data?.trips || []}
          columns={[
            {
              key: "startTime",
              label: "Start Time",
              format: (value) => moment(value).format("MMM DD, YYYY HH:mm"),
            },
            {
              key: "duration",
              label: "Duration",
              Render: (row) =>
                getDuration(
                  moment
                    .duration(moment(row.endTime).diff(moment(row.startTime)))
                    .asMinutes()
                ),
            },
            {
              key: "maxGpsSpeed",
              label: "Max Speed",
              format: (value) => parseFloat(value || 0).toFixed(0) + " KMPH",
            },
            {
              key: "avgGpsSpeed",
              label: "Avg Speed",
              format: (value) => parseFloat(value || 0).toFixed(0) + " KMPH",
            },
            {
              key: "startingVoltate",
              label: "Starting Voltage",
              Render: (trip) =>
                trip.batteryVoltageAdc.length > 0 &&
                trip.batteryVoltageAdc[trip.batteryVoltageAdc.length - 1] &&
                trip.batteryVoltageAdc[trip.batteryVoltageAdc.length - 1]
                  .voltage
                  ? trip.batteryVoltageAdc[
                      trip.batteryVoltageAdc.length - 1
                    ].voltage.toFixed(2) + "V"
                  : "N/A",
            },
            {
              key: "endingVoltage",
              label: "Ending Voltage",
              Render: (trip) =>
                trip.batteryVoltageAdc.length > 0 &&
                trip.batteryVoltageAdc[0] &&
                trip.batteryVoltageAdc[0].voltage
                  ? trip.batteryVoltageAdc[0].voltage.toFixed(2) + "V"
                  : "N/A",
            },
            {
              key: "distance",
              label: "Distance",
              format: (value) =>
                `${(parseFloat(value || 0) / 1000).toFixed(2)} km`,
            },
            {
              key: "driverScore",
              label: "Driver Score",
              Render: (row) => (
                <DriverScore
                  row={row}
                  vin={vin}
                  setDriverInfoDialog={() => {}}
                />
              ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Button
                  size="small"
                  variant="action"
                  onClick={() => setTrip(row)}
                >
                  View
                </Button>
              ),
            },
          ]}
        />
      </Box>
    </Paper>
  );
};

const DriverScore = ({ row, vin, setDriverInfoDialog }: any) => {
  const [score, setScore] = useState<any>(null);
  const [info, setInfo] = useState<any>(null);

  useEffect(() => {
    getData();
    // eslint-disable-next-line
  }, []);

  const getData = () => {
    fetch(
      `${DATAFEED_URL}/driverscoretrip?tripid=${row.id}&token=1234&vin=${vin}&starttime=${row.startTime}&endtime=${row.endTime}`
    )
      .then((res) => res.json())
      .then((data) => {
        setScore(
          data?.driverScore ? parseFloat(data.driverScore).toFixed(2) : "N/A"
        );
        setInfo(data?.userDetails);
      });
  };

  return !score ? (
    <CircularProgress size={18} />
  ) : (
    <Box display="flex" justifyContent="space-between">
      {score}
      {info && (
        <Tooltip title="Driver Info">
          <IconButton
            size="small"
            onClick={() => {
              setDriverInfoDialog({ open: true, data: info });
            }}
          >
            <Info />
          </IconButton>
        </Tooltip>
      )}
    </Box>
  );
};

export default RecentTrips;
