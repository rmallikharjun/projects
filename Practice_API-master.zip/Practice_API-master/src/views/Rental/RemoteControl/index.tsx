import {
  Autocomplete,
  // Avatar,
  Box,
  Button,
  // Button,
  // MenuItem,
  Paper,
  // Select,
  // Switch,
  TextField,
  Typography,
} from "@mui/material";
// import { gql, useQuery } from "@apollo/client";
import { useEffect, useState } from "react";
import Breadcrumbs from "components/Breadcrumbs";
import {
  // DoDisturbAlt,
  ExploreOutlined,
  LockOpenOutlined,
  LockOutlined,
  // PowerSettingsNewOutlined,
} from "@mui/icons-material";
import { API_URL, LEASE_URL } from "utils/constants";
import { useMutation, useQuery } from "react-query";
import { authorizedFetch, setLoader, snackbar } from "utils";

// const GET_VEHICLES = gql`
//   query Vehicles($where: VehicleWhereInput!, $orderBy: VehicleOrderByInput) {
//     vehicles {
//       getAll(where: $where, orderBy: $orderBy) {
//         vin
//         peripheral {
//           device {
//             type
//           }
//         }
//       }
//     }
//   }
// `;

const RemoteControl = () => {
  const [assetList, setAssetList] = useState<any>([]);
  const [selectedAsset, setSelectedAsset] = useState("");
  const [deviceType, setDeviceType] = useState("");
  const [lockChecked, setLockChecked] = useState(false);
  const [unlockChecked, setUnlockChecked] = useState(false);

  // const { data: assetData } = useQuery(GET_VEHICLES, {
  //   variables: {
  //     where: {
  //       // protocol_in: ['IOT', 'RIDE_SHARING'],
  //       status: "RENTAL",
  //       rentalStatus_not: "INSTOCK",
  //     },
  //     orderBy: "createdAt_DESC",
  //   },
  // });

  // useEffect(() => {
  //   if (assetData) {
  //     let arr: any = [];
  //     // eslint-disable-next-line
  //     assetData?.vehicles?.getAll?.map((el: any) => {
  //       arr.push(el.vin);
  //     });
  //     setAssetList(arr);
  //   }
  // }, [assetData]);

  const vehiclesUrl = `${LEASE_URL}/company/vehicles`;

  const { data: vehiclesData } = useQuery("getVehicles", () =>
    authorizedFetch(vehiclesUrl)
  );

  console.log(
    vehiclesData?.data?.vehicles?.filter((el: any) => {
      return (
        el?.model?.protocol === "ICONCOX" || el?.model?.protocol === "ICONCOX"
      );
    })
  );

  useEffect(() => {
    if (vehiclesData) {
      let arr: any = [];
      // eslint-disable-next-line
      vehiclesData?.data?.vehicles?.map((el: any) => {
        arr.push({ vin: el.vin, protocol: el?.model?.protocol });
      });
      setAssetList(arr);
    }
  }, [vehiclesData]);

  const lockURL = `${LEASE_URL}/vehicles/${selectedAsset}/lock`;

  const mutationLock = useMutation(
    `lockVehicle`,
    () =>
      authorizedFetch(lockURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Asset Locked`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error locking asset`);
      },
    }
  );

  const unlockURL = `${LEASE_URL}/vehicles/${selectedAsset}/unlock`;

  const mutationUnlock = useMutation(
    `unlockVehicle`,
    () =>
      authorizedFetch(unlockURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Asset Unlocked`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error unlocking asset`);
      },
    }
  );

  const locateURL = `${API_URL}/v2/vehicles/${selectedAsset}/exec`;

  const mutationLocate = useMutation(
    `unlockVehicle`,
    () =>
      authorizedFetch(locateURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          command: "FIND",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Asset Located`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error locating asset`);
      },
    }
  );

  useEffect(() => {
    if (selectedAsset && lockChecked) {
      setLoader(true);
      mutationLock.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lockChecked]);

  useEffect(() => {
    if (selectedAsset && unlockChecked) {
      setLoader(true);
      mutationUnlock.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlockChecked]);

  useEffect(() => {
    if (selectedAsset) {
      let current = assetList.filter((el: any) => {
        return el.vin === selectedAsset;
      });

      setDeviceType(current[0].protocol);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAsset]);

  return (
    <>
      <Box
        width={1}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>

      <Box
        sx={{
          display: "flex",
          "& > .MuiPaper-root": {
            borderRadius: 2,
            boxShadow: "0 0 4px #1C295A14",
          },
          w: 1,
        }}
      >
        <Paper
          sx={{
            p: 3,
            width: { xs: "100%", md: "50%" },
            mt: 2,
          }}
        >
          <Typography className="label">Asset Name</Typography>
          <Autocomplete
            disablePortal
            value={selectedAsset}
            onChange={(event: any, newValue: any) => {
              setSelectedAsset(newValue);
            }}
            id="controllable-demo"
            options={assetList.map((el: any) => el.vin)}
            getOptionLabel={(option: any) => option}
            sx={{ width: 1, mt: 3, mb: selectedAsset ? 0 : 2 }}
            renderInput={(params) => <TextField {...params} label="Asset" />}
          />
          {/* <Select
            fullWidth
            value={selectedAsset}
            onChange={(e: any) => {
              setSelectedAsset(e.target.value);
            }}
            displayEmpty
            sx={{ mt: 0.5 }}
          >
            <MenuItem disabled value="">
              <em>Select an Asset</em>
            </MenuItem>
            {assetList?.map((el: any) => (
              <MenuItem key={el} value={el}>
                {el}
              </MenuItem>
            ))}
          </Select> */}
          {selectedAsset && (
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(2, 1fr)",
                gap: 3,
                mt: 4,
                mb: 1,
              }}
            >
              {/* <Box
              sx={{
                height: 200,
                borderRadius: 2,
                border: "1px solid #00000020",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Avatar variant="icon" className="icon">
                <LockOpenOutlined sx={{ fontSize: 22 }} />
              </Avatar>
              <Typography className="label" mt={2} sx={{ fontSize: 15 }}>
                Unlock
              </Typography>
              <Typography sx={{ fontSize: 12 }}>Off</Typography>
              <Switch
                sx={{ mt: 1 }}
                disabled={[selectedAsset].includes("")}
                onChange={() => {
                  setUnlockChecked(!unlockChecked);
                }}
              />
            </Box>
            <Box
              sx={{
                height: 200,
                borderRadius: 2,
                border: "1px solid #00000020",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Avatar variant="icon" className="icon">
                <LockOutlined sx={{ fontSize: 22 }} />
              </Avatar>
              <Typography className="label" mt={2} sx={{ fontSize: 15 }}>
                Lock
              </Typography>
              <Typography sx={{ fontSize: 12 }}>Off</Typography>
              <Switch
                sx={{ mt: 1 }}
                onChange={() => {
                  setLockChecked(!lockChecked);
                }}
                disabled={[selectedAsset].includes("")}
              />
            </Box>
            <Box
              sx={{
                height: 200,
                borderRadius: 2,
                border: "1px solid #00000020",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Avatar variant="icon" className="icon">
                <ExploreOutlined sx={{ fontSize: 22 }} />
              </Avatar>
              <Typography className="label" mt={2} sx={{ fontSize: 15 }}>
                Location
              </Typography>
              <Typography sx={{ fontSize: 12 }}>Off</Typography>
              <Switch sx={{ mt: 1 }} disabled={[selectedAsset].includes("")} />
            </Box>  */}

              <Button
                variant="outlined"
                size="large"
                onClick={() => {
                  setUnlockChecked(!unlockChecked);
                }}
              >
                <LockOpenOutlined sx={{ fontSize: 18, mb: 0.5, mr: 0.5 }} />
                UNLOCK
              </Button>
              <Button
                variant="outlined"
                size="large"
                onClick={() => {
                  setLockChecked(!lockChecked);
                }}
              >
                <LockOutlined sx={{ fontSize: 18, mb: 0.5, mr: 0.5 }} />
                LOCK
              </Button>

              {deviceType && ["TBIT", "ICONCOX"].includes(deviceType) ? (
                <Button
                  variant="outlined"
                  sx={{ gridColumn: "span 2" }}
                  size="large"
                  onClick={() => {
                    mutationLocate.mutate();
                  }}
                >
                  <ExploreOutlined sx={{ fontSize: 18, mb: 0.5, mr: 0.5 }} />
                  LOCATE
                </Button>
              ) : (
                ""
              )}

              {/* <Button variant="outlined">
              <PowerSettingsNewOutlined
                sx={{ fontSize: 18, mb: 0.5, mr: 0.5 }}
              />
              IGNITION ON
            </Button>
            <Button variant="outlined">
              <DoDisturbAlt sx={{ fontSize: 18, mb: 0.5, mr: 0.5 }} />
              IGNITION OFF
            </Button> */}
            </Box>
          )}
        </Paper>
      </Box>
    </>
  );
};

export default RemoteControl;
