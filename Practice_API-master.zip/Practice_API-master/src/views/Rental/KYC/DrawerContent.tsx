import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import {
  CheckCircleOutline,
  Close,
  HighlightOff,
  HighlightOffOutlined,
  PendingOutlined,
} from "@mui/icons-material";
import {
  Box,
  IconButton,
  Avatar,
  Card,
  CardMedia,
  CardContent,
  Typography,
  CardActionArea,
  ToggleButtonGroup,
  ToggleButton,
  CircularProgress,
  Dialog,
} from "@mui/material";
import { drawer, getDarkModePreference, GlobalState } from "utils";
import { gql, useLazyQuery } from "@apollo/client";

const GET_KYC_DOCS = gql`
  query KYCDocuments($companyId: ID, $userId: ID) {
    company {
      get(where: { id: $companyId }) {
        rentalUsers(where: { id: $userId }) {
          kyc {
            associations {
              kyc {
                documents {
                  id
                  file {
                    buffer
                  }
                  type
                  status
                }
              }
            }
          }
        }
      }
    }
  }
`;

const DrawerContent = ({ user }: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const { company } = useSelector((state: GlobalState) => state.global);
  // const { canWrite } = getPermissions("rental:kyc");

  let table = [
    { header: "User Info" },
    {
      label: "Name",
      value: `${user?.firstName || ""} ${user?.lastName || ""}`,
    },
    { label: "Email", value: user?.email || "-" },
    { label: "Phone", value: user?.phone || "-" },
  ];

  const [docs, setDocs] = useState<any>([]);
  const [getDocs, { loading, data }] = useLazyQuery(GET_KYC_DOCS, {
    variables: {
      userId: user?.id,
      companyId: company.id,
    },
  });

  const [viewDialog, setViewDialog] = useState({ open: false, data: null });

  useEffect(() => {
    if (user) getDocs();
    // eslint-disable-next-line
  }, [user]);

  useEffect(() => {
    if (data) {
      let docs =
        data.company?.get?.rentalUsers[0]?.kyc?.associations[0]?.kyc
          ?.documents || [];
      setDocs(docs);
    }
  }, [data]);

  return (
    <>
      <ViewDialog
        open={viewDialog.open}
        data={viewDialog.data}
        handleClose={() => setViewDialog((prev) => ({ ...prev, open: false }))}
      />
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box display="flex" alignItems="center">
            {user?.firstName || ""} {user?.lastName || ""}
            <Avatar
              variant="status"
              className={
                user?.kyc?.status === "REJECTED"
                  ? "red"
                  : user?.kyc?.status !== "APPROVED"
                  ? "yellow"
                  : ""
              }
              sx={{ ml: 2 }}
            >
              {user?.kyc?.status || "N/A"}
            </Avatar>
          </Box>
          <Box>
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              py: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  position: "relative",
                  "& td": {
                    py: 2,
                    position: "absolute",
                    verticalAlign: "middle",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(({ header, label, value }, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                        </td>
                      ) : (
                        <>
                          {label && <td className="bold">{label}</td>}
                          {value && <td>{value}</td>}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <Box
              sx={{
                mb: 3,
                px: 2,
                py: 1.5,
                width: 1,
                backgroundColor: (theme) => theme.customColors.header,
                borderRadius: "4px",
                fontSize: 16,
                fontWeight: 600,
              }}
            >
              KYC Documents
            </Box>
            {loading ? (
              <Box display="flex" justifyContent="center">
                <CircularProgress size={24} />
              </Box>
            ) : docs.length === 0 ? (
              <Typography textAlign="center" color="text.secondary">
                No documents
              </Typography>
            ) : (
              docs.map((doc: any, i: number) => (
                <Box
                  key={i}
                  sx={{
                    mb: 1.5,
                    width: 1,
                    display: "flex",
                    alignItems: "center",
                    // justifyContent: "space-between"
                  }}
                >
                  <Card
                    onClick={() => setViewDialog({ open: true, data: doc })}
                    variant="outlined"
                    sx={{ mr: 2 }}
                  >
                    <CardActionArea sx={{ display: "flex" }}>
                      <CardMedia
                        component="img"
                        sx={{ width: 150, height: 150 }}
                        image={doc.file?.buffer || ""}
                      />
                      <CardContent sx={{ width: 240 }}>
                        <Typography mb={0.5} variant="h6">
                          {doc.type || "-"}
                        </Typography>
                        <Typography
                          // variant="body2"
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            color:
                              doc.status === "APPROVED"
                                ? "success.main"
                                : doc.status === "REJECTED"
                                ? "error.main"
                                : "warning.main",
                          }}
                        >
                          {doc.status === "APPROVED" ? (
                            <CheckCircleOutline
                              fontSize="small"
                              sx={{ mr: 0.5 }}
                            />
                          ) : doc.status === "REJECTED" ? (
                            <HighlightOffOutlined
                              fontSize="small"
                              sx={{ mr: 0.5 }}
                            />
                          ) : (
                            <PendingOutlined
                              fontSize="small"
                              sx={{ mr: 0.5 }}
                            />
                          )}
                          {doc.status[0] + doc.status.toLowerCase().slice(1)}
                        </Typography>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                  <ToggleButtonGroup
                    size="small"
                    orientation="vertical"
                    exclusive
                    defaultValue={doc.status}
                  >
                    <ToggleButton value="APPROVED">Approve</ToggleButton>
                    <ToggleButton value="REJECTED">Reject</ToggleButton>
                  </ToggleButtonGroup>
                </Box>
              ))
            )}
          </Box>
        </Box>
      </Box>
    </>
  );
};

const ViewDialog = ({ open, data, handleClose }: any) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <img src={data?.file?.buffer || ""} alt="KYC Document" />
      <IconButton
        sx={{
          position: "absolute",
          top: 0,
          right: 0,
          m: 1,
        }}
        onClick={handleClose}
        color="inherit"
      >
        <Close />
      </IconButton>
    </Dialog>
  );
};

export default DrawerContent;
