import { gql, useQuery } from "@apollo/client";
import { Avatar, Box, Button, Paper, Tab, Tabs } from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { drawer } from "utils";
import DrawerContent from "./DrawerContent";

const GET_USERS = gql`
  query Account($first: Int, $skip: Int) {
    account {
      me {
        company {
          rentalUsers(first: $first, skip: $skip) {
            id
            firstName
            lastName
            email
            phone
            kyc {
              status
            }
          }
        }
      }
    }
  }
`;

const KYC = () => {
  const [tab, setTab] = useState(0);

  // const [page, setPage] = useState(1);
  // const [pageSize, setPageSize] = useState(10);

  const { data, loading } = useQuery(
    GET_USERS
    // {
    //   variables: {
    //     first: pageSize,
    //     skip: pageSize * (page - 1)
    //   }
    // }
  );

  const [users, setUsers] = useState({
    all: [],
    approved: [],
    pending: [],
    rejected: [],
    required: [],
  });

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  useEffect(() => {
    if (!loading && data) {
      let allUsers = data?.account?.me?.company?.rentalUsers || [];

      let approved: any = [],
        pending: any = [],
        rejected: any = [],
        required: any = [];

      allUsers.forEach((el: any) => {
        let status = el.kyc?.status || "";
        switch (status) {
          case "APPROVED":
            approved.push(el);
            break;
          case "PENDING":
            pending.push(el);
            break;
          case "REJECTED":
            rejected.push(el);
            break;
          case "REQUIRED":
            required.push(el);
            break;
          default:
            break;
        }
      });

      setUsers({
        all: allUsers,
        approved,
        pending,
        rejected,
        required,
      });
    }
  }, [loading, data]);

  // useEffect(() => {
  //   setPage(1);
  //   setPageSize(10);
  // }, [tab]);

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs
              className="dense"
              value={tab}
              onChange={(e, tab) => setTab(tab)}
            >
              <Tab
                label="All"
                className="hasCount"
                sx={{ "&:after": { content: `"${users.all.length || "-"}"` } }}
              />
              <Tab
                label="Approved"
                className="hasCount"
                sx={{
                  "&:after": { content: `"${users.approved.length || "-"}"` },
                }}
              />
              <Tab
                label="Pending"
                className="hasCount"
                sx={{
                  "&:after": { content: `"${users.pending.length || "-"}"` },
                }}
              />
              <Tab
                label="Rejected"
                className="hasCount"
                sx={{
                  "&:after": { content: `"${users.rejected.length || "-"}"` },
                }}
              />
              <Tab
                label="Required"
                className="hasCount"
                sx={{
                  "&:after": { content: `"${users.required.length || "-"}"` },
                }}
              />
            </Tabs>
          </Box>
          {/* <FilterBy /> */}
        </Box>
        <Table
          loading={loading}
          rows={
            tab === 0
              ? users.all
              : tab === 1
              ? users.approved
              : tab === 2
              ? users.pending
              : tab === 3
              ? users.rejected
              : users.required
          }
          // rowCount={0}
          // serverSidePagination
          // activePage={page}
          // activePageSize={pageSize}
          // onPageChange={(value) => setPage(value)}
          // onPageSizeChange={(value) => setPageSize(value)}
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => {
                let { firstName, lastName } = row;
                return `${firstName || ""} ${lastName || ""}`;
              },
            },
            { key: "email", label: "Email" },
            { key: "phone", label: "Phone" },
            {
              key: "kyc.status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={
                    row?.kyc?.status === "REJECTED"
                      ? "red"
                      : row?.kyc?.status === "APPROVED"
                      ? "green"
                      : "yellow"
                  }
                >
                  {row?.kyc?.status || "N/A"}
                </Avatar>
              ),
            },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => {
                    // setUpdateDialog({ open: true, user: row });
                    drawer.open(<DrawerContent user={row} />);
                  }}
                >
                  View
                </Button>
              ),
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default KYC;
