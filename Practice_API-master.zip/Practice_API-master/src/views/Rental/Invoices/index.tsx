import { Box } from "@mui/material";

const Invoices = () => {
  return <Box>Invoices</Box>;
};

export default Invoices;
