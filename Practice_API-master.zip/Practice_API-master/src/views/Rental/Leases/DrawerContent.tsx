import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Tab,
  Tabs,
} from "@mui/material";
import { drawer, getDarkModePreference, GlobalState } from "utils";
import Table from "components/Table";

const DrawerContent = ({ key, vehicle }: any) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [tab, setTab] = useState(0);
  const [table, setTable] = useState([
    { header: "Basic Details" },
    { label: "Vin", value: "" },
    { label: "User", value: "" },
    { label: "Start Time", value: "" },
    { label: "Type", value: "" },
  ]);

  useEffect(() => {
    if (vehicle) {
      setTable([
        { header: "Basic Details" },
        { label: "Vin", value: vehicle.vin },
        { label: "User", value: vehicle.user },
        { label: "Start Time", value: vehicle.startTime },
        { label: "Type", value: vehicle.type },
      ]);
    }
  }, [vehicle]);

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  let tripData: any = [];
  // eslint-disable-next-line
  [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].map((el: any) => {
    tripData.push({
      id: el,
      driver: "Jon Doe",
      location: "Bangalore",
      start: "1:00 pm",
      end: "1:30 pm",
    });
  });

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {vehicle.vin}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            {/* <IconButton
              children={<DeleteOutline />}
              color="inherit"
              size="small"
              onClick={() => setDeleteDialog(true)}
            /> */}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box width={270} mt={4} ml={3}>
          <Tabs value={tab} onChange={(e: any, value) => setTab(value)}>
            <Tab label="Details" />
            <Tab label="Recent Trips" />
          </Tabs>
        </Box>
        {tab === 0 && (
          <Box flexGrow={1} overflow="auto">
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 2,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme) => theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& span": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 3,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  {table.map(({ header, label, value }, i) => {
                    const isFirst = table[i - 1]?.header;
                    const isLast = !table[i + 1] || table[i + 1].header;

                    return (
                      <tr
                        key={i}
                        className={
                          header
                            ? "header"
                            : `${isFirst ? "first" : ""} ${
                                isLast ? "last" : ""
                              }`
                        }
                      >
                        {header ? (
                          <td colSpan={2}>
                            <span>{header}</span>
                            {/* <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                          /> */}
                          </td>
                        ) : (
                          <>
                            <td className="bold">{label}</td>
                            <td>{value}</td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </Box>
          </Box>
        )}
        {tab === 1 && (
          <Box mt={3}>
            <Table
              height={500}
              rowsPerPage={8}
              small
              smallPagination
              loading={false}
              rows={tripData || []}
              columns={[
                {
                  key: "driver",
                  label: "Driver",
                },
                {
                  key: "location",
                  label: "Location",
                },
                {
                  key: "start",
                  label: "Start",
                },
                {
                  key: "end",
                  label: "end",
                },
              ]}
            />
          </Box>
        )}
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
    </>
  );
};

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to DELETE:{" "}
        <span style={{ fontWeight: "bold" }}>Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DrawerContent;
