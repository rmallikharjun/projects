// import { InfoOutlined } from "@mui/icons-material";
import {
  Box,
  Paper,
  // Tab,
  // Tabs,
  // IconButton,
  // Hidden,
  Avatar,
  Button,
  Tab,
  Tabs,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import Table from "components/Table";

import { useEffect, useState } from "react";
import {
  authorizedFetch,
  drawer,
  getPermissions,
  setLoader,
  snackbar,
} from "utils";
// import DrawerContent from "./DrawerContent";

// import Filter from "../../../components/Filter";
import { LEASE_URL } from "utils/constants";
import { useMutation, useQuery } from "react-query";
// import Search from "../../../components/Search";
import moment from "moment";

const List = () => {
  const { canWrite } = getPermissions("rental:vehicles");
  const [tab, setTab] = useState(0);
  const [selectedRows, setSelectedRows] = useState([]);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [payDialog, setPayDialog] = useState({
    open: false,
    data: {},
  });

  const [startDialog, setStartDialog] = useState({
    open: false,
    data: {},
  });

  const [endDialog, setEndDialog] = useState({
    open: false,
    data: {},
  });

  const [cancelDialog, setCancelDialog] = useState({
    open: false,
    data: {},
  });

  const [terminateDialog, setTerminateDialog] = useState({
    open: false,
    data: {},
  });

  // const [search, setSearch] = useState("");

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  // Filter

  // const [dropdownEntries, setDropdownEntries] = useState([
  //   {
  //     type: "heading",
  //     label: "CITY",
  //     searchable: true,
  //   },
  // ]);

  // const [filterList, setFilterList] = useState<string[]>([]);

  // array of cities to filter the select cities
  // const [cityListArr, setCityListArr] = useState<any>([]);

  // city search
  // const [citySearchDialog, setCitySearchDialog] = useState({
  //   open: false,
  //   input: "",
  // });
  // const [selectedCity, setSelectedCity] = useState<any>("");

  // const getDropdownData = (entry: any[]) => {
  //   setDropdownEntries([
  //     { type: "heading", label: "AVAILABILTY", searchable: false },
  //     { type: "name", name: "Booked", count: 420 },
  //     { type: "name", name: "Active", count: 319 },
  //     { type: "name", name: "Ended", count: 0 },
  //     {
  //       type: "heading",
  //       label: "CITY",
  //       searchable: true,
  //     },
  //     ...entry,
  //   ]);
  // };

  // useEffect(() => {
  //   if (filterList) {
  //     let newList: any = "";
  //     // eslint-disable-next-line
  //     filterList.map((el: any) => {
  //       if (cityListArr.includes(el)) {
  //         newList = newList + el + "_";
  //       }
  //     });
  //     // setSelectedCity(newList.slice(0, -1));
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [filterList]);

  // const cityUrl = `${BOLT_URL}/company/stats/city`;
  // const { data: cityData } = useQuery(["getCityStats"], () =>
  //   authorizedFetch(cityUrl)
  // );

  // const [cityList, setCityList] = useState<any>();

  // useEffect(() => {
  //   if (cityData && cityData?.data?.constructor === Array) {
  //     let cityList: any = [];
  //     // eslint-disable-next-line
  //     cityData?.data?.map((el: any) => {
  //       cityList.push({
  //         type: "name",
  //         name: el.city,
  //         count: el.totalVendors,
  //       });
  //     });
  //     cityList.sort((a: any, b: any) =>
  //       a.count < b.count ? 1 : b.count < a.count ? -1 : 0
  //     );
  //     setCityList(cityList);
  //   }
  // }, [cityData]);

  // useEffect(() => {
  //   if (cityList) {
  //     const list = cityList.map((el: any) => {
  //       return el.name;
  //     });
  //     setCityListArr(list);
  //     getDropdownData(cityList);
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [cityList]);

  useEffect(() => {
    setPage(1);
    setPageSize(10);
  }, [tab]);

  const leasesURL = `${LEASE_URL}/company/bookings?sort=-1&first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&status=${
    tab === 0
      ? ""
      : tab === 1
      ? "BOOKED"
      : tab === 2
      ? "PENDING_PAYMENT"
      : tab === 3
      ? "PAYMENT_INITIALISED"
      : "TERMINATED"
  }`;

  const {
    isLoading: leaseLoading,
    data: leasesData,
    refetch: refetchBookings,
  } = useQuery(["getAllBookings", page, pageSize, tab], () =>
    authorizedFetch(leasesURL)
  );

  return (
    <>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: "100%",
            p: 3,
            pb: 2.75,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ width: "59.5%" }}>
            <Tabs value={tab} onChange={(e: any, value) => setTab(value)}>
              <Tab label="All" />
              <Tab label="Booked" />
              <Tab label="Pending Payment" />
              <Tab label="Payment Initialised" />
              <Tab label="Terminated" />
            </Tabs>
          </Box>

          {/* <Filter
            dropdownEntries={dropdownEntries}
            getDropdownData={getDropdownData}
            filterList={filterList}
            setFilterList={setFilterList}
            entrySearchDialog={citySearchDialog}
            setEntrySearchDialog={setCitySearchDialog}
            dropdownHeight={118}
            searchableEntryList={cityListArr}
            entryList={cityList}
            onClose={() => {
              setCitySearchDialog({ open: false, input: "" });
              getDropdownData(cityList);
            }}
            count={false}
          /> */}
          {/* <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    // setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box> */}
        </Box>

        <Table
          idKey="id"
          rowCount={leasesData?.data?.count}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={leaseLoading}
          setSelectedRows={setSelectedRows}
          selectedRows={selectedRows}
          selectable={canWrite}
          // selectOnClick
          rows={leasesData?.data?.bookings || []}
          columns={[
            {
              key: "vin",
              label: "vin",
            },
            {
              key: "user",
              label: "User",
              Render: (row) => {
                return <Box>{row?.leasee?.user?.firstName}</Box>;
              },
            },
            {
              key: "startTime",
              label: "Start Time",
              format: (value) => moment(value).format("MMM DD, hh:mm A"),
            },
            {
              key: "type",
              label: "Type",
            },

            {
              key: "status",
              label: "Status",
              Render: (row) => {
                return <Avatar variant="status">{row.status}</Avatar>;
              },
            },

            {
              key: "bookingAmount",
              label: "Amount",
              Render: (row) => {
                return <Box>{"₹ " + row?.bookingAmount}</Box>;
              },
            },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Box display="flex" alignItems="center" gap={1}>
                  {["BOOKED"].includes(row?.status) ? (
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => {
                        setStartDialog({ open: true, data: row });
                      }}
                    >
                      Start
                    </Button>
                  ) : (
                    ""
                  )}
                  {["BOOKED", "ACTIVE"].includes(row?.status) ? (
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => {
                        setEndDialog({ open: true, data: row });
                      }}
                    >
                      End
                    </Button>
                  ) : (
                    ""
                  )}

                  {["PENDING_PAYMENT", "PAYMENT_INITIALISED"].includes(
                    row?.status
                  ) ? (
                    <Button
                      variant="contained"
                      size="small"
                      onClick={() => {
                        setPayDialog({ open: true, data: row });
                      }}
                    >
                      Pay
                    </Button>
                  ) : (
                    ""
                  )}
                  {["BOOKED"].includes(row?.status) ? (
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => {
                        setCancelDialog({ open: true, data: row });
                      }}
                    >
                      Cancel
                    </Button>
                  ) : (
                    ""
                  )}
                  {["PENDING_PAYMENT", "PAYMENT_INITIALISED"].includes(
                    row?.status
                  ) ? (
                    <Button
                      variant="outlined"
                      size="small"
                      onClick={() => {
                        setTerminateDialog({ open: true, data: row });
                      }}
                    >
                      TERMINATE
                    </Button>
                  ) : (
                    ""
                  )}
                  {/* <IconButton
                    size="small"
                    sx={{
                      ml: 0.5,
                      color: (theme) => theme.customColors.action,
                    }}
                    children={<InfoOutlined fontSize="small" />}
                    onClick={() =>
                      drawer.open(<DrawerContent key={row.id} vehicle={row} />)
                    }
                  /> */}
                </Box>
              ),
            },
          ]}
        />
      </Paper>
      <PaymentDialog
        open={payDialog.open}
        handleClose={() => {
          setPayDialog({ ...payDialog, open: false });
        }}
        booking={payDialog.data}
        refetchBookings={refetchBookings}
      />
      <StartDialog
        open={startDialog.open}
        handleClose={() => {
          setStartDialog({ ...startDialog, open: false });
        }}
        booking={startDialog.data}
        refetchBookings={refetchBookings}
      />
      <EndDialog
        open={endDialog.open}
        handleClose={() => {
          setEndDialog({ ...endDialog, open: false });
        }}
        booking={endDialog.data}
        refetchBookings={refetchBookings}
      />
      <CancelDialog
        open={cancelDialog.open}
        handleClose={() => {
          setCancelDialog({ ...cancelDialog, open: false });
        }}
        booking={cancelDialog.data}
        refetchBookings={refetchBookings}
      />
      <TerminateDialog
        open={terminateDialog.open}
        handleClose={() => {
          setTerminateDialog({ ...terminateDialog, open: false });
        }}
        booking={terminateDialog.data}
        refetchBookings={refetchBookings}
      />
    </>
  );
};

const PaymentDialog = ({
  open,
  handleClose,
  booking,
  refetchBookings,
}: any) => {
  const payInitialiseURL = `${LEASE_URL}/company/booking/${booking?.id}/payment/init`;

  const initMutation = useMutation(
    `paymentInitialisation`,
    () =>
      authorizedFetch(payInitialiseURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          amount: 0,
          amountPaid: 0,
          remark: "",
          stage: "TEST",
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
      },
    }
  );

  const payConfirmURL = `${LEASE_URL}/company/booking/${booking?.id}/payment/confirm`;

  const confirmMutation = useMutation(
    `paymentInitialisation`,
    () =>
      authorizedFetch(payConfirmURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success("Payment Confirmed");
        refetchBookings();
        setLoader(false);
      },
      onError: () => {
        snackbar.success("Error confirming Payment");
      },
    }
  );

  useEffect(() => {
    if (open) {
      initMutation.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const onConfirm = () => {
    setLoader(true);
    confirmMutation.mutate();
    handleClose();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Comfirm Payment</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to
        <span style={{ fontWeight: "bold" }}> Comfirm Payment</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onConfirm}
        >
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const StartDialog = ({ open, handleClose, booking, refetchBookings }: any) => {
  const startURL = `${LEASE_URL}/company/booking/${booking?.id}/start`;

  const startMutation = useMutation(
    `startBooking`,
    () =>
      authorizedFetch(startURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success("Booking Started");
        refetchBookings();
        setLoader(false);
      },
      onError: () => {
        snackbar.success("Error starting booking");
      },
    }
  );

  const onStart = () => {
    setLoader(true);
    startMutation.mutate();
    handleClose();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Start Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to
        <span style={{ fontWeight: "bold" }}> Start Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onStart}
        >
          Start
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const EndDialog = ({ open, handleClose, booking, refetchBookings }: any) => {
  const endURL = `${LEASE_URL}/company/booking/${booking?.id}/end`;

  const endMutation = useMutation(
    `endBooking`,
    () =>
      authorizedFetch(endURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success("Booking Ended");
        refetchBookings();
        setLoader(false);
      },
      onError: () => {
        snackbar.success("Error ended booking");
      },
    }
  );

  const onEnd = () => {
    setLoader(true);
    endMutation.mutate();
    handleClose();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>End Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to
        <span style={{ fontWeight: "bold" }}> End Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onEnd}
        >
          End
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const CancelDialog = ({ open, handleClose, booking, refetchBookings }: any) => {
  const cancelURL = `${LEASE_URL}/company/booking/${booking?.id}/cancel`;

  const cancelMutation = useMutation(
    `cancelBooking`,
    () =>
      authorizedFetch(cancelURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success("Booking Cancelled");
        refetchBookings();
        setLoader(false);
      },
      onError: () => {
        snackbar.success("Error cancelling booking");
      },
    }
  );

  const onCancel = () => {
    setLoader(true);
    cancelMutation.mutate();
    handleClose();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Cancel Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to
        <span style={{ fontWeight: "bold" }}> Cancel Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Back</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onCancel}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const TerminateDialog = ({
  open,
  handleClose,
  booking,
  refetchBookings,
}: any) => {
  const terminateURL = `${LEASE_URL}/company/booking/${booking?.id}/payment/fail`;

  const terminateMutation = useMutation(
    `terminateBooking`,
    () =>
      authorizedFetch(terminateURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      }),
    {
      onSuccess: () => {
        snackbar.success("Booking Terminated");
        refetchBookings();
        setLoader(false);
      },
      onError: () => {
        snackbar.success("Error terminating booking");
      },
    }
  );

  const onTerminate = () => {
    setLoader(true);
    terminateMutation.mutate();
    handleClose();
  };

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Terminate Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to
        <span style={{ fontWeight: "bold" }}> Terminate Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onTerminate}
        >
          Terminate
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default List;
