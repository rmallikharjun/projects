import {
  EditOutlined,
  ErrorOutline,
  HighlightOff,
  // OpenInFull,
} from "@mui/icons-material";
import {
  // Autocomplete,
  Box,
  Button,
  // Checkbox,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  // FormControlLabel,
  // FormGroup,
  IconButton,
  InputAdornment,
  MenuItem,
  // Radio,
  // RadioGroup,
  Select,
  // Skeleton,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";
import { useState, useEffect } from "react";
import DateTimePicker from "@mui/lab/DateTimePicker";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import { LEASE_URL } from "utils/constants";
import { useMutation, useQuery } from "react-query";
import { authorizedFetch, setLoader, snackbar } from "utils";
import moment from "moment";

import { CountdownCircleTimer } from "react-countdown-circle-timer";

interface Props {
  open: boolean;
  handleClose: () => void;
}

type inputData = {
  vehicle: string;
  type: string;
  amount: number;
  pricingType: { id: string; name: string };
  pricingName: string;
  pricingUnit: string;
  baseAmount: number;
  costPerUnit: number;
  paymentAccount: string;
};

const AddDialog: React.FC<Props> = ({ open, handleClose }) => {
  const [step, setStep] = useState(0);
  const steps = ["User Info", "Lease Info", "Finish"];
  const [startImmediately, setStartImmediately] = useState(false);

  const [pricingValue, setPricingValue] = useState("preset");

  const [startTime, setStartTime] = useState<Date | null>(new Date());

  const [endTime, setEndTime] = useState<Date | null>(new Date());

  const [pricingList, setPricingList] = useState<any>([]);
  const [vehicleList, setVehicleList] = useState<any>([]);

  const pricingUrl = `${LEASE_URL}/company/pricing`;

  const { data: pricingData } = useQuery("getPricing", () =>
    authorizedFetch(pricingUrl)
  );

  const vehiclesUrl = `${LEASE_URL}/company/vehicles`;

  const { data: vehiclesData } = useQuery("getVehicles", () =>
    authorizedFetch(vehiclesUrl)
  );

  const [input, setInput] = useState<inputData>({
    vehicle: "",
    type: "",
    amount: 0,

    pricingType: { id: "", name: "" },
    pricingName: "",
    pricingUnit: "",
    baseAmount: 0,
    costPerUnit: 0,
    paymentAccount: "",
  });

  function handleChange(key: string, value: string) {
    setInput((prevInput: inputData) => ({ ...prevInput, [key]: value }));
  }

  const handleStartTime = (newValue: Date | null) => {
    setStartTime(newValue);
  };

  const handleEndTime = (newValue: Date | null) => {
    setEndTime(newValue);
  };

  // const handlePricingChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setPricingValue((event.target as HTMLInputElement).value);
  // };

  const {
    vehicle,
    type,
    amount,
    pricingType,

    pricingName,
    pricingUnit,
    baseAmount,
    costPerUnit,
    paymentAccount,
  } = input;

  const [verifiedUser, setVerifiedUser] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    status: 0,
  });

  const { firstName, lastName, phone, email, status } = verifiedUser;

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![firstName, lastName, phone, email].includes("");
      case 1:
        return startImmediately
          ? pricingValue === "preset"
            ? ![vehicle, type, amount.toExponential, pricingType].includes("")
            : ![
                vehicle,
                type,
                amount,
                pricingName,
                pricingUnit,
                baseAmount,
                costPerUnit,
                paymentAccount,
              ].includes("")
          : ![vehicle, type].includes("");

      default:
        break;
    }
  }

  // const disabledFirst = [
  //   vehicle,
  //   type,
  //   firstName,
  //   lastName,
  //   phone,
  //   email,
  // ].includes("");

  // const disabledPreset = [
  //   vehicle,
  //   type,
  //   pricingType,
  //   firstName,
  //   lastName,
  //   phone,
  //   email,
  // ].includes("");

  // const disabledNew = [
  //   vehicle,
  //   firstName,
  //   lastName,
  //   phone,
  //   email,
  //   type,
  //   pricingName,
  //   pricingUnit,
  //   baseAmount,
  //   costPerUnit,
  //   paymentAccount,
  // ].includes("");

  // const disabled = startImmediately
  //   ? pricingValue === "preset"
  //     ? disabledPreset
  //     : disabledNew
  //   : disabledFirst;

  useEffect(() => {
    if (!open) {
      setInput({
        vehicle: "",
        type: "",
        amount: 0,
        pricingType: { id: "", name: "" },
        pricingName: "",
        pricingUnit: "",
        baseAmount: 0,
        costPerUnit: 0,
        paymentAccount: "",
      });
      setStep(0);
      setStartImmediately(false);
      setPricingValue("preset");
    }
  }, [open]);

  const onStartImmediately: any = startImmediately
    ? pricingValue === "preset"
      ? [{ label: "Preset Pricing", value: pricingType.name, required: true }]
      : [
          { label: "Pricing Name", value: pricingName, required: true },
          { label: "Pricing Unit", value: pricingUnit, required: true },
          {
            label: "Base Amount",
            value: baseAmount ? `₹ ${baseAmount}` : "",
            required: true,
          },
          {
            label: "Cost Per Unit",
            value: costPerUnit ? `₹ ${costPerUnit}` : "",
            required: true,
          },
          {
            label: "Payment Account",
            value: paymentAccount,
            required: true,
          },
        ]
    : "";

  useEffect(() => {
    if (vehiclesData) {
      let arr: any = [];
      // eslint-disable-next-line
      vehiclesData?.data?.vehicles?.map((el: any) => {
        arr.push({
          id: el.id,
          vin: el.vin,
        });
      });
      setVehicleList(arr);
    }
  }, [vehiclesData]);

  useEffect(() => {
    if (pricingData) {
      let arr: any = [];
      // eslint-disable-next-line
      pricingData?.data?.map((el: any) => {
        arr.push({
          id: el.id,
          name: el.name,
        });
      });
      setPricingList(arr);
    }
  }, [pricingData]);

  console.log(pricingData);

  const [verifyPhone, setVerifyPhone] = useState("");

  const verifyUser = `${LEASE_URL}/company/verifyUser`;

  const {
    data: userData,
    mutate,
    isLoading: userLoading,
  } = useMutation(
    `verifyUser`,
    () =>
      authorizedFetch(verifyUser, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          user: {
            phone: `+91${verifyPhone}`,
          },
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
      },
    }
  );

  console.log(userData);

  const addLease = `${LEASE_URL}/company/vehicle/${vehicle}/booking/create`;

  const {
    data: leaseData,
    mutate: leaseMutation,
    // isLoading: leaseLoading,
  } = useMutation(
    `addVehicleBooking`,
    () =>
      authorizedFetch(addLease, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          userInfo: {
            phone: "9967252326",
            firstName: "Vishal",
            lastName: "Thakur",
          },
          type: type,
          startTime: `${moment(startTime).toISOString()}`,
          endTime: `${moment(endTime).toISOString()}`,
          amount: amount,
          priceInfo: "6268eeb91a6aad00082be27e",
          stage: "TEST",
          remarks: ".",
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Lease Added");
        if (leaseData) {
          console.log(leaseData);
        }
        setPaymentDialog({
          open: true,
          data: "",
        });
      },
      onError: () => {
        snackbar.error("Error adding lease");
      },
    }
  );

  useEffect(() => {
    if (leaseData) {
      console.log(leaseData);
    }
  }, [leaseData]);

  function handleVerification() {
    mutate();
  }

  useEffect(() => {
    if (userData && userData?.msg === "User details") {
      setVerifiedUser({
        firstName: userData?.data?.firstName,
        lastName: userData?.data?.lastName,
        phone: userData?.data?.phone,
        email: userData?.data?.email,
        status: 200,
      });
    }
    if (userData && userData?.msg === "User not found") {
      setVerifiedUser({
        firstName: "",
        lastName: "",
        phone: "",
        email: "",
        status: 404,
      });
    }
  }, [userData]);

  useEffect(() => {
    if (!open) {
      setVerifiedUser({
        firstName: "",
        lastName: "",
        phone: "",
        email: "",
        status: 0,
      });
      setVerifyPhone("");
    }
  }, [open]);

  const handleSave = () => {
    setLoader(true);
    leaseMutation();
    handleClose();
  };

  function handleNext() {
    if (step === steps.length - 1) {
      handleSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  const getAmount = `${LEASE_URL}/company/booking/amount`;

  const {
    data: amountData,
    mutate: amountMutation,
    // isLoading: amountLoading,
  } = useMutation(
    `addVehicleBooking`,
    () =>
      authorizedFetch(getAmount, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          priceInfoId: "6268eeb91a6aad00082be27e",
          startTime: moment(startTime).toISOString().toString(),
          endTime: moment(endTime).toISOString().toString(),
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Lease Added");
      },
      onError: () => {
        snackbar.error("Error adding lease");
      },
    }
  );

  const intializePay = `${LEASE_URL}/company/booking/${leaseData?.data?._id}/payment/init`;

  const {
    mutate: intializeMutation,
    // isLoading: amountLoading,
  } = useMutation(
    `addVehicleBooking`,
    () =>
      authorizedFetch(intializePay, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          amount: amount,
          amountPaid: 0,
          remark: "",
          stage: "TEST",
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Lease Added");
      },
      onError: () => {
        snackbar.error("Error adding lease");
      },
    }
  );

  useEffect(() => {
    if (leaseData) {
      console.log(leaseData);
      intializeMutation();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leaseData]);

  useEffect(() => {
    if (amountData) {
      setInput({ ...input, amount: amountData?.data?.amount });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [amountData]);

  const amountHandler = () => {
    amountMutation();
  };

  const [paymentDialog, setPaymentDialog] = useState({
    open: false,
    data: {},
  });

  console.log(amount);

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            maxWidth: 800,
            width: 1,
            "& .MuiInputBase-root": {
              fontSize: 14,
              borderRadius: 1,
              p: "3.5px 5px",
            },
          },
        }}
      >
        <DialogTitle
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "start",
          }}
        >
          <Box>
            Add Lease{" "}
            {/* <span
              style={{ fontSize: "14px", color: "#00000060", fontWeight: 800 }}
            >
              : Create Booking
            </span> */}
          </Box>
          <IconButton
            children={<HighlightOff />}
            color="inherit"
            onClick={handleClose}
            sx={{ transform: "translate(8px, -8px)" }}
          />
        </DialogTitle>
        <DialogContent sx={{ pb: "16px !important" }}>
          <Stepper
            sx={{ my: 4, mx: "auto", maxWidth: 534 }}
            activeStep={step}
            nonLinear
            alternativeLabel
          >
            {steps.map((label, i) => (
              <Step key={i}>
                <StepButton onClick={() => setStep(i)}>{label}</StepButton>
              </Step>
            ))}
          </Stepper>
          {step === 0 && (
            <Box
              sx={{
                maxWidth: { xs: 280, sm: 560 },
                mx: "auto",
                display: "grid",
                gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gap: 3,
                mt: 2,
              }}
            >
              <Box
                sx={{
                  gridColumn: { sm: "span 2" },
                }}
              >
                <Typography className="label">Verify User</Typography>
                <Box display="flex" gap={2}>
                  <TextField
                    type="number"
                    fullWidth
                    size="small"
                    value={verifyPhone ? verifyPhone : "Phone Number"}
                    placeholder="Phone Number"
                    onInput={(e: any) => {
                      e.target.value = Math.max(0, parseInt(e.target.value))
                        .toString()
                        .slice(0, 10);
                    }}
                    onChange={(e: any) => {
                      setVerifyPhone(e.target.value);
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          +91
                        </InputAdornment>
                      ),
                    }}
                  />
                  <Button
                    variant="contained"
                    sx={{ width: 200 }}
                    onClick={handleVerification}
                  >
                    Verify
                  </Button>
                </Box>
              </Box>
              {userLoading ? (
                <Box
                  sx={{
                    gridColumn: { sm: "span 2" },
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <CircularProgress />
                </Box>
              ) : status === 200 ? (
                <>
                  <Box sx={{ gridColumn: "span 2", mt: 1, mb: -2 }}>
                    <Typography className="label">User Info</Typography>
                  </Box>
                  <Box>
                    <Typography className="label" sx={{ fontSize: 14 }}>
                      First Name
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      value={firstName}
                      placeholder="First Name"
                      disabled
                    />
                  </Box>

                  <Box>
                    <Typography className="label" sx={{ fontSize: 14 }}>
                      Last Name
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      value={lastName}
                      placeholder="Last Name"
                      disabled
                    />
                  </Box>
                  <Box>
                    <Typography className="label" sx={{ fontSize: 14 }}>
                      Phone Number
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      value={phone}
                      placeholder="Phone Number"
                      disabled
                    />
                  </Box>
                  <Box>
                    <Typography className="label" sx={{ fontSize: 14 }}>
                      Email
                    </Typography>
                    <TextField
                      fullWidth
                      size="small"
                      value={email}
                      placeholder="Email"
                      disabled
                    />
                  </Box>
                </>
              ) : status === 404 ? (
                <Box
                  sx={{
                    gridColumn: "span 2",
                    mt: 2,
                    mb: -2,
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  <Typography className="label" sx={{ fontSize: 14, mt: -2 }}>
                    User Not Found. Try Again.
                  </Typography>
                </Box>
              ) : (
                ""
              )}
            </Box>
          )}
          {step === 1 && (
            <Box
              sx={{
                maxWidth: { xs: 280, sm: 560 },
                mx: "auto",
                display: "grid",
                gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                gap: 3,
                mt: 2,
              }}
            >
              <Box
              // sx={{
              //   gridColumn: { sm: "span 2" },
              // }}
              >
                <Typography className="label">Vehicle</Typography>
                <Select
                  fullWidth
                  value={vehicle}
                  onChange={(e: any) => {
                    handleChange("vehicle", e.target.value);
                  }}
                  displayEmpty
                >
                  <MenuItem disabled value="">
                    <em>Select</em>
                  </MenuItem>
                  {vehicleList?.map((el: any) => (
                    <MenuItem key={el.id} value={el.vin}>
                      {el.vin}
                    </MenuItem>
                  ))}
                </Select>
              </Box>
              <Box
              // sx={{
              //   gridColumn: { sm: "span 2" },
              // }}
              >
                <Typography className="label">Type</Typography>
                <Select
                  fullWidth
                  value={type}
                  onChange={(e: any) => {
                    handleChange("type", e.target.value);
                  }}
                  displayEmpty
                >
                  <MenuItem disabled value="">
                    <em>Select</em>
                  </MenuItem>
                  {["SHORT_TERM", "LONG_TERM"].map((option, i) => (
                    <MenuItem key={i} value={option}>
                      {option}
                    </MenuItem>
                  ))}
                </Select>
              </Box>

              <Box>
                <Typography className="label">Start Time</Typography>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DateTimePicker
                    value={startTime}
                    onChange={handleStartTime}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        fullWidth
                        sx={{
                          "& .MuiIconButton-root": {
                            marginRight: 1,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
                <Typography fontSize={12} mt={1}>
                  * start and end time should not be the same
                </Typography>
              </Box>
              <Box>
                <Typography className="label">End Time</Typography>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DateTimePicker
                    value={endTime}
                    onChange={handleEndTime}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        fullWidth
                        sx={{
                          "& .MuiIconButton-root": {
                            marginRight: 1,
                          },
                        }}
                      />
                    )}
                  />
                </LocalizationProvider>
              </Box>
              {/* <Box>
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      onChange={() => {
                        setStartImmediately(!startImmediately);
                      }}
                    />
                  }
                  checked={startImmediately}
                  label="Start Immediately"
                />
              </FormGroup>
            </Box> */}
              {/* {startImmediately && (
              <>
                <Box gridColumn={{ sm: "span 2" }}>
                  <RadioGroup
                    row
                    defaultValue="preset"
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    sx={{
                      mt: -2,
                      mb: -1,
                      "& .MuiTypography-root": {
                        fontSize: 16,
                        fontWeight: 500,
                      },
                    }}
                    onChange={handlePricingChange}
                  >
                    <FormControlLabel
                      value="preset"
                      control={<Radio checked={pricingValue === "preset"} />}
                      label="Preset Pricing"
                    />
                    <FormControlLabel
                      value="new"
                      control={
                        <Radio
                          checked={pricingValue === "new"}
                          sx={{ ml: 5 }}
                        />
                      }
                      label="Create New Pricing"
                    />
                  </RadioGroup>
                </Box>
                {pricingValue === "preset" ? (
                  <Box gridColumn={{ sm: "span 2" }}>
                    <Select
                      fullWidth
                      value={pricingType.name ? pricingType : ""}
                      onChange={(e: any) => {
                        handleChange("pricingType", e.target.value);
                      }}
                      displayEmpty
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>
                      {pricingList?.map((el: any) => (
                        <MenuItem key={el.id} value={el}>
                          {el.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </Box>
                ) : (
                  <>
                    <Box>
                      <Typography className="label">Pricing Name</Typography>
                      <TextField
                        fullWidth
                        size="small"
                        value={pricingName}
                        placeholder="Pricing Name"
                        onChange={(e) => {
                          handleChange("pricingName", e.target.value);
                        }}
                      />
                    </Box>
                    <Box>
                      <Typography className="label">Pricing Unit</Typography>
                      <Select
                        fullWidth
                        value={pricingUnit}
                        onChange={(e: any) => {
                          handleChange("pricingUnit", e.target.value);
                        }}
                        displayEmpty
                      >
                        <MenuItem disabled value="">
                          <em>Select</em>
                        </MenuItem>
                        {["Hours", "Days", "Weeks", "Months"].map(
                          (option, i) => (
                            <MenuItem key={i} value={option}>
                              {option}
                            </MenuItem>
                          )
                        )}
                      </Select>
                    </Box>
                    <Box>
                      <Typography className="label">Base Amount</Typography>
                      <TextField
                        type="number"
                        fullWidth
                        size="small"
                        value={baseAmount}
                        placeholder="Base Amount"
                        onChange={(e) => {
                          handleChange("baseAmount", e.target.value);
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start" sx={{ ml: 1 }}>
                              ₹
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>
                    <Box>
                      <Typography className="label">Cost Per Unit</Typography>
                      <TextField
                        type="number"
                        fullWidth
                        size="small"
                        value={costPerUnit}
                        placeholder="Cost Per Unit"
                        onChange={(e) => {
                          handleChange("costPerUnit", e.target.value);
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start" sx={{ ml: 1 }}>
                              ₹
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>
                    <Box gridColumn={{ sm: "span 2" }}>
                      <Typography className="label">Payment Account</Typography>
                      <Select
                        fullWidth
                        value={paymentAccount}
                        onChange={(e: any) => {
                          handleChange("paymentAccount", e.target.value);
                        }}
                        displayEmpty
                      >
                        <MenuItem disabled value="">
                          <em>Select</em>
                        </MenuItem>
                        {["REVOS ICICI Account"].map((option, i) => (
                          <MenuItem key={i} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </Box>
                  </>
                )}
              </>
            )} */}
              <Box gridColumn={{ sm: "span 2" }}>
                <Typography className="label">Pricing</Typography>
                <Select
                  fullWidth
                  value={pricingType.name ? pricingType : ""}
                  onChange={(e: any) => {
                    handleChange("pricingType", e.target.value);
                  }}
                  displayEmpty
                >
                  <MenuItem disabled value="">
                    <em>Select</em>
                  </MenuItem>
                  {pricingList?.map((el: any) => (
                    <MenuItem key={el.id} value={el}>
                      {el.name}
                    </MenuItem>
                  ))}
                </Select>
              </Box>
              <Box
                sx={{
                  gridColumn: { sm: "span 2", display: "flex", gap: 5 },
                }}
              >
                <Box sx={{ width: "70%" }}>
                  <Typography className="label">Amount</Typography>
                  <TextField
                    fullWidth
                    disabled
                    size="small"
                    value={amount}
                    placeholder="Amount"
                    onChange={(e) => {
                      handleChange("pricingName", e.target.value);
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>

                <Box sx={{ width: "30%", mt: "auto", mb: 0 }}>
                  <Button
                    size="large"
                    sx={{ minWidth: 1, mt: "auto", minHeight: 45 }}
                    variant="outlined"
                    onClick={amountHandler}
                  >
                    Add Amount
                  </Button>
                </Box>
              </Box>
            </Box>
          )}

          {step === 2 && (
            <Box
              sx={{
                maxWidth: 560,
                mx: "auto",
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      bgcolor: (theme) => theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& span": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 3,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  {[
                    { header: "User Info", onEdit: () => setStep(1) },
                    { label: "First Name", value: firstName, required: true },
                    { label: "Last Name", value: lastName, required: true },
                    { label: "Phone Number", value: phone, required: true },
                    { label: "Email", value: email, required: true },
                    { header: "Lease Info", onEdit: () => setStep(0) },
                    { label: "Vehicle", value: vehicle, required: true },
                    { label: "Type", value: type, required: true },
                    {
                      label: "Start Time",
                      value: moment(startTime).format("MMM DD, hh:mm A"),
                      required: true,
                    },
                    {
                      label: "End Time",
                      value: moment(endTime).format("MMM DD, hh:mm A"),
                      required: true,
                    },
                    ...onStartImmediately,
                  ].map(
                    ({ header, onEdit, label, value, required }, i, arr) => {
                      const isFirst = arr[i - 1]?.header;
                      const isLast = !arr[i + 1] || arr[i + 1].header;

                      return (
                        <tr
                          key={i}
                          className={
                            header
                              ? "header"
                              : `${isFirst ? "first" : ""} ${
                                  isLast ? "last" : ""
                                }`
                          }
                        >
                          {header ? (
                            <td colSpan={2}>
                              <span>{header}</span>
                              <IconButton
                                sx={{ ml: 1.5 }}
                                children={<EditOutlined />}
                                color="primary"
                                size="small"
                                onClick={onEdit}
                              />
                            </td>
                          ) : (
                            <>
                              <td>{label}</td>
                              <td className="bold">
                                {value ||
                                  (required && (
                                    <Box display="flex" alignItems="center">
                                      <ErrorOutline
                                        fontSize="small"
                                        color="error"
                                        style={{ marginRight: 8 }}
                                      />
                                      Required
                                    </Box>
                                  ))}
                              </td>
                            </>
                          )}
                        </tr>
                      );
                    }
                  )}
                </tbody>
              </table>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          {step !== 0 && (
            <Button variant="outlined" onClick={handleBack}>
              Back
            </Button>
          )}
          {step === 0 && (
            <Button variant="outlined" onClick={handleClose}>
              Cancel
            </Button>
          )}
          <Button
            onClick={handleNext}
            variant={
              isComplete(step) || step === steps.length - 1
                ? "contained"
                : "outlined"
            }
            disableElevation
            // disabled={step === steps.length - 1 && disabled}
          >
            {step === steps.length - 1
              ? "Save"
              : isComplete(step)
              ? "Next"
              : "Skip"}
          </Button>
        </DialogActions>
      </Dialog>
      <PaymentDialog
        open={paymentDialog.open}
        handleClose={() => {
          setPaymentDialog({ ...paymentDialog, open: false });
        }}
        data={paymentDialog.data}
      />
    </>
  );
};

const PaymentDialog = ({ open, data, handleClose }: any) => {
  const [isRunning, setIsRunning] = useState(true);

  // const getStatus = `https://payments.dev.revos.in/v1/payments/orders/cashfree/orderstatus`;

  // const {
  //   // data: statusData,
  //   // mutate: statusMutation,
  //   // isLoading: amountLoading,
  // } = useMutation(
  //   `getPaymentStatus`,
  //   () =>
  //     authorizedFetch(getStatus, {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: {
  //         orderId: "u8xhVIWqXaYtmgoWmhPCa",
  //       },
  //     }),
  //   {
  //     onSuccess: () => {
  //       setLoader(false);
  //     },
  //     onError: () => {},
  //   }
  // );

  useEffect(() => {
    const status = setInterval(() => {
      // statusMutation();
    }, 1000);
    return () => {
      clearInterval(status);
    };
  }, []);

  // const confirm = `${LEASE_URL}/company/booking/:bookingID/payment/confirm`;

  // const {
  //   // data: confirmData,
  //   // mutate: confirmMutation,
  //   // isLoading: amountLoading,
  // } = useMutation(
  //   `addVehicleBooking`,
  //   () =>
  //     authorizedFetch(confirm, {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: {},
  //     }),
  //   {
  //     onSuccess: () => {
  //       setLoader(false);
  //       snackbar.success("Payment Confirmed");
  //     },
  //     onError: () => {
  //       snackbar.error("Payment Failed");
  //     },
  //   }
  // );

  // const fail = `${LEASE_URL}/company/booking/:bookingID/payment/fail`;

  // const {
  //   // data: failData,
  //   // mutate: failMutation,
  //   // isLoading: amountLoading,
  // } = useMutation(
  //   `addVehicleBooking`,
  //   () =>
  //     authorizedFetch(fail, {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: {},
  //     }),
  //   {
  //     onSuccess: () => {
  //       setLoader(false);
  //       snackbar.error("Payment Failed");
  //     },
  //     onError: () => {
  //       snackbar.error("Payment Failed");
  //     },
  //   }
  // );

  // useEffect(() => {
  //   if (statusData) {
  //     confirmMutation();
  //   } else {
  //     failMutation();
  //   }
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [statusData]);

  const timerProps = {
    isPlaying: true,
    size: 200,
    strokeWidth: 3,
  };

  const children = ({ remainingTime }: any) => {
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;

    if (remainingTime === 0) {
      setIsRunning(false);
    }

    return (
      <Typography fontSize={32} color="#00000090">{`${minutes}:${
        seconds < 10 ? `0${seconds}` : seconds
      }`}</Typography>
    );
  };

  const startTime = Date.now() / 1000;
  const endTime = startTime + 300;

  const remainingTime = endTime - startTime;

  return (
    <Dialog
      open={open}
      PaperProps={{
        sx: {
          maxWidth: 700,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        <Box>
          {/* Add Lease{" "} */}
          {/* <span
            style={{ fontSize: "14px", color: "#00000060", fontWeight: 800 }}
          >
            : Payment
          </span> */}
        </Box>

        {/* <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        /> */}
      </DialogTitle>
      <DialogContent
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          mb: 5,
        }}
      >
        <Typography
          variant="caption"
          component="div"
          fontSize={14}
          textAlign="center"
          sx={{ mb: 5 }}
        >
          {isRunning ? (
            <>
              A Payment link has been sent to the <strong>Email Id</strong> &{" "}
              <strong>Phone Number</strong> of the User.
              <br />
              Please complete the transaction before the timer ends.
            </>
          ) : (
            <>Payment window is closed. Please create another Booking.</>
          )}
        </Typography>
        <CountdownCircleTimer
          {...timerProps}
          children={children}
          colors="#3CB99E"
          duration={300}
          initialRemainingTime={300}
          onComplete={(totalElapsedTime) => ({
            shouldRepeat: remainingTime - totalElapsedTime > 0,
          })}
        ></CountdownCircleTimer>
        <Button sx={{ mt: 5 }} variant="outlined" size="large">
          Cancel Booking
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default AddDialog;
