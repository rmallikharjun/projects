import { Box } from "@mui/system";
import Total from "./Total";
import Leases from "./Leases";
import Earnings from "./Earnings";
import Distance from "./Distance";

const Dashboard = () => {
  return (
    <Box
      sx={{
        width: 1,
        gap: { xs: 2, md: 3 },
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          lg: "repeat(6, 1fr)",
          xl: "repeat(6, 1fr)",
        },
        "& > .MuiPaper-root": {
          borderRadius: 2,
          boxShadow: "0 0 4px #1C295A14",
        },
        mt: 2,
      }}
    >
      <Total />
      <Leases />
      <Earnings />
      <Distance />
    </Box>
  );
};

export default Dashboard;
