import { useState } from "react";
import { Box, Button } from "@mui/material";
import { Add } from "@mui/icons-material";
import Breadcrumbs from "../../../components/Breadcrumbs";
import ViewSelector, { View } from "components/ViewSelector";
import Dashboard from "./Dashboard";
import List from "./List";

import { getPermissions } from "utils";
import AddDialog from "./AddDialog";

// import SearchBox from "components/Search";

const Vehicles = () => {
  const { canWrite } = getPermissions("rental:leases");

  const [view, setView] = useState<View>("grid");
  const [addDialog, setAddDialog] = useState(false);

  return (
    <>
      <Box
        width={1}
        mb={{ xs: view === "grid" ? 1 : 2, md: view === "grid" ? 1 : 3 }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />

        <ViewSelector
          view={view}
          setView={setView}
          extras={
            canWrite || view === "list"
              ? () => {
                  return (
                    <>
                      {canWrite && (
                        <Button
                          sx={{ mr: { xs: 1, md: 2 } }}
                          onClick={() => setAddDialog(true)}
                        >
                          <Add />
                        </Button>
                      )}
                    </>
                  );
                }
              : undefined
          }
        />
        {/* )} */}
      </Box>
      {view === "grid" ? (
        <Box
          sx={{
            width: 1,
          }}
        >
          <Dashboard />
        </Box>
      ) : (
        <List />
      )}
      <AddDialog
        open={addDialog}
        handleClose={() => {
          setAddDialog(false);
        }}
      />
    </>
  );
};

export default Vehicles;
