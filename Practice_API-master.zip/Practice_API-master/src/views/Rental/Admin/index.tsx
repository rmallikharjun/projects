import { Box } from "@mui/material";

const Admin = () => {
  return <Box>Admin</Box>;
};

export default Admin;
