import React, { useState } from "react";
import { useSelector } from "react-redux";
import {
  AttachMoney,
  EventAvailableOutlined,
  HighlightOff,
  Timer,
} from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Avatar,
  Tabs,
  Tab,
  // InputAdornment,
  // TextField,
  // Tab,
  // Tabs,
} from "@mui/material";
import {
  authorizedFetch,
  drawer,
  getDarkModePreference,
  GlobalState,
  // setLoader,
  // snackbar,
} from "utils";
import moment from "moment";
import Table from "components/Table";
import { LEASE_URL } from "utils/constants";
import { useQuery } from "react-query";

// import Table from "components/Table";

const DrawerContent = ({ key, user }: any) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [tab, setTab] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(4);
  // const [refundDialog, setRefundDialog] = useState({
  //   open: false,
  //   user: "",
  //   data: "",
  // });

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  const userURL = `${LEASE_URL}/company/users/${
    user.id
  }/bookings?first=${pageSize}&skip=${pageSize * (page - 1)}`;

  const { isLoading: userLoading, data: userData } = useQuery(
    ["getUserBookings", page, pageSize],
    () => authorizedFetch(userURL)
  );

  const userEarningsURL = `${LEASE_URL}/company/users/${user.id}/earnings`;

  const { data: userEarningsData } = useQuery("getUserEarnings", () =>
    authorizedFetch(userEarningsURL)
  );

  const userDistanceURL = `${LEASE_URL}/company/users/${user.id}/duration`;

  const { data: userDistanceData } = useQuery("getUserDistance", () =>
    authorizedFetch(userDistanceURL)
  );

  console.log(userDistanceData);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {user.firstName} {user.lastName}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            {/* <IconButton
              children={<DeleteOutline />}
              color="inherit"
              size="small"
              onClick={() => setDeleteDialog(true)}
            /> */}
            {/* <Button
              variant="contained"
              size="small"
              sx={{ mr: 1 }}
              onClick={() =>
                SetRefundDialog({
                  open: true,
                  user: user,
                  data: "",
                })
              }
            >
              Refund
            </Button> */}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box px={2.5} pt={2}>
          <Box
            mb={1.5}
            display="flex"
            justifyContent="space-between"
            alignItems="center"
          >
            <Typography variant="h6">Stats</Typography>
          </Box>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 1,
              "& > div": {
                width: 1,
                p: 1.5,
                display: "flex",
                border: 1,
                borderRadius: "3px",
                borderColor: (theme) => theme.customColors.border,
                "& .MuiAvatar-root": {
                  mr: 1,
                },
                "& .info": {
                  display: "flex",
                  flexDirection: "column",
                  "& .label": {
                    fontSize: 17,
                    fontWeight: 600,
                    color: "text.primary",
                    lineHeight: "1.15em",
                  },
                  "& .value": {
                    fontSize: 12,
                    color: "text.secondary",
                  },
                },
              },
            }}
          >
            <Box>
              <Avatar variant="icon">
                <Timer />
              </Avatar>
              <Box className="info">
                <span className="label">
                  {userDistanceData?.data?.total_duration > 1000
                    ? userDistanceData?.data?.total_duration.toFixed(0) / 1000 +
                      " Kms"
                    : userDistanceData?.data?.total_duration + " meters"}
                </span>
                <span className="value">Duration</span>
              </Box>
            </Box>
            <Box>
              <Avatar variant="icon">
                <AttachMoney />
              </Avatar>
              <Box className="info">
                <span className="label">
                  {"₹ " + userEarningsData?.data?.total_earnings || 0}
                </span>
                <span className="value">Earnings</span>
              </Box>
            </Box>
            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Avatar variant="icon">
                <EventAvailableOutlined />
              </Avatar>
              <Box className="info">
                <span className="label">{userData?.data?.count}</span>
                <span className="value">Total Bookings</span>
              </Box>
            </Box>
          </Box>
          <Box mt={3.75} mb={2}>
            <Tabs
              className="dense"
              value={tab}
              onChange={(e, tab): any => setTab(tab)}
              sx={{ width: 150, mb: 2 }}
            >
              <Tab label="Recent Bookings" />
            </Tabs>
            {tab === 0 ? (
              <Table
                px={0}
                rowCount={userData?.data?.count}
                serverSidePagination={true}
                activePage={page}
                activePageSize={pageSize}
                onPageChange={(value: any) => setPage(value)}
                onPageSizeChange={(value: any) => setPageSize(value)}
                height={310}
                rowsPerPage={4}
                small
                smallPagination
                loading={userLoading}
                rows={userData?.data?.bookings || []}
                columns={[
                  {
                    key: "vin",
                    label: "Vin",
                  },
                  {
                    key: "startTime",
                    label: "Start",
                    format: (value: any) =>
                      moment(value).format("MMM DD, HH:mm"),
                  },
                  {
                    key: "endTime",
                    label: "end",
                    format: (value: any) =>
                      moment(value).format("MMM DD, HH:mm"),
                  },
                  {
                    key: "bookingDuration",
                    label: "Duration",
                    Render: (row) => {
                      return (
                        <Box>
                          {row?.bookingDuration?.hours
                            ? row?.bookingDuration?.hours + "h"
                            : ""}{" "}
                          {row?.bookingDuration?.minutes
                            ? row?.bookingDuration?.minutes + "m"
                            : "-"}{" "}
                          {row?.bookingDuration?.seconds
                            ? row?.bookingDuration?.seconds + "s"
                            : ""}
                        </Box>
                      );
                    },
                  },
                  {
                    key: "bookingAmount",
                    label: "Amount",
                    // eslint-disable-next-line
                    format: (value) => (value ? "₹" + " " + value : "₹ 0"),
                  },
                  // {
                  //   key: "actions",
                  //   label: "Actions",
                  //   Render: (row) => (
                  //     <Button
                  //       variant="action"
                  //       size="small"
                  //       onClick={() => {
                  //         setRefundDialog({
                  //           open: true,
                  //           data: row,
                  //           user: user,
                  //         });
                  //       }}
                  //     >
                  //       Refund
                  //     </Button>
                  //   ),
                  // },
                ]}
              />
            ) : (
              ""
            )}
          </Box>
        </Box>
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
      {/* <RefundDialog
        open={refundDialog.open}
        data={refundDialog.data}
        handleClose={() => {
          setRefundDialog({ ...refundDialog, open: false });
        }}
        refetchTransactions={refetchTransactions}
        user={refundDialog.user}
      /> */}
    </>
  );
};

// interface Props {
//   open: boolean;
//   handleClose: () => void;
//   data: any;
//   user: any;
//   refetchTransactions: () => void;
// }

// const RefundDialog: React.FC<Props> = ({
//   open,
//   handleClose,
//   data,
//   refetchTransactions,
//   user,
// }) => {
//   const [input, setInput] = useState({
//     amount: "",
//     remarks: "",
//   });

//   console.log(data);

//   useEffect(() => {
//     if (open && data) {
//       setInput({
//         ...input,
//         remarks: `Refund for BookingId: ${data._id}`,
//       });
//     }
//     if (!open) {
//       setInput({
//         amount: "",
//         remarks: "",
//       });
//     }
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [open, data]);

//   const { amount, remarks } = input;

//   const mutation = useMutation(
//     ["initiateRefund", amount],
//     () =>
//       authorizedFetch(
//         `https://payments.dev.revos.in/v1/payments/refunds/cashfree/initiaterefund`,
//         {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: {
//             bookingId: data._id,
//             orderId: data._id,
//             amount: amount,
//             remark: remarks,
//           },
//         }
//       ),
//     {
//       onSuccess: () => {
//         snackbar.success(`Refund Successful`);
//         refetchTransactions();
//         setLoader(false);
//       },
//       onError: () => {
//         snackbar.error(`Error sending refund`);
//       },
//     }
//   );

//   function onSend() {
//     setLoader(true);
//     mutation.mutate();
//     handleClose();
//   }

//   return (
//     <Dialog open={open} onClose={handleClose}>
//       <DialogTitle>
//         <Box
//           sx={{
//             display: "flex",
//             justifyContent: "space-between",
//             alignItems: "start",
//           }}
//         >
//           Refund Money
//           <IconButton
//             children={<HighlightOff />}
//             color="inherit"
//             onClick={handleClose}
//             sx={{ transform: "translate(8px, -8px)" }}
//           />
//         </Box>
//         <Typography sx={{ fontSize: 13, mt: -1.5 }}>
//           {user.firstName ? user?.firstName + " " + user?.lastName : "-"}
//         </Typography>
//       </DialogTitle>

//       <DialogContent className="py-1">
//         <Box mt={2}>
//           <Typography className="label">Amount</Typography>
//           <TextField
//             fullWidth
//             size="small"
//             placeholder="0"
//             value={amount}
//             onChange={(e: any) => {
//               setInput({ ...input, amount: e.target.value });
//             }}
//             InputProps={{
//               startAdornment: (
//                 <InputAdornment position="start">₹</InputAdornment>
//               ),
//             }}
//           />
//         </Box>

//         <Box mt={4}>
//           <Typography className="label">Remarks</Typography>
//           <TextField
//             fullWidth
//             id="outlined-multiline-static"
//             multiline
//             rows={5}
//             placeholder="Type a remark..."
//             value={remarks}
//             onChange={(e: any) => {
//               setInput({ ...input, remarks: e.target.value });
//             }}
//           />
//         </Box>
//       </DialogContent>
//       <DialogActions>
//         <Button variant="outlined" onClick={handleClose}>
//           Cancel
//         </Button>
//         <Button
//           disabled={input.remarks.length === 0 || input.amount.length === 0}
//           variant="contained"
//           onClick={onSend}
//         >
//           Refund
//         </Button>
//       </DialogActions>
//     </Dialog>
//   );
// };

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to DELETE:{" "}
        <span style={{ fontWeight: "bold" }}>Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DrawerContent;
