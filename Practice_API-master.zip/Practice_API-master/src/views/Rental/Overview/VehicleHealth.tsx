import { Box, Paper, Tooltip, Typography, useTheme } from "@mui/material";
import { Doughnut } from "react-chartjs-2";
import CircularProgress from "@mui/material/CircularProgress";
import { InfoOutlined } from "@mui/icons-material";
// import { TRIGGER_URL } from "utils/constants";
import { useQuery } from "react-query";
import { authorizedFetch, GlobalState } from "utils";
import { useSelector } from "react-redux";

interface Props {}

const VehicleHealth: React.FC<Props> = () => {
  const theme = useTheme();

  const { company } = useSelector((state: GlobalState) => state.global);

  const healthUrl = `https://trigger.revos.in/health?type=Company&id=${company?.id}&token=${company?.token}`;

  const { isLoading: healthLoading, data: healthData } = useQuery(
    "getHealthStats",
    () => authorizedFetch(healthUrl)
  );

  const circularProgress = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 180,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" />
    </Box>
  );

  return (
    <Paper
      sx={{
        minWidth: 0,
        height: 1,
        p: { xs: 2, md: 3 },
        gridColumn: { lg: "span 3", md: "span 8" },
      }}
    >
      <Typography variant="h6" mb={1}>
        Vehicle Health
      </Typography>
      {healthLoading ? (
        circularProgress
      ) : (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            justifyItems: "center",
            mt: 5,
          }}
        >
          <Box
            width={{ xs: 160, sm: 190 }}
            alignSelf="center"
            position="relative"
          >
            <Doughnut
              style={{ position: "relative", zIndex: 2 }}
              data={(canvas) => {
                return {
                  datasets: [
                    {
                      data: [
                        healthData?.result?.healthy || 0,
                        healthData?.result?.inactive || 0,
                      ],
                      backgroundColor: [
                        theme.customColors.greenSecondary,
                        theme.customColors.blueSecondary,
                      ],
                      spacing: 1,
                      hoverOffset: 0,
                      borderWidth: 0,
                      borderRadius: 50,
                      cutout: "80%",
                    },
                  ],
                  labels: ["Active", "Inactive"],
                };
              }}
              options={{
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    displayColors: false,
                  },
                },
              }}
            />
            <Box
              sx={{
                zIndex: 1,
                position: "absolute",
                top: { xs: 55, sm: 70 },
                right: 0,
                left: 0,
                mx: "auto",
                pointerEvents: "none",
                textAlign: "center",
              }}
            >
              <Typography
                fontSize={{ xs: 24, sm: 28 }}
                fontWeight={700}
                lineHeight="1.2em"
              >
                {(healthData?.result?.healthy || 0) +
                  (healthData?.result?.inactive || 0)}
              </Typography>
              <Typography
                sx={{
                  textTransform: "uppercase",
                  fontSize: { xs: 12, sm: 14 },
                  fontFamily: "Poppins !important",
                }}
              >
                Total Vehicles
              </Typography>
            </Box>
          </Box>
          <Box ml={2}>
            {[
              {
                label: "Healthy",
                value: healthData?.result?.healthy,
                color: theme.customColors.text.greenSecondary,
                title: "Healthy Vehicles",
              },

              {
                label: "Inactive",
                value: healthData?.result?.inactive,
                color: theme.customColors.text.blueSecondary,
                title: "Inactive Vehicles",
              },
            ].map(({ label, value, color, title }, i) => (
              <Box
                key={i}
                sx={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  // width: 1,
                  pl: { xs: 1.75, sm: 2.75 },
                  mb: 2.5,
                  "& .value": {
                    mb: { xs: 0.5, sm: 1 },
                    lineHeight: "1.2em",
                    fontSize: { xs: 16, sm: 20 },
                    fontWeight: 700,
                    color: color,
                    "&:before": {
                      content: '""',
                      position: "absolute",
                      top: { xs: 3, sm: 4 },
                      left: 0,
                      width: { xs: 10, sm: 14 },
                      height: { xs: 10, sm: 14 },
                      bgcolor: color,
                      borderRadius: "2px",
                    },
                  },
                  "& .title": {
                    display: "flex",
                    alignItems: "center",
                    color: "text.secondary",
                    fontSize: 14,
                    lineHeight: "0.9em",
                  },
                }}
              >
                <span className="value">{value}</span>
                <span className="title">
                  {label}
                  <Tooltip title={title}>
                    <InfoOutlined
                      color="action"
                      fontSize="inherit"
                      sx={{ ml: 0.5, cursor: "pointer" }}
                    />
                  </Tooltip>
                </span>
              </Box>
            ))}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default VehicleHealth;
