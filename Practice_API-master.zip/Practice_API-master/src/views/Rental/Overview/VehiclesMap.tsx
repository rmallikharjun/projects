import { Box, Paper, Typography, useTheme } from "@mui/material";

import Map from "components/Map";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { LEASE_URL } from "utils/constants";

interface Props {
  chargersStats: any;
}

const VehiclesMap: React.FC<Props> = () => {
  const theme = useTheme();

  const statsUrl = `${LEASE_URL}/company/vehicles/stats`;

  const { data: statsData } = useQuery("getVehicleStats", () =>
    authorizedFetch(statsUrl)
  );

  const [mapList, setMapList] = useState<any>();

  const mapUrl = `${LEASE_URL}/company/vehicles/map`;

  const { data: mapsData } = useQuery("getVehicleMap", () =>
    authorizedFetch(mapUrl)
  );

  useEffect(() => {
    if (mapsData && mapsData?.data?.constructor === Array) {
      let arr: any = [];
      // eslint-disable-next-line
      mapsData?.data?.map((el: any) => {
        if (el.rentalStatus === "AVAILABLE" || el.rentalStatus === "BOOKED") {
          arr.push({
            vehicle: { vehicleStatus: el.rentalStatus },
            id: el.vin,
            station: {
              location: {
                latitude: el.location.coordinates[1],
                longitude: el.location.coordinates[0],
              },
            },
          });
        }
      });
      setMapList(arr);
    }
  }, [mapsData]);

  console.log(statsData);

  return (
    <Paper
      sx={{
        zIndex: 1,
        position: "relative",
        height: { xs: 400, md: 350 },
        gridColumn: {
          md: "span 8",
          lg: "span 5",
        },
        display: "grid",
        gridTemplateColumns: { xs: "1fr", md: "1fr 204px" },
        gridTemplateRows: { xs: "270px 1fr", md: "auto" },
        bgcolor: "divider",
        overflow: "hidden",
        "& .gm-style-cc": {
          transform: "translateX(-9px)",
        },
      }}
    >
      <Map
        key={mapList}
        loading={false}
        type="points"
        dataArray={mapList || []}
      />
      <Paper
        sx={{
          boxShadow: "none",
          position: { md: "absolute" },
          top: { md: 0 },
          right: { md: 0 },
          width: { md: 230 },
          height: 1,
          transform: {
            xs: "translateY(-23px)",
            md: "none",
          },
          borderRadius: 2,
          p: 3,
        }}
      >
        <Typography variant="h6" mb={1.5}>
          Vehicles
        </Typography>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "auto auto auto",
              md: "1fr",
            },
          }}
        >
          <Box>
            <Typography
              fontSize={{ xs: "1.4rem", md: "1.7rem" }}
              fontWeight={700}
            >
              {typeof statsData?.data[0]?.count === "number"
                ? statsData?.data[0]?.count
                : "-"}
            </Typography>
            <Typography fontSize={14} color="text.secondary" mb={2}>
              TOTAL VEHICLES
            </Typography>
          </Box>
          {[
            {
              label: "Booked",
              value:
                typeof statsData?.data[1]?.count === "number"
                  ? statsData?.data[1]?.count
                  : "-",
              color: theme.customColors.text.green,
            },
            {
              label: "Available",
              value:
                typeof statsData?.data[2]?.count === "number"
                  ? statsData?.data[2]?.count
                  : "-",
              color: theme.customColors.text.blue,
            },
          ].map(({ label, value, color }, i) => (
            <Box
              key={i}
              sx={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                width: 1,
                pl: 2.75,
                mb: 1.25,
                "& .value": {
                  mb: -0.25,
                  fontSize: 20,
                  fontWeight: 700,
                  color: color,
                  "&:before": {
                    content: '""',
                    position: "absolute",
                    top: 7,
                    left: 0,
                    width: 14,
                    height: 14,
                    bgcolor: color,
                    borderRadius: "2px",
                  },
                },
                "& .title": {
                  color: "text.secondary",
                  fontSize: 14,
                },
              }}
            >
              <span className="value">{value}</span>
              <span className="title">{label}</span>
            </Box>
          ))}
        </Box>
      </Paper>
    </Paper>
  );
};

export default VehiclesMap;
