import { Paper, Typography, useMediaQuery, useTheme } from "@mui/material";
import Table from "components/Table";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { DATAFEED_URL } from "utils/constants";
import { GlobalState } from "utils";
import { useSelector } from "react-redux";
import moment from "moment";
import { useState } from "react";

const RecentTrips = () => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(4);

  const companyId = useSelector(
    (state: GlobalState) => state.global.company.id
  );

  const tripsURL = `${DATAFEED_URL}/analytics/alltrips?token=1234&id=${companyId}&first=${pageSize}&skip=${
    pageSize * (page - 1)
  }`;

  const { isLoading: tripsLoading, data: tripsData } = useQuery(
    ["getTrips", page, pageSize],
    () => authorizedFetch(tripsURL)
  );

  console.log(tripsData);

  return (
    <Paper
      sx={{
        minWidth: 0,
        height: 422,
        p: 0,
        gridColumn: { lg: "span 4", md: "span 8" },
      }}
    >
      <Typography
        variant="h6"
        mb={2.5}
        p={{ xs: 2, md: 3 }}
        pb={{ xs: 0, md: 0 }}
        mt="2px"
      >
        Recent Trips
      </Typography>
      <Table
        rowCount={tripsData?.tripCount}
        serverSidePagination={true}
        activePage={page}
        activePageSize={pageSize}
        onPageChange={(value) => setPage(value)}
        onPageSizeChange={(value) => setPageSize(value)}
        px={isMdUp ? 3 : 2}
        height={290}
        rowsPerPage={4}
        small
        smallPagination
        loading={tripsLoading}
        rows={tripsData?.trips || []}
        columns={[
          {
            key: "tripId",
            label: "Trip Id",
          },
          {
            key: "vin",
            label: "Vehicle Id",
          },
          {
            key: "startTime",
            label: "Start",
            format: (value) => moment(value).format("MMM DD, HH:mm"),
          },
          {
            key: "endTime",
            label: "end",
            format: (value) => moment(value).format("MMM DD, HH:mm"),
          },
        ]}
      />
    </Paper>
  );
};

export default RecentTrips;
