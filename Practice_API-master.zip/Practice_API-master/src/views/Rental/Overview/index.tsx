import { Box } from "@mui/material";

import Breadcrumbs from "components/Breadcrumbs";
import Insights from "./Insights";
import RecentTrips from "./RecentTrips";
import Total from "./Total";
import VehicleHealth from "./VehicleHealth";
import VehiclesMap from "./VehiclesMap";

const Overview = () => {
  const chargerStats: any = [];
  return (
    <>
      <Box
        sx={{
          width: 1,
          mb: { xs: 2, md: 3 },
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Breadcrumbs />
      </Box>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "1fr 1fr",
            lg: "repeat(8, 1fr)",
          },
          gap: { xs: 2, md: 3 },
          "& > .MuiPaper-root": {
            borderRadius: 2,
            boxShadow: "0 0 4px #1C295A14",
          },
          "& > .MuiPaper-root:nth-of-type(-n+2)": {
            boxShadow: "0 0 10px #1C295A14",
          },
        }}
      >
        <Total />
        <VehiclesMap chargersStats={chargerStats} />
        <VehicleHealth />
        <Insights />
        <RecentTrips />
      </Box>
    </>
  );
};

export default Overview;
