import { Box, Paper, Typography, Avatar, Skeleton } from "@mui/material";
import {
  AttachMoney,
  EventAvailableOutlined,
  PeopleOutlined,
  StraightenOutlined,
} from "@mui/icons-material";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { LEASE_URL } from "utils/constants";

interface Props {}

const Loading = () => (
  <Box>
    <Skeleton width={38} height={38} variant="circular" />
    <Typography variant="h5" className="value">
      <Skeleton height={20} width="30%" />
    </Typography>
    <Typography variant="body2" className="title">
      <Skeleton width="60%" />
    </Typography>
  </Box>
);

const Total: React.FC<Props> = () => {
  const bookingStats = `${LEASE_URL}/company/bookings/stats`;

  const { isLoading: statsLoading } = useQuery("getBookingsStats", () =>
    authorizedFetch(bookingStats)
  );

  const distanceStats = `${LEASE_URL}/company/bookings/distance/stats`;

  const { isLoading: distanceLoading, data: distanceData } = useQuery(
    "getDistanceStats",
    () => authorizedFetch(distanceStats)
  );

  const earningStats = `${LEASE_URL}/company/bookings/earnings/stats`;

  const { isLoading: earningsLoading, data: earningsData } = useQuery(
    "getEarningsStats",
    () => authorizedFetch(earningStats)
  );

  const userURL = `${LEASE_URL}/company/users`;

  const { isLoading: userLoading, data: userData } = useQuery("getUsers", () =>
    authorizedFetch(userURL)
  );

  const statsUrl = `${LEASE_URL}/company/vehicles/stats`;

  const { data: vehiclesData } = useQuery("getVehicleStats", () =>
    authorizedFetch(statsUrl)
  );

  return (
    <Paper
      sx={{
        height: "auto",
        p: 2,
        gridColumn: { md: "span 8", lg: "span 8" },
        display: "grid",
        gap: 2,
        overflowX: "auto",
        gridTemplateColumns: {
          xs: "repeat(2, minmax(max-content, 1fr))",
          lg: "repeat(4, minmax(max-content, 1fr))",
        },
        alignItems: "center",
        "& > div": {
          p: 2,
          border: 1,
          borderColor: (theme) => theme.customColors.border,
          borderRadius: "4px",
          display: "flex",
          alignItems: "center",
          height: "auto",

          "& .icon": {
            mr: 2,
            width: 48,
            height: 48,
            borderRadius: 50,
          },
          "& .value": {
            fontWeight: 700,
            fontSize: 24,
            color: "text.primary",
            lineHeight: "1em",
            marginBottom: 0.5,

            "& span": {
              fontWeight: 500,
              fontSize: 16,

              "&.bigger": {
                fontSize: 22,
                lineHeight: "1em",
              },
            },
          },
          "& .title": {
            fontSize: 15,
            lineHeight: "20px",
            color: "text.secondary",
          },
        },
      }}
    >
      {statsLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <EventAvailableOutlined />
          </Avatar>
          <Box>
            <Typography className="value">
              {Number(vehiclesData?.data[0]?.count).toLocaleString()}
            </Typography>
            <Typography className="title">Total Vehicles</Typography>
          </Box>
        </Box>
      )}
      {earningsLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <AttachMoney />
          </Avatar>
          <Box>
            <Typography className="value">
              <span className="bigger" style={{ marginRight: 5 }}>
                ₹
              </span>
              {Number(
                earningsData?.data?.total_earnings?.toFixed(0)
              )?.toLocaleString()}
            </Typography>
            <Typography className="title">Total Earnings</Typography>
          </Box>
        </Box>
      )}
      {userLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <PeopleOutlined />
          </Avatar>
          <Box>
            <Typography className="value">
              {userData?.data?.count
                ? Number(userData?.data?.count).toLocaleString()
                : 0}
            </Typography>
            <Typography className="title">Total Users</Typography>
          </Box>
        </Box>
      )}
      {distanceLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <StraightenOutlined />
          </Avatar>
          <Box>
            <Typography className="value">
              {Number(
                (distanceData?.data?.total_distance / 1000).toFixed(0)
              ).toLocaleString()}
              <span style={{ marginLeft: 5 }}>Kms</span>
            </Typography>
            <Typography className="title">Total Distance</Typography>
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default Total;
