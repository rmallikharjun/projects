import { Box, Paper, Tabs, Tab, Button } from "@mui/material";
import Table from "components/Table";
import moment from "moment";
import { authorizedFetch } from "utils";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { RETAIL_URL } from "utils/constants";
import { useQuery } from "react-query";
import { useState, useEffect } from "react";
import Search from "components/Search";

const UsersList = () => {
  const [tab, setTab] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const url = `${RETAIL_URL}/assembly/vehicle?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }`;

  const { isLoading, data: vehiclesList } = useQuery(
    ["ListCompomemt", page, pageSize],
    () => authorizedFetch(url)
  );

  useEffect(() => {
    console.log("list data is => ", vehiclesList);
  }, [vehiclesList]);

  const AssignedAs = () => {
    return tab === 0 ? (
      <Box sx={{ display: "flex", flexDirection: "row" }}>
        <Box sx={{ mt: 0.35, mr: 4 }}>Admin</Box>
        <Box sx={{ mr: 3 }}>
          <KeyboardArrowDownIcon fontSize="medium" />
        </Box>
      </Box>
    ) : (
      <Box sx={{ display: "flex", flexDirection: "row" }}>
        <Box sx={{ mt: 0.35 }}>Not Assigned</Box>
        <Box sx={{ mr: 1 }}>
          <KeyboardArrowDownIcon fontSize="medium" />
        </Box>
      </Box>
    );
  };
  const Reject = () => {
    return tab === 0 ? (
      <Button
        variant="text"
        sx={{
          color: "#0058FF",
        }}
      >
        Unassign
      </Button>
    ) : (
      <Button
        variant="text"
        sx={{
          color: "#0058FF",
        }}
      >
        Reject
      </Button>
    );
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <Box sx={{ fontSize: 18, fontWeight: "bold", mt: 2, mb: 3 }}>
          {tab === 0 ? "Approved Users" : "Pending Users"}
        </Box>
        <Search
          enableBorder
          sx={{
            width: 300,
            p: 1,
            pl: 1.5,
            mr: 1.5,
          }}
          handleSearch={() => {}}
        />
      </Box>

      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        ></Box>

        <Box width="fit-content" mb={2} ml={3} mt={-2}>
          <Tabs
            className="dense"
            value={tab}
            onChange={(e: any, tab) => setTab(tab)}
          >
            <Tab
              label="Approved"
              value="0"
              className="hasCount"
              sx={{
                "&:after": {
                  content: `"${"24"}"`,
                },
              }}
            />
            <Tab
              label="Pending"
              value="1"
              className="hasCount"
              sx={{
                "&:after": {
                  content: `"${"24"}"`,
                },
              }}
            />
          </Tabs>
        </Box>
        <Table
          loading={isLoading}
          rowCount={vehiclesList?.meta?.totalCount}
          rows={vehiclesList?.data || []}
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          columns={[
            {
              key: "userName",
              label: "Name",
              Render: (row) => "Test Data",
            },
            {
              key: "emailId",
              label: "Email ID",
              Render: (row) => "testData@gmail.com",
            },
            {
              key: "assignedOn",
              label: "Assigned On",
              format: (value) => moment(value).format("ddd, MMM DD, YYYY"),
            },
            {
              key: "assignedAs",
              label: "Assigned As",
              Render: (row) => <AssignedAs />,
            },
            {
              key: "action",
              label: "Action",
              Render: (row) => <Reject />,
            },
          ]}
        />
      </Paper>
    </>
  );
};
export default UsersList;
