// import { Box } from "@mui/material";

// const Admin = () => {
//   return <Box>Admin</Box>;
// };

// export default Admin;

import UsersList from "./UsersList";

const Admin = () => {
  return <UsersList />;
};

export default Admin;
