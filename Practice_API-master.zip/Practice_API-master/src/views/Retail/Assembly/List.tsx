import {
  Box,
  Button,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  Hidden,
} from "@mui/material";
import { InfoOutlined } from "@mui/icons-material";
import { RETAIL_URL } from "utils/constants";
import TableComponent from "components/Table";
import moment from "moment";
import { useQuery } from "react-query";
import { useMemo, useState, useEffect } from "react";
import { getPermissions } from "utils";
import { DeleteOutline } from "@mui/icons-material";
import TuneIcon from "@mui/icons-material/Tune";
import { authorizedFetch } from "utils";
import Search from "components/Search";

const ListCompomemt = ({ onViewClick }: any) => {
  const { canWrite } = getPermissions("retail:assembly");
  // const [selectedRows, setSelectedRows] = useState([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [deleteDialog, setDeleteDialog] = useState<any>({
    open: false,
    selected: [],
  });

  const url = `${RETAIL_URL}/assembly/vehicle?first=${pageSize}
&skip=${pageSize * (page - 1)}${search ? "&search=" + search : ""}`;

  const { isLoading, data: vehiclesList } = useQuery(
    ["ListCompomemt", page, pageSize, search],
    () => authorizedFetch(url)
  );

  useEffect(() => {
    console.log("list data is => ", vehiclesList);
  }, [vehiclesList]);

  return (
    <>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          mr: 3.5,
          ml: 3.3,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box sx={{ display: "flex", flexDirection: "row", mt: 1.5 }}></Box>
          <Box display="flex" sx={{ pr: 99 }}>
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setPage(1);
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
          <Box sx={{ pr: 3 }}>
            <Button
              sx={{
                borderRadius: "4px",
                boxShadow: 1,
                color: "#000",
                background: "#f6f8fb",
                border: "none",
                width: "100%",
                "&:hover": {
                  border: "1px solid #000",
                },
              }}
              variant="outlined"
              startIcon={<TuneIcon />}
            >
              Filter By
            </Button>
          </Box>
        </Box>{" "}
        <TableComponent
          loading={isLoading}
          rowCount={vehiclesList?.meta?.totalCount}
          rows={vehiclesList?.data || []}
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          selectable={canWrite}
          columns={[
            {
              key: "vin",
              label: "Vin",
              //   Render: (row) => <Box sx={{ py: 2 }}>{row.vin}</Box>,
            },
            {
              key: "model",
              label: "Model",
              Render: (row) => <Box>{row.model?.name}</Box>,
            },
            {
              key: "updatedAt",
              label: "Updated At",
              format: (value) => moment(value).format("MMM DD, YYYY"),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <IconButton
                  size="small"
                  sx={{
                    ml: 0.5,
                    color: (theme) => theme.customColors.action,
                  }}
                  children={<InfoOutlined fontSize="small" />}
                  onClick={() => {
                    const index = vehiclesList?.data.findIndex(
                      ({ _id }: any) => _id === row._id
                    );
                    onViewClick(index, row);
                  }}
                />
              ),
            },
          ]}
          toolbar={() => (
            <Button
              startIcon={<DeleteOutline />}
              onClick={() => {
                // setDeleteDialog({ open: true, data: selectedRows });
              }}
            >
              Delete
            </Button>
          )}
        />
      </Paper>
      <DeleteDialog
        open={deleteDialog.open}
        handleClose={() => {
          setDeleteDialog({ ...deleteDialog, open: false });
        }}
        selected={deleteDialog.data}
      />
    </>
  );
};

const List = ({ editModel, onViewClick }: any) => {
  return useMemo(
    () => <ListCompomemt editModel={editModel} onViewClick={onViewClick} />,
    [editModel, onViewClick]
  );
};

interface DeleteVendorProps {
  open: boolean;
  handleClose: () => void;
  selected: string[];
}

const DeleteDialog: React.FC<DeleteVendorProps> = ({
  open,
  handleClose,
  selected,
}) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Model{selected?.length > 1 ? "s" : ""}</DialogTitle>
      <DialogContent className="py-1">
        Delete {selected?.length > 1 || ""} selected vendor
        {selected?.length > 1 ? "s" : ""}?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button variant="contained" color="primary" disableElevation>
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default List;
