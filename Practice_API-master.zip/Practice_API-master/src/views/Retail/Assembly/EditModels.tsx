import { useState, useEffect, useCallback } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  MenuItem,
  Stepper,
  Step,
  IconButton,
  StepButton,
  Typography,
  Checkbox,
  FormControlLabel,
} from "@mui/material";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { HighlightOff } from "@mui/icons-material";
import { useMutation } from "react-query";
import { authorizedFetch, snackbar, setLoader } from "utils";
import { RETAIL_URL } from "utils/constants";

interface Props {
  open: boolean;
  handleClose: () => void;
  data: any;
  count: number;

  closeDrawer: () => void;

  activeGridType: any;
  setActiveCard: any;
}

const min = 0;
const max = 100;

const EditModels: React.FC<Props> = ({ open, handleClose, data }) => {
  const [activeStep, setActiveStep] = useState(0);
  const steps = ["Model Info.", "Model Config", "Devices"];
  const isLastStep = activeStep === steps.length - 1;

  console.log("data is", data);
  const [model, setModel] = useState(data.name);
  const [id, setId] = useState(data._id);
  const [type, setType] = useState(data.type);
  const [protocol, setProtocol] = useState(data.protocol);
  const [cOvl, setcOvl] = useState(data.cOvl);
  const [cUvl, setcUvl] = useState(data.cUvl);
  const [bMinvl, setbMinvl] = useState(data.bMinvl);
  const [bMaxvl, setbMaxvl] = useState(data.bMaxvl);
  const [brGlimit, setbrGlimit] = useState(data.brGlimit);
  const [bMaxvoltage, setMaxVoltage] = useState(data.bMaxvoltage);
  const [bMinsl, setbMinsl] = useState(data.bMinsl);
  const [zLimit, setzLimit] = useState(data.zLimit);
  const [pcLimit, setpcLimit] = useState(data.pcLimit);
  const [bMincl, setbMincl] = useState(data.bMincl);
  const [access, setAccess] = useState(data.access);
  const [cUVolL, setcUVolL] = useState(data.cUVolL);
  const [hillAssist, setHillAssist] = useState(data.hillAssist);
  const [parking, setParking] = useState(data.parking);
  const [regenBraking, setRegenBraking] = useState(data.regenBraking);
  const [ebs, setEbs] = useState(data.ebs);
  const [protocolOptData, setProtocolOptData] = useState<any>([]);
  const [pnpProtocol, setPnpProtocol] = useState<boolean>();
  const [viewProtocol, setViewProtocol] = useState<boolean>();
  const [viewPlusProtocol, setViewPlusProtocol] = useState<boolean>();
  const [smartProtocol, setSmartProtocol] = useState<boolean>();
  const [smartPlusProtocol, setSmartPlusProtocol] = useState<boolean>();
  const [controller, setController] = useState<any>([]);
  const [telematics, setTelematics] = useState<any>([]);
  const [deviceData, setDeviceData] = useState<any>([]);

  const handleChange = (event: SelectChangeEvent<typeof telematics>) => {
    const {
      target: { value },
    } = event;
    setTelematics(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const selectMultiple = (event: SelectChangeEvent<typeof controller>) => {
    const {
      target: { value },
    } = event;
    setController(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };
  const deviceUrl = `${RETAIL_URL}/inventory/protocol/devices/SMART_PLUS`;

  const getDevices = useMutation(
    "getDevice",
    () =>
      authorizedFetch(deviceUrl, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("device data is =>", data);
        setDeviceData(data);
      },
    }
  );

  useEffect(
    () => {
      getDevices.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  console.log("Data for edit model is", data);

  function handleSubmit(e: React.SyntheticEvent) {
    e.preventDefault();
  }

  const url = `${RETAIL_URL}/assembly/model/62441137db1b5d94119f96c8`;

  const editModel = useMutation(
    `editModel `,
    () => {
      console.log("test Edit Models: ");

      return authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          id: data.id,
          name: data.name,
          type: data.type,
          protocol: data.protocol,
          devices: [
            {
              category: "CONTROLLER",
              modelId: ["6235b5924bacc62e2ee0768a"],
            },
          ],
          specs: {
            COLOR: "RED",
            TEST: "1",
            alloyWheels: "true",
          },
          config: {
            hillAssist: false,
            wheelDiameter: data.cUvl,
            diskBrakes: true,
          },
        },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Model updated");
      },
      onError: () => {
        snackbar.error("Error updating Model");
      },
    }
  );

  const onSave = () => {
    editModel.mutate();
    handleClose();
  };

  const protocolUrl = `https://retail.dev.revos.in/inventory/protocol`;

  const protocolOptins = useMutation(
    "viewProtocolOpt",
    () =>
      authorizedFetch(protocolUrl, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("protocolData =>", data);
        setProtocolOptData(data);
      },
    }
  );

  useEffect(
    () => {
      protocolOptins.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const protocolOptViewUrl = `${RETAIL_URL}/inventory/protocol-config/VIEW`;
  const protocolOptView = useMutation(
    "protocolOptView",
    () =>
      authorizedFetch(protocolOptViewUrl, {
        method: "GET",
      }),
    {
      onSuccess: (res: any) => {
        console.log("protocolOptView res => ", res);
      },
    }
  );

  const getViewRelatedData = useCallback(
    () => {
      if (viewProtocol) {
        protocolOptView.mutate();
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [viewProtocol]
  );

  const protocolOptPnpUrl = `${RETAIL_URL}/inventory/protocol-config/PNP`;
  const protocolOptPnp = useMutation(
    "protocolOptView",
    () =>
      authorizedFetch(protocolOptPnpUrl, {
        method: "GET",
      }),
    {
      onSuccess: (res: any) => {
        console.log("protocolOptPnp res => ", res);
      },
    }
  );

  const getPnpRelatedData = useCallback(
    () => {
      if (pnpProtocol) {
        protocolOptPnp.mutate();
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [pnpProtocol]
  );

  const protocolOptViewPlusUrl = `${RETAIL_URL}/inventory/protocol-config/VIEW_PLUS`;
  const protocolOptViewPlus = useMutation(
    "protocolOptViewPlus",
    () =>
      authorizedFetch(protocolOptViewPlusUrl, {
        method: "GET",
      }),
    {
      onSuccess: (res: any) => {
        console.log("protocolOptViewPlus res => ", res);
      },
    }
  );

  const getViewPlusRelatedData = useCallback(
    () => {
      if (viewPlusProtocol) {
        protocolOptViewPlus.mutate();
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [viewPlusProtocol]
  );

  const protocolOptSmartUrl = `${RETAIL_URL}/inventory/protocol-config/SMART`;
  const protocolOptSmart = useMutation(
    "protocolOptSmart",
    () =>
      authorizedFetch(protocolOptSmartUrl, {
        method: "GET",
      }),
    {
      onSuccess: (res: any) => {
        console.log("protocolOptSmart res => ", res);
      },
    }
  );

  const getSmartRelatedData = useCallback(
    () => {
      if (smartProtocol) {
        protocolOptSmart.mutate();
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [smartProtocol]
  );

  const protocolOptSmartPlusUrl = `${RETAIL_URL}/inventory/protocol-config/SMART_PLUS`;
  const protocolOptSmartPlus = useMutation(
    "protocolOptSmartPlus",
    () =>
      authorizedFetch(protocolOptSmartPlusUrl, {
        method: "GET",
      }),
    {
      onSuccess: (res: any) => {
        console.log("SmartPlus data is", res);
      },
    }
  );

  const getSmartPlusRelatedData = useCallback(
    () => {
      if (smartPlusProtocol) {
        protocolOptSmartPlus.mutate();
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [smartPlusProtocol]
  );

  return (
    <Dialog
      open={open}
      onClose={() => handleClose()}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Edit Model
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={() => handleClose()}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <form onSubmit={handleSubmit}>
        <DialogContent sx={{ pb: "16px !important" }}>
          <Stepper
            sx={{ mb: 4, mt: 2, mx: "auto", maxWidth: 534 }}
            activeStep={activeStep}
            alternativeLabel
            nonLinear
          >
            {steps.map((label: string, i) => (
              <Step key={i}>
                <StepButton onClick={() => setActiveStep(i)}>
                  {label}
                </StepButton>
                {/* <StepLabel>{label}</StepLabel> */}
              </Step>
            ))}
          </Stepper>
          {activeStep === 0 && (
            <Box>
              <Box>
                <Box sx={{ display: "flex", flexDirection: "row" }}>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      width: "50%",
                      mr: 2,
                    }}
                  >
                    <Typography className="label">Vehicle Model</Typography>

                    <TextField
                      required
                      margin="dense"
                      id="vehicle"
                      placeholder="Enter Name"
                      // variant="outlined"
                      size="small"
                      value={model}
                      onChange={(e) => setModel(e.target.value)}
                    ></TextField>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      width: "50%",
                    }}
                  >
                    <Typography className="label"> Model Id</Typography>

                    <TextField
                      required
                      margin="dense"
                      id="model"
                      placeholder="Enter Id"
                      variant="outlined"
                      size="small"
                      value={id}
                      onChange={(e) => setId(e.target.value)}
                    ></TextField>
                  </Box>
                </Box>
                <Box sx={{ display: "flex", flexDirection: "row" }}>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      mt: 2,
                      mr: 2,
                      width: "100%",
                    }}
                  >
                    <Typography className="label"> Vehicle Type</Typography>
                    <Select
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                      displayEmpty
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>

                      <MenuItem value="TWO">Two Wheeler</MenuItem>
                      <MenuItem value="THREE">Three Wheeler</MenuItem>
                    </Select>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      mt: 2,
                      width: "100%",
                    }}
                  >
                    <Typography className="label"> Protocol</Typography>
                    <Select
                      value={protocol}
                      onChange={(e) => {
                        setProtocol(e.target.value);
                        setViewProtocol(
                          "view" === e.target.value.toLowerCase()
                        );
                        setPnpProtocol("pnp" === e.target.value.toLowerCase());
                        setViewPlusProtocol("VIEW_PLUS" === e.target.value);
                        setSmartProtocol(
                          "smart" === e.target.value.toLowerCase()
                        );
                        setSmartPlusProtocol("SMART_PLUS" === e.target.value);
                      }}
                      displayEmpty
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>
                      {protocolOptData?.data?.map((name: any) => (
                        <MenuItem key={name} value={name}>
                          {name}
                        </MenuItem>
                      ))}
                    </Select>
                  </Box>
                </Box>
              </Box>
            </Box>
          )}

          {activeStep === 1 && (
            <Box>
              {viewProtocol && (
                <>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 3,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Access Type</Typography>
                      <Select
                        value={access}
                        onChange={(e) => setAccess(e.target.value)}
                        displayEmpty
                      >
                        <MenuItem disabled value="">
                          <em>Select</em>
                        </MenuItem>
                        <MenuItem value="KEY">KEY</MenuItem>
                        <MenuItem value="KEYLESS">KEYLESS</MenuItem>
                        <MenuItem value="HYBRID">HYBRID</MenuItem>
                      </Select>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Wheel Diameter</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Wheel Diameter"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={cUvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcUvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Max Speed</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Max Speed"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMaxvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMaxvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Speed Limit</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Speed Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMinsl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMinsl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Pickup Control Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Pickup Control Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={pcLimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setpcLimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Brake Regeneration Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Brake Regeneration Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={brGlimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbrGlimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Zero Throttle Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Zero Throttle Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={zLimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setzLimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Current Limit</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Current Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMincl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMincl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={hillAssist}
                            onChange={(e) => setHillAssist(e.target.value)}
                          />
                        }
                        label="Hill Assist"
                      />
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={parking}
                            onChange={(e) => setParking(e.target.value)}
                          />
                        }
                        label="Parking Status"
                      />
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={regenBraking}
                            onChange={(e) => setRegenBraking(e.target.value)}
                          />
                        }
                        label="Regenerative Braking Status"
                      />
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={ebs}
                            onChange={(e) => setEbs(e.target.value)}
                          />
                        }
                        label="E-ABS Status"
                      />
                    </Box>
                  </Box>
                </>
              )}
              {pnpProtocol && (
                <>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Controller Under Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Under Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={cUVolL}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcUVolL(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Controller Over Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Over Voltage Limit"
                        variant="outlined"
                        type="number"
                        inputProps={{ min, max }}
                        size="small"
                        value={cOvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcOvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Battery Min Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Min Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMinvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMinvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        {" "}
                        Battery Max Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Max Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMaxvoltage}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setMaxVoltage(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                </>
              )}
              {(viewPlusProtocol || smartProtocol || smartPlusProtocol) && (
                <>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 3,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Access Type</Typography>
                      <Select
                        value={access}
                        onChange={(e) => setAccess(e.target.value)}
                        displayEmpty
                      >
                        <MenuItem disabled value="">
                          <em>Select</em>
                        </MenuItem>

                        <MenuItem value="KEY">KEY</MenuItem>
                        <MenuItem value="KEYLESS">KEYLESS</MenuItem>
                        <MenuItem value="HYBRID">HYBRID</MenuItem>
                      </Select>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Wheel Diameter</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Wheel Diameter"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={cUvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcUvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Max Speed</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Max Speed"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMaxvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMaxvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Speed Limit</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Speed Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMinsl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMinsl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Pickup Control Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Pickup Control Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={pcLimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setpcLimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Brake Regeneration Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Brake Regeneration Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={brGlimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbrGlimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Zero Throttle Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Zero Throttle Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={zLimit}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setzLimit(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Current Limit</Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Current Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMincl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMincl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Controller Under Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Under Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={cUVolL}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcUVolL(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Controller Over Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Over Voltage Limit"
                        variant="outlined"
                        type="number"
                        inputProps={{ min, max }}
                        size="small"
                        value={cOvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setcOvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        Battery Min Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Min Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMinvl}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setbMinvl(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;
                        }}
                      ></TextField>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">
                        {" "}
                        Battery Max Voltage Limit
                      </Typography>
                      <TextField
                        required
                        margin="dense"
                        id="vehicle"
                        label="Max Voltage Limit"
                        variant="outlined"
                        size="small"
                        type="number"
                        inputProps={{ min, max }}
                        value={bMaxvoltage}
                        onChange={(e) => {
                          var value = parseInt(e.target.value, 100);
                          setMaxVoltage(e.target.value);
                          if (value > max) value = max;
                          if (value < min) value = min;

                          // setValue(value);
                        }}
                      ></TextField>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={hillAssist}
                            onChange={(e) => setHillAssist(e.target.value)}
                          />
                        }
                        label="Hill Assist"
                      />
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={parking}
                            onChange={(e) => setParking(e.target.value)}
                          />
                        }
                        label="Parking Status"
                      />
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "row" }}>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={regenBraking}
                            onChange={(e) => setRegenBraking(e.target.value)}
                          />
                        }
                        label="Regenerative Braking Status"
                      />
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <FormControlLabel
                        sx={{ fontWeight: 500 }}
                        control={
                          <Checkbox
                            value={ebs}
                            onChange={(e) => setEbs(e.target.value)}
                          />
                        }
                        label="E-ABS Status"
                      />
                    </Box>
                  </Box>
                </>
              )}
            </Box>
          )}

          {activeStep === 2 && (
            <Box sx={{ display: "flex", flexDirection: "row" }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 3,
                  mr: 2,
                  width: "100%",
                }}
              >
                <Box sx={{ display: "flex", flexDirection: "row" }}>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      mt: 2,
                      mr: 2,
                      width: "100%",
                    }}
                  >
                    <Typography className="label">Controller</Typography>
                    <Select
                      value={controller}
                      onChange={selectMultiple}
                      displayEmpty
                      multiple
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>
                      {deviceData?.data[0]?.CONTROLLER?.map((val: any) => (
                        <MenuItem key={val.name} value={val.name}>
                          {val.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      mt: 2,
                      mr: 2,
                      width: "100%",
                    }}
                  >
                    <Typography className="label">Telematics</Typography>
                    <Select
                      value={telematics}
                      onChange={handleChange}
                      displayEmpty
                      multiple
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>
                      {deviceData?.data[0]?.TELEMATICS?.map((val: any) => (
                        <MenuItem key={val.id} value={val.name}>
                          {val.name}
                        </MenuItem>
                      ))}
                      {/* {device?.map((el: any) => (
                  <MenuItem key={el.id} value={el.name}>
                    {el.name}
                  </MenuItem>
                ))}  */}
                    </Select>
                  </Box>
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>
      </form>
      <DialogActions>
        <Button
          variant="outlined"
          onClick={() => {
            if (activeStep === 0) {
              handleClose();
            } else {
              setActiveStep(activeStep - 1);
            }
          }}
        >
          {activeStep === 0 ? "Cancel" : "Previous"}
        </Button>

        <Button
          variant="contained"
          onClick={() => {
            if (isLastStep) {
              // handleClose({
              //   name: model,
              //   type: type,
              //   protocol: protocol,
              //   devices: [
              //     {
              //       category: "CONTROLLER",
              //       modelId: [id],
              //     },
              //   ],
              //   components: [
              //     {
              //       category: "SPEEDOMETER",
              //       modelId: [id],
              //     },
              //   ],
              //   config: {
              //     hillAssist: false,
              //     wheelDiameter: cUvl,
              //     diskBrakes: true,
              //   },
              // });
              setActiveStep(0);
              onSave();
              // handleClose();
            } else {
              getViewRelatedData();
              getPnpRelatedData();
              getViewPlusRelatedData();
              getSmartRelatedData();
              getSmartPlusRelatedData();
              setActiveStep(activeStep + 1);
            }
          }}
        >
          {isLastStep ? "Save" : "Next"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditModels;
