import {
  CancelOutlined,
  DeleteOutline,
  EditOutlined,
} from "@mui/icons-material";
import { Box, IconButton, Tab, Tabs } from "@mui/material";
import { useEffect, useState } from "react";
import img from "../../../assets/images/revoslogo.png";
import { authorizedFetch, drawer, snackbar } from "utils";
import { RETAIL_URL } from "utils/constants";
import EditModels from "./EditModels";
import { useMutation } from "react-query";

const VehicleModel = {
  basicInfo: [
    { label: "VIN", value: "name" },
    { label: "Vehicle Model", value: "type" },
    { label: "Protocol", value: "protocol" },
    // { label: "Type", value: "type" },
    { label: "Vehicle Status", value: "vehicle status" },
  ],

  configTabData: [
    { label: "Access Type", value: "accessType" },
    { label: "Wheel Diameter", value: "wheelDiameter" },
    { label: "Max Speed", value: "maxSpeed" },
    { label: "Pickup Control Limit", value: "pickupControlLimit" },
    { label: "Zero Throttle Limit", value: "zeroThrottleRegenLimit" },
    { label: "Current Limit", value: "currentLimit" },
    { label: "Controller Over Voltage Limit", value: "overVoltageLimit" },
    { label: "Controller Under Voltage Limit", value: "underVoltageLimit" },
    { label: "Hill Assist", value: "hillAssistStatus" },
  ],
};

interface Props {
  activeGridType: any;
  setActiveCard: (val: number | null) => void;
  data: any;
  editModel: any;
  modelConfigdData: any;
  index: any;
  gridType: any;
  //  data: any;
  //  activeGridType: any;
  //  setActiveCard: any;
  //  openTab: number;
  //  editModel:any
}

const AssemblyInfo: React.FC<Props> = ({
  activeGridType,
  setActiveCard,
  data,
  gridType,
  modelConfigdData,
  editModel,
  index,
}) => {
  // const AssemblyInfo: React.FC<any> = (props) => {
  //   const { activeGridType, setActiveCard, data, editModel } = props;
  const [activeTab, setActiveTab] = useState<string>("config");
  const [modelData, setModelData] = useState<any>();

  const [editDialog, setEditDialog] = useState({
    open: false,
    count: 0,
  });

  const modelDataByUrl = `${RETAIL_URL}/assembly/model/${data?._id}`;
  const vehicleDataByIdUrl = `${RETAIL_URL}/vehicle/${data?._id}`;

  const deleteVehicle = useMutation(
    "DELETE_VEHICLE",
    () =>
      authorizedFetch(vehicleDataByIdUrl, {
        method: "DELETE",
        body: {
          vehicleId: data?._id,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Vehicle Deleted`);
        getAllModels.mutate();
      },
      onError: () => {
        snackbar.error(`Error Deleting vehicle`);
      },
    }
  );

  const delModel = useMutation(
    "DELMODEL",
    () =>
      authorizedFetch(modelDataByUrl, {
        method: "DELETE",
        body: {
          modelId: data?.ID,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Model Deleted`);
        getAllModels.mutate();
      },
      onError: () => {
        snackbar.error(`Error Deleting model`);
      },
    }
  );
  const getAllModels = useMutation(
    "modelData",
    () =>
      authorizedFetch(modelDataByUrl, {
        method: "GET",
      }),
    {
      onError: () => {
        snackbar.error(`Error Fetching model`);
      },
      onSuccess: ({ data: [mainData] = [{}] }: any) => {
        console.log("modelData =>", mainData);
        setModelData(mainData);
      },
      // onSuccess: (data: any) => {
      //   console.log("modelData =>", data);
      //   setModelData(data);
      // }
    }
  );

  useEffect(() => {
    if (modelData?.models?.get) {
      console.log("model data", modelData?.models?.get);
      // setCurrentItemData(modelData?.models?.get);
    }
  }, [modelData]);

  useEffect(
    () => {
      getAllModels.mutate();
      return () => {
        drawer.close();
      };
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useEffect(() => {
    getAllModels.mutate();
    return () => {
      drawer.close();
    };
    // eslint-disable-next-line
  }, []);

  console.log("data ==> ", data);
  const basicInfoDataObj = !!modelData ? modelData : data;

  const renderdata = (label: string) => {
    if (label === "Vehicle Model") return data.model?.name;
    else if (label === "Protocol") return data.model?.protocol;
    else if (label === "VIN") return data?.vin;
    else if (label === "Vehicle Status") return data?.status;
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          p: 1,
          background: "#03241d",
        }}
      >
        <Box sx={{ fontWeight: "bold", fontSize: 14, color: "#f6f8fb" }}>
          {data?.name || "Revos Test Encription"}
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            // onClick={
            //   () => editModel(data?._id)
            //   //  open={showDialog === "edit"}
            // }
            onClick={() => {
              setEditDialog({
                open: true,
                count: 1,
              });
            }}
          >
            <EditOutlined />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => {
              activeGridType === "grid"
                ? delModel.mutate(data?._id)
                : deleteVehicle.mutate(data?._id);
              setActiveCard(null);
              drawer.close();
            }}
          >
            <DeleteOutline />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => {
              setActiveCard(null);
              drawer.close();
            }}
          >
            <CancelOutlined />
          </IconButton>
        </Box>
      </Box>
      <Box p={2}>
        <Box
          sx={{
            background: "#f6f8fb",
            borderRadius: "6px",
            p: 1,
            fontSize: "14px",
            fontWeight: "bold",
          }}
        >
          Basic Info
        </Box>
        <Box mt={2} sx={{ display: "flex", flexDirection: "row", height: 150 }}>
          {activeGridType === "grid" && (
            <Box
              sx={{
                width: "160px",
                background: `url(${img}) no-repeat`,
                backgroundSize: "cover",
                backgroundPositionY: "50%",
                borderRadius: "8px",
              }}
              mr={2}
            />
          )}
          <Box
            sx={{
              width: activeGridType === "grid" ? "calc(100% - 160px)" : "100%",
              p: 1,
            }}
          >
            {VehicleModel.basicInfo.map((infoData: any, index: number) => (
              <Box
                key={index}
                sx={{ display: "flex", justifyContent: "space-between" }}
                mt={1}
                mb={1}
              >
                <Box
                  component="span"
                  sx={{ fontSize: 14, width: "50%", fontWeight: "bold" }}
                >
                  {infoData?.label}
                </Box>
                {console.log(modelData, data, infoData?.value)}
                <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                  {basicInfoDataObj &&
                    (basicInfoDataObj[infoData?.value] || null)}
                  {/* {modelData?.data[0][infoData.value] || data[infoData.value]} */}
                  {renderdata(infoData.label)}
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
        {activeGridType === "grid" && (
          <Box mt={3}>
            <Tabs
              value={activeTab}
              onChange={(_, val) => setActiveTab(val)}
              centered
            >
              <Tab value="config" sx={{ width: "50%" }} label="Configuration" />
            </Tabs>
            {activeTab === "config" && (
              <Box p={2.5}>
                {VehicleModel.configTabData.map(
                  (infoData: any, index: number) => (
                    <Box
                      key={index}
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                      mt={1}
                      mb={1}
                    >
                      <Box
                        component="span"
                        sx={{
                          fontSize: 14,
                          width: "50%",
                          fontWeight: "bold",
                        }}
                      >
                        {infoData.label}
                      </Box>
                      <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                        {/* {currentItemData.config[infoData.value] ||
                          data[infoData.value]} */}
                      </Box>
                    </Box>
                  )
                )}
              </Box>
            )}
          </Box>
        )}
      </Box>
      <EditModels
        open={editDialog.open}
        closeDrawer={() => drawer.close()}
        handleClose={() => {
          setEditDialog({ open: false, count: 0 });
        }}
        data={data}
        count={editDialog.count}
        activeGridType={activeGridType}
        setActiveCard={setActiveCard}
      />
    </>
  );
};

export default AssemblyInfo;
