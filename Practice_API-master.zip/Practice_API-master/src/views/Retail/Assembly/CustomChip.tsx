import { Box } from "@mui/material";
import React from "react";

interface ChipProps {
  label: string;
  sx?: any;
  color?: string;
  bgColor?: string;
}

const CustomChip: React.FC<ChipProps> = ({
  label,
  sx = {},
  color = "#3CB99E",
  bgColor = "rgba(104, 214, 165, 0.3)",
}) => {
  return (
    <Box
      sx={{
        background: bgColor,
        padding: 1,
        fontSize: 10,
        color: { color },
        height: 26,
        display: "flex",
        alignItems: "Center",
        borderRadius: "4px",
        ...sx,
      }}
    >
      {label}
    </Box>
  );
};

export default CustomChip;
