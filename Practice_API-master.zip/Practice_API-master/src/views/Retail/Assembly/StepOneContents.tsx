import JSONForm, {
  AjvError,
  IChangeEvent,
  ISubmitEvent,
  UiSchema,
} from "@rjsf/core";
import type { JSONSchema7 } from "json-schema";

const schema: JSONSchema7 = {
  title: "xyz",
  type: "object",
  required: ["name"],
  properties: {
    title: { type: "string", title: "Title", default: "Anew Title" },
    done: { type: "boolean", title: "Done?", default: false },
  },
};

const uiSchema: UiSchema = {};
const Form: React.FC = () => {
  const onSubmit = (e: ISubmitEvent<unknown>) => {
    console.log("submit", e.formData);
  };
  const onChange = (e: IChangeEvent<unknown>) => {
    console.log("change", e.formData);
  };
  const onError = (err: AjvError[]) => {
    console.error(err);
  };
  return (
    <JSONForm
      schema={schema}
      uiSchema={uiSchema}
      onSubmit={onSubmit}
      onChange={onChange}
      onError={onError}
    />
  );
};
export default Form;
