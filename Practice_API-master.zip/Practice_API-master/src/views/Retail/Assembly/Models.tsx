import { useState, useEffect, useCallback } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  MenuItem,
  Stepper,
  Step,
  IconButton,
  StepButton,
  Typography,
  // Select,
  Checkbox,
  FormControlLabel,
} from "@mui/material";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { HighlightOff } from "@mui/icons-material";
import { useMutation } from "react-query";
import { authorizedFetch } from "utils";
import { RETAIL_URL } from "utils/constants";
import Form from "@rjsf/material-ui";
// import {transformErrors} from './ArrayFieldTemplate.tsx';

// import JSONForm ,{AjvError,IChangeEvent,ISubmitEvent,UiSchema} from '@rjsf/core';
// import type {JSONSchema7} from 'json-schema'
const min = 0;
const max = 100;

const CreateModel: React.FC<any> = ({
  masterView,
  open = false,
  handleClose = () => {},
  modelId = null,
}) => {
  const [activeStep, setActiveStep] = useState(0);
  const steps = ["Model Info.", "Model Config", "Devices"];
  const isLastStep = activeStep === steps.length - 1;
  const [model, setModel] = useState<string>();
  const id = "";
  // const [id, setId] = useState("");
  const [type, setType] = useState("");
  const [protocol, setProtocol] = useState("");
  const [cOvl, setcOvl] = useState("");
  const [cUvl, setcUvl] = useState("");
  const [bMinvl, setbMinvl] = useState("");
  const [bMaxvl, setbMaxvl] = useState("");
  const [brGlimit, setbrGlimit] = useState("");
  const [bMaxvoltage, setMaxVoltage] = useState("");
  const [bMinsl, setbMinsl] = useState("");
  const [zLimit, setzLimit] = useState("");
  const [pcLimit, setpcLimit] = useState("");
  const [bMincl, setbMincl] = useState("");
  const [access, setAccess] = useState("");
  const [cUVolL, setcUVolL] = useState("");
  const [hillAssist, setHillAssist] = useState("");
  const [parking, setParking] = useState("");
  const [regenBraking, setRegenBraking] = useState("");
  const [ebs, setEbs] = useState("");
  const [protocolOptData, setProtocolOptData] = useState<any>([]);
  const [accessData, setaccessData] = useState<any>([]);
  const [deviceData, setDeviceData] = useState<any>([]);
  const [pnpProtocol, setPnpProtocol] = useState<boolean>();
  const [viewProtocol, setViewProtocol] = useState<boolean>();
  const [viewPlusProtocol, setViewPlusProtocol] = useState<boolean>();
  const [smartProtocol, setSmartProtocol] = useState<boolean>();
  const [smartPlusProtocol, setSmartPlusProtocol] = useState<boolean>();
  const [controller, setController] = useState<any>([]);
  const [telematics, setTelematics] = useState<any>([]);
  const [protocolPNP, setprotocolPNP] = useState<any>([]);
  const [protocolVIEW, setprotocolVIEW] = useState<any>([]);
  const [protocolVPlus, setprotocolVPlus] = useState<any>([]);
  const [protocolSmart, setprotocolSmart] = useState<any>([]);
  const [protocolSmartPlus, setprotocolSmartPlus] = useState<any>([]);
  const [modelError, setModelError] = useState<{ model: string }>();
  const [protocolData, setProtocolData] = useState<any>([]);
  const [protocolSelected, setProtocolSelected] = useState<any>([]);
  const [findingData, setFindingData] = useState<any>([]);
  // const [vehiceError, setvehicleError] = useState(false);
  // const uiSchema : UiSchema = {}
  // function Form(){
  //   const onSubmit = (e: ISubmitEvent<unknown>) => {
  //     console.log('submit', e.formData)
  //   }
  //   const onChange = (e: IChangeEvent<unknown>) => {
  //     console.log('change', e.formData)
  //   }
  //   const onError = (err: AjvError[]) => {
  //     console.error(err)
  //   }
  // }

  const handleValidation = (e: any) => {
    const {
      target: { value },
    } = e;
    setModelError({ model: "" });
    setModel(e.target.value);
    // let mod = new RegExp(/^\s*([0-9a-zA-Z]+)\s*$/).test(value);
    let mod = new RegExp(/^\w+$/).test(value);
    if (!mod) {
      setModelError({ model: "Fill Something" });
      setActiveStep(0);
    }
  };

  const handleChange = (event: SelectChangeEvent<typeof telematics>) => {
    const {
      target: { value },
    } = event;
    setTelematics(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const selectMultiple = (event: SelectChangeEvent<typeof controller>) => {
    const {
      target: { value },
    } = event;
    setController(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  // const protocol = `https://retail.dev.revos.in/inventory/protocol`;

  //   function getdynamicdata(protocol){
  //     let url =`${RETAIL_URL}/inventory/protocol-config/${protocol}`;
  //     dynamicdata =    usemutation(url)
  //     setdynamicdata(dynamicdata)
  // }

  const url = `${RETAIL_URL}/inventory/protocol-config/${protocol}`;
  console.log("protocol =>", protocol);
  const dynamicData = useMutation(
    "getDynamicData",
    () =>
      authorizedFetch(url, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("finding data is", data);
        setFindingData(data);
      },
    }
  );
  const getDynamicData = useCallback(
    () => {
      dynamicData.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [protocolSelected]
  );
  console.log("Protocol Data =>", protocolData);
  //  const GetDynamicData = (isenabled: any) => {

  //       const { isLoading, data } = useQuery(
  //     ["getDynamicData" ],
  //      () =>
  //       authorizedFetch(url), {
  //     enabled: isenabled || false
  //       }
  //   );

  //  }

  // useEffect(
  //   () => {
  //     dynamicData.mutate();
  //   },
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolSelected]
  // );

  // const dynamicForm = (val: string,options?: string[]) => {
  //   if (val === protocolData.data?.type) {
  //     if ((val === 'string' || 'number')) {
  //       <>
  //         <Typography className="label">{protocolData?.data?.name}</Typography>
  //         <TextField></TextField>
  //       </>
  //     }
  //     if ((val === 'boolean')) {
  //       <>
  //         <Typography className="label">{protocolData?.data?.name}</Typography>
  //         <FormControlLabel
  //           sx={{ fontWeight: 500 }}
  //           control={
  //             <Checkbox />
  //           }
  //           label="checkBox"
  //         />
  //       </>
  //     }
  //     if ((val === "dropdown-single")) {
  //       <>
  //         <Typography className="label">{protocolData?.data?.name}</Typography>
  //         <Select>
  //           {options?.map((option: string, i: number) => {
  //             return (<MenuItem key={i} value={option}>{option}</MenuItem>);
  //           })}
  //         </Select>
  //       </>
  //     }
  //   }
  // }

  const protocolUrl = `https://retail.dev.revos.in/inventory/protocol`;

  const protocolOptins = useMutation(
    "protocolOptins",
    () =>
      authorizedFetch(protocolUrl, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("protocolData =>", data);
        setProtocolOptData(data);
      },
    }
  );

  useEffect(
    () => {
      protocolOptins.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [protocolData]
  );

  // const protocolOptViewUrl = `${RETAIL_URL}/inventory/protocol-config/VIEW`;
  // const protocolOptView = useMutation(
  //   "protocolOptView",
  //   () =>
  //     authorizedFetch(protocolOptViewUrl, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("protocolOptView res => ", res);
  //       setProtocolData(res);
  //     },
  //   }
  // );
  // console.log("protocolData =>", protocolData)
  // const getViewRelatedData = useCallback(
  //   () => {
  //     if (viewProtocol) {
  //       protocolOptView.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [viewProtocol]
  // );

  // const protocolOptPnpUrl = `${RETAIL_URL}/inventory/protocol-config/PNP`;
  // const protocolOptPnp = useMutation(
  //   "protocolOptView",
  //   () =>
  //     authorizedFetch(protocolOptPnpUrl, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("protocolOptPnp res => ", res);
  //       setProtocolData(res);
  //     },
  //   }
  // );

  // const getPnpRelatedData = useCallback(
  //   () => {
  //     if (pnpProtocol) {
  //       protocolOptPnp.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [pnpProtocol]
  // );

  const deviceUrl = `${RETAIL_URL}/inventory/protocol/devices/SMART_PLUS`;

  const getDevices = useMutation(
    "getDevice",
    () =>
      authorizedFetch(deviceUrl, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("device data is =>", data);
        setDeviceData(data);
      },
    }
  );

  useEffect(
    () => {
      getDevices.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  // const getSmartPlusRelatedData = useCallback(
  //   () => {
  //     if (smartPlusProtocol) {
  //       protocolOptSmartPlus.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [smartPlusProtocol]
  // );

  // const url_PNP = `${RETAIL_URL}/inventory/protocol/devices/PNP`;

  // const ProtocalPNP = useMutation(
  //   "ProtocalPNP",
  //   () =>
  //     authorizedFetch(url_PNP, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("PNP data is", res);
  //     },
  //   }
  // );

  // const getProtocol_PNP = useCallback(
  //   () => {
  //     if (protocolPNP) {
  //       ProtocalPNP.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolPNP]
  // );

  // const url_VIEW = `${RETAIL_URL}/inventory/protocol/devices/VIEW`;

  // const ProtocalVIEW = useMutation(
  //   "ProtocalVIEW",
  //   () =>
  //     authorizedFetch(url_VIEW, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("VIEW data is", res);
  //     },
  //   }
  // );

  // const getProtocol_VIEW = useCallback(
  //   () => {
  //     if (protocolVIEW) {
  //       ProtocalVIEW.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolVIEW]
  // );

  // const url_VIEW_Plus = `${RETAIL_URL}/inventory/protocol/devices/VIEW_PLUS`;

  // const ProtocalVIEWPlus = useMutation(
  //   "ProtocalVIEW",
  //   () =>
  //     authorizedFetch(url_VIEW_Plus, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("VIEWPlus data is", res);
  //     },
  //   }
  // );

  // const getProtocol_VIEWPlus = useCallback(
  //   () => {
  //     if (protocolVPlus) {
  //       ProtocalVIEWPlus.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolVPlus]
  // );

  // const url_Smart_Plus = `${RETAIL_URL}/inventory/protocol/devices/VIEW_PLUS`;

  // const ProtocalSmart = useMutation(
  //   "ProtocalVIEW",
  //   () =>
  //     authorizedFetch(url_Smart_Plus, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("Smart data is", res);
  //     },
  //   }
  // );

  // const getProtocol_Smart = useCallback(
  //   () => {
  //     if (protocolSmart) {
  //       ProtocalSmart.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolSmart]
  // );

  // const url_Smart_PlusD = `${RETAIL_URL}/inventory/protocol/devices/SMART_PLUS`;

  // const ProtocalSmartPlus = useMutation(
  //   "ProtocalVIEW",
  //   () =>
  //     authorizedFetch(url_Smart_PlusD, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (res: any) => {
  //       console.log("SmartPlus data is", res);
  //     },
  //   }
  // );

  // const getProtocol_Smart_Plus = useCallback(
  //   () => {
  //     if (protocolSmartPlus) {
  //       ProtocalSmartPlus.mutate();
  //     }
  //   }, // eslint-disable-next-line react-hooks/exhaustive-deps
  //   [protocolSmartPlus]
  // );

  const HandleNext = () => {
    if (isLastStep) {
      // handleClose({
      //   name: model,
      //   type: type,
      //   protocol: protocol,
      //   devices: [
      //     {
      //       category: "CONTROLLER",
      //       modelId: [id],
      //     },
      //   ],
      //   components: [
      //     {
      //       category: "SPEEDOMETER",
      //       modelId: [id],
      //     },
      //   ],
      //   config: {
      //     hillAssist: false,
      //     wheelDiameter: cUvl,
      //     diskBrakes: true,
      //   },
      // });
      handleClose({
        name: model,
        company: "5cfa443da7b11b00073f9657",
        type: type,
        config: {
          _id: id,
          configs: {
            overVoltageLimit: cOvl,
            underVoltageLimit: cUVolL,
            batteryMinVoltage: bMinvl,
            batteryMaxVoltage: bMaxvoltage,
          },
          createdAt: "2022-05-20T07:23:44.755Z",
          updatedAt: "2022-05-20T07:23:44.755Z",
          __v: 0,
        },
        components: [
          {
            modelId: [id],
            category: "",
          },
        ],
        protocol: protocol,
        status: "ACTIVE",
        _id: "62874200b227986b7a6454d5",
        createdAt: "2022-05-20T07:23:44.763Z",
        updatedAt: "2022-05-20T07:23:44.763Z",
        __v: 0,
      });
      setActiveStep(0);
    } else {
      let modelErrorLocal = false;
      if (model && type && protocol) {
        console.log("Model", model);
        modelErrorLocal = true;
        // modelError = true;
      }
      // if(type) {
      //   console.log("Type is", type);
      //   modelErrorLocal = true;
      // }
      // if(protocol) {
      //   console.log("Protocol is", protocol);
      //   modelErrorLocal = true;
      // }

      // getViewRelatedData();
      // getPnpRelatedData();
      // getViewPlusRelatedData();
      // getSmartRelatedData();
      // getSmartPlusRelatedData();
      // getProtocol_PNP();
      // getProtocol_VIEW();
      // getProtocol_VIEWPlus();
      // getProtocol_Smart();
      // getProtocol_Smart_Plus();
      getDynamicData();
      console.log("Model error is", modelError);
      // setModelError(modelErrorLocal);
      if (Boolean(modelErrorLocal)) setActiveStep(activeStep + 1);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={() => handleClose()}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        {/* {modelId === null ? "Create Model" : "Edit Model"} */}
        Create Model
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={() => handleClose()}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ my: 4, mx: "auto", maxWidth: 534 }}
          activeStep={activeStep}
          alternativeLabel
          nonLinear
        >
          {steps.map((label: string, i) => (
            <Step key={i}>
              <StepButton onClick={() => setActiveStep(i)}>{label}</StepButton>
              {/* <StepLabel>{label}</StepLabel> */}
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <Box>
            <Box>
              <Box sx={{ display: "grid", flexDirection: "row" }}>
                {/* <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >  */}
                <Box
                  sx={{
                    gridColumn: { sm: "span 2" },
                  }}
                >
                  <Typography className="label">Vehicle Model*</Typography>
                  <TextField
                    fullWidth
                    // error
                    // id="outlined-error-helper-text"
                    // label="Error"
                    // defaultValue="Hello World"
                    helperText={modelError?.model}
                    size="small"
                    placeholder="Enter Name"
                    value={model}
                    //required
                    error={Boolean(modelError?.model)}
                    onChange={handleValidation}
                  />
                </Box>
                {/* <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    width: "50%",
                  }}
                >
                  <Typography className="label"> Model Id</Typography>

                  <TextField
                    required
                    margin="dense"
                    id="model"
                    placeholder="Enter Id"
                    variant="outlined"
                    size="small"
                    value={id}
                    onChange={(e) => setId(e.target.value)}
                  ></TextField>
                </Box> */}
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label"> Vehicle Type*</Typography>
                  <Select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    displayEmpty
                  >
                    <MenuItem disabled value="">
                      <em>Select</em>
                    </MenuItem>

                    <MenuItem value="TWO">Two Wheeler</MenuItem>
                    <MenuItem value="THREE">Three Wheeler</MenuItem>
                  </Select>

                  {/* <TextField
                    margin="dense"
                    id="vehicle"
                    label="Vehicle Type"
                    variant="outlined"
                    select
                    sx={{ flexGrow: 1 }}
                    size="small"
                  >
                    {vehicleOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField> */}
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label"> Protocol*</Typography>
                  <Select
                    value={protocol}
                    onChange={(e) => {
                      setProtocol(e.target.value);
                      {
                        console.log("value ==>", e.target.value);
                      }
                      // setViewPlusProtocol("VIEW_PLUS" === e.target.value);
                      // setSmartPlusProtocol("SMART_PLUS" === e.target.value);
                      // setprotocolPNP("PNP" === e.target.value);
                      // setprotocolVIEW("VIEW" === e.target.value);
                      // setprotocolVPlus("VIEW_PLUS" === e.target.value);
                      // setprotocolSmart("SMART" === e.target.value);
                      // setprotocolSmartPlus("SMART_PLUS" === e.target.value);
                    }}
                    displayEmpty
                  >
                    <MenuItem disabled value="">
                      <em>Select</em>
                    </MenuItem>

                    {protocolOptData?.data?.map((name: any) => (
                      <MenuItem
                        key={name}
                        value={name}
                        onClick={() => setProtocolSelected(name)}
                      >
                        {name}
                      </MenuItem>
                    ))}
                    {console.log("protocolSelected =>", protocolSelected)}
                  </Select>
                </Box>
              </Box>
            </Box>
          </Box>
        )}

        {activeStep === 1 && (
          <Box>
            {/* {findingData?.data.map((pro:any) => {
                pro.data.type == "boolean" &&
                <>
                  <Typography>{pro.data.name}</Typography>
                  <input type="checkbox" />
                </> 
               pro.data.type == "number" &&
              <>
                <Typography>{pro.data.name}</Typography>
                <input type="number" />
                
              </> 
               pro.data.type == "string" &&
               <>
                 <Typography>{pro.data.name}</Typography>
                 <input type="text" />

               </> 
            
            }
              )}     
               */}
            <>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                {console.log("finding data is=> ", findingData)}
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 3,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Access Type</Typography>
                  {/* {JSON.stringify(protocolData)} */}

                  <Select
                    value={access}
                    onChange={(e) => setAccess(e.target.value)}
                    displayEmpty
                  >
                    <MenuItem disabled value="">
                      <em>Select</em>
                    </MenuItem>
                    {accessData?.data?.map((name: any) => (
                      <MenuItem key={name} value={name}>
                        {name}
                      </MenuItem>
                    ))}
                    {/* <MenuItem value="KEY">KEY</MenuItem>
    <MenuItem value="KEYLESS">KEYLESS</MenuItem>
    <MenuItem value="HYBRID">HYBRID</MenuItem> */}
                  </Select>
                </Box>

                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Wheel Diameter</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Wheel Diameter"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={cUvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcUvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;

                      // setValue(value);
                    }}
                  >
                    {/* {protocolOptions.map((option) => (
  <MenuItem key={option.value} value={option.value}>
    {option.label}
  </MenuItem>
))} */}
                  </TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Max Speed</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Max Speed"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMaxvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMaxvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Speed Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Speed Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMinsl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMinsl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Pickup Control Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Pickup Control Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={pcLimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setpcLimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Brake Regeneration Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Brake Regeneration Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={brGlimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbrGlimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Zero Throttle Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Zero Throttle Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={zLimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setzLimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Current Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Current Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMincl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMincl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={hillAssist}
                        onChange={(e) => setHillAssist(e.target.value)}
                      />
                    }
                    label="Hill Assist"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={parking}
                        onChange={(e) => setParking(e.target.value)}
                      />
                    }
                    label="Parking Status"
                  />
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={regenBraking}
                        onChange={(e) => setRegenBraking(e.target.value)}
                      />
                    }
                    label="Regenerative Braking Status"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={ebs}
                        onChange={(e) => setEbs(e.target.value)}
                      />
                    }
                    label="E-ABS Status"
                  />
                </Box>
              </Box>
            </>

            <>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Controller Under Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Under Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={cUVolL}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcUVolL(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Controller Over Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Over Voltage Limit"
                    variant="outlined"
                    type="number"
                    inputProps={{ min, max }}
                    size="small"
                    value={cOvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcOvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Battery Min Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Min Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMinvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMinvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    {" "}
                    Battery Max Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Max Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMaxvoltage}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setMaxVoltage(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;

                      // setValue(value);
                    }}
                  ></TextField>
                </Box>
              </Box>
            </>

            <>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 3,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Access Type</Typography>
                  <Select
                    value={access}
                    onChange={(e) => setAccess(e.target.value)}
                    displayEmpty
                  >
                    <MenuItem disabled value="">
                      <em>Select</em>
                    </MenuItem>

                    <MenuItem value="KEY">KEY</MenuItem>
                    <MenuItem value="KEYLESS">KEYLESS</MenuItem>
                    <MenuItem value="HYBRID">HYBRID</MenuItem>
                  </Select>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Wheel Diameter</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Wheel Diameter"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={cUvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcUvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;

                      // setValue(value);
                    }}
                  >
                    {/* {protocolOptions.map((option) => (
<MenuItem key={option.value} value={option.value}>
  {option.label}
</MenuItem>
))} */}
                  </TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Max Speed</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Max Speed"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMaxvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMaxvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Speed Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Speed Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMinsl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMinsl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Pickup Control Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Pickup Control Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={pcLimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setpcLimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Brake Regeneration Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Brake Regeneration Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={brGlimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbrGlimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Zero Throttle Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Zero Throttle Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={zLimit}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setzLimit(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">Current Limit</Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Current Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMincl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMincl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Controller Under Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Under Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={cUVolL}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcUVolL(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Controller Over Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Over Voltage Limit"
                    variant="outlined"
                    type="number"
                    inputProps={{ min, max }}
                    size="small"
                    value={cOvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setcOvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    Battery Min Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Min Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMinvl}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setbMinvl(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;
                    }}
                  ></TextField>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <Typography className="label">
                    {" "}
                    Battery Max Voltage Limit
                  </Typography>
                  <TextField
                    required
                    margin="dense"
                    id="vehicle"
                    label="Max Voltage Limit"
                    variant="outlined"
                    size="small"
                    type="number"
                    inputProps={{ min, max }}
                    value={bMaxvoltage}
                    onChange={(e) => {
                      var value = parseInt(e.target.value, 100);
                      setMaxVoltage(e.target.value);
                      if (value > max) value = max;
                      if (value < min) value = min;

                      // setValue(value);
                    }}
                  ></TextField>
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={hillAssist}
                        onChange={(e) => setHillAssist(e.target.value)}
                      />
                    }
                    label="Hill Assist"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={parking}
                        onChange={(e) => setParking(e.target.value)}
                      />
                    }
                    label="Parking Status"
                  />
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={regenBraking}
                        onChange={(e) => setRegenBraking(e.target.value)}
                      />
                    }
                    label="Regenerative Braking Status"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={ebs}
                        onChange={(e) => setEbs(e.target.value)}
                      />
                    }
                    label="E-ABS Status"
                  />
                </Box>
              </Box>
            </>
          </Box>
          // <Form/>
        )}

        {activeStep === 2 && (
          <Box sx={{ display: "flex", flexDirection: "row" }}>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                mt: 3,
                mr: 2,
                width: "100%",
              }}
            >
              <Box
                sx={{
                  display: "grid",
                  flexDirection: "row",
                  alignItems: "center",
                }}
              >
                {(protocolVIEW || protocolSmart || protocolSmartPlus) && (
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      mt: 2,
                      mr: 2,
                      width: "100%",
                    }}
                  >
                    <Typography className="label">Controller</Typography>
                    <Select
                      value={controller}
                      onChange={selectMultiple}
                      displayEmpty
                      multiple
                    >
                      <MenuItem disabled value="">
                        <em>Select</em>
                      </MenuItem>
                      {deviceData?.data[0]?.CONTROLLER?.map((val: any) => (
                        <MenuItem key={val.name} value={val.name}>
                          {val.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </Box>
                )}

                {(protocolPNP || protocolVPlus || protocolSmartPlus) && (
                  <>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "column",
                        mt: 2,
                        mr: 2,
                        width: "100%",
                      }}
                    >
                      <Typography className="label">Telematics</Typography>
                      <Select
                        value={telematics}
                        onChange={handleChange}
                        displayEmpty
                        multiple
                      >
                        <MenuItem disabled value="">
                          <em>Select</em>
                        </MenuItem>
                        {deviceData?.data[0]?.TELEMATICS?.map((val: any) => (
                          <MenuItem key={val.id} value={val.name}>
                            {val.name}
                          </MenuItem>
                        ))}
                        {/* {device?.map((el: any) => (
                  <MenuItem key={el.id} value={el.name}>
                    {el.name}
                  </MenuItem>
                ))}  */}
                      </Select>
                    </Box>
                  </>
                )}
              </Box>
            </Box>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          onClick={() => {
            if (activeStep === 0) {
              handleClose();
            } else {
              setActiveStep(activeStep - 1);
            }
          }}
        >
          {activeStep === 0 ? "Cancel" : "Previous"}
        </Button>
        <Button variant="contained" onClick={HandleNext}>
          {isLastStep ? "Save" : "Next"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateModel;
