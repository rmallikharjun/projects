// import React from 'react';
// import { utils } from '@rjsf/core';
// import {
//     Button,
//     TextField,
//     Dialog,
//     DialogActions,
//     DialogContent,
//     DialogTitle,
//     Box,
//     MenuItem,
//     Stepper,
//     Step,
//     IconButton,
//     StepButton,
//     Typography,
//     // Select,
//     Checkbox,
//     FormControlLabel,
// } from "@mui/material";
// import Select, { SelectChangeEvent } from "@mui/material/Select";

// const { isMultiSelect, getDefaultRegistry } = utils

// const ArrayFieldTemplate = (props: any) => {
//     const { schema, registry = getDefaultRegistry() } = props;
//     if (isMultiSelect(schema, registry.rootSchema)) {
//         return <DefaultFixedArrayFieldTemplate {...props} />;
//     } else {
//         return <DefaultNormalArrayFieldTemplate {...props} />;
//     }
// };
// const ArrayFieldTitle = ({ TitleField, idSchema, title, required }: any) => {
//     if (!title) {
//         return null;
//     }
//     const id = `${idSchema.$id}__title`;
//     return <TitleField id={id} title={title} required={required} />
// };
// //   const DefaultArrayItem = (props: any) => {
// //     // const itemStyle ={

// //     // }

// //   }
// const DefaultFixedArrayFieldTemplate = (props: any) => {
//     return (
//         <>
//             <fieldset className={props.className}>
//             <ArrayFieldTitle
//                 key = {`array-field-title- ${props.idSchema.$id}`}
//                 TitleField = {props.TitleField}
//                 idSchema = {props.idSchema}
//                 title = {props.uiSchema}
//                 required = {props.required}
//             />
//             </fieldset>
//         </>
//     )
// };
// const DefaultNormalArrayFieldTemplate = (props: any) =>{
//     return(
//         <>
//         <Box><Box/>
//         </>
//     )
// }
