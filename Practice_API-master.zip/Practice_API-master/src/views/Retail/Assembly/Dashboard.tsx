import { Fragment, useState, useEffect, useCallback } from "react";
import { Add, TuneOutlined } from "@mui/icons-material";
import {
  Box,
  Button,
  FormControlLabel,
  Checkbox,
  Grid,
  Pagination,
  Hidden,
} from "@mui/material";
import {
  authorizedFetch,
  drawer,
  setLoader,
  snackbar,
  API_METHODS,
} from "utils";
import Search from "components/Search";
import ViewSelector, { View } from "components/ViewSelector";
import ListView from "./List";
import CreateModel from "./Models";
import AddVehicle from "./Vehicles";
import AssemblyCard from "./AssemblyCard";
import AssemblyInfo from "./AssemblyInfo";
import { RETAIL_URL } from "utils/constants";
import { useMutation } from "react-query";

interface AssemblyProps {}

interface GetVehiclesType {
  first?: string;
  skip?: string;
  orderBy?: string;
  ascending?: string;
  search?: string;
}

const Assembly: React.FC<AssemblyProps> = (props) => {
  const [vehiclesData, setVehiclesData] = useState<any>({});
  const [activeCard, setActiveCard] = useState<number | null>(null);
  const [activeGridType, setActiveGridType] = useState<string>("grid");
  const [showDialog, setShowDialog] = useState<null | string>(null);
  // const [showSelectedOptions, setShowSeletcedOptions] = useState<number | null>(
  //   null
  // );
  const [totalVehiclesCount, setTotalVehiclesCount] = useState<number>(0);
  const [activePage, setActivePage] = useState<number>(1);
  const [createModalDataId, setCreateModalDataId] = useState<
    string | undefined
  >(undefined);
  // const [modelId,setModelId]
  const [vehicleId, setVehicleId] = useState<null | string>(null);
  const [showEditVehicle, setShowEditVehicle] = useState<boolean>(false);
  const [showEditModel, setShowEditModel] = useState<boolean>(false);

  // const editModelUrl = `${RETAIL_URL}/assembly/model/${createModalDataId}`;
  const createModelUrl = `${RETAIL_URL}/assembly/model/create`;
  const addVehicleUrl = `${RETAIL_URL}/assembly/vehicle/create`;
  // const editVehicleUrl = `${RETAIL_URL}/assembly/vehicle/${vehicleId}`;

  // const editVehicle = useMutation(
  //   `editModel`,
  //   (data: any) => {
  //     console.log("test print edit data ", data);

  //     return authorizedFetch(editVehicleUrl, {
  //       method: "PUT",
  //       headers: {
  //         "Content-Type": "application/json",
  //         token: "1234",
  //       },
  //       body: {
  //         specs: {
  //           COLOR: "Grey",
  //           tatoo: "Hello World",
  //         },
  //         components: {
  //           CONTROLLER: "abcd1234",
  //         },
  //       },
  //     });
  //   },
  //   {
  //     onSuccess: () => {
  //       setLoader(false);
  //       snackbar.success("Vehicle Updated");
  //     },
  //     onError: () => {
  //       snackbar.error("Error Updating Vehicle");
  //     },
  //   }
  // );

  // const editModel = useMutation(
  //   `editModel`,
  //   (data: any) => {
  //     console.log(editModelUrl);
  //     return authorizedFetch(editModelUrl, {
  //       method: "PUT",
  //       headers: {
  //         token: "1234",
  //       },
  //       body: {
  //         id: data.id,
  //         name: data.name,
  //         type: data.type,
  //         protocol: data.protocol,
  //         devices: [
  //           {
  //             category: "CONTROLLER",
  //             modelId: ["6235b5924bacc62e2ee0768a"],
  //           },
  //         ],
  //         specs: {
  //           COLOR: "RED",
  //           TEST: "1",
  //           alloyWheels: "true",
  //         },
  //         config: {
  //           hillAssist: false,
  //           wheelDiameter: data.cUvl,
  //           diskBrakes: true,
  //         },
  //       },
  //     });
  //   },

  //   {
  //     onSuccess: () => {
  //       snackbar.success(`Model edited`);
  //       setLoader(false);
  //     },
  //     onError: () => {
  //       snackbar.error(`Error editing Model`);
  //     },
  //   }
  // );

  const createModel = useMutation(
    `addModel`,
    (data: any) => {
      console.log("test print data ", data);

      return authorizedFetch(createModelUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          name: data.name,
          type: data.type,
          protocol: data.protocol,
          devices: [
            {
              category: "CONTROLLER",
              modelId: ["5ea8f3e7e03dd8000b9441b1"],
            },
          ],
          components: [
            {
              category: "BATTERY",
              modelId: ["5ea8f3e7e03dd8000b9441b1"],
            },
          ],
          config: {
            overVoltageLimit: data.cOvl,
            underVoltageLimit: data.cUVolL,
            batteryMinVoltage: data.bMinvl,
            batteryMaxVoltage: data.bMaxvoltage,
          },
        },
      });
    },
    {
      onSuccess: (res) => {
        console.log("error => ", res);
        if (res?.meta?.success === true) {
          snackbar.success("Model Added");
          setLoader(false);
        } else {
          snackbar.error("Error Adding Model");
        }
      },
      // onError: () => {

      // },
    }
  );
  const addVehicle = useMutation(
    `addVehicle`,
    (data: any, type: API_METHODS = "POST") => {
      console.log("test vehicle data is ", data);

      return authorizedFetch(addVehicleUrl, {
        method: type as API_METHODS,
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          vin: data.vin,
          model: "623aed7b42ef50096b5b211f",
          specs: {
            COLOR: "Red",
            tatoo: "Son of Sardar",
          },
          components: {
            CONTROLLER: "abcd1234",
          },
        },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Vehicle Added");
      },
      onError: () => {
        snackbar.error("Error adding Vehicle");
      },
    }
  );
  const getModelsListing = useMutation(
    ({
      first = "9",
      skip = "0",
      search = "",
      orderBy = "createdAt",
      ascending = "false",
    }: GetVehiclesType) =>
      authorizedFetch(
        `${RETAIL_URL}/assembly/model?first=${first}&skip=${skip}&search=${search}&orderBy=${orderBy}&ascending=${ascending}`
      )
  );

  const getVehiclesData = useCallback(
    (payload = {}) => {
      getModelsListing.mutate(payload, {
        onSuccess: (data: any) => {
          setVehiclesData(data);
          setTotalVehiclesCount(data?.meta?.totalCount);
        },
      });
    },
    [getModelsListing]
  );

  useEffect(
    () => {
      getVehiclesData();
      return () => {
        drawer.close();
      };
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  console.log("veh data ==> ", vehiclesData);

  const modelConfigdData = () => {
    authorizedFetch(`${RETAIL_URL}/inventory/protocol-config/SMART_PLUS`);
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        position: "relative",
      }}
    >
      <Box
        sx={{
          // p: 3,
          display: "flex",
          flexDirection: "column",
          width: "100%",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "56px",
            p: 3,
            mt: 4,
          }}
        >
          <Box sx={{ fontSize: 18, fontWeight: "bold", mt: 4 }}>Models</Box>
          <Box sx={{ display: "flex" }}>
            <ViewSelector
              extras={() => (
                <>
                  {activeGridType === "grid" ? (
                    <Hidden mdDown>
                      <Search
                        enableBorder
                        sx={{
                          width: 200,
                          p: 1,
                          pl: 1.5,
                          mr: 1.5,
                          height: 0.7,
                        }}
                        handleSearch={(val: string) => {
                          getVehiclesData({ search: val });
                        }}
                        persist
                        enableClear
                      />
                    </Hidden>
                  ) : null}
                  <Button
                    sx={{ mr: { xs: 1, md: 2 } }}
                    onClick={() => {
                      setCreateModalDataId(undefined);
                      setActiveCard(null);
                      // drawer.close();
                      setShowDialog("create");
                    }}
                  >
                    <Add />
                  </Button>
                </>
              )}
              view={activeGridType as View}
              setView={(type: View) => {
                drawer.close();
                setActiveCard(null);
                setShowEditVehicle(false);
                setShowEditModel(false);
                setCreateModalDataId(undefined);
                setActiveGridType(type);
              }}
            />
          </Box>
        </Box>
        {activeGridType === "grid" ? (
          <Fragment>
            <Box
              sx={{
                // mt: 4,
                p: 3,
                display: "flex",
                justifyContent: "flex-start",
              }}
            >
              {/* <Box
                sx={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  fontSize: 14,
                }}
              >
                <Box sx={{ mr: 2, display: "flex", alignItems: "center" }}>
                  <TuneOutlined style={{ marginRight: "10px" }} />
                  Protocol Filters:
                </Box>
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Bluetooth"
                />
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Sim"
                />
                <FormControlLabel
                  sx={{ fontWeight: 500 }}
                  control={<Checkbox checked={false} />}
                  label="Speedometer"
                />
              </Box> */}
            </Box>
            <Grid
              container
              spacing={2}
              columns={{ xs: 2, sm: 6, md: 6, lg: 12 }}
              sx={{
                pb: 2,
                pr: 3,
                pl: 3,
                maxHeight: "60vh",
                overflow: "auto",
              }}
            >
              {vehiclesData?.data?.map((data: any, index: number) => (
                <AssemblyCard
                  modelConfigdData={modelConfigdData}
                  data={data}
                  activeCard={activeCard}
                  index={index}
                  gridType={activeGridType}
                  activeGridType={activeGridType}
                  setActiveCard={(i) => {
                    setActiveCard(i);
                    setCreateModalDataId(data?._id);
                  }}
                  showDialog={setShowDialog}
                  editModel={
                    () => {
                      setShowDialog("create");
                      setShowEditModel(true);
                    }
                    // setEditData(editData)
                  }
                />
              ))}
            </Grid>
          </Fragment>
        ) : (
          <Fragment>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ListView
                onViewClick={(index: number, data: any) => {
                  // setActiveCard(index);
                  drawer.open(
                    <AssemblyInfo
                      modelConfigdData={modelConfigdData}
                      activeGridType={activeGridType}
                      gridType={activeGridType}
                      setActiveCard={setActiveCard}
                      data={data}
                      index={index}
                      editModel={(id: any) => {
                        setShowDialog("add");
                        setShowEditVehicle(true);
                        setCreateModalDataId(data?._id || undefined);
                        setVehicleId(id);
                        // updateModel.mutate();
                      }}
                    />
                  );
                }}
                // onSelectionChange={(rows: any) =>
                //   setShowSeletcedOptions(
                //     rows && rows.length ? rows.length : null
                //   )
                // }
              />
            </Box>
          </Fragment>
        )}
      </Box>
      <AddVehicle
        open={showDialog === "add"}
        handleClose={(data: any, type: API_METHODS = "POST") => {
          if (data) {
            addVehicle.mutate(data as any, "POST" as any);
          }
          //else {
          //   editVehicle.mutate(data as any, "PUT" as any);
          // }
          setShowDialog(null);
        }}
        modelId={createModalDataId}
        vehicleId={vehicleId}
        isEdit={showEditVehicle}
      />
      <CreateModel
        open={showDialog === "create"}
        handleClose={(data: any, type: API_METHODS = "POST") => {
          if (data) {
            createModel.mutate(data as any, "POST" as any);
          }

          setShowDialog(null);
        }}
        modelId={createModalDataId}
        isEdit={showEditModel}
      />
      {activeGridType === "grid" && (
        <Pagination
          sx={{
            display: "flex",
            justifyContent: "center",
            padding: "20px 0px",
          }}
          boundaryCount={1}
          count={Math.ceil(totalVehiclesCount / 10)}
          page={activePage}
          onChange={(e: any, value: number) => {
            if (typeof value === "number") {
              setActivePage(value);
              getVehiclesData({ skip: (value - 1) * 10 });
            }
          }}
        />
      )}
    </Box>
  );
};

export default Assembly;
