import { useState, useEffect } from "react";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  Divider,
  IconButton,
  Typography,
  FormControlLabel,
  Checkbox,
} from "@mui/material";

import { HighlightOff, Delete } from "@mui/icons-material";
import { useMutation } from "react-query";
import { authorizedFetch, drawer, snackbar } from "utils";
import { RETAIL_URL } from "utils/constants";

export const AddVehicle: React.FC<any> = ({
  open = false,
  handleClose = () => {
    // setDeviceId("");
    console.log("Clicked");
  },
  modelId = null,
  isEdit = false,
  vehicleId,
  data,
}) => {
  const [addOthers, setAddOthers] = useState<boolean>(false);
  // const [addController, setAddController] = useState<boolean>(false);
  const [vin, setVin] = useState("");
  // const [color, setColor] = useState("");
  //const [modelName, setModelName] = useState("");
  const [deviceId, setDeviceId] = useState("");
  const [macId, setMacId] = useState("");
  const [pin, setPin] = useState("");
  const [modelID, setModelId] = useState<any>([]);
  // const [getModel, setGetModel] = useState("");
  const color = "";
  const modelName = "";

  const selectedCardDetails: any = sessionStorage.getItem("selectedCard");

  // const url = `${RETAIL_URL}/assembly/model/624bf077f2ab25cbcdbd4ef9`;

  // const getModelData = useMutation(
  //   "getModelData",
  //   () =>
  //     authorizedFetch(url, {
  //       method: "GET",
  //     }),
  //   {
  //     onSuccess: (data: any) => {
  //       console.log("getModel data is =>", data);
  //       setGetModel(data);
  //     },
  //   }
  // );

  // useEffect(
  //   () => {
  //     getModelData.mutate();
  //   },
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  //   []
  // );

  const modelIdUrl = `${RETAIL_URL}/assembly/vehicle`;

  const getModelId = useMutation(
    "getModelId",
    () =>
      authorizedFetch(modelIdUrl, {
        method: "GET",
      }),
    {
      onSuccess: (data: any) => {
        console.log("getModel id data is =>", data);
        setModelId(data);
      },
    }
  );

  useEffect(
    () => {
      getModelId.mutate();
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  console.log("Model id is", data);

  console.log("Model id is:", modelID);

  const getVehicleUrl = `${RETAIL_URL}/assembly/vehicle/${vehicleId}`;

  const [vehicleData, setVehicleData] = useState<any>();
  // const [currentItemData, setCurrentItemData] = useState<any>({});

  const getVehicleData = useMutation(
    "vehicleData",
    () =>
      authorizedFetch(getVehicleUrl, {
        method: "GET",
      }),
    {
      onError: () => {
        snackbar.error(`Error Fetching Vehicle`);
      },
      onSuccess: (data: any) => {
        console.log("vehicleData =>", data);
        setVehicleData(data);
      },
    }
  );
  useEffect(() => {
    if (vehicleData?.data?.get) {
      console.log("vehicle data", vehicleData?.data?.get);
      // setCurrentItemData(vehicleData?.data?.get);
    }
  }, [vehicleData]);

  useEffect(
    () => {
      if (vehicleId !== null) {
        getVehicleData.mutate();
        return () => {
          drawer.close();
        };
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  return (
    <Dialog
      PaperProps={{
        sx: {
          maxWidth: 700,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
      open={open}
      onClose={handleClose}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        {isEdit ? "Edit Vehicle" : "Add Vehicle"}
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={() => handleClose()}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 1,
            display: "flex",
            flexDirection: "column",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        >
          <Box>
            <Typography className="label">Vin</Typography>
            <TextField
              fullWidth
              size="small"
              value={vin}
              placeholder="Vin"
              onChange={(e) => setVin(e.target.value)}
            />
          </Box>
        </Box>
        {JSON.parse(selectedCardDetails)?.includes("CONTROLLER") && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Typography className="label">Add Controller</Typography>
            <Box gridColumn={{ sm: "span 2" }}>
              <Typography className="label">Device ID</Typography>
              <TextField
                required
                fullWidth
                size="small"
                value={""}
                placeholder="Device ID"
                onChange={(e) => setDeviceId(e.target.value)}
              />
            </Box>

            {
              <Box gridColumn={{ sm: "span 1" }}>
                <Typography className="label">Mac ID</Typography>
                <TextField
                  fullWidth
                  size="small"
                  value={macId}
                  placeholder="Mac ID"
                  onChange={(e) => setMacId(e.target.value)}
                />
              </Box>
            }
            {
              <Box gridColumn={{ sm: "span 1" }}>
                <Typography className="label">Pin</Typography>
                <TextField
                  fullWidth
                  size="small"
                  value={pin}
                  placeholder="Pin"
                  onChange={(e) => setPin(e.target.value)}
                />
              </Box>
            }
          </Box>
        )}
        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 1,
            display: "flex",
            flexDirection: "column",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        >
          {!addOthers ? (
            <Button
              variant="text"
              sx={{ width: 166, mt: 1 }}
              onClick={() => setAddOthers(true)}
            >
              + Add More Fields
            </Button>
          ) : (
            <Box sx={{ display: "flex", flexDirection: "column", mt: 2 }}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <Box>Add Other Fields</Box>
                <Box>
                  <Button
                    onClick={() => setAddOthers(false)}
                    variant="text"
                    startIcon={<Delete />}
                    sx={{ color: "#5A607F" }}
                  >
                    Remove
                  </Button>
                </Box>
              </Box>
              <Divider sx={{ mb: 2, mt: 1 }} />

              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={vin}
                        onChange={(e) => setVin(e.target.value)}
                      />
                    }
                    label="Firmware"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={vin}
                        onChange={(e) => setVin(e.target.value)}
                      />
                    }
                    label="expected Firmware"
                  />
                </Box>
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={vin}
                        onChange={(e) => setVin(e.target.value)}
                      />
                    }
                    label="PinResetRequired"
                  />
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    mt: 2,
                    mr: 2,
                    width: "100%",
                  }}
                >
                  <FormControlLabel
                    sx={{ fontWeight: 500 }}
                    control={
                      <Checkbox
                        value={vin}
                        onChange={(e) => setVin(e.target.value)}
                      />
                    }
                    label="OdoResetRequired"
                  />
                </Box>
              </Box>
            </Box>
          )}
          {JSON.parse(selectedCardDetails)?.includes("SPEEDOMETER") && (
            <>
              <Typography className="label">Add Speedometer</Typography>
              <Box gridColumn={{ sm: "span 2" }}>
                <Typography className="label">Device ID</Typography>
                <TextField
                  required
                  fullWidth
                  size="small"
                  value={deviceId}
                  placeholder="Device ID"
                  onChange={(e) => setDeviceId(e.target.value)}
                />
              </Box>
            </>
          )}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          color="primary"
          onClick={() => handleClose()}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={() =>
            handleClose(
              {
                vin: vin,
                model: modelName,
                specs: {
                  COLOR: color,
                  tatoo: "Son of Sardar",
                },
                components: {
                  CONTROLLER: "abcd1234",
                },
              },
              isEdit ? "PUT" : "POST"
            )
          }
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddVehicle;
