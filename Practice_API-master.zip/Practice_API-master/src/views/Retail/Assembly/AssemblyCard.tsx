import { Box, Button, Grid, Card } from "@mui/material";
// import { Session } from "inspector";
import React from "react";
import { drawer } from "utils";
import img from "../../../assets/images/revoslogo.png";
import AssemblyInfo from "./AssemblyInfo";
import CustmChip from "./CustomChip";

interface AssemblyCardProps {
  modelConfigdData: () => void;
  data: any;
  activeCard: null | number;
  activeGridType: any;
  setActiveCard: (val: null | number) => void;
  gridType: string;
  showDialog: (val: string) => void;
  index: number;
  editModel: () => void;
}

const AssemblyCard: React.FC<AssemblyCardProps> = ({
  modelConfigdData,
  data,
  activeCard,
  index,
  setActiveCard,
  gridType,
  activeGridType,
  showDialog,
  editModel,
}) => {
  const activeCardStyles =
    activeCard === index
      ? {
          border: "2px solid #3CB99E",
        }
      : {};
  const assemble = (e: any) => {
    let componentData: any = [];
    data.components.forEach((component: any) => {
      componentData.push(component?.category);
    });
    sessionStorage.setItem("selectedCard", JSON.stringify(componentData));
    console.log("componentData : ", componentData);
    console.log("data =>", data);
    showDialog("add");
    e.preventDefault();
    e.stopPropagation();
  };
  // const modelUrl = `${RETAIL_URL}/assembly/model/623aed7b42ef50096b5b211f`;

  return (
    <Grid
      key={index}
      xs={2}
      sm={3}
      md={3}
      lg={activeCard !== null ? 6 : 4}
      item
      sx={{
        height: 310,
      }}
      onClick={(e: any) => {
        modelConfigdData();
        e.preventDefault();
        const activeVal = index === activeCard ? null : index;
        setActiveCard(activeVal);
        if (activeVal === null) {
          drawer.close();
        } else {
          console.log("id is: " + data?.id);
          drawer.open(
            <AssemblyInfo
              activeGridType={activeGridType}
              setActiveCard={setActiveCard}
              data={{ ...data }}
              editModel={editModel}
              gridType={gridType}
              index={index}
              modelConfigdData={modelConfigdData}
            />
          );
        }
      }}
    >
      <Card
        sx={{
          p: 1,
          borderRadius: "12px",
          cursor: "pointer",
          "&:hover": {
            border: "1px solid #3CB99E",
            // p:1
          },
          height: "100%",
          ...activeCardStyles,
        }}
      >
        <Box
          sx={{
            pb: 1,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box sx={{ fontWeight: "bold", fontSize: 16 }}>
            {console.log("vin ==> ", data)}
            {data.name || "Revos Test Encription"}
          </Box>
          <CustmChip label="Instock- 5 Left" />
        </Box>
        <Box sx={{ width: "100%" }}>
          <Box
            sx={{
              height: 137,
              background: `url(${img}) no-repeat`,
              // background: `url(${data?.owner?.companyLogo}) no-repeat`,
              backgroundSize: "cover",
              backgroundPositionY: "50%",
              borderRadius: "8px",
            }}
          />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row", mt: 1.5 }}>
          <CustmChip label="Bluetooth" sx={{ mr: 1.5 }} />
          <CustmChip label="Sim" sx={{ mr: 1.5 }} />
          <CustmChip label="Speedometer" />
        </Box>
        <Box
          sx={{
            mt: 2,
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Button
            variant="outlined"
            fullWidth
            // onClick={() => {}}
            sx={{ mr: 1, fontSize: 12 }}
          >
            VIEW INVENTORY
          </Button>
          <Button
            variant="contained"
            fullWidth
            onClick={assemble}
            sx={{ fontSize: 12 }}
          >
            ASSEMBLE
          </Button>
        </Box>
      </Card>
    </Grid>
  );
};

export default AssemblyCard;
