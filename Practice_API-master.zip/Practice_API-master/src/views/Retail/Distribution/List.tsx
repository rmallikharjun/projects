import { AddBoxOutlined } from "@mui/icons-material";
import {
  Box,
  Button,
  Hidden,
  Paper,
  Tab,
  Tabs,
  IconButton,
} from "@mui/material";
import { InfoOutlined } from "@mui/icons-material";
import Table from "components/Table";
import { useEffect, useState } from "react";
// import { useTheme } from "@emotion/react";
// import { useMediaQuery } from "@mui/material";
import { getPermissions } from "utils";
import AssignDistributor from "./AssignDistributor";
import moment from "moment";
// import { RETAIL_URL } from "utils/constants";
import Search from "components/Search";
import { getBoltToken } from "utils/request";
import storageManager from "utils/storageManager";
import TuneIcon from "@mui/icons-material/Tune";

//import RestrictedUsersDialog from "../../Charger/Chargers/RestrictedUsersDialog";
// import { useMutation } from "react-query";

const List = ({
  search,
  refetchStats,
  // totalChargers,
  totalBooked,
  totalAvailable,
  vendors,
  distVehiclesListData,
  onViewClick,
}: // setHealth,
any) => {
  // const theme = useTheme();
  // const isMdUp: boolean = useMediaQuery(theme.breakpoints.up("md"));
  // const [activePage, setActivePage] = useState<number>(1);
  const { canWrite } = getPermissions("retail:distribution");
  const [tab, setTab] = useState(0);
  // const [restrictedUsersDialog, setRestrictedUsersDialog] = useState({
  //   open: false,
  //   data: null,
  // });
  useEffect(() => {
    setVehiclesListData(vendors);
  }, [vendors]);
  const [vehiclesListData, setVehiclesListData] = useState<any>({});
  const [selectedRows, setSelectedRows] = useState<any>([]);
  const [distributors, setDistributors] = useState<any>([]);
  const [selectedDistributor, setSelectedDistributor] = useState<any>([]);
  const [vendorsDialog, setVendorsDialog] = useState({
    open: false,
    data: {},
  });
  console.log(vendorsDialog);

  console.log(vendors, "vendors");

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  // interface GetVehiclesType {
  //   first?: string | number;
  //   skip?: string | number;
  //   orderBy?: string;
  //   ascending?: string;
  //   search?: string;
  // }

  const markAsRental = async (vehicleId: string) => {
    try {
      let boltToken = await getBoltToken();
      let newHeaders = {
        token: storageManager?.get("companyToken") || "",
        Authorization: `Bearer ${boltToken}`,
      };
      const res = await fetch(
        `${
          process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
        }/distribution/${vehicleId}/mark-rental`,
        { headers: newHeaders, method: "POST" }
      ).then((res) => res.json());
      console.log(res, "response at rental vehicle");
    } catch (e: any) {
      console.log(e.message);
    }
  };

  const getDistributor = async () => {
    try {
      let boltToken = await getBoltToken();
      let newHeaders = {
        token: storageManager?.get("companyToken") || "",
        Authorization: `Bearer ${boltToken}`,
      };
      const res = await fetch(
        `${
          process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
        }/distribution/distributors`,
        { headers: newHeaders, method: "GET" }
      ).then((res) => res.json());
      setDistributors(res.data[0]);
      console.log(res.data[0], selectedRows, "response at distributors");
    } catch (e: any) {
      console.log(e.message);
    }
  };

  const assignDistributor = async () => {
    try {
      let body = {
        distributor: selectedDistributor,
        vehicles: selectedRows,
      };
      let boltToken = await getBoltToken();
      let newHeaders = {
        token: storageManager?.get("companyToken") || "",
        Authorization: `Bearer ${boltToken}`,
        "Content-Type": "application/json",
      };
      const res = await fetch(
        `${
          process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
        }/distribution/assign-distributor`,
        { headers: newHeaders, method: "POST", body: JSON.stringify(body) }
      ).then((res) => res.json());
      console.log(res, "response at assignDistributors");
    } catch (e: any) {
      console.log(e.message);
    }
  };

  // useEffect(() => {
  //   getVehiclesList.mutate(
  //     {
  //       first: 10,
  //       skip: (page - 1) * 10,
  //       orderBy: "vin",
  //       ascending: "true",
  //       search: "",
  //     },
  //     {
  //       onSuccess: (data: any) => {
  //         setVehiclesListData(data);
  //       },
  //     }
  //   );
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [page]);

  // useEffect(() => {
  //   return () => {
  //     drawer.close();
  //   };
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, []);
  // console.log("vehicleListData =>");

  return (
    <>
      {/* <RestrictedUsersDialog
        key={restrictedUsersDialog.data}
        open={restrictedUsersDialog.open}
        handleClose={() =>
          setRestrictedUsersDialog({ ...restrictedUsersDialog, open: false })
        }
        charger={restrictedUsersDialog.data}
      /> */}
      <Paper
        sx={{
          width: 1,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            p: { xs: 2, md: 3 },
            pb: 2.75,
            display: { xs: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Tabs
              value={tab}
              onChange={(e, tab) => setTab(tab)}
              {...(!search ? { className: "dense" } : {})}
              variant="scrollable"
            >
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${vehiclesListData?.meta?.totalCount}"`,
                  },
                }}
              />

              {!search && (
                <Tab
                  label="Assigned"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${totalBooked?.data?.count || "-"}"`,
                    },
                  }}
                />
              )}
              {!search && (
                <Tab
                  label="UnAssigned"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${totalAvailable?.data?.count || "-"}"`,
                    },
                  }}
                />
              )}
            </Tabs>
          </Box>
          <Box display="flex">
            <Hidden mdDown>
              {/* <Box mt={1} mr={2}></Box> */}
              <Box sx={{ pl: 50 }}>
                <Search
                  handleSearch={(val: string) => {
                    distVehiclesListData({ search: val });
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
          <Box sx={{ pr: 3 }}>
            <Button
              sx={{
                borderRadius: "4px",
                boxShadow: 1,
                color: "#000",
                background: "#f6f8fb",
                border: "none",
                width: "100%",
                "&:hover": {
                  border: "1px solid #000",
                },
              }}
              variant="outlined"
              startIcon={<TuneIcon />}
            >
              Filter By
            </Button>
          </Box>
        </Box>
        <Table
          // px={isMdUp ? 3 : 2}
          // rowCount={
          //   search
          //     ? // ? (data?.data?.chargers || []).length
          //       (distVehiclesListData || []).length
          //     : tab === 0
          //     ? totalChargers
          //     : tab === 1
          //     ? totalBooked
          //     : tab === 2
          //     ? totalAvailable
          //     : ""
          // }
          loading={!!!vehiclesListData?.data}
          setSelectedRows={(rows) => {
            if (selectedRows?.sort().join(",") !== rows?.sort().join(",")) {
              setSelectedRows(rows);
            }
          }}
          {...console.log("vehiclesListData =>", vehiclesListData)}
          {...(!search
            ? {
                serverSidePagination: true,
                activePage: page,
                activePageSize: pageSize,
                // onPageChange: (value) => setPage(value),
                onPageChange: (value) => {
                  setPage(value);
                  // setActivePage(value);
                  distVehiclesListData({ skip: (value - 1) * 10 });
                },
                onPageSizeChange: (value) => setPageSize(value),
                rowCount: vehiclesListData?.meta?.totalCount,
              }
            : {})}
          // loading={false}
          // setSelectedRows={setSelectedRows}
          selectedRows={selectedRows}
          selectable={canWrite}
          // selectOnClick
          // rows={data?.data?.chargers || []}
          rows={vehiclesListData?.data || []}
          {...console.log("vendors =>", vendors)}
          columns={[
            {
              key: "VIN",
              label: "Vin",
              Render: (row) => <Box sx={{ py: 2 }}>{row.vin}</Box>,
            },
            {
              key: "Model",
              label: "Model",
              Render: (row) => <Box>{row.model?.name}</Box>,
            },
            {
              key: "Status",
              label: "Status",
              Render: (row) => (
                <Box
                  sx={
                    row.status.toLowerCase() === "assigned"
                      ? {
                          background: "rgba(104,214,165,0.3)",
                          color: "#3CB99E",
                          fontSize: 12,
                          borderRadius: "4px",
                          display: "flex",
                          justifyContent: "center",
                          width: 100,
                          p: 0.2,
                        }
                      : {
                          background: "rgba(246,53,88,0.3)",
                          color: "#f63558",
                          fontSize: 12,
                          borderRadius: "4px",
                          display: "flex",
                          justifyContent: "center",
                          width: 100,
                          p: 0.2,
                        }
                  }
                >
                  {row.status}
                </Box>
              ),
            },
            {
              key: "Distributor",
              label: "Distributor",
              Render: (row) => <Box>{row.owner?.name}</Box>,
            },
            {
              key: "Assigned",
              label: "Assigned On",
              Render: (row) => (
                <Box>{moment(row.createdAt).format("MMM DD, hh:mm A")}</Box>
              ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                // <Button variant="action" onClick={() => onViewClick(row.id)}>
                //   View
                // </Button>
                <IconButton
                  size="small"
                  sx={{
                    ml: 0.5,
                    color: (theme) => theme.customColors.action,
                  }}
                  children={<InfoOutlined fontSize="small" />}
                  onClick={() => {
                    console.log(row, "row");
                    onViewClick(row._id);
                  }}
                />
              ),
            },
          ]}
          toolbar={() => (
            <>
              <Button
                sx={{ mr: 1.5 }}
                startIcon={<AddBoxOutlined />}
                onClick={() => {
                  setVendorsDialog({ open: true, data: selectedRows });
                  getDistributor();
                }}
              >
                Assign Distributor
              </Button>
              <Button
                sx={{ mr: 1.5 }}
                // startIcon={<AddBoxOutlined />}
                onClick={() => {
                  markAsRental(selectedRows);
                }}
              >
                Mark as Rental
              </Button>
              {/* <Button startIcon={<DeleteOutline />}>Delete</Button> */}
            </>
          )}
        />
      </Paper>
      <AssignDistributor
        open={vendorsDialog.open}
        data={vendorsDialog.data}
        handleClose={() => {
          setVendorsDialog({ ...vendorsDialog, open: false });
          assignDistributor();
        }}
        refetchStats={refetchStats}
        vendors={distributors || []}
        setSelectedDistributor={setSelectedDistributor}
      />
    </>
  );
};

export default List;
