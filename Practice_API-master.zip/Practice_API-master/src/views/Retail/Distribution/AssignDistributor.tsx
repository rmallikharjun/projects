import { useState, useEffect } from "react";
// import { authorizedFetch, snackbar } from "utils";
import {
  Dialog,
  IconButton,
  Typography,
  DialogActions,
  DialogContent,
  DialogTitle,
  Select,
  Box,
  Button,
  MenuItem,
} from "@mui/material";
import { HighlightOff } from "@mui/icons-material";

interface VendorProps {
  open: boolean;
  handleClose: () => void;
  data: any;
  vendors: any[];
  refetchStats: () => void;
  setSelectedDistributor: Function;
}

const AssignDistributor: React.FC<VendorProps> = ({
  open,
  handleClose,
  setSelectedDistributor,
  data,
  vendors,
  refetchStats,
}) => {
  const [selectedVendor, setSelectedVendor] = useState<string>(
    vendors[0]?.name
  );

  function onSave() {
    handleClose();
  }

  useEffect(() => {
    if (open && vendors) {
      setSelectedVendor(vendors[0]?.name);
    }
  }, [open, vendors]);

  return (
    <Dialog
      open={open}
      onClose={() => {
        handleClose();
      }}
      PaperProps={{
        sx: {
          maxWidth: 500,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Assign Distributor
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ py: 2 }}>
          Assigning <strong>{data.length} </strong> Distributors
        </Typography>

        <Typography sx={{ pt: 2 }}>Select Distributor</Typography>

        <Box sx={{ pt: 1 }}>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={selectedVendor}
            onChange={(e: any) => {
              const theVendor = vendors.filter(
                (el: any) => el.name === e.target.value
              );
              setSelectedDistributor(theVendor[0]._id);
              setSelectedVendor(e.target.value);
            }}
          >
            {vendors && vendors.constructor === Array
              ? vendors.map((filter, i) => (
                  <MenuItem key={i} value={filter.name}>
                    {filter.name}
                  </MenuItem>
                ))
              : null}
          </Select>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={onSave}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AssignDistributor;
