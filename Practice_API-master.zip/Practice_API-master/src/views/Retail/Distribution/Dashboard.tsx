import {
  BoltOutlined,
  PersonAddAlt1Outlined,
  HowToRegRounded,
  EditOutlined,
  DeleteOutline,
  CancelOutlined,
} from "@mui/icons-material";

import { useState, Fragment, useEffect, useCallback } from "react";
import { Box, Button, IconButton, Paper, Tab, Tabs } from "@mui/material";
// import Search from "components/Search";
import ChartCard from "./ChartCard";
import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";
import ViewSelector, { View } from "components/ViewSelector";
import ListView from "./List";
import { RETAIL_URL } from "utils/constants";

import {
  // BookDemo,
  SellVehicles,
} from "./PanelContents";
import BookmarkBorderOutlinedIcon from "@mui/icons-material/BookmarkBorderOutlined";
import PersonAddAltOutlinedIcon from "@mui/icons-material/PersonAddAltOutlined";
import { authorizedFetch, drawer, GlobalState } from "utils";
import { useSelector } from "react-redux";
import storageManager from "utils/storageManager";
import { getBoltToken } from "utils/request";
import { useMutation } from "react-query";
import moment from "moment";

const infoTabData = [
  { label: "VIN", value: "Vin" },
  { label: "Model", value: "Model" },
  { label: "Protocol", value: "Protocol" },
  { label: "Status", value: "Status" },
  // { label: "Vendor", value: "" },
  // { label: "Assigned On", value: "createdAt" },
];

// const elevationShadow =
//   "rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px";
// const activeButton = {
//   color: "#fff",
//   background: "#3CB99E",
// };

interface GetVehiclesType {
  startDate?: string;
  endDate?: string;
}

const DistributionInfo: React.FC<any> = ({ data }) => {
  console.log(data, "distribution data");
  const [activeTab, setActiveTab] = useState<string>("sell");

  const deleteVehicle = async (vehicleId: string) => {
    try {
      let boltToken = await getBoltToken();
      let newHeaders = {
        token: storageManager?.get("companyToken") || "",
        Authorization: `Bearer ${boltToken}`,
      };
      const res = await fetch(
        `${
          process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
        }/assembly/vehicle/${vehicleId}`,
        { headers: newHeaders, method: "DELETE" }
      ).then((res) => res.json());
      console.log(res, "response at delete vehicle");
    } catch (e: any) {
      console.log(e.message);
    }
  };

  const renderdata = (label: string) => {
    if (label === "VIN") return data?.vin;
    else if (label === "Model") return data?.model.name;
    else if (label === "Status") return data?.status;
    // else if (label === "vendor") return data?.owner?.name;
    else if (label === "Protocol") return data?.model.protocol;
  };

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          p: 1,
          background: "#03241d",
        }}
      >
        <Box sx={{ fontWeight: "bold", fontSize: 14, color: "#f6f8fb" }}>
          Revos Test Encription
        </Box>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
          >
            <EditOutlined />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => {
              deleteVehicle(data._id);
            }}
          >
            <DeleteOutline />
          </IconButton>
          <IconButton
            size="small"
            sx={{
              color: "#fff",
              mr: 0.8,
            }}
            onClick={() => drawer.close()}
          >
            <CancelOutlined />
          </IconButton>
        </Box>
      </Box>
      <Box p={2}>
        <Box
          sx={{
            background: "#f6f8fb",
            borderRadius: "6px",
            p: 1,
            fontSize: "14px",
            fontWeight: "bold",
          }}
        >
          Basic Info
        </Box>
        <Box
          sx={{
            width: "100%",
            p: 1,
          }}
        >
          {infoTabData.map((infoData: any, index: number) => (
            <Box
              key={index}
              sx={{ display: "flex", justifyContent: "space-between" }}
              mt={1}
              mb={1}
            >
              <Box
                component="span"
                sx={{ fontSize: 14, width: "50%", fontWeight: "bold" }}
              >
                {infoData.label || "Test"}
              </Box>
              <Box component="span" sx={{ fontSize: 14, width: "50%" }}>
                {renderdata(infoData.label)}
              </Box>
            </Box>
          ))}
        </Box>
        {/* <Box mt={1.5}> */}
        <Tabs
          value={activeTab}
          onChange={(_, val) => setActiveTab(val)}
          centered
        >
          <Tab value="sell" sx={{ width: "50%" }} label="Sell Vehicles" />
          {/* <Tab value="book" sx={{ width: "50%" }} label="Book Demo" /> */}
        </Tabs>
        {console.log(data, "data")}
        {activeTab === "sell" && (
          <SellVehicles vehicleId={data?._id} handleClose={() => {}} />
        )}
        {/* {activeTab === "book" && <BookDemo />} */}
        {/* </Box> */}
      </Box>
    </>
  );
};

const Distribution = () => {
  const [activeGridType, setActiveGridType] = useState<string>("grid");
  // eslint-disable-next-line
  const [tab, setTab] = useState("all");
  // eslint-disable-next-line
  const [activeCard, setActiveCard] = useState<number | null>(null);
  // const [activeTab, setActiveTab] = useState<string>("sell");
  const [showSelectedOptions, setShowSeletcedOptions] = useState<number | null>(
    null
  );
  const [vehiclesList, setVehiclesList] = useState<any>([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [distInsightsModels, setDistInsightsModels] = useState<any>([{}]);
  const [distInsights, setDistInsights] = useState<any>([{}]);
  const [distInsightsSummary, setDistInsightsSummary] = useState<any>([{}]);
  const [distInsightsStatusSummary, setDistInsightsStatusSummary] =
    useState<any>([{}]);

  const vehicleDistribution = useMutation(
    ({
      startDate = "2022-01-01",
      endDate = moment().format("yyyy-MM-DD"),
    }: GetVehiclesType) =>
      authorizedFetch(
        `${RETAIL_URL}/distribution/analytics?startDate=${startDate}&endDate=${endDate}`
      )
  );

  const getVehicleDistribution = useCallback(
    (payload = {}) => {
      vehicleDistribution.mutate(payload, {
        onSuccess: (res: any) => {
          console.log("data ==> ", res);
          setDistInsightsModels(res.data[0]?.vehicleModels.slice(0, 5));
          setDistInsights(res.data[0]?.soldVehicles);
          setDistInsightsSummary(res.data[0]?.distributorsSummary);
          setDistInsightsStatusSummary(res.data[0]?.statusSummary);
          // setDistSummary(res.data[0].distributorsSummary)
        },
      });
    },
    [vehicleDistribution]
  );

  const getDistVehiclesList = useMutation(
    ({
      first = "10",
      skip = "0",
      orderBy = "createdAt",
      ascending = "false",
      search = "",
    }: any) =>
      authorizedFetch(
        `${RETAIL_URL}/assembly/vehicle?first=${first}&skip=${skip}&search=${search}&orderBy=${orderBy}&ascending=${ascending}`
      )
  );

  const distVehiclesListData = useCallback(
    (payload = {}) => {
      getDistVehiclesList.mutate(payload, {
        onSuccess: (data: any) => {
          console.log("vehicle list distdata ==> ", data);
          setVehiclesList(data);
        },
      });
    },
    [getDistVehiclesList]
  );

  useEffect(() => {
    distVehiclesListData();
    getVehicleDistribution();
    // eslint-disable-next-line  react-hooks/exhaustive-deps
  }, []);

  // const getVehicleData = async () => {
  //   try {
  //     let boltToken = await getBoltToken();
  //     let newHeaders = {
  //       token: storageManager?.get("companyToken") || "",
  //       Authorization: `Bearer ${boltToken}`,
  //     };
  //     const res = await fetch(
  //       `${
  //         process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
  //       }/assembly/vehicle?first=${pageSize}&skip=${
  //         (page - 1) * pageSize
  //       }&orderBy=vin&ascending=true`,
  //       { headers: newHeaders }
  //     ).then((res) => res.json());
  //     console.log(res, "response at get vehicle");
  //     setVehiclesList(res.data);
  //   } catch (e: any) {
  //     console.log(e.message);
  //   }
  // };

  // useEffect(() => {
  //   getVehicleData();
  // }, []);
  //const [showDialog, setShowDialog] = useState<boolean>(false);

  const { drawer: rightDrawerPanel } = useSelector(
    (state: GlobalState) => state.global
  );

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "row",
        position: "relative",
        overflow: "auto",
        height: "calc(100vh - 68px)",
      }}
    >
      <Box sx={{ display: "flex", flexDirection: "column", flex: 1 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            height: "56px",
            p: 3,
            mt: 4,
          }}
        >
          <Box sx={{ fontSize: 18, fontWeight: "bold", mt: 1.5 }}>
            Distributor
          </Box>
          <Box sx={{ display: "flex" }}>
            <ViewSelector
              extras={() => (
                <>
                  {/* {activeGridType === "grid" ? (
                    <Search
                      enableBorder
                      sx={{
                        width: 300,
                        p: 1,
                        pl: 1.5,
                        mr: 1.5,
                      }}
                      handleSearch={() => {}}
                    />
                  ) : null} */}
                </>
              )}
              view={activeGridType as View}
              setView={(type: View) => {
                if (type === "grid") {
                  drawer.close();
                }
                setActiveGridType(type);
              }}
            />
          </Box>
        </Box>
        {activeGridType === "grid" ? (
          <Fragment>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                p: 3,
                // overflow: "auto",
                // height: "calc(100vh - 168px)",
              }}
            >
              <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                <ChartCard
                  distInsights={distInsights}
                  distInsightsModels={distInsightsModels}
                  type="bar"
                  title="Vehicle Models"
                  color="#ffcd4f"
                  sx={{ width: "60%", mr: 3 }}
                />
                <ChartCard
                  distInsights={distInsights}
                  distInsightsModels={distInsightsModels}
                  type="doughnut"
                  title="Vehicle Models"
                  color="#ffcd4f"
                  sx={{ width: "40%", minWidth: "fit-content" }}
                />
              </Box>
              <Box sx={{ display: "flex", flexDirection: "row" }}>
                <ChartCard
                  distInsightsModels={distInsightsModels}
                  distInsights={distInsights}
                  type="line"
                  title="Sold Vehicle Insights"
                  color="#8acdff"
                  sx={{ width: "60%", mr: 3 }}
                />
                <Paper
                  sx={{
                    height: 388,
                    gridColumn: "span 3",
                    p: 3,
                    display: "flex",
                    flexDirection: "column",
                    width: "40%",
                    borderRadius: "12px",
                  }}
                >
                  <Box sx={{ fontWeight: 700 }}>Distributors Summary</Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-evenly",
                      alignItems: "strech",
                      height: "100%",
                    }}
                  >
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        height: "100%",
                        alignItems: "center",
                      }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: "14px",
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <DirectionsCarIcon
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            {distInsightsSummary[0]?.count}
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Total Distributors</Box>
                        </Box>
                      </Paper>
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          border: "0.3px solid #e3e3e3",
                          mr: 1,
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <PersonAddAlt1Outlined
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            {distInsightsSummary[1]?.count}
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Total SubDistributors</Box>
                        </Box>
                      </Paper>
                    </Box>
                    <Box sx={{ fontWeight: 700, mt: 7 }}>Status Summary</Box>
                    <Box
                      sx={{
                        display: "flex",
                        flexDirection: "row",
                        justifyContent: "space-between",
                        height: "100%",
                        alignItems: "center",
                      }}
                    >
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: "14px",
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <HowToRegRounded
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            {distInsightsStatusSummary[0]?.count}
                          </Box>
                          <Box sx={{ fontSize: 14 }}>Assigned Distributors</Box>
                        </Box>
                      </Paper>
                      <Paper
                        elevation={0}
                        sx={{
                          width: "50%",
                          height: 100,
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                          p: 1,
                          mr: 1,
                          border: "0.3px solid #e3e3e3",
                        }}
                      >
                        <Box
                          sx={{
                            background: "rgba(104,214,165,0.5)",
                            borderRadius: "5rem",
                            mr: 1,
                            p: 1,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                          }}
                        >
                          <BoltOutlined
                            style={{ color: "#3CB99E", fontSize: 32 }}
                          />
                        </Box>
                        <Box>
                          <Box sx={{ fontWeight: "bolder", fontSize: 24 }}>
                            {distInsightsStatusSummary[1]?.count}
                          </Box>
                          <Box sx={{ fontSize: 13 }}>
                            UnAssigned Distributors
                          </Box>
                        </Box>
                      </Paper>
                    </Box>
                  </Box>
                </Paper>
              </Box>
            </Box>
          </Fragment>
        ) : (
          <Box sx={{ ml: 3, mt: 2, mr: activeCard !== null ? 0 : 3 }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                height: "5px",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                  p: 3,
                }}
              >
                <Box>
                  {showSelectedOptions &&
                    tab === "unassigned" &&
                    activeCard === null && (
                      <>
                        <Button
                          sx={{
                            color: "#000",
                          }}
                          variant="text"
                          startIcon={<PersonAddAltOutlinedIcon />}
                          // onClick={() => setShowDialog(true)}
                        >
                          Assign Distributor
                        </Button>
                        <Button
                          sx={{
                            color: "#000",
                          }}
                          variant="text"
                          startIcon={<BookmarkBorderOutlinedIcon />}
                        >
                          Mark As Rental
                        </Button>
                      </>
                    )}
                </Box>
                {/* <Button
                  sx={{
                    borderRadius: "4px",
                    boxShadow: elevationShadow,
                    color: "#000",
                    background: "#f6f8fb",
                    border: "none",
                    mt: 10,
                    "&:hover": {
                      border: "1px solid #000",
                    },
                  }}
                  variant="outlined"
                  startIcon={<TuneOutlined />}
                >
                  Filter By
                </Button> */}
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: rightDrawerPanel.open ? "calc(100vw - 678px)" : "100%",
              }}
            >
              <ListView
                vendors={vehiclesList}
                page={page}
                setPage={setPage}
                pageSize={pageSize}
                distVehiclesListData={distVehiclesListData}
                setPageSize={setPageSize}
                onViewClick={(vehicleId: string) => {
                  console.log(vehiclesList, vehicleId);
                  const vehicle = vehiclesList?.data?.filter(
                    (veh: any) => veh._id === vehicleId
                  );
                  console.log("output is: ", vehicleId, vehicle);
                  // setActiveCard(index);
                  drawer.open(
                    // <DistributionInfo data={DistributionData.data[index]} />
                    <DistributionInfo data={vehicle[0]} />
                  );
                }}
                onSelectionChange={(rows: any) =>
                  setShowSeletcedOptions(
                    rows && rows.length ? rows.length : null
                  )
                }
              />
            </Box>
          </Box>
        )}
      </Box>

      {/* <AssignDistributor
        open={showDialog}
        handleClose={() => setShowDialog(false)}
      /> */}
    </Box>
  );
};

export default Distribution;
