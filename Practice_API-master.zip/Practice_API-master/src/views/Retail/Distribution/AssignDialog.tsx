import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Box,
  Button,
  MenuItem,
  TextField,
} from "@mui/material";
import { CancelOutlined } from "@mui/icons-material";

const distOptions: Array<{ label: string; value: string }> = [];

export const AssignDistributor: React.FC<any> = ({
  open = false,
  handleClose = () => {},
}) => {
  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          width: "41vw",
          maxWidth: "60vw",
          position: "relative",
          padding: "10",
          height: "40%",
        },
      }}
    >
      <DialogTitle>Assign Distributor</DialogTitle>
      <DialogContent>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            mr: 2,
            mt: 2,
            width: "100%",
          }}
        >
          Select Distributor
          <TextField
            margin="dense"
            id="dist"
            label="Select"
            variant="outlined"
            select
            sx={{ width: "100%" }}
            size="small"
          >
            {distOptions.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
        </Box>
        <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 1 }}>
          <Button
            variant="outlined"
            sx={{ mt: 3, mr: 2, width: "28%" }}
            size="large"
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            sx={{ mt: 3, mr: 2, width: "28%" }}
            size="large"
          >
            Save
          </Button>
        </Box>
        <CancelOutlined
          onClick={handleClose}
          style={{
            position: "absolute",
            top: 12,
            right: 12,
            fontSize: 22,
            cursor: "pointer",
          }}
        />
      </DialogContent>
    </Dialog>
  );
};
