import { Box } from "@mui/system";
import React from "react";
import { useState } from "react";
import {
  Button,
  TextField,
  DialogContent,
  Stepper,
  Step,
  StepButton,
} from "@mui/material";
// import { getBoltToken } from "utils/request";
// import storageManager from "utils/storageManager";

interface PanelContentsProps {
  vehicleId: String;
  handleClose: any;
}

export const SellVehicles: React.FC<PanelContentsProps> = (
  { handleClose = () => {} },
  vehicleId: string
) => {
  const [userDetails, setUserDetails] = useState({
    firstName: null,
    lastName: null,
    phone: null,
    address: null,
    email: null,
  });
  const [activeStep, setActiveStep] = useState(0);

  // const saveFormValues = async () => {
  //   try {
  //     let body = {
  //       firstName: userDetails.firstName,
  //       lastName: userDetails.lastName,
  //       phone: userDetails.phone,
  //       address: userDetails.address,
  //     };
  //     let boltToken = await getBoltToken();
  //     let newHeaders = {
  //       token: storageManager?.get("companyToken") || "",
  //       Authorization: `Bearer ${boltToken}`,
  //     };
  //     const res = await fetch(
  //       `${
  //         process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
  //       }/distribution/${vehicleId}/sell-vehicle`,

  //       { headers: newHeaders,
  //         method: "POST",
  //          body: JSON.stringify(body) }
  //     ).
  //     then((res) => res.json());
  //     console.log(JSON.stringify(vehicleId), "response at sell vehicle");
  //   }
  //   catch (e: any) {
  //     console.log(e.message);
  //   }
  // };

  // const saveFormValues = async () => {
  //   try {
  //     // let body = {
  //     //   firstName: userDetails.firstName,
  //     //   lastName: userDetails.lastName,
  //     //   phone: userDetails.phone,
  //     //   address: userDetails.address,
  //     // };
  //     // let boltToken = await getBoltToken();
  //     // let newHeaders = {
  //     //   token: storageManager?.get("companyToken") || "",
  //     //   Authorization: `Bearer ${boltToken}`,
  //     // };
  //     // const res = await fetch(
  //     //   `${
  //     //     process.env.REACT_APP_RETAIL_URL || "https://retail.dev.revos.in"
  //     //   }/distribution/${vehicleId}/sell-vehicle`,
  //     //   { headers: newHeaders, method: "POST", body: JSON.stringify(body) }
  //     // ).then((res) => res.json());
  //     console.log(JSON.stringify(vehicleId), "response at sell vehicle");
  //   } catch (e: any) {
  //     console.log(e.message);
  //   }
  // };

  const steps = [
    "User info",
    // "Vehicle warranty",
    // "Invoice"
  ];
  const isLastStep = activeStep === steps.length - 1;
  return (
    <Box sx={{ width: "100%", mt: 1.5 }}>
      {/* export default function HorizontalLabelPositionBelowStepper() { */}
      <DialogContent>
        <Stepper activeStep={activeStep} alternativeLabel nonLinear>
          {steps.map((label: string, i) => (
            <Step key={i}>
              <StepButton onClick={() => setActiveStep(i)}>{label}</StepButton>
              {/* <StepLabel>{label}</StepLabel> */}
            </Step>
          ))}
        </Stepper>
        {activeStep === 0 && (
          <Box>
            <Box
              sx={{
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
                overflow: "auto",
                height: "32vh",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                First Name
                <TextField
                  required
                  margin="dense"
                  id="fname"
                  label="First Name"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                  onChange={(e: any) => {
                    setUserDetails({
                      ...userDetails,
                      firstName: e.target.value,
                    });
                  }}
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 1.5,
                }}
              >
                Last Name
                <TextField
                  margin="dense"
                  id="lname"
                  label="Last Name"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                  onChange={(e: any) => {
                    setUserDetails({
                      ...userDetails,
                      lastName: e.target.value,
                    });
                  }}
                />
              </Box>

              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Phone no
                <TextField
                  required
                  margin="dense"
                  id="mobilenum"
                  label="Phone no"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                  onChange={(e: any) => {
                    setUserDetails({ ...userDetails, phone: e.target.value });
                  }}
                />
              </Box>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Email Id
                <TextField
                  required
                  margin="dense"
                  id="email"
                  label="Email Id"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                  onChange={(e: any) => {
                    setUserDetails({ ...userDetails, email: e.target.value });
                  }}
                />
              </Box>

              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  mt: 1,
                  mr: 1,
                  flexGrow: 1,
                  lineHeight: 0.95,
                }}
              >
                Address
                <TextField
                  margin="dense"
                  id="loc"
                  label="Address"
                  variant="outlined"
                  sx={{ width: "100%" }}
                  size="small"
                  onChange={(e: any) => {
                    setUserDetails({ ...userDetails, address: e.target.value });
                  }}
                />
              </Box>
            </Box>
          </Box>
        )}
      </DialogContent>

      {/* <Button variant="contained" sx={{mt:2,width:"25%"}}>Next</Button> */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
        {activeStep !== 0 && (
          <Button
            variant="outlined"
            onClick={() => {
              if (activeStep === 0) {
                handleClose();
              } else {
                setActiveStep(activeStep - 1);
              }
            }}
            sx={{ mt: "10%", mr: 2, width: "30%", height: "40%" }}
          >
            {activeStep === 0 ? "Cancel" : "Previous"}
          </Button>
        )}

        <Button
          variant="contained"
          onClick={() => {
            if (isLastStep) {
              handleClose();
              setActiveStep(0);
              // saveFormValues();
            } else {
              setActiveStep(activeStep + 1);
            }
          }}
          sx={{ mt: "10%", width: "30%", height: "40%" }}
        >
          {isLastStep ? "Save" : "Next"}
        </Button>
      </Box>
    </Box>
  );
};
