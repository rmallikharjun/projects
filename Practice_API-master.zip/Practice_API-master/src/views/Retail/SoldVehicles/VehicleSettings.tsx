import { HighlightOff, Lock, LockOpen } from "@mui/icons-material";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import {
  Box,
  Button,
  Checkbox,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Fab,
  FormControlLabel,
  IconButton,
  Input,
  Slider,
  Switch,
  Tab,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "react-query";
import { snackbar } from "utils";
import storageManager from "utils/storageManager";
import DateAdapter from "@mui/lab/AdapterDateFns";
import TimePicker from "@mui/lab/TimePicker";
import moment from "moment";
import { TRIGGER_URL } from "utils/constants";

const VehicleSettings = ({ open, vehicle, onClose }: any) => {
  const token = storageManager.get("companyToken") || 1234;
  const vin = vehicle?.vin || "";

  const defaultTab = 0;
  const [tab, setTab] = useState(defaultTab);

  const existingValues = useMemo(
    () => ({
      overVoltageLimit: Number(vehicle?.model.config.overVoltageLimit || 0),
      underVoltageLimit: Number(vehicle?.model.config.underVoltageLimit || 0),
      batteryMinVoltage: Number(vehicle?.model.config.batteryMinVoltage || 0),
      batteryMaxVoltage: Number(vehicle?.model.config.batteryMaxVoltage || 0),
      ...(vehicle?.model?.protocol !== "PNP"
        ? {
            speedLimit: Number(vehicle?.model.config.speedLimit || 0),
            pickupControlLimit: Number(
              vehicle?.model.config.pickupControlLimit || 0
            ),
            brakeRegenLimit: Number(vehicle?.model.config.brakeRegenLimit || 0),
            zeroThrottleRegenLimit: Number(
              vehicle?.model.config.zeroThrottleRegenLimit || 0
            ),
            currentLimit: Number(vehicle?.model.config.currentLimit || 0),
            hillAssistStatus: Boolean(vehicle?.model.config.hillAssistStatus),
            eabsStatus: Boolean(vehicle?.model.config.eabsStatus),
          }
        : {}),
    }),
    [vehicle]
  );
  let settingsObj: { [key: string]: any } = {
    Antitheft: { enabled: false },
    "Geofence Alert": { enabled: false },
    Ignition: { enabled: false },
    "Device Plugged/Unplugged/Power Cut Off": { enabled: false },
    Overspeed: { enabled: false, value: "" },
    Curfew: { enabled: false, value: "" },
    "Offline Time": { enabled: false, value: "" },
    "Stop Time": { enabled: false, value: "" },
    "Idle Time": { enabled: false, value: "" },
  };

  const [values, setValues] = useState<any>({ ...existingValues });
  const [settings, setSettings] = useState<{ [key: string]: any }>({
    ...settingsObj,
  });
  const [curfewStart, setCurfewStart] = useState<Date | null>(null);
  const [curfewEnd, setCurfewEnd] = useState<Date | null>(null);
  const [recepientPhone, setRecepientPhone] = useState("");
  const [recepientEmail, setRecepientEmail] = useState("");

  const {
    data: notificationsData,
    isLoading: notificationsLoading,
    remove,
    refetch,
  } = useQuery(
    ["getNotificationSettings", token, vin],
    () =>
      fetch(
        `${"https://trigger.revos.in"}/getsettings?token=${token}&vin=${vin}`
      ).then((res) => res.json()),
    {
      enabled: Boolean(vin),
    }
  );

  useEffect(() => {
    if (open) {
      setTab(defaultTab);
      setValues({ ...existingValues });
    }
    // eslint-disable-next-line
  }, [open]);

  useEffect(() => {
    if (notificationsData && notificationsData.status === 200) {
      let { channels, notification } = notificationsData.response;

      setRecepientPhone(
        (channels || []).find((el: any) => el.type === "SMS")?.value || ""
      );
      setRecepientEmail(
        (channels || []).find((el: any) => el.type === "Email")?.value || ""
      );

      let newSettings = { ...settingsObj };
      Object.keys(settings).forEach((el) => {
        let existing = notification.find(
          (existing: any) => existing.name === el
        );
        if (existing) {
          newSettings[el].enabled = true;
          if (
            [
              "Overspeed",
              "Curfew",
              "Offline Time",
              "Stop Time",
              "Idle Time",
            ].includes(el)
          ) {
            let value = existing.trigger?.value;
            value = el === "Curfew" ? value.equalTo : value.greaterThan;
            newSettings[el].value = value;
            if (el === "Curfew") {
              setCurfewStart(moment(value.split("R")[0], "HH:mm:ss").toDate());
              setCurfewEnd(moment(value.split("R")[1], "HH:mm:ss").toDate());
            }
          }
        }
      });
      setSettings(newSettings);
    }
    // eslint-disable-next-line
  }, [notificationsData, notificationsLoading]);

  function handleChange(label: string, value?: any) {
    if (value === undefined) {
      setSettings((prev) => {
        prev[label].enabled = !prev[label].enabled;
        return { ...prev };
      });
    } else {
      setSettings((prev) => {
        prev[label].value = value;
        return { ...prev };
      });
    }
  }

  function handleNotificationsSave() {
    const channel = [recepientPhone, recepientEmail];
    let data: any = [];
    Object.keys(settings).forEach((el: any) => {
      if (settings[el].enabled) {
        data.push({
          name: el,
          value:
            el === "Curfew"
              ? moment(curfewStart).format("HH:mm:ss") +
                "R" +
                moment(curfewEnd).format("HH:mm:ss")
              : Object.keys(settings[el]).find((el) => el === "value")
              ? settings[el].value
              : "",
        });
      }
    });
    fetch(`${TRIGGER_URL}/notificationconfig`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        data,
        vin: vehicle.vin,
        type: "VEHICLE",
        channel,
      }),
    }).then((res) => {
      remove();
      refetch();
      snackbar.success("Saved changes");
    });
  }

  const isPnp = vehicle?.model?.protocol === "PNP";
  const hasChanges = JSON.stringify(existingValues) !== JSON.stringify(values);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        <Box display="flex" alignItems="center">
          Settings
          <Divider flexItem orientation="vertical" sx={{ mx: 1.5 }} />
          <Typography color="text.secondary">{vehicle?.vin}</Typography>
        </Box>
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={onClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        <Box pt={1} pb={4}>
          <Tabs sx={{ mb: 4 }} value={tab} onChange={(e, tab) => setTab(tab)}>
            <Tab label="Commands" />
            <Tab label="Limits" />
            <Tab label="Notifications" />
          </Tabs>
          {tab === 0 && <Commands vehicle={vehicle} />}
          {tab === 1 && (
            <Limits isPnp={isPnp} values={values} setValues={setValues} />
          )}
          {tab === 2 && (
            <Box
              sx={{
                width: 1,
                display: "grid",
                gridTemplateColumns: "1fr 2fr",
                rowGap: 1.5,
                columnGap: 1,
              }}
            >
              {notificationsLoading ? (
                <CircularProgress />
              ) : (
                Object.keys(settings).map((label, i) => {
                  if (i > 3)
                    return (
                      <Box
                        key={i}
                        sx={{
                          gridColumn: "span 2",
                          display: "grid",
                          gridTemplateColumns: "minmax(130px, auto) 1fr",
                          gap: 1,
                        }}
                      >
                        <FormControlLabel
                          key={i}
                          control={
                            <Checkbox
                              // size="small"
                              checked={settings[label].enabled}
                              onChange={() => handleChange(label)}
                            />
                          }
                          label={label}
                        />
                        {label !== "Curfew" ? (
                          <TextField
                            sx={{ maxWidth: 150 }}
                            size="small"
                            placeholder="Value"
                            value={settings[label]?.value || ""}
                            onChange={(e) =>
                              handleChange(label, e.target.value)
                            }
                            disabled={!settings[label]?.enabled}
                          />
                        ) : (
                          <LocalizationProvider dateAdapter={DateAdapter}>
                            <Box
                              sx={{
                                display: "flex",
                                alignItems: "center",
                              }}
                            >
                              <TimePicker
                                ampm={false}
                                openTo="hours"
                                views={["hours", "minutes", "seconds"]}
                                inputFormat="HH:mm:ss"
                                mask="__:__:__"
                                label="Start"
                                OpenPickerButtonProps={{ size: "small" }}
                                value={curfewStart}
                                onChange={(value) => {
                                  setCurfewStart(value);
                                }}
                                renderInput={(params) => (
                                  <TextField
                                    error={false}
                                    size="small"
                                    {...params}
                                  />
                                )}
                                disabled={!settings[label]?.enabled}
                              />
                              <Box mx={1}>to</Box>
                              <TimePicker
                                ampm={false}
                                openTo="hours"
                                views={["hours", "minutes", "seconds"]}
                                inputFormat="HH:mm:ss"
                                mask="__:__:__"
                                label="End"
                                OpenPickerButtonProps={{ size: "small" }}
                                value={curfewEnd}
                                onChange={(value) => {
                                  setCurfewEnd(value);
                                }}
                                renderInput={(params) => (
                                  <TextField
                                    error={false}
                                    size="small"
                                    {...params}
                                  />
                                )}
                                disabled={!settings[label]?.enabled}
                              />
                            </Box>
                          </LocalizationProvider>
                        )}
                      </Box>
                    );
                  else
                    return (
                      <FormControlLabel
                        key={i}
                        control={
                          <Checkbox
                            // size="small"
                            checked={settings[label].enabled}
                            onChange={() => handleChange(label)}
                          />
                        }
                        label={label}
                      />
                    );
                })
              )}
              <Box gridColumn="span 2" display="flex" flexDirection="column">
                <Divider sx={{ mt: 1, mb: 1.5 }} />
                <Typography variant="h6" sx={{ mb: 1.75 }}>
                  Specify Recepients
                </Typography>
                <TextField
                  sx={{ width: "fit-content", mb: 2 }}
                  size="small"
                  label="Phone"
                  value={recepientPhone}
                  onChange={(e) => setRecepientPhone(e.target.value)}
                />
                <TextField
                  sx={{ width: "fit-content" }}
                  size="small"
                  label="Email"
                  value={recepientEmail}
                  onChange={(e) => setRecepientEmail(e.target.value)}
                />
              </Box>
            </Box>
          )}
        </Box>
      </DialogContent>
      {tab !== 0 && (
        <DialogActions>
          {hasChanges && (
            <Button onClick={() => setValues({ ...existingValues })}>
              Undo Changes
            </Button>
          )}
          <Button
            variant="contained"
            onClick={() => {
              if (tab === 2) handleNotificationsSave();
            }}
          >
            Save
          </Button>
        </DialogActions>
      )}
    </Dialog>
  );
};

const Commands = ({ vehicle }: any) => {
  return (
    <Box
      sx={{
        pt: 8,
        pb: 10,
        mx: "auto",
        width: "fit-content",
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 4,
      }}
    >
      <Fab variant="extended">
        <Lock sx={{ mr: 1 }} />
        Lock
      </Fab>
      <Fab variant="extended">
        <LockOpen sx={{ mr: 1 }} />
        Unlock
      </Fab>
    </Box>
  );
};

const Limits = ({ isPnp, values, setValues }: any) => {
  return (
    <Box
      sx={{
        maxWidth: 500,
        mx: "auto",
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          sm: "1fr 1fr",
        },
        columnGap: 3,
        rowGap: 2,
      }}
    >
      {[
        ...(!isPnp
          ? [
              {
                id: "speedLimit",
                label: "Speed Limit",
              },
              {
                id: "pickupControlLimit",
                label: "Pickup",
              },
              {
                id: "brakeRegenLimit",
                label: "Regeneration on Braking",
              },
              {
                id: "zeroThrottleRegenLimit",
                label: "Regeneration on Zero Throttle",
              },
              {
                id: "currentLimit",
                label: "Current Limit",
              },
            ]
          : []),
        {
          id: "overVoltageLimit",
          label: "Controller Over Voltage Limit",
        },
        {
          id: "underVoltageLimit",
          label: "Controller Under Voltage Limit",
        },
        {
          id: "batteryMinVoltage",
          label: "Battery Minimum Voltage Limit",
        },
        {
          id: "batteryMaxVoltage",
          label: "Battery Maximum Voltage Limit",
        },
      ].map(({ id, label }, i) => (
        <Box key={i}>
          <Typography variant="body2">{label}</Typography>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr 30px",
              gap: 2,
            }}
          >
            <Slider
              min={0}
              max={id === "speedLimit" ? 150 : id === "currentLimit" ? 50 : 100}
              size="small"
              value={typeof values[id] === "number" ? values[id] : 0}
              onChange={(e, val) =>
                setValues((prev: any) => ({ ...prev, [id]: val }))
              }
            />
            <Input
              value={values[id]}
              size="small"
              onChange={(e) =>
                setValues((prev: any) => ({
                  ...prev,
                  [id]: e.target.value === "" ? "" : Number(e.target.value),
                }))
              }
              onBlur={() => {
                if (values[id] < 0) {
                  setValues((prev: any) => ({ ...prev, [id]: 0 }));
                } else if (values[id] > 100) {
                  setValues((prev: any) => ({ ...prev, [id]: 100 }));
                }
              }}
            />
          </Box>
        </Box>
      ))}
      {!isPnp && (
        <FormControlLabel
          sx={{ gridColumn: 1 }}
          control={
            <Switch
              checked={values?.hillAssistStatus || false}
              onChange={(e) =>
                setValues((prev: any) => ({
                  ...prev,
                  hillAssistStatus: e.target.checked,
                }))
              }
            />
          }
          label="Hill Assist"
        />
      )}
      {!isPnp && (
        <FormControlLabel
          control={
            <Switch
              checked={values?.eabsStatus || false}
              onChange={(e) =>
                setValues((prev: any) => ({
                  ...prev,
                  eabsStatus: e.target.checked,
                }))
              }
            />
          }
          label="E-ABS Status"
        />
      )}
    </Box>
  );
};

export default VehicleSettings;
