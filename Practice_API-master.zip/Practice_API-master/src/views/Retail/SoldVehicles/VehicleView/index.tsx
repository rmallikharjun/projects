import { Box, CircularProgress, Tab, Tabs } from "@mui/material";
import { useEffect, useState } from "react";
import VehicleMonitoring from "./VehicleMonitoring";
import BasicDetails from "./BasicDetails";
import RecentTrips from "./RecentTrips";
import { useQuery } from "@apollo/client";
import { GET_VEHICLE } from "../queries";
import { useHistory } from "react-router-dom";
import { snackbar } from "utils";

const VehicleView = ({ setVehicleData, match }: any) => {
  const vin = match.params.vin;
  const [tab, setTab] = useState(2);
  const [trip, setTrip] = useState(null);

  const history = useHistory();

  const { loading, data } = useQuery(GET_VEHICLE, {
    variables: {
      vin,
    },
    onError: (err) => {
      snackbar.error(`No vehicle found with VIN "${vin}"`);
      history.push("/sold-vehicles");
    },
  });

  useEffect(() => {
    setVehicleData(data || null);
    return () => {
      setVehicleData(null);
    };
    // eslint-disable-next-line
  }, [data]);

  useEffect(() => {
    if (!trip) return;
    setTab(2);
  }, [trip]);

  useEffect(() => {
    if (tab === 2) return;
    setTrip(null);
  }, [tab]);

  const vehicle = data?.vehicles?.get;

  return (
    <Box>
      <Box
        mb={2}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box width="fit-content">
          <Tabs
            className="less-dense"
            value={tab}
            onChange={(e, tab) => setTab(tab)}
          >
            <Tab label="Vehicle Details" />
            <Tab label="Recent Trips" />
            <Tab label="Monitor" />
          </Tabs>
        </Box>
        {/* <Button variant="contained" size="large" sx={{ textTransform: "none" }}>
          Request to Monitor
        </Button> */}
      </Box>
      {loading || !vehicle ? (
        <CircularProgress size={30} />
      ) : (
        <>
          {tab === 0 && <BasicDetails vehicle={vehicle} />}
          {tab === 1 && <RecentTrips vehicle={vehicle} setTrip={setTrip} />}
          {tab === 2 && (
            <VehicleMonitoring
              vehicle={vehicle}
              trip={trip}
              setTrip={setTrip}
            />
          )}
        </>
      )}
    </Box>
  );
};

export default VehicleView;
