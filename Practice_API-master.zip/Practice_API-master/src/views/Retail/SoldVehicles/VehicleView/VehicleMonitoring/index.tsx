import { useEffect, useRef, useState } from "react";
import RangePicker from "components/RangePicker";
import {
  FiberManualRecord,
  LockOpenOutlined,
  Lock,
  Pause,
  ArrowBack,
} from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import { DATAFEED_URL } from "utils/constants";
import { useSelector } from "react-redux";
import { authorizedFetch, GlobalState } from "utils";
import moment from "moment";
import useInterval from "use-interval";
import Stats from "./Stats";
import VehicleMap from "./VehicleMap";
import Chart from "./Chart";
import { useQuery } from "react-query";
const io = require("socket.io-client/dist/socket.io");

const LiveButton = ({ isLive, setIsLive }: any) => {
  const [hover, setHover] = useState(false);

  return (
    <Button
      size="small"
      variant="outlined"
      color="secondary"
      sx={{
        ml: 2,
        // color: theme => theme.customColors.grey,
      }}
      startIcon={
        isLive && hover ? (
          <Pause />
        ) : (
          <FiberManualRecord color={isLive ? "error" : "disabled"} />
        )
      }
      onClick={() => {
        setIsLive(!isLive);
        setHover(false);
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      Live
    </Button>
  );
};

const VehicleMonitoring = ({ vehicle, trip, setTrip }: any) => {
  const { vin } = vehicle;
  // const vin = "JOY_BLACK1"

  const socketRef = useRef<any>(null);
  const { company, token } = useSelector((state: GlobalState) => state.global);

  const [vehicleSnapshot, setVehicleSnapshot] = useState<any>(null);
  const [vehicleLogs, setVehicleLogs] = useState<any>(null);

  const [isLive, setIsLive] = useState(trip ? false : true);
  const [range, setRange] = useState<any>(null);

  const { data: tripData } = useQuery(
    ["getTrip", trip?.tripId],
    () =>
      authorizedFetch(
        `${DATAFEED_URL}/tripV2?token=${token}&id=${company.id}&tripid=${trip?.tripId}&vin=${vin}`
      ),
    {
      enabled: trip !== null,
    }
  );

  console.log(tripData);

  useEffect(() => {
    if (trip) {
      socketRef.current?.close();
    } else if (socketRef.current === null) {
      socketRef.current = io(DATAFEED_URL, {
        path: "/mysocket",
        transports: ["websocket", "xhr-polling", "jsonp-polling", "polling"],
      });
      const socket = socketRef.current;
      socket.on("RESPONSE:VEHICLE_LOGS_V2", (data: any) => {
        // console.log("VEHICLE_LOGS", data.responseData);
        setVehicleLogs(data.responseData);
      });
      socket.on("RESPONSE:VEHICLE_SNAPSHOT_V2", (data: any) => {
        // console.log('VEHICLE_SNAPSHOT', data.responseData)
        // let rideSelected = false;
        // if (isLive || rideSelected) {
        setVehicleSnapshot(data.responseData);
        // }
      });
      getSocketData();
    }

    return () => {
      socketRef.current?.close();
    };
    // eslint-disable-next-line
  }, [trip]);

  useInterval(
    () => {
      getSocketData();
    },
    isLive ? 5000 : null
  );

  useEffect(() => {
    if (isLive) {
      setRange(null);
      setTrip(null);
    }
    getSocketData();
    // eslint-disable-next-line
  }, [isLive]);

  useEffect(() => {
    if (range !== null) setIsLive(false);
    getSocketData();
    // eslint-disable-next-line
  }, [range]);

  useEffect(() => {
    if (!tripData) return;
    setVehicleLogs(tripData);
  }, [tripData]);

  function getSocketData() {
    const socket = socketRef.current;
    if (socket === null) return;
    // console.log('Getting data...')
    let search = {
      vin,
      startTime:
        isLive || !range ? "now-30m" : moment(range[0]).valueOf().toString(),
      endTime: isLive || !range ? "now" : moment(range[1]).valueOf().toString(),
    };
    socket.emit(
      "REQUEST:VEHICLE_LOGS_V2",
      JSON.stringify({
        companyId: company.id,
        isLive,
        search,
      })
    );
    socket.emit(
      "REQUEST:VEHICLE_SNAPSHOT_V2",
      JSON.stringify({
        companyId: company.id,
        vin,
      })
    );
  }

  console.log(vehicleLogs);
  console.log(tripData);

  return (
    <Paper
      sx={{
        width: 1,
        boxShadow: (theme) => theme.customShadows.small,
        borderRadius: 2,
        p: 3,
      }}
    >
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 2,
        }}
      >
        {trip ? (
          <Box display="flex" alignItems="center">
            <IconButton
              size="small"
              sx={{ mr: 0.5 }}
              onClick={() => {
                setIsLive(true);
              }}
            >
              <ArrowBack />
            </IconButton>
            <Typography>Trip ID:&nbsp;</Typography>
            <Typography fontWeight={500}>{trip.tripId}</Typography>
          </Box>
        ) : (
          <Box display="flex" alignItems="center">
            <Typography variant="h6" mr={2}>
              {vin}
            </Typography>
            {parseInt(vehicleSnapshot?.ignition?.lock || "") === 1 ||
            parseInt(vehicleSnapshot?.ignition?.ignition || "") === 0 ? (
              <Tooltip title="Unlocked">
                <LockOpenOutlined fontSize="small" color="action" />
              </Tooltip>
            ) : parseInt(vehicleSnapshot?.ignition?.lock || "") === 0 ||
              parseInt(vehicleSnapshot?.ignition?.ignition || "") === 1 ? (
              <Tooltip title="Locked">
                <Lock fontSize="small" color="action" />
              </Tooltip>
            ) : null}
          </Box>
        )}
        <Box display="flex" alignItems="center">
          {trip === null && (
            <RangePicker
              range={range}
              setRange={setRange}
              presets={["12H", "1D", "4D"]}
              initialRange={isLive ? undefined : "12H"}
            />
          )}
          <LiveButton isLive={isLive} setIsLive={setIsLive} />
        </Box>
      </Box>
      <Box
        sx={{
          width: 1,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1fr 1fr",
          },
          gap: { xs: 2, md: 3 },
          "& .MuiPaper-root": {
            width: 1,
            borderRadius: 2,
            border: 1,
            borderColor: (theme) => theme.customColors.border,
            boxShadow: (theme) => theme.customShadows.small,
            overflow: "hidden",
          },
        }}
      >
        <Stats vehicle={vehicle} data={{ vehicleSnapshot }} />
        <Box>
          <VehicleMap
            loading={[vehicleSnapshot, vehicleLogs].includes(null)}
            vehicleSnapshot={vehicleSnapshot}
            vehicleLogs={vehicleLogs}
            trip={trip}
            tripData={tripData}
            setVehicleSnapshot={setVehicleSnapshot}
          />
        </Box>
        <Chart type="voltage" vehicleLogs={vehicleLogs} />
        <Chart type="speed" vehicleLogs={vehicleLogs} />
      </Box>
    </Paper>
  );
};

export default VehicleMonitoring;
