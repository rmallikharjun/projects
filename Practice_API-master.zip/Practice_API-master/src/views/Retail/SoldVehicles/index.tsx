import { Settings } from "@mui/icons-material";
import { Box, Tabs, Tab, Paper, Button } from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Search from "components/Search";
import TableComponent from "components/Table";
import moment from "moment";
import { useState } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import { Route, Switch, useHistory, useRouteMatch } from "react-router-dom";
import { authorizedFetch, getDarkModePreference, GlobalState } from "utils";
import { HOTFIX_URL } from "utils/constants";
import VehicleSettings from "./VehicleSettings";
import VehicleView from "./VehicleView";

const SoldVehicles = () => {
  const { company } = useSelector((state: GlobalState) => state.global);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");

  const history = useHistory();
  const match = useRouteMatch("/sold-vehicles/:vin");

  const [vehicleData, setVehicleData] = useState<any>(null);
  const [vehicleSettingsDialog, setVehicleSettingsDialog] = useState({
    open: false,
    data: null,
  });

  const url = `${HOTFIX_URL}/retail/soldVehicles/getSoldVehicleData?companyId=${
    company.id
  }&first=${pageSize}&skip=${pageSize * (page - 1)}${
    search ? "&search=" + search : ""
  }`;

  const { isLoading, data } = useQuery(
    ["soldVehicles", page, pageSize, search],
    () => authorizedFetch(url)
  );

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
        {match && (
          <Box
            sx={{
              display: "flex",
              "& button": {
                minWidth: 40,
                height: 40,
                p: 0,
                border: 1,
                borderColor: (theme) => theme.customColors.border,
                bgcolor: isDarkMode ? "background.default" : "#fff",
              },
            }}
          >
            <Button
              disabled={!vehicleData}
              onClick={() => {
                setVehicleSettingsDialog({
                  open: true,
                  data: vehicleData?.vehicles?.get,
                });
              }}
            >
              <Settings />
            </Button>
          </Box>
        )}
      </Box>
      <VehicleSettings
        open={vehicleSettingsDialog.open}
        vehicle={vehicleSettingsDialog.data}
        onClose={() => {
          setVehicleSettingsDialog((prev) => ({ ...prev, open: false }));
        }}
      />
      <Switch>
        <Route
          exact
          path="/sold-vehicles"
          render={() => (
            <Paper
              sx={{
                width: 1,
                boxShadow: "0 0 4px #1C295A14",
                borderRadius: 2,
              }}
            >
              <Box
                sx={{
                  width: 1,
                  p: 3,
                  pb: 2.75,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Box width="fit-content">
                  <Tabs className="dense" value={0}>
                    <Tab
                      label="All"
                      className="hasCount"
                      sx={{
                        "&:after": {
                          content: `"${data?.data?.count || 0}"`,
                        },
                      }}
                    />
                  </Tabs>
                </Box>
                <Search
                  handleSearch={(value) => {
                    setPage(1);
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
                {/* <FilterBy /> */}
              </Box>
              <TableComponent
                loading={isLoading}
                rowCount={data?.data?.count}
                rows={data?.data?.vehicles || []}
                serverSidePagination
                activePage={page}
                activePageSize={pageSize}
                onPageChange={(value) => setPage(value)}
                onPageSizeChange={(value) => setPageSize(value)}
                columns={[
                  { key: "vin", label: "VIN" },
                  {
                    key: "model",
                    label: "Model",
                    format: (value) => value.name,
                  },
                  {
                    key: "protocol",
                    label: "Protocol",
                    Render: (row) => row.model.protocol,
                  },
                  {
                    key: "updatedAt",
                    label: "Updated At",
                    format: (value) => moment(value).format("MMM DD, YYYY"),
                  },
                  {
                    key: "actions",
                    label: "Actions",
                    Render: (row) => (
                      <Button
                        variant="action"
                        size="small"
                        onClick={() => {
                          history.push("/sold-vehicles/" + row.vin);
                        }}
                      >
                        View
                      </Button>
                    ),
                  },
                ]}
              />
            </Paper>
          )}
        />
        <Route
          path="/sold-vehicles/:vin"
          render={(props) => {
            return <VehicleView setVehicleData={setVehicleData} {...props} />;
          }}
        />
      </Switch>
    </>
  );
};

export default SoldVehicles;
