import { useEffect, useState } from "react";
import {
  Box,
  Paper,
  useTheme,
  CircularProgress,
  Autocomplete,
  TextField,
  useMediaQuery,
} from "@mui/material";
import { Bar } from "react-chartjs-2";
import { KeyboardArrowDown } from "@mui/icons-material";
import { format, sub } from "date-fns";
import { authorizedFetch, snackbar } from "utils";
import { useQuery } from "react-query";
import { BOLT_URL } from "utils/constants";
import RangePicker from "components/RangePicker";

const TopLeastRevenue = ({ statsLoading, stats, vendors }: any) => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const colors = {
    primary: "#57B8FD",
    secondary: "#FED337",
  };

  const [vendorList, setVendorList] = useState<any>([
    { id: "all", label: "All Vendors" },
  ]);
  const [selectedVendor, setSelectedVendor] = useState(vendorList[0]);

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const {
    totalEarnings,
    // totalChargers,
    // totalUsers,
    // totalBooked,
    totalEnergyConsumed,
  } = stats || {};

  useEffect(() => {
    if (vendors && vendors?.vendorsData?.data?.constructor === Array) {
      let newList = [{ id: "all", label: "All Vendors" }];
      // eslint-disable-next-line
      vendors?.vendorsData?.data?.map((el: any) => {
        newList.push({ id: el.id, label: el.name });
      });
      setVendorList(newList);
    }
  }, [vendors]);

  const [vendorsChartData, setVendorsChartData] = useState<any>(null);

  const vendorUrl = `${BOLT_URL}/company/stats/vendor/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}&vendorId=${
    selectedVendor?.id === "all" ? "" : selectedVendor?.id
  }`;

  const { isLoading, data: vendorsData } = useQuery(
    ["getVendorStatsByDate", dateFrom, dateTo, selectedVendor],
    () => authorizedFetch(vendorUrl),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (vendorsData?.data?.stats?.constructor === Array) {
      let chartData: any = {
        earnings: [],
      };
      // eslint-disable-next-line
      vendorsData?.data?.stats?.map((el: any) => {
        let date = format(new Date(el.date), "MMM d, yyyy");

        chartData.earnings.push({ x: date, y: el.totalEarnings });
      });

      setVendorsChartData(chartData);
    }
  }, [vendorsData]);

  console.log(vendorsData);

  return (
    <Paper
      sx={{
        height: 388,
        gridColumn: "span 3",
        p: 3,
        display: "flex",
        flexDirection: "column",
        borderRadius: "12px",
        boxShadow: "0 0 10px #1c295a14",
      }}
    >
      <Box
        sx={{
          gridColumn: { md: "span 5" },
          height: 1,
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Box
          mb={2.5}
          display="flex"
          flexDirection={{ xs: "column", sm: "row" }}
          justifyContent="space-between"
          alignItems={{ xs: "start", lg: "center" }}
        >
          <Box
            width={{ xs: 1, sm: "auto" }}
            display="grid"
            alignItems="center"
            justifyItems={{ xs: "center", sm: "end" }}
            gridTemplateColumns={{ xs: "auto", lg: "auto auto" }}
            gap={1.5}
          >
            <Autocomplete
              size="small"
              sx={{
                width: 140,
                "& .MuiOutlinedInput-input": { fontSize: 14, height: 20 },
              }}
              disableClearable
              popupIcon={<KeyboardArrowDown />}
              value={selectedVendor}
              onChange={(e: any, newValue: any) => {
                setSelectedVendor(newValue);
              }}
              options={vendorList}
              renderInput={(params: any) => (
                <TextField
                  {...params}
                  placeholder="Vendor"
                  sx={{ "& input": { pr: "16px !important" } }}
                />
              )}
            />
            <Box gridRow={{ xs: 1, lg: "unset" }}>
              <RangePicker range={range} setRange={setRange} />
            </Box>
          </Box>
        </Box>

        <Box
          flexGrow={1}
          minHeight={0}
          display="flex"
          justifyContent="center"
          alignItems="center"
        >
          {isLoading ? (
            <CircularProgress />
          ) : (
            <Bar
              data={{
                labels: vendorsChartData?.earnings?.map(
                  (el: any) => el.x.split(",")[0]
                ),
                datasets: [
                  {
                    fill: true,
                    data: vendorsChartData?.earnings?.map((el: any) => el.y),
                    borderWidth: 0,
                    backgroundColor: colors.primary,
                    borderRadius: 5,
                    barPercentage: 0.6,
                    maxBarThickness: 25,
                  },
                ],
              }}
              options={{
                scales: {
                  xAxis: {
                    grid: {
                      display: false,
                      tickWidth: 0,
                      tickLength: 16,
                      drawBorder: false,
                    },
                    ticks: {
                      display: true,
                    },
                  },
                  yAxis: {
                    title: {
                      display: true,
                      text: "Earnings (₹)",
                      padding: {
                        top: 0,
                        bottom: 8,
                      },
                      color: theme.customColors.grey,
                      font: {
                        weight: "500",
                        size: 12,
                      },
                    },
                    ticks: {
                      display: true,
                    },
                    grid: {
                      borderDash: [10],
                      tickWidth: 0,
                      tickLength: 16,
                      drawBorder: false,
                    },
                  },
                },
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    caretSize: 0,
                    mode: "index",
                    intersect: false,
                    yAlign: "center",
                    displayColors: false,
                    caretPadding: 16,
                    titleFont: {
                      weight: "400",
                    },
                    bodyFont: {
                      weight: "500",
                    },
                  },
                },
                interaction: {
                  mode: "index",
                  intersect: false,
                },
              }}
            />
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default TopLeastRevenue;
