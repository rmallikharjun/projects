import { Box, Divider, Paper } from "@mui/material";
import { Fragment } from "react";
import GraphCard from "./GraphCard";
import VehicleHealth from "./ServiceTicket";

const Dashboard = () => {
  // const [activeCard, setActiveCard] = useState<number | null>(null);
  return (
    <Fragment>
      <Box>
        <Box sx={{ display: "flex", flexDirection: "row" }}>
          <GraphCard
            id={1}
            type="bar"
            title="Inventory - Instock"
            color="#ffcd4f"
            sx={{ width: "55%", mr: 3 }}
            showDateFilter={false}
          />
          <GraphCard
            id={2}
            type="bar"
            title="Distribution"
            color="#ffcd4f"
            sx={{ width: "45%" }}
            showDateFilter={false}
          />
        </Box>
        <Paper
          sx={{
            display: "flex",
            flexDirection: "row",
            height: 340,
            // height: "100%",
            gridColumn: "span 3",
            width: "auto",
            borderRadius: "12px",
            mt: 3,
          }}
        >
          <GraphCard
            type="doughnut"
            title="Service Ticket"
            color="#8acdff"
            sx={{ width: "50%", height: "100%" }}
            showDateFilter={true}
          />
          <Divider orientation="vertical" flexItem />
          <Box
            sx={{
              ml: 3,
              mt: 3,
            }}
          >
            <Box sx={{ fontWeight: 700, fontSize: 18 }}>
              Service Ticket Title
            </Box>
            <Box sx={{ display: "flex", flexDirection: "row", mt: 3 }}>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  flexWrap: "wrap",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                  }}
                >
                  <Box>Tyre</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Motor</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Switches</Box>
                  <Box sx={{ fontWeight: 700 }}>03</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>DC Converter</Box>
                  <Box sx={{ fontWeight: 700, ml: 2 }}>04</Box>
                </Box>
              </Box>
              <Divider orientation="vertical" flexItem />
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  flexWrap: "wrap",
                  ml: 3,
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                  }}
                >
                  <Box>Tyre</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Motor</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Switches</Box>
                  <Box sx={{ fontWeight: 700, ml: 7 }}>03</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Others</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
              </Box>
              <Divider orientation="vertical" flexItem />
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  flexWrap: "wrap",
                  ml: 3,
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                  }}
                >
                  <Box>Tyre</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Motor</Box>
                  <Box sx={{ fontWeight: 700 }}>04</Box>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    mr: 2,
                    mt: 4,
                  }}
                >
                  <Box>Speedometer</Box>
                  <Box sx={{ fontWeight: 700, ml: 7 }}>03</Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Paper>
        <Paper
          sx={{
            display: "flex",
            flexDirection: "row",
            // height: 388,
            height: "100%",
            gridColumn: "span 3",
            width: "100%",
            borderRadius: "12px",
            mt: 3,
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <VehicleHealth />
            <VehicleHealth />
          </Box>
        </Paper>
      </Box>
    </Fragment>
  );
};

export default Dashboard;
