import { Box } from "@mui/material";
import Breadcrumbs from "../../../components/Breadcrumbs";
import Dashboard from "./Dashboard";

const Overview = () => {
  return (
    <>
      <Box
        width={1}
        mb={2}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>
      <Box
        sx={{
          width: 1,
        }}
      >
        <Dashboard />
      </Box>
    </>
  );
};

export default Overview;
