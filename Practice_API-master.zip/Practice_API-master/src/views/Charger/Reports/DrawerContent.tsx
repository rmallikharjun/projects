import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { saveAs } from "file-saver";
import {
  Autocomplete,
  Box,
  Button,
  Collapse,
  Dialog,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  IconButton,
  Radio,
  RadioGroup,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  authorizedFetch,
  getDarkModePreference,
  GlobalState,
  setLoader,
  snackbar,
} from "utils";
import RangePicker from "components/RangePicker";
import {
  CancelOutlined,
  KeyboardArrowDown,
  Launch,
  SaveAlt,
} from "@mui/icons-material";
import { sub } from "date-fns";
import { BOLT_URL, DATAFEED_URL, REPORTS_URL } from "utils/constants";
import { useQuery } from "react-query";
import moment from "moment";
import { saveReport } from "actions";

const DrawerContent = () => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const dispatch = useDispatch();
  const { company } = useSelector((state: GlobalState) => state.global);

  const [toggle, setToggle] = useState("vendors");
  // const [reportsFor, setReportsFor] = useState<string>('specific')
  const [selected, setSelected] = useState(null);
  const [format, setFormat] = useState("pdf");
  // const [sendToEmail, setSendToEmail] = useState<boolean | null>(null);
  const [previewDialog, setPreviewDialog] = useState<any>({
    open: false,
    data: null,
  });

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);
  let startTime = moment(range[0]).toISOString();
  let endTime = moment(range[1]).toISOString();

  const chargersUrl = `${BOLT_URL}/company/chargers`;
  const { isLoading: chargersLoading, data: chargersData } = useQuery(
    "getChargers",
    () => authorizedFetch(chargersUrl)
  );
  const vendorsUrl = `${BOLT_URL}/company/getVendors`;
  const { isLoading: vendorsLoading, data: vendorsData } = useQuery(
    "getVendors",
    () => authorizedFetch(vendorsUrl)
  );

  function downloadReports() {
    setLoader(true);
    let url;
    let token = 1234;
    // const isForAll = reportsFor === 'all'
    let type = toggle === "chargers" ? "Charger" : "Vendor";

    // if (isForAll) url = `${DATAFEED_URL}/reports/v1/charger/cumulative?id=${company.id}&startTime=${startTime}&endTime=${endTime}&token=${token}`
    // else
    url =
      toggle === "chargers"
        ? selected === "All Chargers"
          ? `${DATAFEED_URL}/reports/v1/charger/cumulative?id=${company.id}&startTime=${startTime}&endTime=${endTime}&token=${token}`
          : `${REPORTS_URL}/chargerindividualreport?uid=${selected}&start=${startTime}&end=${endTime}&token=${token}&format=${format}`
        : selected === "All Vendors"
        ? `${REPORTS_URL}/companyassetsummeryreport?id=${
            company.id
          }&start=${startTime}&end=${endTime}&token=${token}${
            format && "&format=" + format
          }`
        : `${REPORTS_URL}/chargeragencyreport2?companyId=${
            company.id
          }&agencyId=${
            (vendorsData?.data || []).find((el: any) => el.name === selected)
              ?.id
          }&start=${startTime}&end=${endTime}&format=${format}&token=${token}`;

    // TODO: open dialog when toggle === 'chargers' && selected === 'All Chargers'

    authorizedFetch(url)
      .then((data) => {
        setLoader(false);
        if (data.file) {
          const formatted = (time: any) => moment(time).format("DD-MM-YYYY");
          const fileUrl = data.file;
          let fileName = `${selected || "All"}_${type}_Report_${formatted(
            startTime
          )}–${formatted(endTime)}.${format === "excel" ? "xlsx" : "pdf"}`;
          saveAs(fileUrl, fileName);
          snackbar.success("Report downloaded");
          dispatch(
            saveReport({
              name: fileName,
              createdAt: moment().valueOf(),
              url: fileUrl,
            })
          );
        } else if (data.message) {
          snackbar.error(data.message);
        }
        // else {
        //   const array = isForAll ? data.data : data.response.info
        //   setDialog({
        //     open: true,
        //     data: {
        //       name: isForAll ? 'All Chargers' : selected,
        //       timeRange: [startTime, endTime],
        //       array: array.map((cur: any, i: any) => ({ ...cur, id: i })),
        //       downloadUrl: isForAll
        //         ? `${REPORTS_URL}/chargercumulativereport?id=${company.id}&start=${startTime}&end=${endTime}&token=${token}`
        //         : `${REPORTS_URL}/chargerindividualreport?uid=${selected}&start=${startTime}&end=${endTime}&token=${token}`
        //     }
        //   })
        // }
      })
      .catch((error) => {
        console.error(error);
      });
  }

  useEffect(() => {
    setSelected(null);
    if (toggle === "chargers") setFormat("pdf");
  }, [toggle]);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 2.5,
            py: 3,
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          Download Reports
        </Box>
        <Box
          flexGrow={1}
          overflow="auto"
          px={2.5}
          py={3}
          display="flex"
          flexDirection="column"
          justifyContent="space-between"
        >
          <Box display="grid" gap={3} maxWidth={400}>
            <Box display="flex" alignItems="center">
              <Typography
                className="label"
                sx={{ mb: "0 !important", mr: 3.5 }}
              >
                Pick a Range
              </Typography>
              <RangePicker range={range} setRange={setRange} />
            </Box>
            <Box display="flex" alignItems="center">
              <Typography
                className="label"
                sx={{ mb: "0 !important", mr: 4.5 }}
              >
                Reports For
              </Typography>
              <FormControl component="fieldset">
                <RadioGroup
                  row
                  value={toggle}
                  onChange={(e) => setToggle(e.target.value)}
                >
                  <FormControlLabel
                    value="vendors"
                    control={<Radio />}
                    label="Vendors"
                  />
                  <FormControlLabel
                    value="chargers"
                    control={<Radio />}
                    label="Chargers"
                  />
                </RadioGroup>
              </FormControl>
            </Box>
            <Box display="flex" alignItems="center">
              <Typography className="label" sx={{ mb: "0 !important", mr: 2 }}>
                Select {toggle === "chargers" ? "Charger" : "Vendor"}
              </Typography>
              {/* {toggle === 'chargers' &&
                <FormControl component="fieldset">
                  <RadioGroup row value={reportsFor} onChange={e => setReportsFor(e.target.value)}>
                    <FormControlLabel value="all" control={<Radio />} label="All Chargers" />
                    <FormControlLabel value="specific" control={<Radio />} label="Specific Charger" />
                  </RadioGroup>
                </FormControl>
              } */}
              {/* <Collapse in={reportsFor === 'specific' || toggle === 'vendors'}> */}

              <Autocomplete
                loading={
                  toggle === "chargers" ? chargersLoading : vendorsLoading
                }
                sx={{ width: 250 }}
                size="small"
                popupIcon={<KeyboardArrowDown />}
                value={selected}
                onChange={(e, newValue) => {
                  setSelected(newValue);
                }}
                options={
                  toggle === "chargers"
                    ? [
                        // "All Chargers",
                        ...(chargersData?.data?.chargers || []).map(
                          (el: any) => el.id
                        ),
                      ]
                    : [
                        ...(vendorsLoading ? [] : ["All Vendors"]),
                        ...(vendorsData?.data || []).map((el: any) => el.name),
                      ]
                }
                noOptionsText={
                  toggle === "vendors" ? "No vendors" : "No chargers"
                }
                renderInput={(params) => (
                  <TextField {...params} placeholder="Choose" />
                )}
              />
              {/* </Collapse> */}
            </Box>
            {/* <Box>
              <Typography className="label">Report Type</Typography>
              <FormGroup
                sx={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                }}
              >
                <FormControlLabel
                  disabled
                  control={<Checkbox />}
                  label="Vendors"
                />
                <FormControlLabel
                  disabled
                  control={<Checkbox />}
                  label="Charger Details"
                />
                <FormControlLabel
                  disabled
                  control={<Checkbox />}
                  label="Sub Vendors"
                />
                <FormControlLabel
                  disabled
                  control={<Checkbox defaultChecked />}
                  label="Summary"
                />
              </FormGroup>
            </Box>*/}
            <Collapse in={toggle === "vendors"}>
              <Box display="flex" alignItems="center">
                <Typography
                  className="label"
                  sx={{ mb: "0 !important", mr: 9 }}
                >
                  Format
                </Typography>
                <RadioGroup
                  row
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                >
                  <FormControlLabel
                    value="pdf"
                    control={<Radio />}
                    label="PDF"
                  />
                  <FormControlLabel
                    value="excel"
                    control={<Radio />}
                    label="XLSX"
                  />
                </RadioGroup>
              </Box>
            </Collapse>
            {/*<Box>
              <Typography className="label">Send report to e-mail?</Typography>
              <RadioGroup
                row
                onChange={(e) =>
                  setSendToEmail(e.target.value === "yes" ? true : false)
                }
              >
                <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                <FormControlLabel value="no" control={<Radio />} label="No" />
              </RadioGroup>
              <Collapse in={Boolean(sendToEmail)}>
                <TextField size="small" fullWidth placeholder="Email" />
              </Collapse>
            </Box>*/}
          </Box>
          <Box display="flex" justifyContent="end">
            <Button
              sx={{ height: 40 }}
              // variant="outlined"
              variant="contained"
              onClick={() => downloadReports()}
              disabled={!selected}
            >
              Download Now
            </Button>
            {/* <Button
              sx={{ height: 40, ml: 2 }}
              variant="contained"
            // onClick={() => downloadReports()}
            >
              Preview Report
            </Button> */}
            <Dialog
              open={previewDialog.open}
              onClose={() =>
                setPreviewDialog({ ...previewDialog, open: false })
              }
              PaperProps={{
                sx: {
                  borderRadius: 0,
                },
              }}
              fullWidth
              maxWidth="lg"
            >
              <DialogTitle
                sx={{
                  bgcolor: (theme) => theme.palette.primary.main,
                  color: "#fff",
                  p: "10px 32px !important",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Box>
                  <Typography mb={0.5} fontSize={16} fontWeight={700}>
                    Report.pdf
                  </Typography>
                  <Typography fontSize={12}>Aug 31st at 10:08 AM</Typography>
                </Box>
                <Box
                  display="grid"
                  gridTemplateColumns="repeat(3, auto)"
                  gap={2}
                  sx={{ transform: "translateX(16px)" }}
                >
                  <Tooltip title="Download">
                    <IconButton color="inherit" children={<SaveAlt />} />
                  </Tooltip>
                  <Tooltip title="Open in new window">
                    <IconButton color="inherit" children={<Launch />} />
                  </Tooltip>
                  <IconButton
                    color="inherit"
                    children={<CancelOutlined />}
                    onClick={() => setPreviewDialog(false)}
                  />
                </Box>
              </DialogTitle>
              <DialogContent sx={{ p: "0px !important" }}>
                <Box height="80vh"></Box>
              </DialogContent>
            </Dialog>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default DrawerContent;
