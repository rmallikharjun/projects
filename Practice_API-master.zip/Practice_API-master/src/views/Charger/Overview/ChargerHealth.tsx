import { Box, Paper, Tooltip, Typography, useTheme } from "@mui/material";
import { Doughnut } from "react-chartjs-2";
import CircularProgress from "@mui/material/CircularProgress";
import { InfoOutlined } from "@mui/icons-material";

interface Props {
  totalChargers: number;
  healthyChargersCount: number;
  moderateChargersCount: number;
  criticalChargersCount: number;
  damagedChargersCount: number;
}

const Availability: React.FC<Props> = ({
  totalChargers,
  healthyChargersCount,
  moderateChargersCount,
  criticalChargersCount,
  damagedChargersCount,
}) => {
  const theme = useTheme();

  const circularProgress = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 180,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" />
    </Box>
  );

  return (
    <Paper
      sx={{
        minWidth: 0,
        height: 1,
        p: { xs: 2, md: 3 },
        gridColumn: { lg: "span 3" },
      }}
    >
      <Typography variant="h6" mb={1}>
        Charger Health
      </Typography>
      {!totalChargers ? (
        circularProgress
      ) : (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            justifyItems: "center",
          }}
        >
          <Box
            width={{ xs: 160, sm: 190 }}
            alignSelf="center"
            position="relative"
          >
            <Doughnut
              style={{ position: "relative", zIndex: 2 }}
              data={(canvas) => {
                return {
                  datasets: [
                    {
                      data: [
                        healthyChargersCount,
                        moderateChargersCount,
                        criticalChargersCount,
                        damagedChargersCount,
                      ],
                      backgroundColor: [
                        theme.customColors.greenSecondary,
                        theme.customColors.yellowSecondary,
                        theme.customColors.orangeSecondary,
                        theme.customColors.redSecondary,
                      ],
                      spacing: 1,
                      hoverOffset: 0,
                      borderWidth: 0,
                      borderRadius: 50,
                      cutout: "80%",
                    },
                  ],
                  labels: ["Healthy", "Moderate", "Critical", "Inactive"],
                };
              }}
              options={{
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    displayColors: false,
                  },
                },
              }}
            />
            <Box
              sx={{
                zIndex: 1,
                position: "absolute",
                top: { xs: 55, sm: 70 },
                right: 0,
                left: 0,
                mx: "auto",
                pointerEvents: "none",
                textAlign: "center",
              }}
            >
              <Typography
                fontSize={{ xs: 24, sm: 28 }}
                fontWeight={700}
                lineHeight="1.2em"
              >
                {totalChargers}
              </Typography>
              <Typography
                sx={{
                  textTransform: "uppercase",
                  fontSize: { xs: 12, sm: 14 },
                  fontFamily: "Poppins !important",
                }}
              >
                Total Chargers
              </Typography>
            </Box>
          </Box>
          <Box ml={2}>
            {[
              {
                label: "Healthy",
                value: healthyChargersCount,
                color: theme.customColors.text.greenSecondary,
                title: "Charger health is good",
              },
              {
                label: "Moderate",
                value: moderateChargersCount,
                color: theme.customColors.text.yellowSecondary,
                title: "Charger has not been pinged since the past 15 days",
              },
              {
                label: "Critical",
                value: criticalChargersCount,
                color: theme.customColors.text.orangeSecondary,
                title: "Charger has not been pinged since the past 30 days",
              },
              {
                label: "Inactive",
                value: damagedChargersCount,
                color: theme.customColors.text.redSecondary,
                title: "Charger has not been pinged since the past 45 days",
              },
            ].map(({ label, value, color, title }, i) => (
              <Box
                key={i}
                sx={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  // width: 1,
                  pl: { xs: 1.75, sm: 2.75 },
                  mb: 2.5,
                  "& .value": {
                    mb: { xs: 0.5, sm: 1 },
                    lineHeight: "1.2em",
                    fontSize: { xs: 16, sm: 20 },
                    fontWeight: 700,
                    color: color,
                    "&:before": {
                      content: '""',
                      position: "absolute",
                      top: { xs: 3, sm: 4 },
                      left: 0,
                      width: { xs: 10, sm: 14 },
                      height: { xs: 10, sm: 14 },
                      bgcolor: color,
                      borderRadius: "2px",
                    },
                  },
                  "& .title": {
                    display: "flex",
                    alignItems: "center",
                    color: "text.secondary",
                    fontSize: 14,
                    lineHeight: "0.9em",
                  },
                }}
              >
                <span className="value">{value}</span>
                <span className="title">
                  {label}
                  <Tooltip title={title}>
                    <InfoOutlined
                      color="action"
                      fontSize="inherit"
                      sx={{ ml: 0.5, cursor: "pointer" }}
                    />
                  </Tooltip>
                </span>
              </Box>
            ))}
          </Box>
        </Box>
      )}
    </Paper>
  );
};

export default Availability;
