import { useEffect, useState } from "react";
import {
  Box,
  CircularProgress,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import RangePicker from "components/RangePicker";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState, snackbar } from "utils";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";
import moment from "moment";
import { InfoOutlined } from "@mui/icons-material";

const Insights = ({ masterView }: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading: chartLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(bookingsNewUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  const [chartData, setChartData] = useState<any>();

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let dataArray = data.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("bookings")) {
            getExisting("bookings").y += cur.totalBookings;
            getExisting("earnings").y += Math.round(
              parseFloat(cur.totalEarnings)
            );
            getExisting("energy").y += cur.totalEnergyConsumed;
            getExisting("users").y += cur.totalUsers;
          } else {
            acc.bookings.push({ x: day, y: cur.totalBookings });
            acc.earnings.push({
              x: day,
              y: Math.round(parseFloat(cur.totalEarnings)),
            });
            acc.energy.push({ x: day, y: cur.totalEnergyConsumed });
            acc.users.push({ x: day, y: cur.totalUsers });
          }
          return acc;
        },
        {
          bookings: [],
          earnings: [],
          energy: [],
          users: [],
        }
      );
      setChartData(chartData);
    }
  }, [data]);

  let chartArray = chartData?.bookings || [];

  const loader = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 70,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" size={24} />
    </Box>
  );

  return (
    <Paper
      sx={{
        height: { md: 422 },
        p: { xs: 2, md: 3 },
        gridColumn: { md: "span 2", lg: "span 5" },
        display: "flex",
        flexDirection: "column",
        bgcolor: isDarkMode ? "background.paper" : "#FDFEFE",
      }}
    >
      <Box
        sx={{
          mb: { xs: 1.75, md: 2.5 },
          width: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Typography variant="h6">Insights</Typography>
        <RangePicker range={range} setRange={setRange} />
      </Box>
      <Box
        sx={{
          flexGrow: 1,
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
          gap: { xs: 1, md: 3 },
          "& > div": {
            border: 1,
            bgcolor: isDarkMode ? "background.default" : "#fff",
            borderColor: (theme) => theme.customColors.border,
            borderRadius: 1,
            px: 2,
            py: 2.5,
            display: "flex",
            flexDirection: "column",
            "& span": {
              display: "flex",
              alignItems: "end",
              ml: 1,
            },
            "& .value": {
              fontSize: "1.75rem",
              fontWeight: 700,
              lineHeight: "0.75em",
            },
            "& .unit": {
              ml: 0.75,
              lineHeight: "1em",
            },
            "& .title": {
              ml: 1.5,
              color: "text.secondary",
              lineHeight: "1em",
            },
          },
        }}
      >
        <Box key={chartArray.length}>
          {chartLoading ? (
            loader
          ) : (
            <LineChart data={chartData?.bookings || []} />
          )}
          <span>
            <Typography className="value">
              {typeof data?.data?.totalBookings === "number"
                ? data?.data?.totalBookings
                : "-"}
            </Typography>
            <Typography className="title">Total Bookings</Typography>
          </span>
        </Box>
        <Box key={chartArray.length + 1}>
          {chartLoading ? (
            loader
          ) : (
            <LineChart isBlue data={chartData?.earnings || []} />
          )}
          <span>
            <Typography className="value">
              {typeof data?.data?.totalEarnings === "number"
                ? "₹" + String(data?.data?.totalEarnings.toFixed(0))
                : "-"}
            </Typography>
            <Typography className="title">Total Earnings</Typography>
          </span>
        </Box>
        <Box key={chartArray.length + 2}>
          {chartLoading ? (
            loader
          ) : (
            <LineChart isBlue data={chartData?.users || []} />
          )}
          <span>
            <Typography className="value">
              {typeof data?.data?.totalUsers === "number"
                ? data?.data?.totalUsers
                : "-"}
            </Typography>
            <Typography className="title">Total Users</Typography>
            <Tooltip title="Total users is total unique users for the given DATE RANGE, the sum of values in the graph might differ as they are number of unique users PER DAY">
              <InfoOutlined
                fontSize="inherit"
                sx={{ ml: 0.5, cursor: "pointer" }}
              />
            </Tooltip>
          </span>
        </Box>
        <Box key={chartArray.length + 3}>
          {chartLoading ? loader : <LineChart data={chartData?.energy || []} />}
          <span>
            <Typography className="value">
              {typeof data?.data?.totalEnergyConsumed === "number"
                ? data?.data?.totalEnergyConsumed.toFixed(3)
                : "-"}
            </Typography>
            {typeof data?.data?.totalEnergyConsumed === "number" && (
              <Typography className="unit">kWh</Typography>
            )}
            <Typography className="title">Energy Dispensed</Typography>
          </span>
        </Box>
      </Box>
    </Paper>
  );
};

const LineChart: React.FC<{ isBlue?: boolean; data: any[] }> = ({
  isBlue,
  data,
}) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  return (
    <Box
      sx={{
        flexGrow: 1,
        position: "relative",
        height: 70,
        width: 1,
        mb: "3px",
      }}
    >
      <Line
        height={70}
        data={(canvas) => {
          const ctx = canvas.getContext("2d");
          const g = ctx?.createLinearGradient(0, 0, 0, 60);

          g?.addColorStop(
            0,
            isBlue ? "rgba(97, 209, 105, 0.7)" : "rgba(97, 209, 105, 0.6)"
          );
          g?.addColorStop(
            0.5,
            isBlue ? "rgba(97, 209, 105, 0.4)" : "rgba(97, 209, 105, 0.2)"
          );
          g?.addColorStop(
            1,
            isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
          );

          let color = isBlue ? "rgba(97,209,105)" : "rgba(97,209,105)";

          return {
            // labels: data?.map(el => el.t),
            datasets: [
              {
                fill: true,
                data: data,
                borderColor: color,
                backgroundColor: g,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: color,
                pointHoverBorderWidth: 3,
              },
            ],
          };
        }}
        options={{
          scales: {
            xAxis: {
              display: false,
              // type: "linear",
              // type: 'time'
            },
            yAxis: {
              display: false,
            },
          },
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              caretSize: 0,
              mode: "index",
              intersect: false,
              yAlign: "center",
              displayColors: false,
              caretPadding: 16,
              titleFont: {
                weight: "400",
              },
              bodyFont: {
                weight: "500",
              },
            },
          },
          layout: {
            padding: {
              bottom: 20,
            },
          },
          interaction: {
            mode: "index",
            intersect: false,
          },
        }}
      />
    </Box>
  );
};

export default Insights;
