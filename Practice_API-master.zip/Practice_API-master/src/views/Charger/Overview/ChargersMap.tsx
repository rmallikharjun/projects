import {
  Box,
  Hidden,
  Paper,
  Switch,
  Tooltip,
  Typography,
  useTheme,
} from "@mui/material";
import { setMasterView, GlobalState } from "utils";
import Map from "components/Map";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { InfoOutlined } from "@mui/icons-material";

interface Props {
  chargersStats: any;
}

const ChargersMap: React.FC<Props> = ({ chargersStats }) => {
  const masterView = useSelector(
    (state: GlobalState) => state.global.masterView
  );
  const companyName = useSelector(
    (state: GlobalState) => state.global.company.name
  );

  useEffect(() => {
    if (companyName !== "REVOS") {
      setMasterView(false);
    }
    if (companyName === "testTVS") {
      setMasterView(true);
    }
  }, [companyName]);

  const theme = useTheme();

  let { isLoading, data } = chargersStats;

  const {
    totalChargers: total,
    totalUnavailable: unavailable,
    totalAvailable: available,
    totalBooked: booked,
  } = data?.data?.stats || {};

  console.log("Charger data is: ", data?.data?.chargers);

  return (
    <Paper
      sx={{
        zIndex: 1,
        position: "relative",
        height: { xs: 400, md: 350 },
        gridColumn: {
          md: "span 2",
          lg: companyName === "testTVS" ? "span 8" : "span 5",
        },
        display: "grid",
        gridTemplateColumns: { xs: "1fr", md: "1fr 204px" },
        gridTemplateRows: { xs: "270px 1fr", md: "auto" },
        bgcolor: "divider",
        overflow: "hidden",
        "& .gm-style-cc": {
          transform: "translateX(-22px)",
        },
      }}
    >
      <Map
        key={data?.data?.chargers}
        loading={isLoading}
        type="points"
        dataArray={data?.data?.chargers || []}
      />
      <Paper
        sx={{
          boxShadow: "none",
          position: { md: "absolute" },
          top: { md: 0 },
          right: { md: 0 },
          width: { md: 230 },
          height: 1,
          transform: {
            xs: "translateY(-23px)",
            md: "none",
          },
          borderRadius: 2,
          p: 3,
        }}
      >
        {companyName === "REVOS" && (
          <Hidden mdDown>
            <Box display="flex">
              <Typography variant="h6" mb={3.5}>
                Master View
              </Typography>
              <Tooltip title="Switch it on to see all data for the bolt platform irrespective of the company">
                <InfoOutlined
                  color="action"
                  fontSize="inherit"
                  sx={{ ml: 0.5, mt: 0.5, cursor: "pointer" }}
                />
              </Tooltip>
              <Switch
                sx={{ ml: 2 }}
                size="small"
                checked={masterView}
                onChange={() => {
                  setMasterView(!masterView);
                }}
              />
            </Box>
          </Hidden>
        )}
        <Typography variant="h6" mb={0.1}>
          Chargers
        </Typography>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "auto auto auto",
              md: "1fr",
            },
          }}
        >
          <Box>
            <Typography
              fontSize={{ xs: "1.4rem", md: "1.7rem" }}
              fontWeight={700}
            >
              {typeof total === "number" ? total : "-"}
            </Typography>
            <Typography fontSize={14} color="text.secondary" mb={2}>
              TOTAL CHARGERS
            </Typography>
          </Box>
          {[
            {
              label: "Available",
              value: typeof available === "number" ? available : "-",
              color: theme.customColors.text.green,
            },
            {
              label: "Booked",
              value: typeof booked === "number" ? booked : "-",
              color: theme.customColors.text.blue,
            },
            {
              label: "Unavailable",
              value: typeof unavailable === "number" ? unavailable : "-",
              color: theme.customColors.text.grey,
            },
          ].map(({ label, value, color }, i) => (
            <Box
              key={i}
              sx={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                width: 1,
                pl: 2.75,
                mb: 1.25,
                "& .value": {
                  mb: -0.25,
                  fontSize: 20,
                  fontWeight: 700,
                  color: color,
                  "&:before": {
                    content: '""',
                    position: "absolute",
                    top: 7,
                    left: 0,
                    width: 14,
                    height: 14,
                    bgcolor: color,
                    borderRadius: "2px",
                  },
                },
                "& .title": {
                  color: "text.secondary",
                  fontSize: 14,
                },
              }}
            >
              <span className="value">{value}</span>
              <span className="title">{label}</span>
            </Box>
          ))}
        </Box>
      </Paper>
    </Paper>
  );
};

export default ChargersMap;
