import {
  Avatar,
  Box,
  CircularProgress,
  Paper,
  Tooltip,
  Typography,
  useTheme,
} from "@mui/material";
import RangePicker from "components/RangePicker";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import {
  authorizedFetch,
  getDarkModePreference,
  GlobalState,
  snackbar,
} from "utils";
import { format, sub } from "date-fns";
import { useQuery } from "react-query";
import { BOLT_URL } from "utils/constants";

import { InfoOutlined } from "@mui/icons-material";

const NewUsers = ({ masterView }: any) => {
  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 2 }),
    new Date(),
  ]);
  const [chartData, setChartData] = useState<any>(null);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  // const usersUrl = `${BOLT_URL}/company/users/latest?dateFrom=${dateFrom}&dateTo=${dateTo}`;
  // const { isLoading, data } = useQuery(
  //   ["usersOverTime", dateFrom, dateTo, masterView],
  //   () =>
  //     authorizedFetch(usersUrl, {
  //       headers: {
  //         master: masterView,
  //       },
  //     }),
  //   {
  //     onError: () => snackbar.error("Error fetching data"),
  //   }
  // );

  // useEffect(() => {
  //   if (data && data.data && data.data.constructor === Array) {
  //     let dataArray = data.data.sort(
  //       (a: any, b: any) =>
  //         moment(a.firstBooking.bookingTime).valueOf() -
  //         moment(b.firstBooking.bookingTime).valueOf()
  //     );
  //     let chartData = dataArray.reduce((result: any, el: any) => {
  //       let date = format(new Date(el.firstBooking.bookingTime), "MMM d, yyyy");
  //       let existing = result.find((d: any) => d.x === date);
  //       if (!existing) result.push({ x: date, y: 1 });
  //       else existing.y += 1;
  //       return result;
  //     }, []);
  //     // chartData.sort(
  //     //   (a: any, b: any) => new Date(a.x).valueOf() - new Date(b.x).valueOf()
  //     // );
  //     setChartData(chartData);
  //   }
  // }, [data]);

  const newUserUrl = `${BOLT_URL}/company/stats/newuser/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getNewUserStats", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(newUserUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let chartData: any = {
        users: [],
      };
      // eslint-disable-next-line
      data?.data?.stats?.map((el: any) => {
        let date = format(new Date(el.date), "MMM d, yyyy");

        chartData.users.push({ x: date, y: el.newUsersCount });
      });

      setChartData(chartData);
    }
  }, [data]);

  console.log(data);

  return (
    <Paper
      sx={{
        height: 510,
        p: { xs: 2, md: 3 },
        gridColumn: { md: "span 2", lg: "span 3" },
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box
        sx={{
          mb: 2,
          width: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box display="flex">
          <Typography variant="h6">New Users</Typography>
          <Tooltip title="Graph showing addition of unique users to the bolt platform everyday">
            <InfoOutlined
              fontSize="inherit"
              sx={{ ml: 0.5, mt: 0.5, cursor: "pointer" }}
            />
          </Tooltip>
          <Avatar variant="label" sx={{ ml: 1 }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              data?.data?.totalNewUsers || 0
            )}
          </Avatar>
        </Box>

        <RangePicker range={range} setRange={setRange} />
      </Box>
      {isLoading ? (
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          flexGrow={1}
        >
          <CircularProgress />
        </Box>
      ) : (
        <LineChart data={chartData?.users || []} />
      )}
    </Paper>
  );
};

const LineChart: React.FC<{ data: any[] }> = ({ data }) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const theme = useTheme();

  return (
    <Box
      sx={{
        width: 1,
        flexGrow: 1,
      }}
    >
      <Line
        data={(canvas) => {
          const ctx = canvas.getContext("2d");
          const g = ctx?.createLinearGradient(0, 0, 0, 280);

          g?.addColorStop(0, "rgba(87, 184, 255, 0.7)");
          g?.addColorStop(
            1,
            isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
          );

          let color = "rgb(87, 184, 255)";
          return {
            labels: data?.map((el: any) => el.x.split(",")[0]),
            datasets: [
              {
                fill: true,
                data: data.map((el: any) => el.y),
                borderColor: color,
                backgroundColor: g,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderWidth: 3,
              },
            ],
          };
        }}
        options={{
          scales: {
            xAxis: {
              // type: 'time',
              grid: {
                display: false,
                tickWidth: 0,
                tickLength: 16,
                drawBorder: false,
              },
              ticks: {
                color: theme.palette.text.secondary,
              },
            },
            yAxis: {
              ticks: {
                color: theme.palette.text.secondary,
              },
              // suggestedMin: 15,
              // suggestedMax: 30,
              grid: {
                borderDash: [4],
                tickWidth: 0,
                tickLength: 16,
                drawBorder: false,
              },
            },
          },
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              caretSize: 0,
              mode: "index",
              intersect: false,
              yAlign: "center",
              displayColors: false,
              caretPadding: 16,
              titleFont: {
                weight: "400",
              },
              bodyFont: {
                weight: "500",
              },
            },
          },
          interaction: {
            mode: "index",
            intersect: false,
          },
        }}
      />
    </Box>
  );
};

export default NewUsers;
