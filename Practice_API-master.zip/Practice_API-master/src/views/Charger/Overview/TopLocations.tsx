import { Paper, Typography, useMediaQuery, useTheme } from "@mui/material";
import Table from "components/Table";
import { BOLT_URL } from "utils/constants";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
// import { getDuration } from "utils";

const TopLocations = ({ masterView }: any) => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

  // const statsUrl = `${BOLT_URL}/company/stats/city`;
  const statsUrl = `${BOLT_URL}/company/stats/city`;
  const { isLoading, data } = useQuery(["getCityStats", masterView], () =>
    authorizedFetch(statsUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  return (
    <Paper
      sx={{
        minWidth: 0,
        height: 422,
        p: 0,
        gridColumn: { lg: "span 3" },
      }}
    >
      <Typography
        variant="h6"
        mb={2.5}
        p={{ xs: 2, md: 3 }}
        pb={{ xs: 0, md: 0 }}
        mt="2px"
      >
        Top Locations
      </Typography>
      <Table
        px={isMdUp ? 3 : 2}
        height={290}
        rowsPerPage={4}
        small
        smallPagination
        loading={isLoading}
        rows={(data?.data?.constructor === Array ? data.data : [])
          .filter((city: any) => city.numberOfBookingsInCity > 0)
          .sort(
            (a: any, b: any) =>
              b.numberOfBookingsInCity - a.numberOfBookingsInCity
          )
          .slice(0, 20)}
        columns={[
          {
            key: "city",
            label: "City",
            format: (value) => (value === "NA" ? "Unknown" : value),
          },
          {
            key: "numberOfBookingsInCity",
            label: "Bookings",
            format: (value) => String(value),
          },
          {
            key: "totalEnergyConsumed",
            label: "Consumption",
            // eslint-disable-next-line
            format: (value) => value.toFixed(3) + " " + "kWh",
          },
        ]}
      />
      {/* <Box width={1} mb={3}>
        <RangePicker isSeparate />
      </Box>
      <Box
        width={1}
        maxWidth={340}
        display="grid"
        gridTemplateColumns="1fr 1fr"
        columnGap={10.5}
        rowGap={3}
      >
        {[
          { name: "Bengaluru", booked: "90%" },
          { name: "Bengaluru", booked: "90%" },
          { name: "Chennai", booked: "60%" },
          { name: "Chennai", booked: "60%" },
          { name: "Hyderabad", booked: "10%" },
          { name: "Hyderabad", booked: "10%" },
        ].map(({ name, booked }, i) => {
          return (
            <Box
              key={i}
              display="flex"
              justifyContent="space-between"
              alignItems="center"
            >
              <Typography variant="body2" color="text.secondary">
                {name}
              </Typography>
              <Typography fontWeight={600}>{booked}</Typography>
            </Box>
          );
        })}
      </Box> */}
    </Paper>
  );
};

export default TopLocations;
