import { Box, Hidden, Switch, Typography } from "@mui/material";
import { toggleMasterView } from "actions";
import Breadcrumbs from "components/Breadcrumbs";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import { authorizedFetch, GlobalState, setMasterView } from "utils";
import { BOLT_URL } from "utils/constants";
import ChargerHealth from "./ChargerHealth";
import ChargersMap from "./ChargersMap";
import Insights from "./Insights";
import TopLocations from "./TopLocations";
import TopUsers from "./TopUsers";
import NewUsers from "./NewUsers";

const Overview = () => {
  const masterView = useSelector(
    (state: GlobalState) => state.global.masterView
  );
  const companyName = useSelector(
    (state: GlobalState) => state.global.company.name
  );

  useEffect(() => {
    if (companyName !== "REVOS") {
      setMasterView(false);
    }
    if (companyName === "testTVS") {
      setMasterView(true);
    }
  }, [companyName]);

  const [allStats, setAllStats] = useState({
    totalChargers: 0,
    healthyChargersCount: 0,
    moderateChargersCount: 0,
    criticalChargersCount: 0,
    damagedChargersCount: 0,
  });

  const statsUrl = `${BOLT_URL}/company/stats/all`;

  useEffect(() => {
    toggleMasterView(true);
  }, []);

  const { isLoading, data } = useQuery(["getAllStats", masterView], () =>
    authorizedFetch(statsUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    let { stats } = data?.data || {};
    if (stats) {
      setAllStats(stats);
    }
  }, [data]);

  const {
    totalChargers,
    healthyChargersCount,
    moderateChargersCount,
    criticalChargersCount,
    damagedChargersCount,
  } = allStats;

  return (
    <>
      <Box
        sx={{
          width: 1,
          mb: { xs: 2, md: 3 },
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Breadcrumbs />

        {companyName === "REVOS" && (
          <Hidden mdUp>
            <Box display="flex" alignItems="center">
              <Typography variant="h6">Master View</Typography>
              <Switch
                sx={{ ml: 1 }}
                size="small"
                checked={masterView}
                onChange={() => {
                  setMasterView(!masterView);
                }}
              />
            </Box>
          </Hidden>
        )}
      </Box>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "1fr 1fr",
            lg: "repeat(8, 1fr)",
          },
          gap: { xs: 2, md: 3 },
          "& > .MuiPaper-root": {
            borderRadius: 2,
            boxShadow: "0 0 4px #1C295A14",
          },
          "& > .MuiPaper-root:nth-of-type(-n+2)": {
            boxShadow: "0 0 10px #1C295A14",
          },
        }}
      >
        <ChargersMap chargersStats={{ isLoading, data }} />
        {companyName === "testTVS" ? (
          ""
        ) : (
          <ChargerHealth
            totalChargers={totalChargers}
            healthyChargersCount={healthyChargersCount}
            moderateChargersCount={moderateChargersCount}
            criticalChargersCount={criticalChargersCount}
            damagedChargersCount={damagedChargersCount}
          />
        )}

        <TopLocations masterView={masterView} />
        <Insights masterView={masterView} />
        <TopUsers masterView={masterView} />
        <NewUsers masterView={masterView} />
      </Box>
    </>
  );
};

export default Overview;
