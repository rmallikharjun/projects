import React, { useEffect, useState } from "react";
import {
  Button,
  Box,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Tooltip,
  ToggleButtonGroup,
  ToggleButton,
  Hidden,
} from "@mui/material";
import { authorizedFetch, getPermissions, setLoader, snackbar } from "utils";
import { gql, useMutation } from "@apollo/client";
import {
  DeleteOutline,
  HighlightOff,
  PersonAddOutlined,
} from "@mui/icons-material";
import TableComponent from "components/Table";
import Search from "components/Search";
import { useQuery } from "react-query";
import { AUTH_URL } from "utils/constants";

const ADD_USERS_TO_USER_GROUP = gql`
  mutation AddUsersToUserGroup(
    $where: UserGroupWhereUniqueInput!
    $data: UserGroupUpdateUsersInput!
  ) {
    userGroup {
      updateUserGroupUsers(where: $where, data: $data) {
        id
      }
    }
  }
`;

const ADD_USERS_TO_SUBSCRIPTION = gql`
  mutation AddUsersToSubscription($data: AddSubscriptionToUserInput!) {
    subscriptionPolicy {
      addSubscriptionToUser(data: $data) {
        id
      }
    }
  }
`;

const DELETE_USERS_FROM_USER_GROUP = gql`
  mutation RemoveUsers(
    $where: UserGroupWhereUniqueInput!
    $data: UserGroupUpdateUsersInput!
  ) {
    userGroup {
      updateUserGroupUsers(where: $where, data: $data) {
        id
      }
    }
  }
`;
const DELETE_USERS_FROM_SUBSCRIPTION = gql`
  mutation RemoveUsers($data: AddSubscriptionToUserInput!) {
    subscriptionPolicy {
      removeUserSubscription(data: $data) {
        count
      }
    }
  }
`;

interface Props {
  open: boolean;
  handleClose: () => void;
  subscription: any;
}

const UsersDialog: React.FC<Props> = ({ open, handleClose, subscription }) => {
  const { canWrite } = getPermissions("charger:subscriptions");
  const [selected, setSelected] = useState([]);
  const [addUsersDialog, setAddUsersDialog] = useState(false);
  const [deleteUsersDialog, setDeleteUsersDialog] = useState(false);

  useEffect(() => {
    setSelected([]);
  }, [subscription, setSelected]);

  return (
    <>
      <AddUsersDialog
        key={subscription}
        open={addUsersDialog}
        handleClose={() => setAddUsersDialog(false)}
        data={{
          type: "subscription",
          subscription,
        }}
      />
      <DeleteUsersDialog
        open={deleteUsersDialog}
        handleClose={() => setDeleteUsersDialog(false)}
        // loading={loading}
        data={{
          type: "subscription",
          subscription,
          selected,
        }}
      />
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "start",
          }}
        >
          <Box display="flex" alignItems="center">
            <Box color="text.secondary">{subscription?.name}</Box>
            <Divider flexItem orientation="vertical" sx={{ mx: 1 }} />
            Users
          </Box>
          <Box
            sx={{
              display: "flex",
              transform: "translate(8px, -8px)",
            }}
          >
            {canWrite && (
              <Tooltip title="Add Users">
                <IconButton
                  sx={{ mr: 1 }}
                  children={<PersonAddOutlined />}
                  color="inherit"
                  onClick={() => setAddUsersDialog(true)}
                />
              </Tooltip>
            )}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              onClick={handleClose}
            />
          </Box>
        </DialogTitle>
        <DialogContent>
          <TableComponent
            px={0}
            height={618}
            selectable={canWrite}
            selectedRows={selected}
            setSelectedRows={setSelected}
            selectOnClick
            // small
            rows={subscription?.users || []}
            columns={[
              {
                key: "name",
                label: "Name",
                Render: (row) => {
                  let { firstName, lastName } = row;
                  return firstName || lastName
                    ? `${firstName || ""} ${lastName || ""}`
                    : "-";
                },
              },
              { key: "email", label: "Email" },
              { key: "phone", label: "Phone" },
            ]}
            toolbar={() => (
              <Button
                startIcon={<DeleteOutline />}
                onClick={() => setDeleteUsersDialog(true)}
              >
                Remove
              </Button>
            )}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

interface DialogProps {
  open: boolean;
  handleClose: () => void;
  data: {
    type: "user-group" | "subscription";
    subscription?: any;
    group?: any;
  };
}

const AddUsersDialog: React.FC<DialogProps> = ({ open, handleClose, data }) => {
  const { subscription, group } = data;
  const [activeView, setActiveView] = useState<"APP_USERS" | "EMPLOYEE">(
    data.type === "subscription" && subscription?.type === "EMPLOYEE"
      ? "EMPLOYEE"
      : "APP_USERS"
  );
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const shouldGetAppUsers =
    data.type === "user-group" ||
    subscription?.type === "ALL" ||
    subscription?.type === "APP_USERS";
  const shouldGetEmployees =
    data.type !== "user-group" ||
    subscription?.type === "ALL" ||
    subscription?.type === "EMPLOYEE";

  const appUsersUrl = `${AUTH_URL}/company/appusers?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;
  const employeesUrl = `${AUTH_URL}/company/users?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;
  const { isLoading: appUsersLoading, data: appUsersData } = useQuery(
    ["getAppUsers", page, pageSize, search],
    () => authorizedFetch(appUsersUrl),
    { enabled: shouldGetAppUsers }
  );
  const { isLoading: employeesLoading, data: employeesData } = useQuery(
    ["getEmployees", page, pageSize, search],
    () => authorizedFetch(employeesUrl),
    { enabled: shouldGetEmployees }
  );

  const [addUsers] = useMutation(
    data.type === "user-group"
      ? ADD_USERS_TO_USER_GROUP
      : ADD_USERS_TO_SUBSCRIPTION,
    {
      refetchQueries:
        data.type === "user-group" ? ["GetUserGroups"] : ["GetSubscriptions"],
      onCompleted: () => {
        setLoader(false);
        setSelected([]);
        handleClose();
        snackbar.success(`Users added to ${data.type}`);
      },
      onError: () => {
        setLoader(false);
        snackbar.error(`Error adding users to ${data.type}`);
      },
    }
  );

  function handleSave() {
    setLoader(true);
    let variables =
      data.type === "user-group"
        ? {
            where: { id: group?.id },
            data: { addedUsers: selected },
          }
        : {
            data: {
              subscriptionId: subscription?.id,
              userIds: selected,
            },
          };
    addUsers({ variables });
  }

  useEffect(() => {
    if (open) {
      if (data.type === "subscription" && subscription?.type === "ALL")
        setActiveView("EMPLOYEE");
      else setActiveView("APP_USERS");
    } else {
      setSearch("");
    }
  }, [open, data, subscription]);

  useEffect(() => {
    setSelected([]);
    setPage(1);
  }, [activeView]);

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add Users
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "auto auto",
            gap: 1,
            transform: "translate(8px, -8px)",
            alignItems: "center",
          }}
        >
          <Hidden smDown>
            <Search handleSearch={setSearch} enableClear persist />
          </Hidden>
          {subscription?.type === "ALL" && (
            <ToggleButtonGroup
              exclusive
              size="small"
              color="primary"
              onChange={(e, value) => value && setActiveView(value)}
              value={activeView}
            >
              <ToggleButton value="EMPLOYEE">Employees</ToggleButton>
              <ToggleButton value="APP_USERS">App Users</ToggleButton>
            </ToggleButtonGroup>
          )}
        </Box>
      </DialogTitle>
      <DialogContent>
        <Hidden smUp>
          <Box mb={1.5} display="flex" flexDirection="row-reverse">
            <Search handleSearch={setSearch} enableClear enableBorder persist />
          </Box>
        </Hidden>
        <TableComponent
          idKey="_id"
          loading={
            activeView === "APP_USERS" ? appUsersLoading : employeesLoading
          }
          rowCount={
            activeView === "APP_USERS"
              ? appUsersData?.data?.count || 0
              : employeesData?.data?.count || 0
          }
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(page) => setPage(page)}
          onPageSizeChange={(pageSize) => setPageSize(pageSize)}
          px={0}
          height={618}
          selectable
          selectOnClick
          selectedRows={selected}
          setSelectedRows={setSelected}
          rows={
            activeView === "APP_USERS"
              ? appUsersData?.data?.users || []
              : employeesData?.data?.users || []
          }
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => {
                let { firstName, lastName } = row;
                return firstName || lastName
                  ? `${firstName || ""} ${lastName || ""}`
                  : "-";
              },
            },
            { key: "email", label: "Email" },
            { key: "phone", label: "Phone" },
          ]}
        />
      </DialogContent>
      <DialogActions className="dense">
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSave}
          disabled={selected.length === 0}
        >
          Add
        </Button>
      </DialogActions>
    </Dialog>
  );
};

interface DeleteDialogProps {
  open: boolean;
  handleClose: () => void;
  data: {
    type: "user-group" | "subscription";
    subscription?: any;
    group?: any;
    selected: any;
  };
}

const DeleteUsersDialog: React.FC<DeleteDialogProps> = ({
  open,
  data,
  handleClose,
}) => {
  const { selected, subscription, group } = data;

  const [deleteUsers] = useMutation(
    data.type === "user-group"
      ? DELETE_USERS_FROM_USER_GROUP
      : DELETE_USERS_FROM_SUBSCRIPTION,
    {
      refetchQueries:
        data.type === "user-group" ? ["GetUserGroups"] : ["GetSubscriptions"],
      onCompleted: () => {
        setLoader(false);
        handleClose();
        snackbar.success(`Users removed from ${data.type}`);
      },
      onError: () => {
        setLoader(false);
        snackbar.error(`Error removing users from ${data.type}`);
      },
    }
  );

  function handleDelete() {
    setLoader(true);
    let variables =
      data.type === "user-group"
        ? {
            where: { id: group?.id },
            data: { removedUsers: selected },
          }
        : {
            data: {
              subscriptionId: subscription?.id,
              userIds: selected,
            },
          };
    deleteUsers({ variables });
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Remove Users</DialogTitle>
      <DialogContent className="py-1">
        Remove selected users from{" "}
        <b>{data.type === "user-group" ? group?.name : subscription?.name}</b>?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          onClick={handleDelete}
          color="primary"
          variant="contained"
          disableElevation
          disabled={false}
        >
          Yes
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default UsersDialog;
