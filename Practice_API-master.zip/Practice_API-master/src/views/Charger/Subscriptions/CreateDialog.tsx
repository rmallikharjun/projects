import { gql, useMutation, useQuery } from "@apollo/client";
import {
  EditOutlined,
  ErrorOutline,
  HighlightOff,
  KeyboardArrowDown,
} from "@mui/icons-material";
import {
  Autocomplete,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import { setLoader, snackbar } from "utils";

const GET_PAYMENT_META = gql`
  query PaymentMeta {
    finance {
      getAllPaymentMeta {
        id
        name
        service
        address
      }
    }
  }
`;

const CREATE_SUBSCRIPTION = gql`
  mutation CreateSubscription($data: SubscriptionPolicyCreateInput!) {
    subscriptionPolicy {
      create(data: $data) {
        id
      }
    }
  }
`;

const UPDATE_SUBSCRIPTION = gql`
  mutation UpdateSubscription(
    $where: SubscriptionPolicyWhereUniqueInput!
    $data: SubscriptionPolicyUpdateInput!
  ) {
    subscriptionPolicy {
      update(where: $where, data: $data) {
        id
      }
    }
  }
`;

const CreateDialog = ({ open, isEditMode, subscription, handleClose }: any) => {
  const formTemplate = useMemo(
    () => ({
      name: "",
      description: "",
      type: "",
      period: {
        value: "",
        unit: "",
      },
      offerType: "DISCOUNT",
      offerPeriod: {
        value: "",
        unit: "",
      },
      amount: "",
      pricing: {
        name: "",
        amountPayable: "",
        paymentMeta: {
          id: "",
          service: "",
          name: "",
          address: "",
        },
        type: "ONETIME",
      },
    }),
    []
  );
  const [form, setForm] = useState({ ...formTemplate });

  const [step, setStep] = useState(0);
  const steps = [
    "Basic Details",
    "Offer Details",
    "Pricing Details",
    "Confirmation",
  ];

  const {
    name,
    description,
    type,
    period,
    offerType,
    offerPeriod,
    amount,
    pricing,
  } = form;

  const { loading: paymentMetaLoading, data: paymentMetaData } =
    useQuery(GET_PAYMENT_META);

  console.log("working!" + JSON.stringify(paymentMetaData));

  const [mutation] = useMutation(
    isEditMode ? UPDATE_SUBSCRIPTION : CREATE_SUBSCRIPTION,
    {
      refetchQueries: ["GetSubscriptions"],
      onCompleted: () => {
        setLoader(false);
        snackbar.success(`${isEditMode ? "Updated" : "Created"} subscription`);
        handleClose();
        setTimeout(() => {
          setForm({ ...formTemplate });
        }, 500);
      },
      onError: (err) => {
        setLoader(false);
        snackbar.error(
          `Error ${isEditMode ? "updating" : "creating"} subscription`
        );
      },
    }
  );

  useEffect(() => {
    if (!open) return;
    setStep(0);
    if (isEditMode) {
      let { name, description, type, period, pricing, offers } = subscription;
      const getPeriodUnit = (unit: string) => {
        if (unit === "NA") return "";
        else return unit[0] + unit.slice(1).toLowerCase();
      };
      setForm({
        name,
        description: description || "",
        type:
          type === "ALL"
            ? "All Users"
            : type === "EMPLOYEE"
            ? "Employees"
            : "App Users",
        period: {
          value: period.value,
          unit: getPeriodUnit(period.unit),
        },
        offerType: offers[0].type,
        offerPeriod: {
          value: offers[0].period.value,
          unit: getPeriodUnit(offers[0].period.unit),
        },
        amount: offers[0].value,
        pricing: {
          name: pricing.name,
          amountPayable: pricing.amountPayable,
          paymentMeta: pricing.paymentMeta,
          type: pricing.type,
        },
      });
    } else setForm({ ...formTemplate });
  }, [open, formTemplate, isEditMode, subscription]);

  function handleChange(key: string, value: any) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function handleSubmit() {
    const data = {
      name,
      description,
      type:
        type === "All Users"
          ? "ALL"
          : type === "App Users"
          ? "APP_USERS"
          : "EMPLOYEE",
      period: {
        create: {
          unit: period.value && period.unit ? period.unit.toUpperCase() : "NA",
          value: period.value && period.unit ? parseInt(period.value) : 0,
        },
      },
      offers: {
        create: [
          {
            assetType: "CHARGING_SOCKET",
            type: offerType,
            period: {
              create: {
                unit:
                  offerPeriod.value && offerPeriod.unit
                    ? offerPeriod.unit.toUpperCase()
                    : "NA",
                value:
                  offerPeriod.value && offerPeriod.unit
                    ? parseInt(offerPeriod.value)
                    : 0,
              },
            },
            value: parseInt(amount) || 0,
          },
        ],
      },
      pricing: {
        create: {
          ...pricing,
          amountPayable: parseFloat(pricing.amountPayable || "0"),
          paymentMeta: {
            connect: {
              id: pricing.paymentMeta?.id,
            },
          },
        },
      },
    };
    const variables = isEditMode
      ? {
          where: {
            id: subscription?.id,
          },
          data: {
            name: data.name,
            description: data.description,
            type: data.type,
            period: {
              update: data.period.create,
            },
            offers: {
              update: {
                where: {
                  id: subscription?.offers[0]?.id,
                },
                data: data.offers.create[0],
              },
            },
            pricing: {
              update: data.pricing.create,
            },
          },
        }
      : {
          data,
        };
    // console.log(variables)
    setLoader(true);
    mutation({ variables });
  }

  const isComplete = (step: number) => {
    if (isEditMode) return false;
    switch (step) {
      case 0:
        return ![name, type].includes("");
      case 1:
        return ![amount].includes("");
      case 2:
        return (
          ![pricing.amountPayable, pricing.paymentMeta?.id].includes("") &&
          Boolean(pricing.paymentMeta)
        );
      default:
        break;
    }
  };

  const isValid =
    ![
      name,
      type,
      offerType,
      amount,
      pricing.type,
      pricing.amountPayable,
      pricing.paymentMeta?.id,
    ].includes("") && pricing.paymentMeta;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        {isEditMode ? "Edit Subscription" : "Create New Subscription"}
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        {step !== steps.length - 1 && (
          <Typography mb={5} fontSize={14} color="text.secondary">
            All fields marked with * are required
          </Typography>
        )}
        <Stepper
          sx={{ mb: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i} completed={isComplete(i)}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {step === 0 && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Subscription Name*</Typography>
              <TextField
                value={name}
                onChange={(e) => handleChange("name", e.target.value)}
                fullWidth
                size="small"
                placeholder="Name"
              />
            </Box>
            <Box>
              <Typography className="label">Description</Typography>
              <TextField
                value={description}
                onChange={(e) => handleChange("description", e.target.value)}
                fullWidth
                size="small"
                placeholder="Description"
              />
            </Box>
            <Box>
              <Typography className="label">Type*</Typography>
              <Select
                value={type}
                onChange={(e) => handleChange("type", e.target.value)}
                fullWidth
                displayEmpty
              >
                <MenuItem value="">
                  <em>Select</em>
                </MenuItem>
                {["All Users", "App Users", "Employees"].map((el, i) => (
                  <MenuItem key={i} value={el}>
                    {el}
                  </MenuItem>
                ))}
              </Select>
            </Box>
            <Box>
              <Typography className="label">Period</Typography>
              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
                <TextField
                  value={period.value}
                  onChange={(e) =>
                    handleChange("period", { ...period, value: e.target.value })
                  }
                  size="small"
                  placeholder="Period"
                  type="number"
                />
                <Select
                  value={period.unit}
                  onChange={(e) => {
                    handleChange("period", { ...period, unit: e.target.value });
                  }}
                  fullWidth
                  displayEmpty
                >
                  <MenuItem value="">
                    <em>Select</em>
                  </MenuItem>
                  {["Weeks", "Months", "Years"].map((el, i) => (
                    <MenuItem key={i} value={el}>
                      {el}
                    </MenuItem>
                  ))}
                </Select>
              </Box>
            </Box>
          </Box>
        )}
        {step === 1 && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Offer Type*</Typography>
              <Select value={offerType} defaultValue="DISCOUNT" fullWidth>
                <MenuItem value="DISCOUNT">Discount</MenuItem>
                <MenuItem value="CREDITS">Credits</MenuItem>
              </Select>
            </Box>
            <Box>
              <Typography className="label">Offer Period</Typography>
              <Box display="grid" gridTemplateColumns="1fr 1fr" gap={2}>
                <TextField
                  value={offerPeriod.value}
                  onChange={(e) =>
                    handleChange("offerPeriod", {
                      ...offerPeriod,
                      value: e.target.value,
                    })
                  }
                  size="small"
                  placeholder="Period"
                  type="number"
                />
                <Select
                  value={offerPeriod.unit}
                  onChange={(e) => {
                    handleChange("offerPeriod", {
                      ...offerPeriod,
                      unit: e.target.value,
                    });
                  }}
                  fullWidth
                  displayEmpty
                >
                  <MenuItem value="">
                    <em>Select</em>
                  </MenuItem>
                  {["Weeks", "Months", "Years"].map((el, i) => (
                    <MenuItem key={i} value={el}>
                      {el}
                    </MenuItem>
                  ))}
                </Select>
              </Box>
            </Box>
            <Box>
              <Typography className="label">Amount*</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Percentage"
                type="number"
                value={amount}
                onChange={(e) => handleChange("amount", e.target.value)}
              />
            </Box>
          </Box>
        )}
        {step === 2 && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Name</Typography>
              <TextField
                value={pricing.name}
                onChange={(e) =>
                  handleChange("pricing", { ...pricing, name: e.target.value })
                }
                fullWidth
                size="small"
                placeholder="Name"
              />
            </Box>
            <Box>
              <Typography className="label">Amount Payable*</Typography>
              <TextField
                value={pricing.amountPayable}
                onChange={(e) =>
                  handleChange("pricing", {
                    ...pricing,
                    amountPayable: e.target.value,
                  })
                }
                fullWidth
                size="small"
                placeholder="Amount"
              />
            </Box>
            <Box>
              <Typography className="label">Payment Account*</Typography>
              <Autocomplete
                fullWidth
                size="small"
                popupIcon={<KeyboardArrowDown />}
                options={paymentMetaData?.finance.getAllPaymentMeta || []}
                getOptionLabel={(option) =>
                  option.service === "UPI" ? option.address : option.name
                }
                loading={paymentMetaLoading}
                itemID="id"
                renderInput={(params) => (
                  <TextField {...params} placeholder="Select" />
                )}
                value={!pricing.paymentMeta?.id ? null : pricing.paymentMeta}
                onChange={(e, newValue) => {
                  handleChange("pricing", {
                    ...pricing,
                    paymentMeta: newValue,
                  });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Pricing Type</Typography>
              <RadioGroup
                row
                sx={{ justifyContent: "space-between" }}
                value={pricing.type}
                // onChange={(e) => handleChange('pricing', { ...pricing, type: e.target.value })}
              >
                <FormControlLabel
                  value="ONETIME"
                  control={<Radio />}
                  label="One Time"
                />
                {/* <FormControlLabel
                  value="SUBSCRIPTION"
                  control={<Radio />}
                  label="Subscription"
                /> */}
              </RadioGroup>
            </Box>
          </Box>
        )}
        {step === 3 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Basic Details", onEdit: () => setStep(0) },
                  { label: "Subscription Name", value: name, required: true },
                  { label: "Description", value: description },
                  { label: "Type", value: type, required: true },
                  {
                    label: "Period",
                    value:
                      period.value && period.unit
                        ? `${period.value} ${period.unit}`
                        : "",
                  },

                  { header: "Offer Details", onEdit: () => setStep(1) },
                  {
                    label: "Offer Type",
                    value: offerType === "DISCOUNT" ? "Discount" : "Credits",
                  },
                  {
                    label: "Offer Period",
                    value:
                      offerPeriod.value && offerPeriod.unit
                        ? `${offerPeriod.value} ${offerPeriod.unit}`
                        : "",
                  },
                  { label: "Amount", value: amount, required: true },

                  { header: "Pricing Details", onEdit: () => setStep(2) },
                  { label: "Name", value: pricing.name },
                  {
                    label: "Amount Payable",
                    value: pricing.amountPayable,
                    required: true,
                  },
                  {
                    label: "Payment Account",
                    value:
                      pricing.paymentMeta?.service === "UPI"
                        ? pricing.paymentMeta?.address
                        : pricing.paymentMeta?.name,
                    required: true,
                  },
                  { label: "Type", value: "One Time" },
                ].map(({ header, onEdit, label, value, required }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td className="bold">{label}</td>
                          <td>
                            {required &&
                            ["", null, undefined].includes(value) ? (
                              <Box display="flex" alignItems="center">
                                <ErrorOutline
                                  fontSize="small"
                                  color="error"
                                  sx={{ mr: 1 }}
                                />
                                Required
                              </Box>
                            ) : (
                              value
                            )}
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && <Button onClick={() => setStep(step - 1)}>Back</Button>}
        <Button
          onClick={() => {
            if (step === steps.length - 1) handleSubmit();
            else setStep(step + 1);
          }}
          variant={
            isComplete(step) || step === steps.length - 1
              ? "contained"
              : "outlined"
          }
          disableElevation
          disabled={step === steps.length - 1 && !isValid}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step) || isEditMode
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateDialog;
