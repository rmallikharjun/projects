import { useSelector } from "react-redux";
import { DeleteOutline, EditOutlined, HighlightOff } from "@mui/icons-material";
import { Box, IconButton } from "@mui/material";
import {
  drawer,
  getDarkModePreference,
  GlobalState,
  getPermissions,
} from "utils";
import moment from "moment";

const DrawerContent = ({
  data,
  setCreateDialog,
  setDeleteDialog,
  setUsersDialog,
}: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const { canWrite } = getPermissions("charger:chargers");

  let usersArray = (data?.users?.constructor === Array ? data.users : []).map(
    (user: any) => ({
      value:
        user.firstName || user.lastName
          ? `${user.firstName || ""} ${user.lastName || ""}`
          : "-",
      value2: user.email,
      value3: user.phone,
    })
  );

  let table = [
    { header: "Subscription Info" },
    { label: "Name", value: data?.name },
    { label: "Description", value: data?.description },
    { label: "Type", value: data?.type },
    {
      label: "Period",
      value:
        data?.period && data?.period?.unit && data?.period?.unit !== "NA"
          ? `${data.period.value} ${data.period.unit}`
          : "-",
    },
    {
      label: "Created At",
      value: moment(data?.createdAt).format("MMM D, YYYY, HH:mm"),
    },
    { header: "Pricing Info" },
    { label: "Name", value: data?.pricing?.name },
    { label: "Status", value: data?.pricing?.status },
    { label: "Type", value: data?.pricing?.type },
    { label: "Amount Payable", value: data?.pricing?.amountPayable },
    {
      label: "Payment Meta",
      value: data?.pricing?.paymentMeta
        ? data.pricing.paymentMeta.service === "UPI"
          ? data.pricing.paymentMeta.address
          : data.pricing.paymentMeta.name
        : "",
    },
    { header: `Users (${usersArray.length})`, enableEdit: true },
    { label: "Name", label2: "Email", label3: "Phone" },
    ...usersArray,
  ];

  return (
    <>
      <Box
        key={data?.id || ""}
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {data.name}
          <Box display="grid" gridTemplateColumns="repeat(3, auto)" gap={1}>
            {canWrite && (
              <>
                <IconButton
                  children={<EditOutlined />}
                  color="inherit"
                  size="small"
                  onClick={() =>
                    setCreateDialog({ open: true, isEditMode: true, data })
                  }
                />
                <IconButton
                  children={<DeleteOutline />}
                  color="inherit"
                  size="small"
                  onClick={() => setDeleteDialog({ open: true, data })}
                />
              </>
            )}

            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              py: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "&.padding": {
                      py: 2.25,
                    },
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(
                  (
                    {
                      header,
                      enableEdit,
                      label,
                      value,
                      label2,
                      value2,
                      label3,
                      value3,
                    },
                    i
                  ) => {
                    const isFirst = table[i - 1]?.header;
                    const isLast = !table[i + 1] || table[i + 1].header;

                    return (
                      <tr
                        key={i}
                        className={
                          header
                            ? "header"
                            : `${isFirst ? "first" : ""} ${
                                isLast ? "last" : ""
                              }`
                        }
                      >
                        {header ? (
                          <td
                            colSpan={2}
                            className={enableEdit ? "" : "padding"}
                          >
                            <span>{header}</span>
                            {enableEdit && (
                              <IconButton
                                sx={{ ml: 1.5 }}
                                children={<EditOutlined />}
                                color="primary"
                                size="small"
                                onClick={() =>
                                  setUsersDialog({ open: true, data })
                                }
                              />
                            )}
                          </td>
                        ) : (
                          <>
                            {label && <td className="bold">{label}</td>}
                            {label2 && <td className="bold">{label2}</td>}
                            {label3 && <td className="bold">{label3}</td>}
                            {value && <td>{value}</td>}
                            {value2 && <td>{value2}</td>}
                            {value3 && <td>{value3}</td>}
                          </>
                        )}
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default DrawerContent;
