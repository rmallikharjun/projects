import React from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { setLoader, snackbar } from "utils";
import { gql, useMutation } from "@apollo/client";

const DELETE_SUBSCRIPTION = gql`
  mutation DeleteSubscription($where: SubscriptionPolicyWhereUniqueInput!) {
    subscriptionPolicy {
      delete(where: $where) {
        id
      }
    }
  }
`;

interface DeleteDialogProps {
  open: boolean;
  handleClose: () => void;
  subscription: any;
}

const DeleteDialog: React.FC<DeleteDialogProps> = ({
  open,
  handleClose,
  subscription,
}) => {
  const [deleteSubscription] = useMutation(DELETE_SUBSCRIPTION, {
    refetchQueries: ["GetSubscriptions"],
    onCompleted: () => {
      setLoader(false);
      snackbar.success("Deleted subscription");
      handleClose();
    },
    onError: () => {
      setLoader(false);
      snackbar.error("Error deleting subscription");
    },
  });

  function handleDelete() {
    setLoader(true);
    deleteSubscription({
      variables: {
        where: {
          id: subscription?.id,
        },
      },
    });
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Subscription</DialogTitle>
      <DialogContent className="py-1">
        Are you sure you want to delete "<b>{subscription?.name}</b>"?
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={handleDelete}>
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteDialog;
