import { gql, useQuery } from "@apollo/client";
import {
  Add,
  DeleteOutline,
  EditOutlined,
  InfoOutlined,
  VisibilityOutlined,
} from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Tab,
  Tabs,
  useMediaQuery,
  useTheme,
  Hidden,
} from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import moment from "moment";
import { useEffect, useState } from "react";
import { drawer, getPermissions, snackbar } from "utils";
import CreateDialog from "./CreateDialog";
import DeleteDialog from "./DeleteDialog";
import DrawerContent from "./DrawerContent";
import UsersDialog from "./UsersDialog";
import Search from "../../../components/Search";

const GET_SUBSCRIPTIONS = gql`
  query GetSubscriptions {
    subscriptionPolicy {
      getAll {
        id
        name
        description
        type
        createdAt
        period {
          value
          unit
        }
        users {
          id
          firstName
          lastName
          email
          phone
        }
        pricing {
          name
          status
          type
          amountPayable
          paymentMeta {
            id
            service
            name
            address
          }
        }
        offers {
          id
          status
          type
          period {
            value
            unit
          }
          value
        }
      }
    }
  }
`;

const Subscriptions = () => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

  const { canWrite } = getPermissions("charger:subscriptions");
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState("");
  const [createDialog, setCreateDialog] = useState({
    open: false,
    isEditMode: false,
    data: null,
  });
  const [usersDialog, setUsersDialog] = useState<any>({
    open: false,
    data: null,
  });
  const [deleteDialog, setDeleteDialog] = useState({ open: false, data: null });
  const [subscriptions, setSubscriptions] = useState([]);
  const [key, setKey] = useState(0);

  const { loading, data } = useQuery(GET_SUBSCRIPTIONS, {
    onError: () => {
      snackbar.error("Error fetching subscriptions");
    },
  });

  console.log("Work! " + JSON.stringify(data));

  useEffect(() => {
    setKey((prev) => prev + 1);
    if (data && !loading) {
      let subsArray = data.subscriptionPolicy.getAll;
      setSubscriptions(subsArray);
      if (usersDialog.open) {
        setUsersDialog({
          ...usersDialog,
          data: subsArray.find((el: any) => el.id === usersDialog.data.id),
        });
      }
    } else {
      setSubscriptions([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, loading]);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
        {canWrite && (
          <Button
            sx={{ height: 40, textTransform: "none" }}
            size={isMdUp ? "medium" : "small"}
            startIcon={<Add />}
            color="primary"
            variant="contained"
            onClick={() =>
              setCreateDialog((prev) => ({
                ...prev,
                open: true,
                isEditMode: false,
              }))
            }
          >
            Create New
          </Button>
        )}
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs
              className={isMdUp ? "" : "dense"}
              value={tab}
              onChange={(e, tab) => setTab(tab)}
            >
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${subscriptions.length || "-"}"`,
                  },
                }}
              />
            </Tabs>
          </Box>
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                {console.log(search, "for search")}
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
        </Box>
        <CreateDialog
          open={createDialog.open}
          isEditMode={createDialog.isEditMode}
          subscription={createDialog.data}
          handleClose={() =>
            setCreateDialog((prev) => ({ ...prev, open: false }))
          }
        />
        <DeleteDialog
          open={deleteDialog.open}
          handleClose={() => setDeleteDialog({ ...deleteDialog, open: false })}
          subscription={deleteDialog.data}
        />
        <UsersDialog
          open={usersDialog.open}
          handleClose={() => setUsersDialog({ ...usersDialog, open: false })}
          subscription={usersDialog.data}
        />
        <Table
          key={key}
          loading={loading}
          rows={subscriptions}
          columns={[
            {
              key: "name",
              label: "Subscription Name",
              Render: (row) => (
                <Box display="flex" alignItems="center">
                  <Button
                    size="small"
                    sx={{
                      ml: 0.5,
                      pl: 2,
                      color: (theme) => theme.customColors.black,
                    }}
                    onClick={() =>
                      drawer.open(
                        <DrawerContent
                          data={row}
                          setCreateDialog={setCreateDialog}
                          setDeleteDialog={setDeleteDialog}
                          setUsersDialog={setUsersDialog}
                        />
                      )
                    }
                  >
                    {row.name}
                    {/* <InfoOutlined fontSize="small" /> */}
                  </Button>
                </Box>
              ),
            },
            { key: "type", label: "Type" },
            {
              key: "createdAt",
              label: "Created At",
              format: (value) => moment(value).format("MMM D, YYYY, HH:mm"),
            },
            {
              key: "offers",
              label: "Offers",
              format: (offers) =>
                offers.map((offer: any) => offer.type).join(", "),
              // Render: (row) => {
              //   let offers = row.offers.map((offer: any) => offer.type)
              //   return offers.join(', ')
              // }
            },
            {
              key: "users",
              label: "Users",
              Render: (row) => (
                <Box display="flex" alignItems="center">
                  {row.users.length}
                  <IconButton
                    sx={{ ml: 1, color: (theme) => theme.customColors.action }}
                    size="small"
                    onClick={() => setUsersDialog({ open: true, data: row })}
                  >
                    <VisibilityOutlined fontSize="small" />
                  </IconButton>
                </Box>
              ),
            },
            ...(canWrite
              ? [
                  {
                    key: "actions",
                    label: "Actions",
                    Render: (row: any) => (
                      <Box display="flex">
                        <IconButton
                          size="small"
                          sx={{
                            ml: 0.5,
                            color: (theme) => theme.customColors.action,
                          }}
                          onClick={() =>
                            drawer.open(
                              <DrawerContent
                                data={row}
                                setCreateDialog={setCreateDialog}
                                setDeleteDialog={setDeleteDialog}
                                setUsersDialog={setUsersDialog}
                              />
                            )
                          }
                        >
                          <InfoOutlined fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          sx={{ color: (theme) => theme.customColors.grey }}
                          onClick={() =>
                            setCreateDialog((prev) => ({
                              ...prev,
                              open: true,
                              isEditMode: true,
                              data: row,
                            }))
                          }
                        >
                          <EditOutlined fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          sx={{ color: (theme) => theme.customColors.grey }}
                          onClick={() =>
                            setDeleteDialog({ open: true, data: row })
                          }
                        >
                          <DeleteOutline fontSize="small" />
                        </IconButton>
                      </Box>
                    ),
                  },
                ]
              : []),
          ]}
        />
      </Paper>
    </>
  );
};

export default Subscriptions;
