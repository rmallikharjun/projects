import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import { drawer, getDarkModePreference, GlobalState } from "utils";
import moment from "moment";

type Booking = {
  id: string | number;
  uid: string;
  [key: string]: any;
};

const InfoDrawer: React.FC<{ booking: Booking }> = ({ booking }) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [table, setTable] = useState([
    { header: "Basic Details" },
    { label: "Booking From", value: "" },
    { label: "Booking To", value: "" },
    { label: "Total Duration", value: "" },
    { label: "User", value: "" },
    { header: "Pricing Info" },
    { label: "Payment Status", value: "" },
    { header: "Additional Details" },
    { label: "Feedback", value: "" },
  ]);

  useEffect(() => {
    if (booking) {
      setTable([
        { header: "Basic Details" },
        {
          label: "Booking From",
          value: moment(booking.bookingStart).format("MMM DD YYYY, hh:mm a "),
        },
        {
          label: "Booking To",
          value: moment(booking.bookingEnd).format("MMM DD YYYY, hh:mm a"),
        },
        {
          label: "Total Duration",
          value:
            booking.bookingDuration < 1
              ? booking.bookingDuration * 60 + " mins"
              : booking.bookingDuration === 1
              ? booking.bookingDuration + " hour"
              : booking.bookingDuration + " hours",
        },
        {
          label: "User",
          value: booking.userName === " " ? "-" : booking.userName,
        },
        { header: "Pricing Info" },
        { label: "Payment Status", value: booking.amount },
        { header: "Additional Details" },
        { label: "Feedback", value: "" },
      ]);
    }
  }, [booking]);

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {booking.chargerId}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            {/* <IconButton
              children={<DeleteOutline />}
              color="inherit"
              size="small"
              onClick={() => setDeleteDialog(true)}
            /> */}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              pt: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 2,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(({ header, label, value }, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          {/* <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                          /> */}
                        </td>
                      ) : (
                        <>
                          <td className="bold">{label}</td>
                          <td>{value}</td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        </Box>
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
    </>
  );
};

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent sx={{ marginTop: "20px" }}>
        Are you sure you want to DELETE:{" "}
        <span style={{ fontWeight: "bold" }}>Booking</span>?
      </DialogContent>
      <DialogActions sx={{ margin: "20px 20px 20px 0" }}>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default InfoDrawer;
