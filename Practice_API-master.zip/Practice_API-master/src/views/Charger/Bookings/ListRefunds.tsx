import { Box, Button, Paper, Tooltip } from "@mui/material";
import Table from "../../../components/Table";
import { useState } from "react";
import { useQuery } from "react-query";
import { authorizedFetch, snackbar } from "utils";

interface ListProps {}

const List: React.FC<ListProps> = () => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  // const [search, setSearch] = useState("");

  const refundsUrl = `https://payments.dev.revos.in/v1/payments/refunds/cashfree/getRefundRequest`;

  const { data } = useQuery(
    ["getRefundRequests"],
    () =>
      authorizedFetch(refundsUrl, {
        headers: {},
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  console.log(data);

  return (
    <Box sx={{ display: "flex" }}>
      <Paper
        sx={{
          zIndex: 2,
          width: 1,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          pt: 3,
        }}
      >
        {/* <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
        </Box> */}
        <Table
          rowCount={10}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          rows={[]}
          loading={false}
          columns={[
            { key: "city", label: "User" },
            { key: "city", label: "Booking Id" },
            { key: "city", label: "Date" },
            { key: "city", label: "Amount" },
            { key: "city", label: "Status" },
            { key: "city", label: "Remarks" },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <Button>Approve</Button>
                  </Tooltip>
                  <Tooltip title="Info">
                    <Button>Reject</Button>
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </Box>
  );
};

export default List;
