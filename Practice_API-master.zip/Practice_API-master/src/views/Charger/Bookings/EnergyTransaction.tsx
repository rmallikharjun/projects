import {
  Box,
  Paper,
  Typography,
  useTheme,
  CircularProgress,
  Avatar,
  Skeleton,
  useMediaQuery,
} from "@mui/material";

import { Line } from "react-chartjs-2";
import { authorizedFetch, snackbar } from "../../../utils";
import RangePicker from "components/RangePicker";
import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { AttachMoney, Bolt } from "@mui/icons-material";
import moment from "moment";

interface Props {
  masterView: boolean;
}

const Loading = () => (
  <Box>
    <Skeleton width={38} height={38} variant="circular" />
    <Typography variant="h5" className="value">
      <Skeleton height={20} width="30%" />
    </Typography>
    <Typography variant="body2" className="title">
      <Skeleton width="60%" />
    </Typography>
  </Box>
);

const EnergyTransactions: React.FC<Props> = ({ masterView }) => {
  const theme = useTheme();
  const isLgUp = useMediaQuery(theme.breakpoints.up("lg"));
  const [chartData, setChartData] = useState<any>(null);

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(bookingsNewUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let dataArray = data.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("earnings")) {
            getExisting("earnings").y += Math.round(
              parseFloat(cur.totalEarnings)
            );
            getExisting("energy").y += cur.totalEnergyConsumed;
          } else {
            acc.earnings.push({
              x: day,
              y: Math.round(parseFloat(cur.totalEarnings)),
            });
            acc.energy.push({ x: day, y: cur.totalEnergyConsumed });
          }
          return acc;
        },
        {
          earnings: [],
          energy: [],
        }
      );
      setChartData(chartData);
    }
  }, [data]);

  // const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading, data } = useQuery(
  //   ["getBookings", dateFrom, dateTo, masterView],
  //   () => authorizedFetch(bookingsUrl, { headers: { master: masterView } }),
  //   {
  //     onError: () => snackbar.error("Error fetching data"),
  //   }
  // );

  // const statsUrl = `${BOLT_URL}/company/stats/all?dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading: statsLoading, data: allStats } = useQuery(
  //   ["getAllStats", dateFrom, dateTo, masterView],
  //   () => authorizedFetch(statsUrl, { headers: { master: masterView } })
  // );

  // useEffect(() => {
  //   if (data?.data?.bookings?.constructor === Array) {
  //     let dataArray = data.data.bookings.sort(
  //       (a: any, b: any) =>
  //         moment(a.bookingTime).valueOf() - moment(b.bookingTime).valueOf()
  //     );
  //     let chartData = dataArray.reduce(
  //       (result: any, el: any) => {
  //         let date = format(new Date(el.bookingTime), "MMM d, yyyy");
  //         if (!result.bookings.find((d: any) => d.x === date)) {
  //           result.bookings.push({ x: date, y: 1 });
  //           result.earnings.push({ x: date, y: el.amount });
  //           result.energy.push({ x: date, y: el.energyConsumed });
  //         } else {
  //           result.bookings.find((d: any) => d.x === date).y += 1;
  //           result.earnings.find((d: any) => d.x === date).y += el.amount;
  //           result.energy.find((d: any) => d.x === date).y += el.energyConsumed;
  //         }
  //         return result;
  //       },
  //       {
  //         bookings: [],
  //         earnings: [],
  //         energy: [],
  //       }
  //     );
  //     // Object.keys(chartData).forEach((chart: any) => {
  //     //   chartData[chart].sort(
  //     //     (a: any, b: any) => moment(a.x).valueOf() - moment(b.x).valueOf()
  //     //   );
  //     // });
  //     // console.log(chartData);
  //     setChartData(chartData);
  //   }
  // }, [data]);

  return (
    <>
      <Paper
        sx={{
          height: isLgUp ? 430 : 650,
          p: { xs: 2, md: 3 },
          gridColumn: { lg: "span 5", xl: "span 4" },
          display: "flex",
          flexDirection: isLgUp ? "row" : "column",
        }}
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            width: isLgUp ? "85%" : "100%",
          }}
        >
          <Box
            mb={1.5}
            display="flex"
            flexDirection={{ xs: "column", sm: "row" }}
            justifyContent={{ sm: "space-between" }}
            alignItems={{ sm: "center" }}
          >
            <Typography variant="h6">Energy vs Transaction</Typography>
            <Box
              sx={{
                my: { xs: 1, sm: 0 },
                alignSelf: { xs: "center", sm: "unset" },
              }}
            >
              <RangePicker range={range} setRange={setRange} />
            </Box>
          </Box>
          <Box
            sx={{
              mb: 3,
              display: "flex",
              alignItems: "center",
              "& .text": {
                position: "relative",
                fontSize: 13,
                lineHeight: "1em",
                color: theme.customColors.greySecondary,
                "&:before": {
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: -18,
                  height: 10,
                  width: 10,
                  backgroundColor: theme.customColors.greenSecondary,
                  borderRadius: 1,
                },
              },
              "& .bookings": {
                ml: 2.5,
                mr: 1,
                "&:before": {
                  backgroundColor: theme.customColors.blueSecondary,
                },
              },
            }}
            display="flex"
            alignItems="center"
          >
            <Box display="flex" alignItems="center">
              <span className="text bookings">Energy (kWh)</span>
              {/* <Avatar variant="label">
                {isLoading ? (
                  <CircularProgress size={13} />
                ) : (
                  data?.data?.totalEnergyConsumed.toFixed(3) || 0
                )}
              </Avatar> */}
            </Box>
            <Box display="flex" alignItems="center" ml={4.5}>
              <span className="text earnings">Transaction (₹)</span>
              {/* <Avatar variant="label" sx={{ ml: 1 }}>
                {isLoading ? (
                  <CircularProgress size={13} />
                ) : (
                  `₹${data?.data?.totalEarnings?.toFixed(0) || 0}`
                )}
              </Avatar> */}
            </Box>
          </Box>
          <Box
            sx={{
              flexGrow: 1,
              width: 1,
              minHeight: 0,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {isLoading ? (
              <CircularProgress />
            ) : (
              <Line
                data={(canvas) => {
                  let labels = chartData?.energy?.map(
                    (el: any) => el.x.split(",")[0]
                  );
                  return {
                    labels,
                    datasets: [
                      {
                        label: "Energy",
                        data: chartData?.energy?.map((el: any) => el.y),
                        pointBackgroundColor: theme.customColors.blueSecondary,
                        borderColor: theme.customColors.blueSecondary,
                        yAxisID: "yAxis",
                      },
                      {
                        label: "Transaction",
                        data: chartData?.earnings?.map((el: any) => el.y),
                        pointBackgroundColor: theme.customColors.greenSecondary,
                        borderColor: theme.customColors.greenSecondary,
                        yAxisID: "yAxis2",
                      },
                    ],
                  };
                }}
                options={{
                  datasets: {
                    line: {
                      tension: 0.4,
                      borderWidth: 2,
                      pointRadius: 0,
                      pointHoverRadius: 4,
                      pointHoverBackgroundColor: "#fff",
                      pointHoverBorderWidth: 3,
                    },
                  },
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false,
                    },
                    tooltip: {
                      caretSize: 0,
                      mode: "index",
                      intersect: false,
                      yAlign: "center",
                      displayColors: false,
                      caretPadding: 16,
                      titleFont: {
                        weight: "400",
                      },
                      bodyFont: {
                        weight: "500",
                      },
                    },
                  },
                  interaction: {
                    mode: "index",
                    intersect: false,
                  },
                  scales: {
                    xAxis: {
                      // type: 'time',
                      grid: {
                        display: false,
                        tickWidth: 0,
                        tickLength: 16,
                        drawBorder: false,
                      },
                      ticks: {
                        color: theme.palette.text.secondary,
                      },
                    },
                    yAxis: {
                      title: {
                        display: true,
                        text: "Energy (kWh)",
                        padding: {
                          top: 0,
                          bottom: 15,
                        },
                        color: theme.customColors.grey,
                        font: {
                          weight: "500",
                          size: 12,
                        },
                      },
                      ticks: {
                        color: theme.palette.text.secondary,
                      },
                      suggestedMin: 15,
                      suggestedMax: 85,
                      grid: {
                        borderDash: [10],
                        tickWidth: 0,
                        tickLength: 16,
                        drawBorder: false,
                      },
                    },
                    yAxis2: {
                      position: "right",
                      title: {
                        display: true,
                        text: "Transaction (₹)",
                        padding: {
                          top: 0,
                          bottom: 15,
                        },
                        color: theme.customColors.grey,
                        font: {
                          weight: "500",
                          size: 12,
                        },
                      },
                      ticks: {
                        color: theme.palette.text.secondary,
                        // callback: (label, index, lables) => '₹' + label
                      },
                      suggestedMin: 15,
                      suggestedMax: 85,
                      grid: {
                        display: false,
                        tickWidth: 0,
                        tickLength: 16,
                        drawBorder: false,
                      },
                    },
                  },
                }}
              />
            )}
          </Box>
        </Box>
        <Box
          sx={{
            // gridColumn: "span 1",
            ml: isLgUp ? 4 : 0,
            mt: isLgUp ? 0 : 3,
            width: isLgUp ? "15%" : "100%",
            height: "auto",
            display: "grid",
            gap: 2,
            overflowX: "auto",
            gridTemplateColumns: {
              xs: "repeat(2, minmax(max-content, 1fr))",
              lg: "1fr",
            },
            "& > div": {
              p: 2,
              height: "100%",
              border: 1,
              borderColor: (theme) => theme.customColors.border,
              borderRadius: "4px",
              "& .icon": {
                mt: 3,
                mr: 2,
                width: 38,
                height: 38,
                borderRadius: 50,
              },
              "& .value": {
                fontWeight: 700,
                fontSize: 24,
                color: "text.primary",
                lineHeight: "1em",
                mb: 1,
                marginTop: 2,
                "& span": {
                  fontWeight: 500,
                  fontSize: 16,
                },
              },
              "& .title": {
                fontSize: 15,
                lineHeight: "20px",
                color: "text.secondary",
              },
            },
          }}
        >
          {isLoading ? (
            <Loading />
          ) : (
            <Box>
              <Avatar variant="icon" className="icon">
                <Bolt />
              </Avatar>
              <Typography className="value">
                {Math.floor(data?.data?.totalEnergyConsumed).toFixed(2)}
                <span> kWh</span>
              </Typography>
              <Typography className="title">Total Energy</Typography>
            </Box>
          )}
          {isLoading ? (
            <Loading />
          ) : (
            <Box>
              <Avatar variant="icon" className="icon">
                <AttachMoney />
              </Avatar>
              <Typography className="value">
                <span>₹</span>
                {Number(data?.data?.totalEarnings.toFixed(0)).toLocaleString()}
              </Typography>
              <Typography className="title">Total Earnings</Typography>
            </Box>
          )}
        </Box>
      </Paper>
    </>
  );
};

export default EnergyTransactions;
