import { FileDownload, InfoOutlined } from "@mui/icons-material";
import {
  Avatar,
  Box,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Tooltip,
} from "@mui/material";
import Table from "../../../components/Table";
import { useEffect, useState } from "react";
import InfoDrawer from "./InfoDrawer";
import { drawer, getDuration, setLoader, snackbar } from "utils";
import moment from "moment";
import { saveAs } from "file-saver";
import { authorizedFetch } from "utils";
import { REPORTS_URL } from "utils/constants";

interface ListProps {
  setInfoDrawer: React.Dispatch<React.SetStateAction<boolean>>;
  infoDrawer: boolean;
  bookingList: any[];
  loading: boolean;
}

const List: React.FC<ListProps> = ({
  setInfoDrawer,
  infoDrawer,
  bookingList,
  loading,
}) => {
  const [tab, setTab] = useState(0);
  const [rows, setRows] = useState<any[]>([]);

  function downloadInvoice(
    bookingId: any,
    chargerId: any,
    chargingStart: any,
    chargingEnd: any
  ) {
    setLoader(true);
    let request: any = authorizedFetch(
      `${REPORTS_URL}/bookinginvoice?format=pdf&token=1234&id=${bookingId}`
    );
    request
      .then((result: any) => {
        setLoader(false);
        if (result.file) {
          const fileURL: any = result.file;
          saveAs(
            fileURL,
            `${chargerId}_${moment(chargingStart).format("DD-MM-YYYY")}.pdf`
          );
          snackbar.success("Downloaded invoice");
        } else if (result.message) {
          snackbar.error("Error downloading invoice");
          console.error(result);
        }
      })
      .catch((err: Error) => {
        console.error(err);
        setLoader(false);
        snackbar.error("Error downloading invoice");
      });
  }

  useEffect(() => {
    if (bookingList) {
      setRows(bookingList);
    }
  }, [bookingList]);

  let tableWidth: number;
  if (infoDrawer) {
    tableWidth = 0.65;
  } else {
    tableWidth = 1;
  }

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Box sx={{ display: "flex" }}>
      <Paper
        sx={{
          zIndex: 2,
          width: tableWidth,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab label="All Bookings" />
            </Tabs>
          </Box>
          {/* <FilterBy /> */}
        </Box>
        <Table
          rows={rows}
          loading={loading}
          columns={[
            { key: "chargerId", label: "Charger UID" },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={row.bookingStatus === "TERMINATED" ? "red" : ""}
                >
                  {row.bookingStatus}
                </Avatar>
              ),
            },
            { key: "city", label: "Location" },
            {
              key: "userName",
              label: "User",
              format: (value) => (value === " " ? "-" : value),
            },
            {
              key: "bookingStart",
              label: "Start Time",
              format: (value) => moment(value).format("MMM DD, HH:mm"),
            },
            {
              key: "bookingDuration",
              label: "Booking Duration",
              format: (value) => getDuration(value * 60),
            },
            {
              key: "actualDuration",
              label: "Charging Duration",
              Render: (row) =>
                getDuration((row.chargingDuration || row.bookingDuration) * 60),
            },
            {
              key: "amount",
              label: "Amount",
              format: (value) =>
                typeof value === "number" ? "₹" + value : "-",
            },
            {
              key: "energyConsumed",
              label: "Energy Utilised",
              format: (value) =>
                typeof value === "number" ? value.toFixed(3) + " kWh" : "-",
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() => drawer.open(<InfoDrawer booking={row} />)}
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                  <Tooltip title="Download Invoice">
                    <IconButton
                      size="small"
                      sx={{ color: (theme) => theme.customColors.grey }}
                      onClick={() =>
                        downloadInvoice(
                          row.bookingId,
                          row.chargerId,
                          row.bookingStart,
                          row.bookingEnd
                        )
                      }
                      children={<FileDownload fontSize="small" />}
                    />
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </Box>
  );
};

export default List;
