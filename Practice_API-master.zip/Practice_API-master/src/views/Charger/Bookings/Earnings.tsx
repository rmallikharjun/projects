import React, { useState } from "react";
import {
  Box,
  Divider,
  Paper,
  Typography,
  CircularProgress,
  MenuItem,
  Select,
} from "@mui/material";
import DatePicker from "../../../components/RangePicker";
import { getDarkModePreference, GlobalState } from "../../../utils";
import { useSelector } from "react-redux";
import { AnyAaaaRecord } from "dns";

interface Props {
  collectionStats: {
    totalEarnings: number;
    totalUsers: number;
    totalBookings: number;
    totalEnergyConsumed: number;
  };
  stats: {
    statsLoading: boolean;
    statsData: any;
  };
}

const Earnings: React.FC<Props> = ({ stats }) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  let { statsLoading, statsData } = stats;

  const { totalEarnings, totalEnergyConsumed } = statsData?.data?.stats || {};

  const ranges = ["Past Three Months", "Past Three Weeks", "Past Three Days"];
  const [range, setRange] = useState("Past Three Months");

  return (
    <Paper
      sx={{
        height: 388,
        p: 3,
        gridColumn: "span 3",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box
        mb={4}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Typography variant="h6">Earnings</Typography>
        <Box minWidth={200}>
          <Select
            className="primary"
            value={range}
            onChange={(e: any) => setRange(e.target.value)}
            sx={{ minWidth: "100%" }}
          >
            {ranges.map((range, i) => (
              <MenuItem key={i} value={range}>
                {range}
              </MenuItem>
            ))}
          </Select>
        </Box>

        {/* <DatePicker /> */}
      </Box>
      <Box
        sx={{
          mb: 3.5,
          width: 1,
          display: "flex",
          alignItems: "end",
          "& .value": { color: "text.primary" },
          "& .title": { color: "text.secondary" },
          "& .info": {
            display: "flex",
            flexDirection: "column",
            lineHeight: "1em",
            "& .value": {
              mb: 2.25,
              fontSize: 24,
              fontWeight: 500,
            },
            "& .title": {
              fontSize: 14,
            },
          },
          "& .main": {
            "& .value": {
              fontWeight: 700,
              fontSize: 32,
              lineHeight: "36px",
              mb: 2,
            },
            "& .title": {
              textTransform: "uppercase",
            },
          },
        }}
      >
        <Box className="info main">
          <span className="value">
            ₹
            {statsLoading ? (
              <CircularProgress size={18} color="inherit" />
            ) : (
              totalEarnings
            )}
          </span>
          <span className="title">Net Revenue</span>
        </Box>
        <Box
          px={2}
          display="flex"
          justifyContent="space-evenly"
          alignItems="center"
          flexGrow={1}
        >
          <Box className="info">
            <span className="value">
              ₹
              {statsLoading ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                totalEarnings
              )}
            </span>
            <span className="title">Total Earnings</span>
          </Box>
          <Divider flexItem orientation="vertical" sx={{ py: 0.5 }} />
          <Box className="info">
            <span className="value">
              {statsLoading ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                Math.floor(totalEnergyConsumed)
              )}
              Kwh
            </span>
            <span className="title">Energy Consumed</span>
          </Box>
        </Box>
      </Box>
      <Box display="grid" gridTemplateColumns="1fr auto">
        {["30%", "30%", "30%"].map((el, i) => (
          <React.Fragment key={i}>
            <Typography gridColumn="span 2" fontSize="14px">
              Kwh
            </Typography>
            <Box mb={2} display="flex" alignItems="center">
              <Box
                sx={{
                  flexGrow: 1,
                  height: 8,
                  position: "relative",
                  bgcolor: isDarkMode ? "#1A1A1A" : "#D7DBEC",
                  borderRadius: 1,
                  "&:after": {
                    content: '""',
                    width: el,
                    height: 1,
                    position: "absolute",
                    top: 0,
                    borderRadius: 1,
                    bgcolor: "#5BDEB4",
                  },
                }}
              ></Box>
              <Typography sx={{ ml: 2.25, fontSize: 16, fontWeight: 500 }}>
                ₹
                {statsLoading ? (
                  <CircularProgress size={18} color="inherit" />
                ) : (
                  totalEarnings
                )}
              </Typography>
            </Box>
          </React.Fragment>
        ))}
      </Box>
    </Paper>
  );
};

export default Earnings;
