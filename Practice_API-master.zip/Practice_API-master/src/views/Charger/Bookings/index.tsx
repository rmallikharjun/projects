import { useState, useEffect } from "react";
import { Box, Tab, Tabs } from "@mui/material";
import Dashboard from "./Dashboard";
import ListBookings from "./ListBookings";
import Breadcrumbs from "../../../components/Breadcrumbs";
import ViewSelector, { View } from "../../../components/ViewSelector";

import { authorizedFetch, GlobalState, snackbar } from "utils";
import { BOLT_URL } from "utils/constants";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import ListRefunds from "./ListRefunds";

const Bookings = () => {
  const masterView = useSelector(
    (state: GlobalState) => state.global.masterView
  );
  const [view, setView] = useState<View>("grid");
  const [infoDrawer, setInfoDrawer] = useState<boolean>(false);
  const [bookingList, setBookingList] = useState<any[]>([]);
  const [cityList, setCityList] = useState<any>();
  const [bookingCountDisplay, setBookingCountDisplay] = useState(0);

  // const [range, setRange] = useState<any>([
  //   sub(new Date(), { months: 1 }),
  //   new Date(),
  // ]);

  // let dateFrom = format(range[0], "yyyy-MM-dd");
  // let dateTo = format(range[1], "yyy-MM-dd");

  const statsUrl = `${BOLT_URL}/company/stats/all`;

  const { data: statsData } = useQuery(["getAllStats", masterView], () =>
    authorizedFetch(statsUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date`;

  const { isLoading: statLoading, data: bookingStats } = useQuery(
    ["getBookingsStatsByDate", masterView],
    () =>
      authorizedFetch(bookingsNewUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  let stats = { statLoading, bookingStats };

  const [collectionStats, setCollectionStats] = useState({
    totalEarnings: 0,
    totalUsers: 0,
    totalBookings: 0,
    totalEnergyConsumed: 0,
    totalBooked: 0,
    totalCancelled: 0,
    totalEnded: 0,
    totalTerminated: 0,
  });

  const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_DESC`; // Filter: &dateFrom=${}&dateTo=${}

  const { isLoading, data } = useQuery(["bookings", masterView], () =>
    authorizedFetch(bookingsUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    if (!data || !statsData) return;

    setBookingList(data.data.bookings);
    setCollectionStats({
      totalEarnings: statsData?.data?.stats?.totalEarnings,
      totalUsers: statsData?.data?.stats?.totalUsers,
      totalBookings: statsData?.data?.stats?.totalBooked,
      totalEnergyConsumed: statsData?.data?.stats?.totalEnergyConsumed,
      totalBooked: statsData?.data?.stats?.totalBooked,
      totalCancelled: statsData?.data?.stats?.bookingsInCancelled,
      totalEnded: statsData?.data?.stats?.bookingsInEnded,
      totalTerminated: statsData?.data?.stats?.bookingsInTerminated,
    });
  }, [data, statsData]);

  const { totalBookings, totalCancelled, totalEnded, totalTerminated } =
    collectionStats;

  const cityUrl = `${BOLT_URL}/company/stats/city`;
  const { data: cityData } = useQuery(["getCityStats", masterView], () =>
    authorizedFetch(cityUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    if (cityData && cityData?.data?.constructor === Array) {
      let cityList: any = [];
      // eslint-disable-next-line
      cityData?.data?.map((el: any) => {
        cityList.push({
          type: "name",
          name: el.city,
          count: el.numberOfBookingsInCity,
        });
      });
      cityList.sort((a: any, b: any) =>
        a.count < b.count ? 1 : b.count < a.count ? -1 : 0
      );
      setCityList(cityList);
    }
  }, [cityData]);

  const [tab, setTab] = useState(0);

  return (
    <>
      <Box
        width={infoDrawer && view !== "grid" ? 0.65 : 1}
        mb={{ xs: 2, md: 3 }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box display="flex" alignItems="center">
          {view === "grid" ? (
            <Breadcrumbs />
          ) : (
            <Box width={"auto"}>
              <Tabs
                sx={{ "& .MuiButtonBase-root": {} }}
                value={tab}
                onChange={(e: any, value: any) => setTab(value)}
              >
                <Tab
                  label="Bookings"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${bookingCountDisplay}"`,
                    },
                  }}
                />
                <Tab label="Refund Requests" />
              </Tabs>
            </Box>
          )}

          {/* {view !== "grid" ? (
            <Box
              ml={1}
              display="flex"
              alignItems="center"
              sx={{ opacity: 0.4 }}
            >
              {
                // eslint-disable-next-line
                "-" + " " + bookingCountDisplay
              }
              <EventAvailableOutlined
                sx={{ width: "18px", mt: "-3px", ml: "2px" }}
              />
            </Box>
          ) : (
            ""
          )} */}
        </Box>

        <ViewSelector view={view} setView={setView} />
      </Box>
      <Box width={1}>
        {view === "grid" ? (
          <Dashboard
            masterView={masterView}
            collectionStats={collectionStats}
            bookingList={bookingList}
            stats={stats}
          />
        ) : tab === 0 ? (
          <ListBookings
            infoDrawer={infoDrawer}
            setInfoDrawer={setInfoDrawer}
            masterView={masterView}
            loading={isLoading}
            cityList={cityList}
            totalBooked={totalBookings}
            totalCancelled={totalCancelled}
            totalEnded={totalEnded}
            totalTerminated={totalTerminated}
            setBookingCountDisplay={setBookingCountDisplay}
          />
        ) : (
          <ListRefunds />
        )}
      </Box>
    </>
  );
};

export default Bookings;
