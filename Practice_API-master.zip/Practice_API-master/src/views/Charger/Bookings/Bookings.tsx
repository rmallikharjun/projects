import {
  Avatar,
  Box,
  Paper,
  Typography,
  useTheme,
  CircularProgress,
} from "@mui/material";
import { alpha } from "@mui/system";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import {
  getDarkModePreference,
  GlobalState,
  authorizedFetch,
  snackbar,
} from "../../../utils";
import RangePicker from "components/RangePicker";
import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";

import { useEffect, useState } from "react";
import { useQuery } from "react-query";

interface Props {
  bookingList: any[];
  masterView: boolean;
}

const Bookings: React.FC<Props> = ({ bookingList, masterView }) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const theme = useTheme();

  const [chartData, setChartData] = useState<any>(null);

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(bookingsNewUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let chartData: any = {
        bookings: [],
      };
      // eslint-disable-next-line
      data?.data?.stats?.map((el: any) => {
        let date = format(new Date(el.date), "MMM d, yyyy");

        chartData.bookings.push({ x: date, y: el.totalBookings });
      });

      setChartData(chartData);
    }
  }, [data]);

  // const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading, data } = useQuery(
  //   ["getBookings", dateFrom, dateTo, masterView],
  //   () => authorizedFetch(bookingsUrl, { headers: { master: masterView } }),
  //   {
  //     onError: () => snackbar.error("Error fetching data"),
  //   }
  // );

  // useEffect(() => {
  //   if (data?.data?.bookings?.constructor === Array) {
  //     let dataArray = data.data.bookings.sort(
  //       (a: any, b: any) =>
  //         moment(a.bookingTime).valueOf() - moment(b.bookingTime).valueOf()
  //     );
  //     let chartData = dataArray.reduce(
  //       (result: any, el: any) => {
  //         let date = format(new Date(el.bookingTime), "MMM d, yyyy");
  //         if (!result.bookings.find((d: any) => d.x === date)) {
  //           result.bookings.push({ x: date, y: 1 });
  //         } else {
  //           result.bookings.find((d: any) => d.x === date).y += 1;
  //         }
  //         return result;
  //       },
  //       {
  //         bookings: [],
  //       }
  //     );
  //     setChartData(chartData);
  //   }
  // }, [data]);

  return (
    <Paper
      sx={{
        p: { xs: 2, md: 3 },
        pb: { xs: 3, md: 4 },
        gridColumn: { lg: "span 4", xl: "span 5" },
        height: 490,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box
        mb={{ xs: 3, md: 4 }}
        display="flex"
        flexDirection={{ xs: "column", sm: "row" }}
        justifyContent={{ sm: "space-between" }}
        alignItems={{ sm: "center" }}
      >
        <Box display="flex" alignItems="center">
          <Typography variant="h6">Bookings</Typography>
          <Avatar variant="label" sx={{ ml: "11px" }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              data?.data?.totalBookings
            )}
          </Avatar>
        </Box>
        <Box
          sx={{
            my: { xs: 1, sm: 0 },
            alignSelf: { xs: "center", sm: "unset" },
          }}
        >
          <RangePicker range={range} setRange={setRange} />
        </Box>
      </Box>
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        sx={{
          flexGrow: 1,
          width: 1,
          minHeight: 0,
        }}
      >
        {isLoading ? (
          <CircularProgress />
        ) : (
          <Line
            data={(canvas) => {
              let color = "#538ADC";
              let labels = chartData?.bookings?.map(
                (el: any) => el.x.split(",")[0]
              );

              return {
                labels,
                datasets: [
                  {
                    fill: true,
                    data: chartData?.bookings?.map((el: any) => el.y),
                    borderColor: color,
                    borderWidth: 2,
                    backgroundColor: alpha(
                      theme.customColors.blueSecondary,
                      isDarkMode ? 0.1 : 0.2
                    ),
                    tension: 0,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    pointHoverBackgroundColor: "#fff",
                    pointHoverBorderWidth: 3,
                  },
                ],
              };
            }}
            options={{
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                },
                yAxis: {
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  suggestedMin: 15,
                  suggestedMax: 85,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
              },
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
            }}
          />
        )}
      </Box>
    </Paper>
  );
};

export default Bookings;
