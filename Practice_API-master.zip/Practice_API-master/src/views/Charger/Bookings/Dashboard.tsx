import { Box } from "@mui/material";
import Total from "./Total";
import Bookings from "./Bookings";
import EnergyTransactions from "./EnergyTransaction";

interface Props {
  collectionStats: {
    totalEarnings: number;
    totalUsers: number;
    totalBookings: number;
    totalEnergyConsumed: number;
  };
  bookingList: any[];
  stats: {
    statLoading: boolean;
    bookingStats: any;
  };
  masterView: boolean;
}

const Dashboard: React.FC<Props> = ({
  collectionStats,
  bookingList,
  stats,
  masterView,
}) => {
  return (
    <Box
      sx={{
        width: 1,
        gap: { xs: 2, md: 3 },
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          lg: "repeat(5, 1fr)",
          xl: "repeat(6, 1fr)",
        },
        "& > .MuiPaper-root": {
          borderRadius: 2,
          boxShadow: "0 0 4px #1C295A14",
        },
      }}
    >
      <Total collectionStats={collectionStats} stats={stats} />
      <Bookings bookingList={bookingList} masterView={masterView} />
      <EnergyTransactions masterView={masterView} />
      {/* <Earnings collectionStats={collectionStats} stats={stats} /> */}
    </Box>
  );
};

export default Dashboard;
