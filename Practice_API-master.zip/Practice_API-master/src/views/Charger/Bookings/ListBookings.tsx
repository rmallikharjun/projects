import { FileDownload, InfoOutlined } from "@mui/icons-material";
import {
  Avatar,
  Box,
  Hidden,
  IconButton,
  Paper,
  // Tab,
  // Tabs,
  Tooltip,
} from "@mui/material";
import Table from "../../../components/Table";
import { useEffect, useState } from "react";
import InfoDrawer from "./InfoDrawer";
import { drawer, getDuration, setLoader, snackbar } from "utils";
import moment from "moment";
import { saveAs } from "file-saver";
import { authorizedFetch } from "utils";
import { BOLT_URL, REPORTS_URL } from "utils/constants";
import Filter from "../../../components/Filter";
import { useQuery } from "react-query";
import Search from "../../../components/Search";

interface ListProps {
  setInfoDrawer: React.Dispatch<React.SetStateAction<boolean>>;
  infoDrawer: boolean;
  masterView: any;
  loading: boolean;
  cityList: any;
  totalBooked: any;
  totalCancelled: any;
  totalEnded: any;
  totalTerminated: any;
  setBookingCountDisplay: React.Dispatch<React.SetStateAction<number>>;
}

const List: React.FC<ListProps> = ({
  // setInfoDrawer,
  infoDrawer,
  masterView,
  cityList,
  totalBooked,
  totalCancelled,
  totalEnded,
  totalTerminated,
  setBookingCountDisplay,
}) => {
  // const [tab, setTab] = useState(0);
  // const [rows, setRows] = useState<any[]>([]);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");

  function downloadInvoice(
    bookingId: any,
    chargerId: any,
    chargingStart: any,
    chargingEnd: any
  ) {
    setLoader(true);
    let request: any = authorizedFetch(
      `${REPORTS_URL}/v2/bookinginvoice?format=pdf&token=1234&id=${bookingId}`
    );
    request
      .then((result: any) => {
        setLoader(false);
        if (result.file) {
          const fileURL: any = result.file;
          saveAs(
            fileURL,
            `${chargerId}_${moment(chargingStart).format("DD-MM-YYYY")}.pdf`
          );
          snackbar.success("Downloaded invoice");
        } else if (result.message) {
          snackbar.error("Error downloading invoice");
          console.error(result);
        }
      })
      .catch((err: Error) => {
        console.error(err);
        setLoader(false);
        snackbar.error("Error downloading invoice");
      });
  }

  let tableWidth: number;
  if (infoDrawer) {
    tableWidth = 0.65;
  } else {
    tableWidth = 1;
  }

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  // Filter

  // filter values
  const [status, setStatus] = useState({
    booked: false,
    cancelled: false,
    ended: false,
    terminated: false,
  });
  const { booked, cancelled, ended, terminated } = status;

  const [filterList, setFilterList] = useState<string[]>([]);

  // array of cities to filter the select cities
  const [cityListArr, setCityListArr] = useState<any>([]);

  // city search
  const [citySearchDialog, setCitySearchDialog] = useState({
    open: false,
    input: "",
  });
  const [selectedCity, setSelectedCity] = useState<any>("");

  const [dropdownEntries, setDropdownEntries] = useState([
    { type: "heading", label: "Status", searchable: false },
    { type: "name", name: "Booked", count: 0 },
    { type: "name", name: "Cancelled", count: 0 },
    { type: "name", name: "Ended", count: 0 },
    { type: "name", name: "Terminated", count: 0 },
    {
      type: "heading",
      label: "CITY",
      searchable: true,
    },
  ]);

  const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_DESC&${
    !search
      ? `first=${pageSize}&skip=${
          pageSize * (page - 1)
        }&city=${selectedCity}&status=${
          // eslint-disable-next-line
          (booked ? "BOOKED" + " " : "") +
          // eslint-disable-next-line
          (cancelled ? "CANCELLED" + " " : "") +
          // eslint-disable-next-line
          (ended ? "ENDED" + " " : "") +
          // eslint-disable-next-line
          (terminated ? "TERMINATED" + " " : "")
        }`
      : `first=${pageSize}&skip=${pageSize * (page - 1)}&search=${search}`
  }`;

  //   const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_DESC&
  // first=${pageSize}&skip=${pageSize * (page - 1)}&city=${selectedCity}&status=${
  //     // eslint-disable-next-line
  //     (booked ? "BOOKED" + " " : "") +
  //     // eslint-disable-next-line
  //     (cancelled ? "CANCELLED" + " " : "") +
  //     // eslint-disable-next-line
  //     (ended ? "ENDED" + " " : "") +
  //     // eslint-disable-next-line
  //     (terminated ? "TERMINATED" + " " : "")
  //   }`;

  const { isLoading, data: bookingList } = useQuery(
    [
      "bookings",
      masterView,
      status,
      selectedCity,
      filterList,
      page,
      pageSize,
      search,
    ],
    () =>
      authorizedFetch(bookingsUrl, {
        headers: {
          master: masterView,
        },
      })
  );

  const getDropdownData = (entry: any[]) => {
    setDropdownEntries([
      { type: "heading", label: "Status", searchable: false },
      { type: "name", name: "Booked", count: totalBooked || 0 },
      { type: "name", name: "Cancelled", count: totalCancelled || 0 },
      { type: "name", name: "Ended", count: totalEnded || 0 },
      { type: "name", name: "Terminated", count: totalTerminated || 0 },

      {
        type: "heading",
        label: "CITY",
        searchable: true,
      },
      ...entry,
    ]);
  };

  useEffect(() => {
    if (cityList) {
      const list = cityList.map((el: any) => {
        return el.name;
      });
      setCityListArr(list);
      getDropdownData(cityList);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cityList]);

  useEffect(() => {
    setPage(1);
    setPageSize(10);
  }, [filterList, search]);

  useEffect(() => {
    if (filterList) {
      setStatus({
        booked: filterList.includes("Booked"),
        ended: filterList.includes("Ended"),
        cancelled: filterList.includes("Cancelled"),
        terminated: filterList.includes("Terminated"),
      });

      let newList: any = "";
      // eslint-disable-next-line
      filterList.map((el: any) => {
        if (cityListArr.includes(el)) {
          newList = newList + el + "_";
        }
      });
      setSelectedCity(newList.slice(0, -1));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterList]);

  useEffect(() => {
    if (bookingList) {
      setBookingCountDisplay(bookingList?.data?.bookingsCount);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingList]);

  console.log(cityList);

  return (
    <Box sx={{ display: "flex" }}>
      <Paper
        sx={{
          zIndex: 2,
          width: tableWidth,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          {/* <Box width="fit-content">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab label="All Bookings" />
            </Tabs>
          </Box> */}
          {/* <FilterBy /> */}
          <Filter
            count
            dropdownEntries={dropdownEntries}
            getDropdownData={getDropdownData}
            filterList={filterList}
            setFilterList={setFilterList}
            entrySearchDialog={citySearchDialog}
            setEntrySearchDialog={setCitySearchDialog}
            dropdownHeight={118}
            searchableEntryList={cityListArr}
            entryList={cityList}
            onClose={() => {
              setCitySearchDialog({ open: false, input: "" });
              getDropdownData(cityList);
            }}
          />
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
        </Box>
        <Table
          rowCount={bookingList?.data?.bookingsCount}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          rows={bookingList?.data?.bookings || []}
          loading={isLoading}
          columns={[
            { key: "chargerId", label: "Charger UID" },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={row.bookingStatus === "TERMINATED" ? "red" : ""}
                >
                  {row.bookingStatus}
                </Avatar>
              ),
            },
            { key: "city", label: "Location" },
            {
              key: "userName",
              label: "User",
              Render: (row) =>
                row.userName
                  ? row.userName
                  : row.userEmail
                  ? row.userEmail
                  : row.userPhone
                  ? row.userPhone
                  : "No Details Found",
            },
            {
              key: "bookingStart",
              label: "Start Time",
              format: (value) => moment(value).format("MMM DD, HH:mm"),
            },
            {
              key: "bookingDuration",
              label: "Booking Duration",
              format: (value) => getDuration(value * 60),
            },
            {
              key: "actualDuration",
              label: "Charging Duration",
              Render: (row) => getDuration(row.chargingDuration * 60),
            },
            {
              key: "amount",
              label: "Amount",
              format: (value) =>
                typeof value === "number" ? "₹" + value : "-",
            },
            {
              key: "energyConsumed",
              label: "Energy Utilised",
              format: (value) =>
                typeof value === "number" ? value.toFixed(3) + " kWh" : "-",
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme: any) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() => drawer.open(<InfoDrawer booking={row} />)}
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                  <Tooltip title="Download Invoice">
                    <IconButton
                      size="small"
                      sx={{ color: (theme: any) => theme.customColors.grey }}
                      onClick={() =>
                        downloadInvoice(
                          row.bookingId,
                          row.chargerId,
                          row.bookingStart,
                          row.bookingEnd
                        )
                      }
                      children={<FileDownload fontSize="small" />}
                    />
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </Box>
  );
};

export default List;
