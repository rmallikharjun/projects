import { Box, Paper, Typography, Avatar, Skeleton } from "@mui/material";
import {
  AttachMoney,
  EventAvailableOutlined,
  PeopleOutlined,
} from "@mui/icons-material";

interface Props {
  collectionStats: {
    totalEarnings: number;
    totalUsers: number;
    totalBookings: number;
    totalEnergyConsumed: number;
  };
  stats: {
    statLoading: boolean;
    bookingStats: any;
  };
}

const Loading = () => (
  <Box>
    <Skeleton width={38} height={38} variant="circular" />
    <Typography variant="h5" className="value">
      <Skeleton height={20} width="30%" />
    </Typography>
    <Typography variant="body2" className="title">
      <Skeleton width="60%" />
    </Typography>
  </Box>
);

const Total: React.FC<Props> = ({ collectionStats, stats }) => {
  let { statLoading, bookingStats } = stats;

  const {
    totalEarnings,
    totalUsers,
    totalBookings,
    // totalEnergyConsumed
  } = bookingStats?.data || {};

  return (
    <Paper
      sx={{
        height: "auto",
        p: 2,
        display: "grid",
        gap: 2,
        overflowX: "auto",
        gridTemplateColumns: {
          xs: "repeat(3, minmax(max-content, 1fr))",
          lg: "1fr",
        },
        "& > div": {
          p: 2,
          border: 1,
          borderColor: (theme) => theme.customColors.border,
          borderRadius: "4px",
          "& .icon": {
            mr: 2,
            width: 38,
            height: 38,
            borderRadius: 50,
          },
          "& .value": {
            fontWeight: 700,
            fontSize: 24,
            color: "text.primary",
            lineHeight: "1em",
            mb: 1,
            marginTop: 2,
            "& span": {
              fontWeight: 500,
              fontSize: 16,
            },
          },
          "& .title": {
            fontSize: 15,
            lineHeight: "20px",
            color: "text.secondary",
          },
        },
      }}
    >
      {statLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <EventAvailableOutlined />
          </Avatar>
          <Typography className="value">
            {Number(totalBookings).toLocaleString()}
          </Typography>
          <Typography className="title">Total Bookings</Typography>
        </Box>
      )}
      {statLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <AttachMoney />
          </Avatar>
          <Typography className="value">
            ₹{Number(totalEarnings?.toFixed(0))?.toLocaleString()}
          </Typography>
          <Typography className="title">Total Earnings</Typography>
        </Box>
      )}
      {statLoading ? (
        <Loading />
      ) : (
        <Box>
          <Avatar variant="icon" className="icon">
            <PeopleOutlined />
          </Avatar>
          <Typography className="value">
            {Number(totalUsers).toLocaleString()}
          </Typography>
          <Typography className="title">Total Users</Typography>
        </Box>
      )}
    </Paper>
  );
};

export default Total;
