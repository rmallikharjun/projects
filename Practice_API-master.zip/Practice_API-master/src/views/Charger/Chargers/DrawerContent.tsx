import {
  EditOutlined,
  HighlightOff,
  PersonAddOutlined,
  FlagOutlined,
  VisibilityOutlined,
  VisibilityOffOutlined,
} from "@mui/icons-material";
import {
  Box,
  FormControlLabel,
  IconButton,
  Radio,
  RadioGroup,
  Tab,
  Tabs,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Button,
  Autocomplete,
  TextField,
  CircularProgress,
  // MenuItem,
  // Select,
} from "@mui/material";
import Map from "components/Map";
import RangePicker from "components/RangePicker";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import {
  authorizedFetch,
  drawer,
  getDuration,
  getDarkModePreference,
  GlobalState,
  getPermissions,
} from "utils";
import moment from "moment";
import Collapse from "@mui/material/Collapse";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import EditChargers from "./EditChargers";
import { snackbar } from "utils";
import { BOLT_URL } from "utils/constants";
import { useMutation, useQuery } from "react-query";
import FlagCharger from "./FlagCharger";
import ChargerHistory from "./ChargerHistory";
import NotificationDialog from "./NotificationDialog";
import ChargerVisibility from "./ChargerVisibility";
import { format, sub } from "date-fns";

interface Props {
  charger: any;
  vendors: any;
  refetchStats: () => void;
  refetchChargers: () => void;
  openTab: number;
}

const DrawerContent: React.FC<Props> = ({
  charger,
  vendors,
  refetchStats,
  refetchChargers,
  openTab,
}) => {
  console.log(charger);
  const { canWrite } = getPermissions("charger:chargers");
  const [tab, setTab] = useState(openTab);
  const [bookingsFilter, setBookingsFilter] = useState("all");
  const [bookingsData, setBookingsData] = useState([]);

  const [assignVendorDialog, setAssignVendorDialog] = useState({
    open: false,
    data: {},
  });
  const [flagDialog, setFlagDialog] = useState({
    open: false,
    data: {},
  });
  const [editDialog, setEditDialog] = useState({
    open: false,
    count: 0,
  });
  const [notificationDialog, setNotificationDialog] = useState({
    open: false,
    data: {},
  });
  const [chargerVisibilityDialog, setChargerVisibilityDialog] = useState({
    open: false,
    data: {},
  });
  const drawerState = useSelector((state: GlobalState) => state.global.drawer);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const [chargerDetails, setChargerDetails] = useState({
    basicInfo: [
      { label: "UID", value: "" },
      { label: "Name", value: "" },
      { label: "Company", value: "" },
    ],
    ownerInfo: [
      { label: "UID", value: "" },
      { label: "Name", value: "" },
      { label: "Company", value: "" },
    ],
    stationInfo: [
      { label: "Contact Name", value: "" },
      { label: "Contact Number", value: "" },
      { label: "Usage Type", value: "" },
      { label: "Station Name", value: "" },
      { label: "Station Address", value: "" },
      { label: "Latitude", value: "" },
      { label: "Longitude", value: "" },
      { label: "Electricity Cost", value: "" },
      { label: "Base Amount", value: "" },
      { label: "Charge per Hour", value: "" },
    ],
    availability: [
      { label: "Monday", value: "" },
      { label: "Tuesday", value: "" },
      { label: "Wednesday", value: "" },
      { label: "Thursday", value: "" },
      { label: "Friday", value: "" },
      { label: "Saturday", value: "" },
      { label: "Sunday", value: "" },
    ],
    specs: [
      { label: "Manufacturer Name", value: "" },
      { label: "Firmware Version", value: "" },
      { label: "Power Rating", value: "" },
      { label: "Communication Protocol", value: "" },
      { label: "Connector Type", value: "" },
      { label: "Current", value: "" },
      { label: "Voltage", value: "" },
    ],
  });

  const chargerDetailsUrl = `${BOLT_URL}/company/charger/${charger?.id}?orderBy=BOOKING_TIME_DESC`;
  const { isLoading, data } = useQuery(["getCharger", charger?.id], () =>
    authorizedFetch(chargerDetailsUrl)
  );

  const nearbyChargersUrl = `${BOLT_URL}/charger/getAvailableList?lat=${charger.station.location.latitude}&lng=${charger.station.location.longitude}&first=20&skip=0&radius=10000`;
  const { data: nearbyChargers } = useQuery(
    ["getNearbyChargers", charger?.id],
    () => authorizedFetch(nearbyChargersUrl)
  );

  function returnTime(day: number) {
    return charger?.availability?.twentyFourSeven
      ? "All Day"
      : charger.availability.days.some((el: any) => el.day === day) === false
      ? "Unavailable"
      : charger.availability.days.map((el: any) => {
          if (el.day === day) {
            return (
              <div>
                {moment(el.fromTime, ["HH:mm"]).format("h:mm A") +
                  "-" +
                  moment(el.toTime, ["HH:mm"]).format("h:mm A")}
              </div>
            );
          } else {
            return "";
          }
        });
  }

  useEffect(() => {
    if (drawerState.open && charger && data) {
      setBookingsData(data.data.bookings);
    }
  }, [drawerState.open, charger, data]);

  useEffect(() => {
    if (charger) {
      setChargerDetails({
        basicInfo: [
          { label: "UID", value: charger.charger.chargerId },
          { label: "Name", value: charger.charger.chargerName },
          // {
          //   label: "Company",
          //   value: charger.charger.companyName,
          // },
        ],
        ownerInfo: [
          {
            label: "Name",
            value: charger.owner.firstName
              ? charger.owner.firstName + " " + charger.owner.lastName
              : "-",
          },
          {
            label: "Phone Number",
            value: charger.owner.phone ? charger.owner.phone : "-",
          },
          {
            label: "Alternate Phone 1",
            value: charger.owner.altPhone1 ? charger.owner.altPhone1 : "-",
          },
          {
            label: "Alternate Phone 2",
            value: charger.owner.altPhone2 ? charger.owner.altPhone2 : "-",
          },
          {
            label: "Email",
            value: charger.owner.email ? charger.owner.email : "-",
          },
          {
            label: "Address",
            value: charger.owner.address ? charger.owner.address : "-",
          },
        ],
        stationInfo: [
          {
            label: "Contact Name",
            value: charger.incharge.name,
          },
          {
            label: "Contact Number",
            value: charger.incharge.phoneNumber,
          },
          {
            label: "Usage Type",
            value: charger.charger.usageType,
          },
          {
            label: "Station Name",
            value: charger.station.stationName,
          },
          {
            label: "Station Address",
            value: charger.station.address,
          },
          {
            label: "Latitude",
            value: charger.station.location.latitude,
          },
          {
            label: "Longitude",
            value: charger.station.location.longitude,
          },
          {
            label: "Electricity Cost",
            value: "₹" + charger.paymentDetails.costPerkWh,
          },
          {
            label: "Base Amount",
            value: "₹" + charger.paymentDetails.baseAmount,
          },
          {
            label: "Charge per Hour",
            value: "₹" + charger.paymentDetails.chargePerHour,
          },
        ],
        availability: [
          {
            label: "Sunday",
            value: returnTime(0),
          },
          {
            label: "Monday",
            value: returnTime(1),
          },
          {
            label: "Tuesday",
            value: returnTime(2),
          },
          {
            label: "Wednesday",
            value: returnTime(3),
          },
          {
            label: "Thursday",
            value: returnTime(4),
          },
          {
            label: "Friday",
            value: returnTime(5),
          },
          {
            label: "Saturday",
            value: returnTime(6),
          },
        ],
        specs: [
          {
            label: "Auto Cutoff",
            // eslint-disable-next-line
            value: charger.specification.autoCutOff.value + " " + "seconds",
          },
          {
            label: "Power Output",
            // eslint-disable-next-line
            value: charger.specification.powerOutput.value + " " + "A",
          },
          {
            label: "Manufacturer Name",
            value: charger.chargerType.manufacturerName,
          },
          {
            label: "Power Rating",
            value: charger.chargerType.powerRating.value + " kW",
          },
          {
            label: "Firmware Version",
            value: charger.specification.firmware,
          },
          {
            label: "Communication Protocol",
            value: charger.chargerType.communicationProtocol,
          },
          {
            label: "Connector Type",
            value: charger.chargerType.connectorType,
          },
          {
            label: "Current",
            value: charger.chargerType.current.value + "A",
          },
          {
            label: "Voltage",
            value: charger.chargerType.voltage.value + "V",
          },
        ],
      });
    }
    // eslint-disable-next-line
  }, [charger]);

  const AlertBox = ({ color, mainText, showUnhideButton }: any) => {
    return (
      <>
        <Box
          width="100%"
          height="60px"
          sx={{
            background: color,
            borderRadius: 1,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            px: 1.5,
          }}
        >
          <Box>
            <Typography sx={{ fontSize: 14, fontWeight: "600" }}>
              {mainText}
            </Typography>

            <Typography sx={{ fontSize: 12, fontWeight: "400" }}>
              Contact Owner Now!
            </Typography>
          </Box>

          <Box>
            <Button
              variant={showUnhideButton ? "outlined" : "contained"}
              size="small"
              sx={{
                background: showUnhideButton ? "white" : "",
                mr: 1,
                height: 38,
              }}
              onClick={() => {
                setNotificationDialog({ open: true, data: charger });
              }}
            >
              Notify
            </Button>
            {showUnhideButton ? (
              <Button
                variant="contained"
                size="small"
                sx={{ height: 38 }}
                onClick={() => {
                  setChargerVisibilityDialog({
                    open: true,
                    data: charger,
                  });
                }}
              >
                Unhide
              </Button>
            ) : (
              ""
            )}
          </Box>
        </Box>
      </>
    );
  };

  useEffect(() => {
    if (drawerState.open) {
      setTab(openTab);

      setBookingsFilter("all");
      // getVendorsData();
    }
  }, [charger, drawerState.open, openTab]);

  let bookings =
    bookingsFilter === "all"
      ? bookingsData
      : bookingsFilter === "terminated"
      ? bookingsData.filter((el: any) => el.bookingStatus === "TERMINATED")
      : bookingsFilter === "ended"
      ? bookingsData.filter((el: any) => el.bookingStatus === "ENDED")
      : bookingsData.filter((el: any) => el.bookingStatus === "PENDING");

  const [openButton, setOpenButton] = useState(false);

  const [chartData, setChartData] = useState<any>();

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const bookingsNewUrl = `${BOLT_URL}/company/stats/charger/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}&chargerId=${charger.charger.chargerId}`;

  const { isLoading: chartLoading, data: chartResponse } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, charger?.id],
    () => authorizedFetch(bookingsNewUrl, {}),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (chartResponse?.data?.stats?.constructor === Array) {
      let dataArray = chartResponse.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("bookings")) {
            getExisting("bookings").y += cur.totalBookings;
            getExisting("earnings").y += Math.round(
              parseFloat(cur.totalEarnings)
            );
            getExisting("energy").y += cur.totalEnergyConsumed;
            getExisting("users").y += cur.totalUsers;
          } else {
            acc.bookings.push({ x: day, y: cur.totalBookings });
            acc.earnings.push({
              x: day,
              y: Math.round(parseFloat(cur.totalEarnings)),
            });
            acc.energy.push({ x: day, y: cur.totalEnergyConsumed });
            acc.users.push({ x: day, y: cur.totalUsers });
          }
          return acc;
        },
        {
          bookings: [],
          earnings: [],
          energy: [],
          users: [],
        }
      );
      setChartData(chartData);
    }
  }, [charger, drawerState.open, chartResponse]);

  let chartArray = chartData?.bookings || [];

  useEffect(() => {
    if (drawerState.open) {
      setRange([sub(new Date(), { months: 1 }), new Date()]);
    }
  }, [drawerState.open, charger]);

  const loader = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 70,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" size={24} />
    </Box>
  );

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {charger.charger.chargerId}
            <IconButton
              sx={{ ml: 1 }}
              children={
                ["HEALTHY", "MODERATE", "CRITICAL"].includes(
                  charger?.charger?.health
                ) ? (
                  <VisibilityOutlined />
                ) : (
                  <VisibilityOffOutlined />
                )
              }
              color="inherit"
              size="small"
              onClick={() => {
                setChargerVisibilityDialog({ open: true, data: charger });
              }}
            />
          </Box>

          <Box display="flex">
            {canWrite && (
              <>
                <IconButton
                  sx={{ mr: 1 }}
                  children={<FlagOutlined />}
                  color="inherit"
                  size="small"
                  onClick={() => {
                    setFlagDialog({ open: true, data: charger });
                  }}
                />
                <IconButton
                  sx={{ mr: 1 }}
                  children={<PersonAddOutlined />}
                  color="inherit"
                  size="small"
                  onClick={() => {
                    setAssignVendorDialog({ open: true, data: charger });
                  }}
                />
              </>
            )}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box pt={2} px={2}>
            {charger?.charger?.health === "MODERATE" ? (
              <AlertBox
                color="#FFFF0030"
                mainText="CHARGER INACTIVE SINCE LAST 15 DAYS."
                showUnhideButton={false}
              />
            ) : charger?.charger?.health === "CRITICAL" ? (
              <AlertBox
                color="#FFA50030"
                mainText="CHARGER INACTIVE SINCE LAST 30 DAYS."
                showUnhideButton={false}
              />
            ) : charger?.charger?.health === "INACTIVE" ? (
              <AlertBox
                color="#FF000020"
                mainText="CHARGER HIDDEN FROM THE MAP."
                showUnhideButton={true}
              />
            ) : (
              ""
            )}
          </Box>

          <Box pt={2} pr={2} pl={2}>
            <Tabs
              className="dense"
              value={tab}
              onChange={(e: any, tab: any) => {
                console.log(tab, "charger-drawer");
                setTab(tab);
              }}
              variant="scrollable"
            >
              <Tab label="Information" />
              <Tab label="Bookings" />
              <Tab label="Stats" />
              <Tab label="Map View" />
              <Tab label="Logs" />
            </Tabs>
          </Box>
          {tab === 0 ? (
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme: any) =>
                        theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& .label": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                        py: 1.125,
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 2.75,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  {/* <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Basic Info</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 0,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>
                  {chargerDetails.basicInfo.map(({ label, value }, i) => (
                    <tr
                      key={i}
                      className={
                        i === 0
                          ? "first"
                          : i === chargerDetails.basicInfo.length - 1
                          ? "last"
                          : ""
                      }
                    >
                      <td>{label}</td>
                      <td className="bold" width="50%">
                        {value}
                      </td>
                    </tr>
                  ))} */}

                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Station Info</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 0,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>
                  {chargerDetails.stationInfo.map(({ label, value }, i) => (
                    <tr
                      key={chargerDetails.stationInfo.length + i}
                      className={
                        i === 0
                          ? "first"
                          : i === chargerDetails.stationInfo.length - 1
                          ? "last"
                          : ""
                      }
                    >
                      <td>{label}</td>
                      <td className="bold">{value}</td>
                    </tr>
                  ))}
                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Owner Info</span>
                      {/* {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 0,
                            });
                          }}
                        />
                      )} */}
                    </td>
                  </tr>
                  {chargerDetails.ownerInfo.map(({ label, value }, i) => (
                    <tr
                      key={i}
                      className={
                        i === 0
                          ? "first"
                          : i === chargerDetails.ownerInfo.length - 1
                          ? "last"
                          : ""
                      }
                    >
                      <td>{label}</td>
                      <td className="bold" width="50%">
                        {value}
                      </td>
                    </tr>
                  ))}
                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Availability</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 1,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>
                  {chargerDetails.availability.map(({ label, value }, i) => (
                    <tr
                      key={chargerDetails.stationInfo.length + i}
                      className={
                        i === 0
                          ? "first"
                          : i === chargerDetails.stationInfo.length - 1
                          ? "last"
                          : ""
                      }
                    >
                      <td>{label}</td>
                      <td className="bold">{value}</td>
                    </tr>
                  ))}
                  <tr className="header" style={{ marginTop: "20px" }}>
                    <td
                      style={{
                        height: "50px",
                        display: "flex",
                        alignItems: "center",
                        marginTop: "10px",
                      }}
                      colSpan={2}
                    >
                      <span className="label">Specifications</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 2,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>

                  {chargerDetails.specs.map(({ label, value }, i) => (
                    <tr
                      key={chargerDetails.basicInfo.length + i}
                      className={
                        i === 0
                          ? "first"
                          : i === chargerDetails.specs.length - 1
                          ? "last"
                          : ""
                      }
                    >
                      <td>{label}</td>
                      <td className="bold">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Box>
          ) : tab === 1 ? (
            <Box>
              <Box px={2.5} my={2}>
                <RadioGroup
                  row
                  value={bookingsFilter}
                  onChange={(e: any) => setBookingsFilter(e.target.value)}
                >
                  <FormControlLabel
                    value="all"
                    control={<Radio />}
                    label="All"
                  />
                  <FormControlLabel
                    value="terminated"
                    control={<Radio />}
                    label="Terminated"
                  />
                  {/* <FormControlLabel value="ongoing" control={<Radio />} label="Ongoing" /> */}
                  <FormControlLabel
                    value="ended"
                    control={<Radio />}
                    label="Ended"
                  />
                  <FormControlLabel
                    value="pending"
                    control={<Radio />}
                    label="Pending Payment"
                  />
                </RadioGroup>
              </Box>
              <Table
                rows={bookings || []}
                loading={isLoading}
                columns={[
                  {
                    key: "userName",
                    label: "User",
                    Render: (row) => (
                      <Box>
                        <IconButton
                          aria-label="expand row"
                          size="small"
                          onClick={() => setOpenButton(!openButton)}
                        >
                          {openButton ? (
                            <KeyboardArrowUpIcon />
                          ) : (
                            <KeyboardArrowDownIcon />
                          )}
                        </IconButton>
                        <Collapse in={openButton} timeout="auto" unmountOnExit>
                          {!row.userName || row.userName === " "
                            ? "-"
                            : row.userName}
                          <br />
                          {!row.userEmail || row.userEmail === " "
                            ? "-"
                            : row.userEmail}
                          <br />
                          {!row.userPhone || row.userPhone === " "
                            ? "-"
                            : row.userPhone}
                        </Collapse>
                      </Box>
                    ),
                  },
                  {
                    key: "bookingStart",
                    label: "Start Time",
                    Render: (row) => (
                      <Box>
                        {moment(row.bookingStart).format("MMM DD, HH:mm")}
                      </Box>
                    ),
                  },
                  {
                    key: "bookingDuration",
                    label: "Booking Duration",
                    format: (value) => getDuration(value * 60),
                  },
                  {
                    key: "chargingDuration",
                    label: "Charging Duration",
                    Render: (row) => getDuration(row.chargingDuration * 60),
                  },
                  {
                    key: "amount",
                    label: "Cost",
                    format: (val) => `₹${val || 0}`,
                  },
                  {
                    key: "energyConsumed",
                    label: "Energy Consum.",
                    format: (value) =>
                      typeof value === "number"
                        ? value.toFixed(3) + " kWh"
                        : "-",
                  },
                ]}
              />
            </Box>
          ) : tab === 2 ? (
            <Box py={3} px={2.5}>
              <Box
                mb={2.5}
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                <Typography fontSize={18} fontWeight={500}>
                  Insights
                </Typography>
                <RangePicker range={range} setRange={setRange} />
              </Box>
              <Box
                sx={{
                  display: "grid",
                  gap: 2,
                  "& > div": {
                    border: 1,
                    bgcolor: isDarkMode ? "background.default" : "#fff",
                    borderColor: (theme: any) => theme.customColors.border,
                    borderRadius: 1,
                    p: 2.5,
                    display: "flex",
                    flexDirection: "column",
                    "& span": {
                      display: "flex",
                      alignItems: "center",
                      "& span": {
                        alignItems: "end",
                      },
                    },
                    "& .value": {
                      fontSize: "1.75rem",
                      fontWeight: 700,
                      lineHeight: "1.75rem",
                    },
                    "& .unit": {
                      ml: 0.75,
                    },
                    "& .title": {
                      ml: 1.5,
                      color: "text.secondary",
                    },
                  },
                }}
              >
                <Box key={chartArray.length}>
                  {chartLoading ? (
                    loader
                  ) : (
                    <LineChart data={chartData?.bookings || []} />
                  )}

                  <span>
                    <Typography className="value">
                      {chartResponse?.data?.totalBookings
                        ? chartResponse?.data?.totalBookings
                        : 0}
                    </Typography>
                    <Typography className="title">Total Bookings</Typography>
                  </span>
                </Box>
                <Box key={chartArray.length + 1}>
                  {chartLoading ? (
                    loader
                  ) : (
                    <LineChart isBlue data={chartData?.earnings || []} />
                  )}
                  <span>
                    <Typography className="value">
                      ₹{chartResponse?.data?.totalEarnings}
                    </Typography>
                    <Typography className="title">Total Earnings</Typography>
                  </span>
                </Box>
                <Box key={chartArray.length + 2}>
                  {chartLoading ? (
                    loader
                  ) : (
                    <LineChart isBlue data={chartData?.users || []} />
                  )}
                  <span>
                    <Typography className="value">
                      {chartResponse?.data?.totalUsers}
                    </Typography>
                    <Typography className="title">Total Users</Typography>
                  </span>
                </Box>
                <Box key={chartArray.length + 3}>
                  {chartLoading ? (
                    loader
                  ) : (
                    <LineChart data={chartData?.energy || []} />
                  )}
                  <span>
                    <span>
                      <Typography className="value">
                        {chartResponse?.data?.totalEnergyConsumed?.toFixed(3)}
                      </Typography>
                      <Typography className="unit">kWh</Typography>
                    </span>
                    <Typography className="title">Energy Dispensed</Typography>
                  </span>
                </Box>
              </Box>
            </Box>
          ) : tab === 3 ? (
            <Box p={2.5} height={436}>
              <Map
                loading={false}
                type="charger"
                borderRadius={1}
                location={charger.station.location}
                dataArray={nearbyChargers?.data || []}
              />
            </Box>
          ) : tab === 4 ? (
            <Box p={2.5} height={436}>
              <Table
                rows={bookings || []}
                loading={isLoading}
                columns={[
                  {
                    key: "bookingStart",
                    label: "Start Time",
                    Render: (row) => (
                      <Box>
                        {moment(row.bookingStart).format("MMM DD, HH:mm")}
                      </Box>
                    ),
                  },
                  {
                    key: "bookingDuration",
                    label: "Booking Duration",
                    format: (value) => getDuration(value * 60),
                  },
                  {
                    key: "chargingDuration",
                    label: "Charging Duration",
                    Render: (row) => getDuration(row.chargingDuration * 60),
                  },
                  {
                    key: "amount",
                    label: "Cost",
                    format: (val) => `₹${val || 0}`,
                  },
                  {
                    key: "energyConsumed",
                    label: "Energy Consum.",
                    format: (value) =>
                      typeof value === "number"
                        ? value.toFixed(3) + " kWh"
                        : "-",
                  },
                ]}
              />
            </Box>
          ) : (
            <ChargerHistory data={charger} tab={tab} open={drawerState.open} />
          )}
        </Box>
      </Box>
      <AssignVendor
        open={assignVendorDialog.open}
        handleClose={() => {
          setAssignVendorDialog({ ...assignVendorDialog, open: false });
        }}
        data={charger}
        vendors={vendors}
        refetchStats={refetchStats}
      />
      <FlagCharger
        open={flagDialog.open}
        handleClose={() => {
          setFlagDialog({ ...flagDialog, open: false });
        }}
        data={charger}
        closeDrawer={() => drawer.close()}
        refetchChargers={refetchChargers}
      />
      <EditChargers
        open={editDialog.open}
        closeDrawer={() => drawer.close()}
        handleClose={() => {
          setEditDialog({ open: false, count: 0 });
        }}
        data={charger}
        count={editDialog.count}
        refetchStats={refetchStats}
        refetchChargers={refetchChargers}
      />
      <NotificationDialog
        open={notificationDialog.open}
        handleClose={() => {
          setNotificationDialog({
            ...notificationDialog,
            open: false,
          });
        }}
        data={notificationDialog.data}
      />
      <ChargerVisibility
        open={chargerVisibilityDialog.open}
        handleClose={() => {
          setChargerVisibilityDialog({
            ...chargerVisibilityDialog,
            open: false,
          });
        }}
        closeDrawer={drawer.close}
        data={chargerVisibilityDialog.data}
        refetchChargers={refetchChargers}
      />
    </>
  );
};

interface VendorProps {
  open: boolean;
  handleClose: () => void;
  data: any;
  vendors: any[];
  refetchStats: () => void;
}

const AssignVendor: React.FC<VendorProps> = ({
  open,
  handleClose,
  data,
  vendors,
  refetchStats,
}) => {
  const [selectedVendor, setSelectedVendor] = useState<string>();

  const theVendor = vendors?.find((el) => el.name === selectedVendor);

  const url = `${BOLT_URL}/company/vendor/${theVendor?.id}/assignChargers`;

  const mutation = useMutation(
    `assignChargers ${theVendor?.id}`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          chargerIds: [data?.charger?.chargerId],
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Charger assigned`);
        refetchStats();
      },
      onError: () => {
        snackbar.error(`Error assigning charger`);
      },
    }
  );

  useEffect(() => {
    if (open && vendors) {
      setSelectedVendor(vendors[0]?.name);
    }
  }, [open, vendors]);

  function onSave() {
    handleClose();
    mutation.mutate();
  }

  return (
    <Dialog
      open={open}
      PaperProps={{
        sx: {
          maxWidth: 500,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Assign Vendor
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        <Typography>
          Charger UID : <strong>{data.chargerStats.chargerId}</strong>
          <Typography sx={{ pt: 2 }}>Choose Vendors</Typography>
          <Box sx={{ pt: 1 }}>
            {console.log(vendors, "vendors?")}
            <Autocomplete
              defaultValue={selectedVendor}
              options={vendors?.map((option) => option.name)}
              onChange={(e: any) => setSelectedVendor(e.target.value)}
              renderInput={(params: any) => (
                <TextField {...params} label="vendor" />
              )}
            />
            {/* <Select
              style={{ width: "100%" }}
              className="primary"
              value={selectedVendor}
              onChange={(e: any) => setSelectedVendor(e.target.value)}
            >
              {(vendors || []).map((filter, i) => (
                <MenuItem key={i} value={filter.name}>
                  {filter.name}
                </MenuItem>
              ))}
            </Select> */}
          </Box>
        </Typography>
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={onSave}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const LineChart: React.FC<{ isBlue?: boolean; data: any[] }> = ({
  isBlue,
  data,
}) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  return (
    <Box
      sx={{
        flexGrow: 1,
        position: "relative",
        height: 70,
        width: 1,
        mb: "3px",
      }}
    >
      <Line
        height={10}
        style={{ marginTop: 10 }}
        data={(canvas) => {
          const ctx = canvas.getContext("2d");
          const g = ctx?.createLinearGradient(0, 0, 0, 60);

          g?.addColorStop(
            0,
            isBlue ? "rgba(97, 209, 105, 0.7)" : "rgba(97, 209, 105, 0.6)"
          );
          g?.addColorStop(
            0.5,
            isBlue ? "rgba(97, 209, 105, 0.4)" : "rgba(97, 209, 105, 0.2)"
          );
          g?.addColorStop(
            1,
            isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
          );

          let color = isBlue ? "rgba(97,209,105)" : "rgba(97,209,105)";

          return {
            // labels: data?.map(el => el.t),
            datasets: [
              {
                fill: true,
                data: data,
                borderColor: color,
                backgroundColor: g,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointHoverBackgroundColor: "#fff",
                pointHoverBorderColor: color,
                pointHoverBorderWidth: 3,
              },
            ],
          };
        }}
        options={{
          scales: {
            xAxis: {
              display: false,
              // type: "linear",
              // type: 'time'
            },
            yAxis: {
              display: false,
            },
          },
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false,
            },
            tooltip: {
              caretSize: 0,
              mode: "index",
              intersect: false,
              yAlign: "center",
              displayColors: false,
              caretPadding: 16,
              titleFont: {
                weight: "400",
              },
              bodyFont: {
                weight: "500",
              },
            },
          },
          layout: {
            padding: {
              bottom: 20,
            },
          },
          interaction: {
            mode: "index",
            intersect: false,
          },
        }}
      />
    </Box>
  );
};

export default DrawerContent;
