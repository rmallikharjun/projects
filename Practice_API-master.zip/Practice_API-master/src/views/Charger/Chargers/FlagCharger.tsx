import { useState, useEffect } from "react";
import { authorizedFetch, setLoader, snackbar } from "utils";
import {
  Box,
  IconButton,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Select,
  MenuItem,
  Button,
  Avatar,
  TextField,
  OutlinedInput,
} from "@mui/material";
import { HighlightOff } from "@mui/icons-material";
import { HEALTH_URL } from "utils/constants";

import { useMutation } from "react-query";

interface VendorProps {
  open: boolean;
  handleClose: () => void;
  data: any;
  refetchChargers: () => void;
  closeDrawer: () => void;
}

const AssignVendor: React.FC<VendorProps> = ({
  open,
  handleClose,
  data,
  refetchChargers,
  closeDrawer,
}) => {
  const [selectedStatus, setSelectedStatus] = useState<string>(
    data?.charger?.health
  );
  const healthStatus = ["HEALTHY", "MODERATE", "CRITICAL", "INACTIVE"];

  const [note, setNote] = useState("");

  const answeredList = ["SELECT", "YES", "NO"];
  const [ansValue, setAnsValue] = useState<any>(answeredList[0]);

  const [phoneList, setPhoneList] = useState<any[]>(["SELECT"]);
  const [phn, setPhn] = useState<any>(phoneList[0]);

  useEffect(() => {
    if (data && open) {
      let list = ["SELECT"];
      setSelectedStatus(data?.charger?.health);

      if (data?.incharge?.phoneNumber) {
        list.push(`Incharge: ${data?.incharge?.phoneNumber}`);
      }
      if (data?.owner?.phone) {
        list.push(`Owner: ${data?.owner?.phone}`);
      }
      if (data?.owner?.altPhone1) {
        list.push(`Alternate No. 1: ${data?.owner?.altPhone1}`);
      }
      if (data?.owner?.altPhone2) {
        list.push(`Alternate No. 2: ${data?.owner?.altPhone2}`);
      }
      setPhoneList(list);
    }
    if (!open) {
      setPhoneList(["SELECT"]);
      setPhn(phoneList[0]);
      setAnsValue(answeredList[0]);
      setNote("");
      setSelectedStatus("");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, open]);

  const mutation = useMutation(
    "updateHealth",
    () =>
      authorizedFetch(`${HEALTH_URL}/product/update`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          token: "1234",
        },
        body: {
          productId: data?.charger?.chargerId,
          productType: "CHARGING_SOCKET",
          answered: ansValue === "YES" ? true : ansValue === "NO" ? false : "",
          contactedThrough: phn,
          note: note,
          health: selectedStatus,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Charger updated`);
        refetchChargers();
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error updating charger`);
      },
    }
  );

  function onSave() {
    setLoader(true);
    mutation.mutate();
    refetchChargers();
    handleClose();
    closeDrawer();
  }

  const disabled = ansValue === "SELECT" || phn === "SELECT" || note === "";

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 400,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "start",
          }}
        >
          Flag Charger
          <IconButton
            children={<HighlightOff />}
            color="inherit"
            onClick={handleClose}
            sx={{ transform: "translate(8px, -8px)" }}
          />
        </Box>
      </DialogTitle>
      <DialogContent>
        {/* <Typography
          sx={{
            py: 2,
            display: "flex",
            pt: 2,
            fontSize: 14,
            fontWeight: "light",
          }}
        >
          No. of Contact Attempts:
          <strong style={{ marginLeft: 15, fontWeight: "bold" }}>2</strong>
        </Typography> */}
        <Typography
          sx={{
            pb: 2,
            display: "flex",
            fontSize: 14,
            fontWeight: "bold",
          }}
        >
          {data.charger.chargerId}:
          {data.charger.health === "HEALTHY" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#3BB89E30",
                color: "#3BB89E",
                borderColor: "#3BB89E30",
                marginLeft: 3,
              }}
            >
              {data.charger.health}
            </Avatar>
          ) : data.charger.health === "MODERATE" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FFFF0030",
                color: "#ffc800",
                borderColor: "#FFFF0030",
                marginLeft: 3,
              }}
            >
              {data.charger.health}
            </Avatar>
          ) : data.charger.health === "CRITICAL" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FFA50030",
                color: "orange",
                borderColor: "#FFA50030",
                marginLeft: 3,
              }}
            >
              {data.charger.health}
            </Avatar>
          ) : data.charger.health === "INACTIVE" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FF000030",
                color: "red",
                borderColor: "#FF000030",
                marginLeft: 3,
              }}
            >
              {data.charger.health}
            </Avatar>
          ) : (
            ""
          )}
        </Typography>

        {/* <Box sx={{ display: "flex", pt: 2 }}>
          <Typography sx={{ py: 2, display: "flex" }}>
            Add Contact Attempt:
          </Typography>
          <ButtonGroup
            size="small"
            aria-label="small outlined button group"
            sx={{ height: 35, mt: 1, ml: 2 }}
          >
            {displayCounter && <Button onClick={handleDecrement}>-</Button>}
            {displayCounter && <Button disabled>{state}</Button>}
            <Button onClick={handleIncrement}>+</Button>
          </ButtonGroup>
        </Box> */}

        <Typography sx={{ pt: 2, pb: 1 }}>Contacted through:</Typography>
        <Box sx={{}}>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={phn}
            onChange={(e) => setPhn(e.target.value)}
            input={<OutlinedInput label="Select" />}
          >
            {phoneList?.map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select>
        </Box>
        <Typography sx={{ pt: 2, pb: 1 }}>Answered:</Typography>
        <Box sx={{}}>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={ansValue}
            onChange={(e) => setAnsValue(e.target.value)}
          >
            {answeredList?.map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select>
        </Box>
        <Typography sx={{ pt: 2, pb: 1 }}>Change Health Status:</Typography>
        <Box sx={{}}>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
          >
            {healthStatus?.map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select>
          <Box mt={2}>
            <Typography>Note</Typography>
            <TextField
              fullWidth
              id="outlined-multiline-static"
              multiline
              rows={6}
              placeholder="Type a message..."
              value={note}
              onChange={(e: any) => {
                setNote(e.target.value);
              }}
              sx={{ mt: 1, mb: 3 }}
            />
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={onSave} disabled={disabled}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AssignVendor;
