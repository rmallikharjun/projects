import React from "react";
import { Typography, Select, MenuItem, TextField } from "@mui/material";
import { Box } from "@mui/system";

interface Props {
  connectorNumber: any;
  connectorType: any;
  basicInput: any;
  setBasicInput: Function;
}

const ConnectorDialog: React.FC<Props> = ({
  connectorNumber,
  connectorType,
  basicInput,
  setBasicInput,
}) => {
  console.log(basicInput, "basic input state inside dialog");
  return (
    <div
      style={{ display: "flex", width: "100%", justifyContent: "space-around" }}
    >
      <Box
        sx={{
          gridColumn: { sm: "span 2" },
        }}
      >
        <Typography className="label">Connector No.</Typography>
        <TextField
          fullWidth
          size="small"
          placeholder="Connector No."
          value={connectorNumber}
        />
        <Typography className="label">Connector Type</Typography>
        <Select
          fullWidth
          value={connectorType}
          onChange={(e: any) => {
            let currentId = connectorNumber - 1;
            let existing = [...basicInput.connectorData];
            let obj = existing[currentId];
            obj.type = e.target.value;
            setBasicInput({
              ...basicInput,
              connectorData: existing,
            });
          }}
          displayEmpty
        >
          <MenuItem disabled value="">
            <em>Select</em>
          </MenuItem>
          <MenuItem value="CCS2">CCS2</MenuItem>
          <MenuItem value="CHAdeMO">CHAdeMO</MenuItem>
          <MenuItem value="GB/T">GB/T</MenuItem>
          <MenuItem value="Type2">Type2</MenuItem>
          <MenuItem value="Tesla">Tesla</MenuItem>
          <MenuItem value="DC001">DC001</MenuItem>
          <MenuItem value="Industrial Socket">Industrial Socket</MenuItem>
        </Select>
      </Box>
    </div>
  );
};

export default ConnectorDialog;
