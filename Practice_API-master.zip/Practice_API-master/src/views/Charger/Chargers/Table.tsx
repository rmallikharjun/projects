import { Paper, Tab, Tabs } from "@mui/material";
import { useState } from "react";

const Table = () => {
  const [tab, setTab] = useState(0);

  return (
    <Paper
      sx={{
        p: 3,
        borderRadius: 2,
        boxShadow: "0 0 4px #1C295A14",
      }}
    >
      <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
        <Tab label="All" />
        <Tab label="Booked" />
        <Tab label="Available" />
      </Tabs>
    </Paper>
  );
};

export default Table;
