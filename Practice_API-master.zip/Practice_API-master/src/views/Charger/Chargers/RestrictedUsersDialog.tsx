import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  ToggleButton,
  ToggleButtonGroup,
  Tooltip,
} from "@mui/material";
import { authorizedFetch, setLoader, snackbar } from "utils";
import { useMutation, useQuery, useQuery as useReactQuery } from "react-query";
import { AUTH_URL, BOLT_URL } from "utils/constants";
import {
  DeleteOutline,
  HighlightOff,
  PersonAddOutlined,
} from "@mui/icons-material";
import TableComponent from "components/Table";
import Search from "components/Search";
import { queryClient } from "index";

interface Props {
  open: boolean;
  handleClose: () => void;
  charger: any;
}

const RestrictedUsersDialog: React.FC<Props> = ({
  open,
  handleClose,
  charger,
}) => {
  const [key, setKey] = useState(0);
  const [selected, setSelected] = useState<any>([]);
  const [addUsersDialog, setAddUsersDialog] = useState(false);
  const [deleteUsersDialog, setDeleteUsersDialog] = useState<any>(false);

  const getUsersUrl = `${BOLT_URL}/charger/restricted/${charger?.id}/getUsers`;
  const { isLoading, data } = useReactQuery(
    ["getRestrictedUsers", charger?.id],
    () => authorizedFetch(getUsersUrl),
    { enabled: !!charger?.id }
  );

  useEffect(() => {
    setSelected([]);
    setKey((prev) => prev + 1);
  }, [isLoading, open]);

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        <Box display="flex" alignItems="center">
          <Box color="text.secondary">{charger?.id || "-"}</Box>
          <Divider flexItem orientation="vertical" sx={{ mx: 1 }} />
          Assigned Users
        </Box>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "auto auto",
            gap: 1,
            transform: "translate(8px, -8px)",
          }}
        >
          <Tooltip title="Add Users">
            <span>
              <IconButton
                disabled={isLoading}
                children={<PersonAddOutlined />}
                color="inherit"
                onClick={() => setAddUsersDialog(true)}
              />
            </span>
          </Tooltip>
          <IconButton
            children={<HighlightOff />}
            color="inherit"
            onClick={handleClose}
          />
        </Box>
      </DialogTitle>
      <DialogContent>
        <TableComponent
          idKey="userId"
          // key={key}
          px={0}
          height={440}
          selectable
          selectedRows={selected}
          setSelectedRows={setSelected}
          selectOnClick
          small
          loading={isLoading}
          rows={data?.data || []}
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => {
                let { firstName, lastName } = row;
                return firstName || lastName
                  ? `${firstName || ""} ${lastName || ""}`
                  : "-";
              },
            },
            { key: "userEmail", label: "Email" },
            { key: "userPhone", label: "Phone" },
          ]}
          toolbar={() => (
            <Button
              startIcon={<DeleteOutline />}
              onClick={() => setDeleteUsersDialog(true)}
            >
              Delete
            </Button>
          )}
        />
        <AddUsersDialog
          key={key}
          open={addUsersDialog}
          handleClose={() => setAddUsersDialog(false)}
          charger={charger}
          // existingUsers={data?.data || []}
        />
        <DeleteUsersDialog
          open={deleteUsersDialog}
          handleClose={() => setDeleteUsersDialog(false)}
          data={{ charger, selected }}
        />
      </DialogContent>
    </Dialog>
  );
};

interface AddDialogProps {
  open: boolean;
  handleClose: () => void;
  charger: any;
  // existingUsers: any;
}

const AddUsersDialog: React.FC<AddDialogProps> = ({
  open,
  handleClose,
  charger,
  // existingUsers,
}) => {
  const [activeView, setActiveView] = useState<"APP_USERS" | "EMPLOYEE">(
    "APP_USERS"
  );
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState("");

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const appUsersUrl = `${AUTH_URL}/company/appusers?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;
  const employeesUrl = `${AUTH_URL}/company/users?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;

  const { isLoading: appUsersLoading, data: appUsersData } = useQuery(
    ["getAppUsers", page, pageSize, search],
    () => authorizedFetch(appUsersUrl)
  );
  const { isLoading: employeesLoading, data: employeesData } = useQuery(
    ["getEmployees", page, pageSize, search],
    () => authorizedFetch(employeesUrl)
  );

  const addUsersUrl = `${BOLT_URL}/charger/restricted/${charger?.id}/addUsers`;
  const addUsersMutation = useMutation(
    ["addRestrictedUsers", charger?.id],
    (selected: any[]) => {
      return authorizedFetch(addUsersUrl, {
        method: "POST",
        headers: {
          stage: "prod",
          "Content-Type": "application/json",
        },
        body: { userIds: selected },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success(`Assigned users to ${charger?.id}`);
        queryClient.resetQueries("getRestrictedUsers");
        handleClose();
      },
      onError: () => {
        setLoader(false);
        snackbar.error("Error assigning users");
      },
    }
  );

  useEffect(() => {
    if (!open) {
      setSearch("");
    }
  }, [open]);

  useEffect(() => {
    setSelected([]);
    setPage(1);
  }, [activeView]);

  function handleSave() {
    setLoader(true);
    addUsersMutation.mutate(selected);
  }

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add Users
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Search handleSearch={setSearch} enableClear persist />
          <ToggleButtonGroup
            sx={{ ml: 1 }}
            exclusive
            size="small"
            color="primary"
            onChange={(e, value) => value && setActiveView(value)}
            value={activeView}
          >
            <ToggleButton value="APP_USERS">App Users</ToggleButton>
            <ToggleButton value="EMPLOYEE">Employees</ToggleButton>
          </ToggleButtonGroup>
        </Box>
      </DialogTitle>
      <DialogContent className="py-1">
        <TableComponent
          idKey="_id"
          loading={
            activeView === "APP_USERS" ? appUsersLoading : employeesLoading
          }
          rowCount={
            activeView === "APP_USERS"
              ? appUsersData?.data?.count || 0
              : employeesData?.data?.count || 0
          }
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(page) => setPage(page)}
          onPageSizeChange={(pageSize) => setPageSize(pageSize)}
          px={0}
          height={376}
          selectable
          selectOnClick
          selectedRows={selected}
          setSelectedRows={setSelected}
          rows={
            activeView === "APP_USERS"
              ? appUsersData?.data?.users || []
              : employeesData?.data?.users || []
          }
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => {
                let { firstName, lastName } = row;
                return firstName || lastName
                  ? `${firstName || ""} ${lastName || ""}`
                  : "-";
              },
            },
            { key: "email", label: "Email" },
            { key: "phone", label: "Phone" },
          ]}
        />
      </DialogContent>
      <DialogActions className="dense">
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSave}
          disabled={selected.length === 0}
        >
          Add
        </Button>
      </DialogActions>
    </Dialog>
  );
};

interface DeleteDialogProps {
  open: boolean;
  handleClose: () => void;
  data: {
    charger: any;
    selected: any;
  };
}

const DeleteUsersDialog: React.FC<DeleteDialogProps> = ({
  open,
  data,
  handleClose,
}) => {
  const { charger, selected } = data;

  const url = `${BOLT_URL}/charger/restricted/${charger?.id}/deleteUsers`;

  const mutation = useMutation(
    ["deleteRestrictedUsers", charger?.id],
    (selected) =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          stage: "prod",
          "Content-Type": "application/json",
        },
        body: { userIds: selected },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success(`Removed users from ${charger?.id}`);
        queryClient.resetQueries("getRestrictedUsers");
        handleClose();
      },
      onError: () => {
        setLoader(false);
        snackbar.error("Error removing users");
      },
    }
  );

  function handleDelete() {
    setLoader(true);
    mutation.mutate(selected);
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Remove Users</DialogTitle>
      <DialogContent className="py-1">
        Remove selected users from restricted list?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          onClick={handleDelete}
          color="primary"
          variant="contained"
          disableElevation
          disabled={false}
        >
          Yes
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default RestrictedUsersDialog;
