import {
  AddBoxOutlined,
  InfoOutlined,
  PeopleAltOutlined,
  Error,
  Sort,
} from "@mui/icons-material";
import {
  Avatar,
  Box,
  Button,
  FormControl,
  Hidden,
  IconButton,
  MenuItem,
  Paper,
  Select,
  // Tab,
  // Tabs,
  Tooltip,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { authorizedFetch, drawer, getPermissions } from "utils";
import DrawerContent from "./DrawerContent";
import moment from "moment";
import AssignVendors from "./AssignToVendors";
import { BOLT_URL } from "utils/constants";
import { useQuery } from "react-query";
import RestrictedUsersDialog from "./RestrictedUsersDialog";
import Search from "../../../components/Search";
import Filter from "components/Filter";

// type SortOptions =
//   "BOOKINGS_DESC"
//   | "CREATED_AT_DESC"
//   | "CREATED_AT_ASC"
//   | "BOOKINGS_ASC"
//   | "BOOKINGS_DESC"
//   | "AMOUNT_ASC"
//   | "AMOUNT_DESC"
//   | "CHARGE_PER_HOUR_ASC"
//   | "CHARGE_PER_HOUR_DESC"
//   | "CHARGE_PER_KWH_ASC"
//   | "CHARGE_PER_KWH_DESC"

const List = ({
  search,
  setSearch,
  masterView,
  refetchStats,
  totalBooked,
  totalAvailable,
  totalRestrictedChargers,
  totalUnavailable,
  healthyChargersCount,
  moderateChargersCount,
  criticalChargersCount,
  damagedChargersCount,
  cityList,
  totalPrivateChargers,
  totalPublicChargers,
  setChargerDisplay,
}: any) => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md") as any);

  const { canWrite } = getPermissions("charger:chargers");

  // const [tab, setTab] = useState(0);
  const [restrictedUsersDialog, setRestrictedUsersDialog] = useState({
    open: false,
    data: null,
  });

  const [selectedRows, setSelectedRows] = useState<any>([]);
  const [vendorsDialog, setVendorsDialog] = useState({
    open: false,
    data: {},
  });

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [selectedCity, setSelectedCity] = useState<any>("");
  const [cityListArr, setCityListArr] = useState<any>([]);

  const [healthStatus, setHealthStatus] = useState({
    healthy: false,
    moderate: false,
    critical: false,
    inactive: false,
  });

  const [availability, setAvailability] = useState({
    available: false,
    booked: false,
    unavailable: false,
  });

  const [usageType, setUsageType] = useState({
    restricted: false,
    publicType: false,
    privateType: false,
  });

  const [rupeeCharger, setRupeeCharger] = useState<boolean>(false);

  const { healthy, moderate, critical, inactive } = healthStatus;
  const { available, booked, unavailable } = availability;
  const { restricted, publicType, privateType } = usageType;

  const [sortBy, setSortBy] = useState("BOOKINGS_DESC");

  const [filterList, setFilterList] = useState<string[]>([]);
  const [citySearchDialog, setCitySearchDialog] = useState({
    open: false,
    input: "",
  });

  const [dropdownEntries, setDropdownEntries] = useState([
    { type: "heading", label: "AVAILABILITY", searchable: false },
    { type: "name", name: "Available", count: 0 },
    { type: "name", name: "Booked", count: 0 },
    { type: "name", name: "Unavailable", count: 0 },
    { type: "heading", label: "USAGE TYPE", searchable: false },
    { type: "name", name: "Restricted", count: 0 },
    { type: "name", name: "Public", count: 0 },
    { type: "name", name: "Private", count: 0 },
    { type: "heading", label: "HEALTH", searchable: false },
    { type: "name", name: "Healthy", count: 0 },
    { type: "name", name: "Moderate", count: 0 },
    { type: "name", name: "Critical", count: 0 },
    { type: "name", name: "Inactive", count: 0 },
    {
      type: "heading",
      label: "CITY",
      searchable: true,
    },
  ]);

  const url = `${BOLT_URL}/company/getVendors`;
  const { data: vendorData } = useQuery(["getVendors", masterView], () =>
    authorizedFetch(url, {
      headers: {
        master: masterView,
      },
    })
  );

  let healthParams = "";

  if (healthy) healthParams += "HEALTHY ";
  if (moderate) healthParams += "MODERATE ";
  if (critical) healthParams += "CRITICAL ";
  if (inactive) healthParams += "INACTIVE ";

  let usageTypeParams = "";

  if (restricted) usageTypeParams += "RESTRICTED ";
  if (publicType) usageTypeParams += "PUBLIC ";
  if (privateType) usageTypeParams += "PRIVATE ";

  let statusParams = "";

  if (available) statusParams += "AVAILABLE ";
  if (booked) statusParams += "BOOKED ";
  if (unavailable) statusParams += "UNAVAILABLE ";

  const chargersUrl = `${BOLT_URL}/company/chargers?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&orderBy=${sortBy}${
    !search
      ? `&health=${healthParams}&usageType=${usageTypeParams}&status=${statusParams}&city=${selectedCity}&rupeeCharger=${rupeeCharger}`
      : `&search=${search}`
  }`;

  const {
    isLoading: chargersLoading,
    data,
    refetch: refetchChargers,
  } = useQuery(
    [
      "getChargers",
      page,
      pageSize,
      search,
      sortBy,
      masterView,
      filterList,
      availability,
      healthStatus,
      usageType,
      selectedCity,
      rupeeCharger,
    ],
    () =>
      authorizedFetch(chargersUrl, {
        headers: {
          master: masterView,
        },
      })
  );

  const getDropdownData = (entry: any[]) => {
    setDropdownEntries([
      { type: "heading", label: "AVAILABILTY", searchable: false },
      { type: "name", name: "Available", count: totalAvailable || 0 },
      { type: "name", name: "Booked", count: totalBooked || 0 },
      { type: "name", name: "Unavailable", count: totalUnavailable || 0 },
      { type: "heading", label: "USAGE TYPE", searchable: false },
      { type: "name", name: "Restricted", count: totalRestrictedChargers },
      { type: "name", name: "Public", count: totalPublicChargers || 0 },
      { type: "name", name: "Private", count: totalPrivateChargers || 0 },
      { type: "heading", label: "CAMPAIGN", searchable: false },
      { type: "name", name: "Rupee One" },
      { type: "heading", label: "HEALTH", searchable: false },
      { type: "name", name: "Healthy", count: healthyChargersCount || 0 },
      { type: "name", name: "Moderate", count: moderateChargersCount || 0 },
      { type: "name", name: "Critical", count: criticalChargersCount || 0 },
      { type: "name", name: "Inactive", count: damagedChargersCount || 0 },
      {
        type: "heading",
        label: "CITY",
        searchable: true,
        searchDialog: citySearchDialog,
        setSearchDialog: setCitySearchDialog,
      },
      ...entry,
    ]);
  };

  useEffect(() => {
    if (cityList) {
      const list = cityList.map((el: any) => {
        return el.name;
      });
      setCityListArr(list);
      getDropdownData(cityList);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cityList]);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  useEffect(() => {
    setPage(1);
    setPageSize(10);
  }, [filterList, search]);

  useEffect(() => {
    if (data) {
      setChargerDisplay(data?.data?.chargersCount);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  useEffect(() => {
    if (filterList) {
      setAvailability({
        available: filterList.includes("Available"),
        booked: filterList.includes("Booked"),
        unavailable: filterList.includes("Unavailable"),
      });
      setUsageType({
        restricted: filterList.includes("Restricted"),
        publicType: filterList.includes("Public"),
        privateType: filterList.includes("Private"),
      });
      setHealthStatus({
        healthy: filterList.includes("Healthy"),
        moderate: filterList.includes("Moderate"),
        critical: filterList.includes("Critical"),
        inactive: filterList.includes("Inactive"),
      });
      setRupeeCharger(filterList.includes("Rupee One"));
      let newList: any = "";
      // eslint-disable-next-line
      filterList.map((el: any) => {
        if (cityListArr.includes(el)) {
          newList = newList + el + "_";
        }
      });
      setSelectedCity(newList.slice(0, -1));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterList]);

  return (
    <>
      <RestrictedUsersDialog
        key={restrictedUsersDialog.data}
        open={restrictedUsersDialog.open}
        handleClose={() =>
          setRestrictedUsersDialog({ ...restrictedUsersDialog, open: false })
        }
        charger={restrictedUsersDialog.data}
      />
      <Paper
        sx={{
          width: 1,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            p: { xs: 2, md: 3 },
            pb: 2.75,
            display: { xs: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          {/* <Box>
            <Tabs
              value={tab}
              onChange={(e, tab) => setTab(tab)}
              {...(!search ? { className: "dense" } : {})}
              variant="scrollable"
            >
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${
                      search
                        ? (data?.data?.chargers || []).length
                        : totalChargers || "-"
                    }"`,
                  },
                }}
              />

              {!search && (
                <Tab
                  label="Booked"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${totalBooked || "-"}"`,
                    },
                  }}
                />
              )}
              {!search && (
                <Tab
                  label="Available"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${totalAvailable || "-"}"`,
                    },
                  }}
                />
              )}
              {!search && (
                <Tab
                  label="Restricted"
                  className="hasCount"
                  sx={{
                    "&:after": {
                      content: `"${totalRestrictedChargers || "-"}"`,
                    },
                  }}
                />
              )}
            </Tabs>
          </Box> */}
          <Box display="flex">
            <FormControl sx={{ mr: 2, maxWidth: 160 }}>
              <Select
                startAdornment={<Sort sx={{ mr: 1 }} />}
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                placeholder="Sort by"
              >
                <MenuItem value="BOOKINGS_DESC">Bookings: High to Low</MenuItem>
                <MenuItem value="BOOKINGS_ASC">Bookings: Low to High</MenuItem>
                <MenuItem value="AMOUNT_DESC">Earnings: High to Low</MenuItem>
                <MenuItem value="AMOUNT_ASC">Earnings: Low to High</MenuItem>
                <MenuItem value="CHARGE_PER_HOUR_DESC">
                  Price per hour: High to Low
                </MenuItem>
                <MenuItem value="CHARGE_PER_KWH_DESC">
                  Price per kWh: High to Low
                </MenuItem>
              </Select>
            </FormControl>
            <Filter
              count
              dropdownEntries={dropdownEntries}
              getDropdownData={getDropdownData}
              filterList={filterList}
              setFilterList={setFilterList}
              entrySearchDialog={citySearchDialog}
              setEntrySearchDialog={setCitySearchDialog}
              dropdownHeight={119}
              searchableEntryList={cityListArr}
              entryList={cityList}
              onClose={() => {
                setCitySearchDialog({ open: false, input: "" });
                getDropdownData(cityList);
              }}
            />
          </Box>
          {/* <Box display="flex" justifyContent="left" alignItems="center">
            <FormControl
              sx={{
                width: 250,

                "& .MuiOutlinedInput-root": {},
                "& .MuiModal-root": {
                  maxHeight: 500,
                },
                "& .MuiPaper-root": {
                  maxHeight: 500,
                  background: "black",
                },
              }}
            >
              <Select
                multiple
                displayEmpty
                value={filterList}
                onChange={handleChangeFilter}
                onClose={() => {
                  setCitySearchDialog({ open: false, input: "" });
                  getDropdownData(cityList);
                }}
                input={<OutlinedInput />}
                renderValue={(selected) => {
                  if (selected.length === 0) {
                    return filterHeading;
                  } else {
                    return filterHeading;
                  }
                }}
                MenuProps={MenuProps}
                inputProps={{ "aria-label": "Without label" }}
              >
                {dropdownEntries.map((entry: any) =>
                  entry.type === "name" ? (
                    <MenuItem
                      sx={{ ml: -1.5, height: 2, display: "flex" }}
                      key={entry.name}
                      value={entry.name}
                    >
                      <Checkbox checked={filterList.indexOf(entry.name) > -1} />
                      <ListItemText
                        primary={
                          <Box display="flex">
                            {entry.name}{" "}
                            <Typography
                              sx={{ fontSize: 12, ml: 1, color: "#00000070" }}
                            >
                              ({entry.count})
                            </Typography>
                          </Box>
                        }
                      />
                    </MenuItem>
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        mt: 1,
                        mb: entry.label === "City" ? 0.5 : "",
                        height: 35,
                      }}
                    >
                      {entry.searchable ? (
                        citySearchDialog.open ? (
                          <OutlinedInput
                            placeholder="Search a City..."
                            size="small"
                            autoFocus
                            fullWidth
                            value={citySearchDialog.input}
                            onKeyDown={(e) => e.stopPropagation()}
                            onKeyPress={handleKeyPress}
                            sx={{
                              "& .MuiOutlinedInput-input": {
                                fontSize: 12,
                              },
                              mx: 1,
                              borderRadius: 10,
                              zIndex: 10,
                            }}
                            onChange={(e: any) => {
                              setCitySearchDialog({
                                ...citySearchDialog,
                                input: e.target.value,
                              });
                            }}
                            endAdornment={
                              <InputAdornment position="end">
                                <IconButton
                                  children={<Close style={{ width: "20px" }} />}
                                  size="small"
                                  onClick={() => {
                                    setCitySearchDialog({
                                      open: false,
                                      input: "",
                                    });
                                    getDropdownData(cityList);
                                  }}
                                  sx={{ mr: -1.5 }}
                                />
                              </InputAdornment>
                            }
                          />
                        ) : (
                          <>
                            <MenuItem
                              key={entry.name}
                              disabled
                              value={entry.name}
                            >
                              <ListItemText primary={entry.label} />
                            </MenuItem>
                            <Box
                              sx={{
                                mr: 1,
                                width: "30px",
                                height: "30px",
                                background: "#40404015",
                                borderRadius: "20px",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                cursor: "pointer",
                              }}
                              onClick={() => {
                                setCitySearchDialog({
                                  ...citySearchDialog,
                                  open: true,
                                });
                              }}
                            >
                              <Searchnew
                                sx={{
                                  width: "20px",
                                  color: "#40404099",
                                }}
                              />
                            </Box>
                          </>
                        )
                      ) : (
                        <MenuItem key={entry.name} disabled value={entry.name}>
                          <ListItemText primary={entry.label} />
                        </MenuItem>
                      )}
                    </Box>
                  )
                )}
              </Select>
            </FormControl>
            {filterList.length
              ? filterList.map((el: any) => {
                  return (
                    <Box
                      sx={{
                        fontSize: 13,
                        px: 1,
                        py: 1.8,
                        border: "1px solid #00000020",
                        height: "15px",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        borderRadius: "5px",
                        ml: 2,
                      }}
                    >
                      {el}
                      <Close
                        sx={{ width: "15px", ml: 1, cursor: "pointer" }}
                        onClick={() => {
                          removeEntryFromArray(el);
                        }}
                      />
                    </Box>
                  );
                })
              : ""}
          </Box> */}
          {/* <Select
            className="primary"
            value={healthFilter}
            onChange={(e) => {
              setHealthFilter(e.target.value);
              setHealth(
                e.target.value !== "All Health Status" ? e.target.value : ""
              );
            }}
            sx={{ width: "170px !important" }}
          >
            {[
              "All Health Status",
              "Healthy",
              "Moderate",
              "Critical",
              "Inactive",
            ].map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select> */}
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>

          {/* <FilterBy /> */}
        </Box>
        <Table
          px={isMdUp ? 3 : 2}
          rowCount={data?.data?.chargersCount}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={chargersLoading}
          setSelectedRows={setSelectedRows}
          selectedRows={selectedRows}
          selectable={canWrite}
          selectOnClick
          rows={data?.data?.chargers || []}
          columns={[
            {
              key: "charger.chargerId",
              label: "Charger UID",
              Render: (row) => (
                <Box display="flex" alignItems="center">
                  {row.charger.chargerId}
                  {["RESTRICTED_FREE", "RESTRICTED_PAID"].includes(
                    row.charger.usageType
                  ) && (
                    <Tooltip title="Restricted Charger">
                      <Box
                        sx={{
                          width: "17px",
                          height: "17px",
                          border: "1px solid",
                          borderColor: (theme: any) =>
                            theme.customColors.redSecondary,
                          borderRadius: "3px",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          fontSize: 10,
                          color: (theme: any) =>
                            theme.customColors.redSecondary,
                          ml: 1,
                          cursor: "default",
                        }}
                      >
                        R
                      </Box>
                    </Tooltip>
                  )}
                </Box>
              ),
            },

            {
              key: "vendor.name",
              label: "Vendor",
              Render: (row) =>
                row?.vendor?.name ? row?.vendor?.name : "Unassigned",
            },
            {
              key: "charger.lastBookingDate",
              label: "Last Used",
              Render: (row) =>
                moment(
                  row.charger.lastBookingDate !== null
                    ? row.charger.lastBookingDate
                    : row.charger.lastPingDate !== null
                    ? row.availability.createdAt
                    : "2022-01-19T09:53:10.756Z"
                ).format("ddd, MMM DD, YYYY"),
            },
            {
              key: "chargerStats.totalEnergyConsumed",
              label: "Energy Dispensed",
              format: (value) => (value ? value.toFixed(3) + " kWh" : "0 kWh"),
            },
            {
              key: "chargerType.communicationProtocol",
              label: "Protocol",
            },
            {
              key: "charger.chargerStatus",
              label: "Status",
              Render: (row) => {
                return (
                  <Avatar variant="status">{row.charger.chargerStatus}</Avatar>
                );
              },
            },
            {
              key: "charger.health",
              label: "Health",
              Render: (row) =>
                row.charger.health === "HEALTHY" ? (
                  <Tooltip title="Charger health is good">
                    <Avatar
                      variant="status"
                      sx={{
                        background: "#3BB89E30",
                        color: "#3BB89E",
                        borderColor: "#3BB89E30",
                      }}
                    >
                      {row.charger.health}
                    </Avatar>
                  </Tooltip>
                ) : row.charger.health === "MODERATE" ? (
                  <Tooltip title="Charger has not been pinged since the past 15 days">
                    <Avatar
                      variant="status"
                      sx={{
                        background: "#FFFF0030",
                        color: "#ffc800",
                        borderColor: "#FFFF0030",
                      }}
                    >
                      {row.charger.health}
                    </Avatar>
                  </Tooltip>
                ) : row.charger.health === "CRITICAL" ? (
                  <Tooltip title="Charger has not been pinged since the past 30 days">
                    <Avatar
                      variant="status"
                      sx={{
                        background: "#FFA50030",
                        color: "orange",
                        borderColor: "#FFA50030",
                      }}
                    >
                      {row.charger.health}
                    </Avatar>
                  </Tooltip>
                ) : row.charger.health === "INACTIVE" ? (
                  <Tooltip title="Charger has not been pinged since the past 45 days">
                    <Avatar
                      variant="status"
                      sx={{
                        background: "#FF000030",
                        color: "red",
                        borderColor: "#FF000030",
                      }}
                    >
                      {row.charger.health}
                    </Avatar>
                  </Tooltip>
                ) : (
                  ""
                ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme: any) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() =>
                        drawer.open(
                          <DrawerContent
                            charger={row}
                            vendors={vendorData?.data || []}
                            refetchStats={refetchStats}
                            refetchChargers={refetchChargers}
                            openTab={0}
                          />
                        )
                      }
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                  {["RESTRICTED_FREE", "RESTRICTED_PAID"].includes(
                    row.charger.usageType
                  ) && (
                    <Tooltip title="Assign Users">
                      <IconButton
                        size="small"
                        sx={{ color: (theme: any) => theme.customColors.grey }}
                        onClick={() =>
                          setRestrictedUsersDialog({ open: true, data: row })
                        }
                        children={<PeopleAltOutlined fontSize="small" />}
                      />
                    </Tooltip>
                  )}

                  {["MODERATE", "CRITICAL", "INACTIVE"].includes(
                    row.charger.health
                  ) && (
                    <Tooltip title="Action Required">
                      <IconButton
                        size="small"
                        sx={{
                          color:
                            row.charger.health === "MODERATE"
                              ? "#ffc80090"
                              : row.charger.health === "CRITICAL"
                              ? "#FFA50090"
                              : row.charger.health === "INACTIVE"
                              ? "#FF000090"
                              : "",
                        }}
                        onClick={() =>
                          drawer.open(
                            <DrawerContent
                              charger={row}
                              vendors={vendorData?.data || []}
                              refetchStats={refetchStats}
                              refetchChargers={refetchChargers}
                              openTab={4}
                            />
                          )
                        }
                        children={<Error fontSize="small" />}
                      />
                    </Tooltip>
                  )}
                </>
              ),
            },
          ]}
          toolbar={() => (
            <>
              <Button
                sx={{ mr: 1.5 }}
                startIcon={<AddBoxOutlined />}
                onClick={() => {
                  setVendorsDialog({ open: true, data: selectedRows });
                }}
              >
                Assign Vendor
              </Button>
              {/* <Button startIcon={<DeleteOutline />}>Delete</Button> */}
            </>
          )}
        />
      </Paper>
      <AssignVendors
        open={vendorsDialog.open}
        data={vendorsDialog.data}
        handleClose={() => {
          setVendorsDialog({ ...vendorsDialog, open: false });
        }}
        refetchStats={refetchStats}
        vendors={vendorData?.data || []}
      />
    </>
  );
};

export default List;
