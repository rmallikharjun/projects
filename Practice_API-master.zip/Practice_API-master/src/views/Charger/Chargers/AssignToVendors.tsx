import { useState, useEffect } from "react";
import { authorizedFetch, snackbar } from "utils";
import {
  Box,
  IconButton,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Select,
  MenuItem,
  Button,
} from "@mui/material";
import { HighlightOff } from "@mui/icons-material";
import { BOLT_URL } from "utils/constants";

interface VendorProps {
  open: boolean;
  handleClose: () => void;
  data: any;
  vendors: any[];
  refetchStats: () => void;
}

const AssignVendor: React.FC<VendorProps> = ({
  open,
  handleClose,
  data,
  vendors,
  refetchStats,
}) => {
  const [selectedVendor, setSelectedVendor] = useState<string>(
    vendors[0]?.name
  );

  function onSave() {
    const theVendor = vendors.filter((el) => el.name === selectedVendor);

    authorizedFetch(
      `${BOLT_URL}/company/vendor/${theVendor[0].id}/assignChargers`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          chargerIds: data,
        },
      }
    ).then((data) => {
      if (data.status === 200) {
        snackbar.success(`Charger assigned`);
        refetchStats();
      } else {
        snackbar.error(`Error assigning charger`);
      }
    });
    handleClose();
  }

  useEffect(() => {
    if (open && vendors) {
      setSelectedVendor(vendors[0]?.name);
    }
  }, [open, vendors]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 500,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Assign Vendor
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        <Typography sx={{ py: 2 }}>
          Assigning <strong>{data.length} </strong> Chargers:
        </Typography>
        <Typography sx={{ pt: 2 }}>Choose Vendors</Typography>
        <Box sx={{ pt: 1 }}>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={selectedVendor}
            onChange={(e: any) => setSelectedVendor(e.target.value)}
          >
            {vendors && vendors.constructor === Array
              ? vendors.map((filter, i) => (
                  <MenuItem key={i} value={filter.name}>
                    {filter.name}
                  </MenuItem>
                ))
              : null}
          </Select>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={onSave}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AssignVendor;
