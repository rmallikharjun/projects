import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import TimePicker from "@mui/lab/TimePicker";
import {
  Tab,
  Tabs,
  Typography,
  Box,
  TextField,
  Button,
  FormControlLabel,
  Switch,
} from "@mui/material";

import React, { useEffect, useState } from "react";

interface Props {
  open: boolean;
  twentyFourSeven: boolean;
  days: any[];
  setTwentyFourSeven: React.Dispatch<React.SetStateAction<boolean>>;
  setDays: React.Dispatch<any>;
}

const SetAvailability: React.FC<Props> = ({
  open,
  days,
  twentyFourSeven,
  setTwentyFourSeven,
  setDays,
}) => {
  const [tab, setTab] = useState(0);

  const defaultTime = "Mon Dec 20 2021 00:00:00 GMT+0530 (India Standard Time)";

  function formatTime(time: any) {
    return `Mon Dec 20 2021 ${time}:00 GMT+0530 (India Standard Time)`;
  }

  useEffect(() => {
    if (open) {
      let newArr = [...days];
      newArr.forEach((el: any, i: any) => {
        el.id = i;
        if (el.fromTime.length < 6) {
          el.fromTime = formatTime(el.fromTime);
        }
        if (el.toTime.length < 6) {
          el.toTime = formatTime(el.toTime);
        } else {
          return "";
        }
      });
      setDays(newArr);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleFromTime = (newValue: any, id: any) => {
    const x = newValue;
    setDays(
      days.map((el: any) => {
        if (el.id === id) {
          el.fromTime = String(x);
          return el;
        } else {
          return el;
        }
      })
    );
  };

  const handleToTime = (newValue: any, id: any) => {
    const x = newValue;
    setDays(
      days.map((el: any) => {
        if (el.id === id) {
          el.toTime = String(x);
          return el;
        } else {
          return el;
        }
      })
    );
  };

  function addSlot() {
    const newDays = [
      ...days,
      {
        id: days.length + 1,
        day: tab,
        fromTime: defaultTime,
        toTime: defaultTime,
      },
    ];
    setDays(newDays);
  }

  function removeSlot(id: number) {
    const newDays = days.filter((el: any) => el.id !== id);
    setDays(newDays);
  }

  function getDay(input: number) {
    switch (input) {
      case 0:
        return "SUNDAY's";
      case 1:
        return "MONDAY's";
      case 2:
        return "TUESDAY's";
      case 3:
        return "WEDNESDAY's";
      case 4:
        return "THURSDAY's";
      case 5:
        return "FRIDAY's";
      case 6:
        return "SATURDAY's";
    }
  }

  return (
    <Box
      sx={{
        maxWidth: 560,
        mx: "auto",
      }}
    >
      <Tabs
        value={tab}
        onChange={(e, tab) => setTab(tab)}
        sx={{
          "& .MuiTabs-indicator": {
            opacity: twentyFourSeven ? "25%" : "100%",
          },
          "& .MuiTab-root": {
            width: 80,
          },
        }}
        variant="scrollable"
      >
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((el: any) => {
          return <Tab label={el} disabled={twentyFourSeven} />;
        })}
      </Tabs>
      <Box>
        {twentyFourSeven ? (
          <Box
            sx={{
              mt: 5,
              mb: 5,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            <Typography sx={{ fontSize: 17 }} className="label">
              Charger is <b> Available 24/7 </b> <br />
              <br />
              <span
                style={{
                  fontSize: "12px",
                  fontWeight: 400,
                  display: "flex",
                  alignItems: "center",
                }}
              >
                &nbsp;Switch it OFF to make the Charger available on specific
                days & specific time slots
              </span>
            </Typography>
          </Box>
        ) : (
          ""
        )}
        {!twentyFourSeven &&
        days.some((el: any) => el.day === tab) === false ? (
          <Box
            sx={{
              mt: 5,
              mb: 5,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            <Typography sx={{ fontSize: 17 }} className="label">
              Charger is Unavailable on <b>{getDay(tab)}</b>
              <br />
              <br />
              <span style={{ fontSize: "12px", fontWeight: 400 }}>
                {" "}
                Add a Slot to make the Charger Available
              </span>
            </Typography>
          </Box>
        ) : (
          ""
        )}
        {!twentyFourSeven
          ? days.map((el1: any) => {
              if (el1.day === tab) {
                return (
                  <>
                    <Box display="grid" gridTemplateColumns="1fr 1fr" gap={3}>
                      <Box
                        sx={{
                          mt: 4,
                          width: "100%",
                        }}
                      >
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                          <TimePicker
                            label="From"
                            value={days.map((el2: any) => {
                              if (el1.id === el2.id) {
                                return el2.fromTime;
                              } else {
                                return "";
                              }
                            })}
                            onChange={(newValue) => {
                              handleFromTime(newValue, el1.id);
                            }}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                sx={{
                                  width: "100%",
                                  "& .MuiIconButton-root": {
                                    marginRight: 1,
                                  },
                                }}
                              />
                            )}
                          />
                        </LocalizationProvider>
                      </Box>
                      <Box
                        sx={{
                          mt: 4,
                          width: "100%",
                        }}
                      >
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                          <TimePicker
                            label="To"
                            value={days.map((el2: any) => {
                              if (el1.id === el2.id) {
                                return el2.toTime;
                              } else {
                                return "";
                              }
                            })}
                            onChange={(newValue) => {
                              handleToTime(newValue, el1.id);
                            }}
                            renderInput={(params) => (
                              <TextField
                                {...params}
                                sx={{
                                  width: "100%",
                                  "& .MuiIconButton-root": {
                                    marginRight: 1,
                                  },
                                }}
                              />
                            )}
                          />
                        </LocalizationProvider>
                      </Box>
                    </Box>

                    <Button
                      onClick={() => {
                        removeSlot(el1.id);
                      }}
                      sx={{ fontSize: 12 }}
                    >
                      Remove Slot
                    </Button>
                  </>
                );
              } else {
                return "";
              }
            })
          : ""}
      </Box>
      <Box
        sx={{ mt: 3, height: 50 }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Button
          sx={{ width: 150 }}
          size="medium"
          variant="contained"
          onClick={addSlot}
          disabled={twentyFourSeven}
        >
          Add Slot
        </Button>
        <FormControlLabel
          sx={{ ml: "auto", mr: 0 }}
          control={
            <Switch
              onChange={() => {
                setTwentyFourSeven(!twentyFourSeven);
              }}
              checked={twentyFourSeven}
            />
          }
          label="24/7 Available"
        />
      </Box>
    </Box>
  );
};

export default SetAvailability;
