import { Box, Tooltip, Typography, useTheme } from "@mui/material";
import { Doughnut } from "react-chartjs-2";
import CircularProgress from "@mui/material/CircularProgress";

interface Props {
  totalChargers: number;
  totalAvailable: number;
  totalBooked: number;
  healthyChargersCount: number;
  moderateChargersCount: number;
  criticalChargersCount: number;
  damagedChargersCount: number;
}

const Availability: React.FC<Props> = ({
  totalChargers,
  healthyChargersCount,
  moderateChargersCount,
  criticalChargersCount,
  damagedChargersCount,
}) => {
  const theme = useTheme();

  const circularProgress = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 280,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" />
    </Box>
  );

  return (
    <>
      <Typography variant="h6" mb={5}>
        Charger Health
      </Typography>
      {!totalChargers ? (
        circularProgress
      ) : (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            justifyItems: "center",
          }}
        >
          <Box width={190} alignSelf="center" position="relative">
            <Doughnut
              style={{ position: "relative", zIndex: 2 }}
              data={(canvas) => {
                return {
                  datasets: [
                    {
                      data: [
                        healthyChargersCount,
                        moderateChargersCount,
                        criticalChargersCount,
                        damagedChargersCount,
                      ],
                      backgroundColor: [
                        theme.customColors.greenSecondary,
                        theme.customColors.yellowSecondary,
                        theme.customColors.orangeSecondary,
                        theme.customColors.redSecondary,
                      ],
                      spacing: 1,
                      hoverOffset: 0,
                      borderWidth: 0,
                      borderRadius: 50,
                      cutout: "80%",
                    },
                  ],
                  labels: ["Healthy", "Moderate", "Critical", "Inactive"],
                };
              }}
              options={{
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    displayColors: false,
                  },
                },
              }}
            />
            <Box
              sx={{
                zIndex: 1,
                position: "absolute",
                top: 70,
                right: 0,
                left: 0,
                mx: "auto",
                pointerEvents: "none",
                textAlign: "center",
              }}
            >
              <Typography fontSize={28} fontWeight={700} lineHeight="1.2em">
                {totalChargers}
              </Typography>
              <Typography
                sx={{
                  textTransform: "uppercase",
                  fontSize: 14,
                  fontFamily: "Poppins !important",
                }}
              >
                Total Chargers
              </Typography>
            </Box>
          </Box>
          <Box ml={3}>
            {[
              {
                label: "Healthy",
                value: healthyChargersCount,
                color: theme.customColors.text.greenSecondary,
                title: "Charger health is good",
              },
              {
                label: "Moderate",
                value: moderateChargersCount,
                color: theme.customColors.text.yellowSecondary,
                title: "Charger has not been pinged since the past 15 days",
              },
              {
                label: "Critical",
                value: criticalChargersCount,
                color: theme.customColors.text.orangeSecondary,
                title: "Charger has not been pinged since the past 30 days",
              },
              {
                label: "Inactive",
                value: damagedChargersCount,
                color: theme.customColors.text.redSecondary,
                title: "Charger has not been pinged since the past 45 days",
              },
            ].map(({ label, value, color, title }, i) => (
              <Box
                key={i}
                sx={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  // width: 1,
                  pl: 2.75,
                  mb: 2.5,
                  "& .value": {
                    mb: 1,
                    lineHeight: "1.2em",
                    fontSize: 20,
                    fontWeight: 700,
                    color: color,
                    "&:before": {
                      content: '""',
                      position: "absolute",
                      top: 4,
                      left: 0,
                      width: 14,
                      height: 14,
                      bgcolor: color,
                      borderRadius: "2px",
                    },
                  },
                  "& .title": {
                    color: "text.secondary",
                    fontSize: 14,
                    lineHeight: "1.4em",
                  },
                }}
              >
                <span className="value">{value}</span>
                <Tooltip title={title}>
                  <span className="title">{label}</span>
                </Tooltip>
              </Box>
            ))}
          </Box>
        </Box>
      )}
    </>
  );
};

export default Availability;
