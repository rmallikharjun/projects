import React, { useEffect, useState } from "react";
import {
  Avatar,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { authorizedFetch, setLoader, snackbar } from "utils";
import { useMutation } from "react-query";
import { HighlightOff } from "@mui/icons-material";
import { HEALTH_URL } from "utils/constants";

interface Props {
  open: boolean;
  handleClose: () => void;
  data: any;
}

const NotificationDialog: React.FC<Props> = ({ open, handleClose, data }) => {
  const [messageInput, setMessageInput] = useState("");

  const [phoneList, setPhoneList] = useState<any[]>(["SELECT"]);
  const [phoneInput, setPhoneInput] = useState(phoneList[0]);

  const [emailList, setEmailList] = useState<any[]>(["SELECT"]);
  const [emailInput, setEmailInput] = useState(emailList[0]);

  useEffect(() => {
    if (data && open) {
      let list = ["SELECT"];
      if (data?.incharge?.phoneNumber) {
        list.push(`${data?.incharge?.phoneNumber}`);
      }
      if (
        data?.owner?.phone &&
        data?.owner?.phone !== data?.incharge?.phoneNumber
      ) {
        list.push(`${data?.owner?.phone}`);
      }
      if (data?.owner?.altPhone1) {
        list.push(`${data?.owner?.altPhone1}`);
      }
      if (data?.owner?.altPhone2) {
        list.push(`${data?.owner?.altPhone2}`);
      }
      setPhoneList(list);
      let mailList = ["SELECT"];
      if (data?.incharge?.email) {
        mailList.push(`${data?.incharge?.email}`);
      }
      if (data?.owner?.email && data?.owner?.email !== data?.incharge?.email) {
        mailList.push(`${data?.owner?.email}`);
      }
      setEmailList(mailList);
    }
    if (!open) {
      setPhoneList(["SELECT"]);
      setMessageInput("");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, open]);

  const mutation = useMutation(
    "sendNotificatons",
    () =>
      authorizedFetch(`${HEALTH_URL}/notify/incharge`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          productId: data?.charger?.chargerId,
          productType: "CHARGING_SOCKET",
          phone: phoneInput,
          email: emailInput,
          subject: "Charger Health Notification",
          message: messageInput,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Notification Sent`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error sending notification`);
      },
    }
  );

  function onSend() {
    setLoader(true);
    mutation.mutate();
    handleClose();
  }

  const disabled =
    messageInput.length === 0 ||
    phoneInput === "SELECT" ||
    emailInput === "SELECT";

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Notify User
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        <Typography
          sx={{
            pb: 2,
            display: "flex",
            fontSize: 14,
            fontWeight: "bold",
          }}
        >
          {data?.charger?.chargerId}:
          {data?.charger?.health === "HEALTHY" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#3BB89E30",
                color: "#3BB89E",
                borderColor: "#3BB89E30",
                marginLeft: 3,
              }}
            >
              {data?.charger?.health}
            </Avatar>
          ) : data?.charger?.health === "MODERATE" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FFFF0030",
                color: "#ffc800",
                borderColor: "#FFFF0030",
                marginLeft: 3,
              }}
            >
              {data?.charger?.health}
            </Avatar>
          ) : data?.charger?.health === "CRITICAL" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FFA50030",
                color: "orange",
                borderColor: "#FFA50030",
                marginLeft: 3,
              }}
            >
              {data?.charger?.health}
            </Avatar>
          ) : data?.charger?.health === "INACTIVE" ? (
            <Avatar
              variant="status"
              sx={{
                background: "#FF000030",
                color: "red",
                borderColor: "#FF000030",
                marginLeft: 3,
              }}
            >
              {data?.charger?.health}
            </Avatar>
          ) : (
            ""
          )}
        </Typography>
        <Box>
          <Typography className="label">Phone Number</Typography>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={phoneInput}
            onChange={(e: any) => {
              setPhoneInput(e.target.value);
            }}
          >
            {phoneList?.map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select>
        </Box>
        <Box mt={4}>
          <Typography className="label">Email</Typography>
          <Select
            style={{ width: "100%" }}
            className="primary"
            value={emailInput}
            onChange={(e: any) => {
              setEmailInput(e.target.value);
            }}
          >
            {emailList?.map((filter, i) => (
              <MenuItem key={i} value={filter}>
                {filter}
              </MenuItem>
            ))}
          </Select>
        </Box>
        <Box mt={4}>
          <Typography className="label">Message</Typography>
          <TextField
            fullWidth
            id="outlined-multiline-static"
            multiline
            rows={10}
            placeholder="Type a message..."
            value={messageInput}
            onChange={(e: any) => {
              setMessageInput(e.target.value);
            }}
          />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button disabled={disabled} variant="contained" onClick={onSend}>
          Notify
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default NotificationDialog;
