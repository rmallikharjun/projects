import {
  Avatar,
  Box,
  Typography,
  useTheme,
  CircularProgress,
  Paper,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState, snackbar } from "utils";
import RangePicker from "components/RangePicker";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";
import moment from "moment";

const Consumption = ({ masterView }: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const theme = useTheme();

  const [chartData, setChartData] = useState<any>(null);

  const [range, setRange] = useState<any>([
    sub(new Date(), { weeks: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(bookingsNewUrl, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let dataArray = data.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("energy")) {
            getExisting("energy").y += cur.totalEnergyConsumed;
          } else {
            acc.energy.push({ x: day, y: cur.totalEnergyConsumed });
          }
          return acc;
        },
        {
          energy: [],
        }
      );
      setChartData(chartData);
    }
  }, [data]);

  // const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading, data } = useQuery(
  //   ["getBookings", dateFrom, dateTo, masterView],
  //   () =>
  //     authorizedFetch(bookingsUrl, {
  //       headers: {
  //         master: masterView,
  //       },
  //     }),
  //   {
  //     onError: () => snackbar.error("Error fetching data"),
  //   }
  // );

  // const statsUrl = `${BOLT_URL}/company/stats/all?dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading: statsLoading, data: stats } = useQuery(
  //   ["getAllStats", dateFrom, dateTo],
  //   () => authorizedFetch(statsUrl)
  // );

  // console.log(stats);

  // useEffect(() => {
  //   if (data?.data?.bookings?.constructor === Array) {
  //     let dataArray = data.data.bookings.sort(
  //       (a: any, b: any) =>
  //         moment(a.bookingTime).valueOf() - moment(b.bookingTime).valueOf()
  //     );
  //     let chartData = dataArray.reduce(
  //       (result: any, el: any) => {
  //         let date = format(new Date(el.bookingTime), "MMM d, yyyy");
  //         if (!result.bookings.find((d: any) => d.x === date)) {
  //           result.bookings.push({ x: date, y: 1 });
  //           result.earnings.push({ x: date, y: el.amount });
  //           result.energy.push({ x: date, y: el.energyConsumed });
  //         } else {
  //           result.bookings.find((d: any) => d.x === date).y += 1;
  //           result.earnings.find((d: any) => d.x === date).y += el.amount;
  //           result.energy.find((d: any) => d.x === date).y += el.energyConsumed;
  //         }
  //         return result;
  //       },
  //       {
  //         bookings: [],
  //         earnings: [],
  //         energy: [],
  //       }
  //     );
  //     setChartData(chartData);
  //   }
  // }, [data]);

  return (
    <Paper
      sx={{
        width: 1,
        maxWidth: 1,
        gridColumn: { md: "span 8", lg: "span 4" },
        height: { sm: 396 },
        p: { xs: 2, md: 3 },
        overflowX: "auto",
        overflowY: "hidden",
      }}
    >
      <Box
        sx={{
          mb: 2,
          display: { xs: "grid", sm: "flex" },
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box display="flex" alignItems="center">
          <Typography variant="h6">Energy Consumption</Typography>
          <Avatar variant="label" sx={{ ml: 1 }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              `${Math.floor(data?.data?.totalEnergyConsumed || 0).toFixed(
                2
              )} kWh`
            )}
          </Avatar>
        </Box>
        <Box sx={{ my: { xs: 1.25, sm: 0 } }}>
          <RangePicker range={range} setRange={setRange} initialRange="7D" />
        </Box>
      </Box>
      <Box
        sx={{
          minWidth: 500,
          height: 295,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        {isLoading ? (
          <CircularProgress />
        ) : (
          <Line
            data={(canvas) => {
              const ctx = canvas.getContext("2d");
              const g = ctx?.createLinearGradient(0, 0, 0, 290);

              g?.addColorStop(0, "rgba(71, 123, 237, 0.7)");
              g?.addColorStop(
                1,
                isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
              );

              let color = theme.customColors.blueSecondary;
              let labels = chartData?.energy?.map(
                (el: any) => el.x.split(",")[0]
              );

              return {
                labels,
                datasets: [
                  {
                    fill: true,
                    data: chartData?.energy?.map((el: any) => el.y),
                    borderColor: color,
                    borderWidth: 2,
                    backgroundColor: g,
                    tension: 0,
                    pointRadius: 0,
                    pointHoverRadius: 4,
                    pointHoverBackgroundColor: "#fff",
                    pointHoverBorderWidth: 3,
                  },
                ],
              };
            }}
            options={{
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                },
                yAxis: {
                  title: {
                    display: true,
                    text: "Energy (kWh)",
                    padding: {
                      top: 0,
                      bottom: 8,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  suggestedMin: 0,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
              },
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
            }}
          />
        )}
      </Box>
    </Paper>
  );
};

export default Consumption;
