import {
  EditOutlined,
  HighlightOff,
  InfoOutlined,

  // InfoOutlined
} from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  Radio,
  RadioGroup,
  // Slider,
  Step,
  StepButton,
  Stepper,
  TextField,
  // Tooltip,
  Typography,
  InputAdornment,
  Slider,
  Tooltip,
} from "@mui/material";
// import InputAdornment from "@mui/material";
import { useState, useEffect } from "react";
import { snackbar, setLoader, authorizedFetch } from "utils";
import { BOLT_URL } from "utils/constants";
import { useMutation, useQuery } from "react-query";
import { v4 as uuidv4 } from "uuid";
import React from "react";
import SetAvailability from "./SetAvailability";
import moment from "moment";

// import ChargerHealth from "../Overview/ChargerHealth";

interface Props {
  open: boolean;
  handleClose: () => void;
  data: any;
  count: number;
  refetchStats: () => void;
  closeDrawer: () => void;
  refetchChargers: () => void;
}

const AddDialog: React.FC<Props> = ({
  open,
  handleClose,
  count,
  data,
  refetchStats,
  closeDrawer,
  refetchChargers,
}) => {
  const [step, setStep] = useState<number>(0);
  // const steps = ["Station Info", "Availability", "Finish"];
  const steps = ["Station Info", "Availability", "Specification", "Finish"];

  const [usageType, setUsageType] = useState("");
  const [twentyFourSeven, setTwentyFourSeven] = useState(false);
  const [days, setDays] = useState<any>([]);

  const chargerUrl = `${BOLT_URL}/company/charger/${data?.charger?.chargerId}`;

  const { data: chargerData } = useQuery(
    ["getCharger", data?.charger?.chargerId],
    () => authorizedFetch(chargerUrl)
  );

  const [input, setInput] = useState({
    uid: "",
    name: "",
    contactName: "",
    phone: "",
    stationName: "",
    address: "",
    latitude: "",
    longitude: "",
    electricityCost: "",
    baseAmount: "",
    chargePerHour: "",
    autoCutoff: 0,
    powerOutput: 0,
  });

  useEffect(() => {
    if (open) {
      setStep(count);
    } else {
      setStep(0);
    }
  }, [open, count]);

  useEffect(() => {
    if (data && open) {
      // console.log(data);
      setUsageType(data.charger.usageType);
      setInput({
        uid: data.charger.chargerId,
        name: data.charger.chargerName,
        contactName: data.incharge.name,
        phone: data.incharge.phoneNumber,
        stationName: data.station.stationName,
        address: data.station.address,
        latitude: data.station.location.latitude,
        longitude: data.station.location.longitude,
        electricityCost: data.paymentDetails.costPerkWh,
        baseAmount: data.paymentDetails.baseAmount,
        chargePerHour: data.paymentDetails.chargePerHour,
        autoCutoff: data.specification.autoCutOff.value,
        powerOutput: data.specification.powerOutput.value,
      });
      setTwentyFourSeven(data.availability.twentyFourSeven);
      setDays(data.availability.days);
    } else {
      setInput({
        uid: "",
        name: "",
        contactName: "",
        phone: "",
        stationName: "",
        address: "",
        latitude: "",
        longitude: "",
        electricityCost: "",
        baseAmount: "",
        chargePerHour: "",
        autoCutoff: 0,
        powerOutput: 0,
      });
      setTwentyFourSeven(false);
      setDays([]);
    }
  }, [data, open]);

  function formatDays() {
    let data = [...days];
    data.forEach((el: any) => {
      delete el.id;
      el.fromTime = moment(el.fromTime).format("HH:mm");
      el.toTime = moment(el.toTime).format("HH:mm");
    });
    return data;
  }

  const {
    uid,
    name,
    contactName,
    phone,
    stationName,
    address,
    electricityCost,
    baseAmount,
    chargePerHour,
    autoCutoff,
    powerOutput,
    latitude,
    longitude,
  } = input;

  const url = `${BOLT_URL}/charger/${uid}/update`;

  const mutation = useMutation(
    `updateCharger ${uid}`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          availability: {
            days: formatDays(),
            twentyFourSeven: twentyFourSeven,
          },
          charger: {
            chargerName: name,
            usageType: usageType,
            restrictedFlag:
              usageType === "RESTRICTED_PAID"
                ? uuidv4()
                : usageType === "RESTRICTED_FREE"
                ? uuidv4()
                : "",
          },
          station: {
            stationName: stationName,
            address: address,
            location: {
              latitude: latitude,
              longitude: longitude,
            },
          },
          incharge: {
            contactName: contactName,
            phoneNumber: phone,
          },
          paymentDetails: {
            costPerkWh: electricityCost,
            baseAmount: baseAmount,
            chargePerHour: chargePerHour,
          },
          specification: {
            autoCutOff: autoCutoff,
            powerOutput: powerOutput,
          },
        },
      }),
    {
      onSuccess: () => {
        refetchChargers();
        refetchStats();
        snackbar.success(`Charger Updated`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error updating charger`);
      },
    }
  );

  function handleNext() {
    if (step === steps.length - 1) {
      onSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  const disabled = [
    uid,
    name,
    contactName,
    phone,
    stationName,
    address,
    electricityCost,
    baseAmount,
    chargePerHour,
    usageType,
    days,
    twentyFourSeven,
  ].includes("");

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![uid, name].includes("");
      case 1:
        return ![
          contactName,
          phone,
          stationName,
          address,
          electricityCost,
          baseAmount,
          chargePerHour,
          usageType,
        ].includes("");
      case 2:
        return ![days, twentyFourSeven].includes("");
      default:
        break;
    }
  }

  function returnTime(day: number) {
    return twentyFourSeven
      ? "All Day"
      : days.some((el: any) => el.day === day) === false
      ? "Unavailable"
      : days
          .filter((el: any) => el.day === day)
          .map((el: any) => (
            <div>
              {moment(el.fromTime, ["ddd MMM DD YYYY HH:mm:ss"]).format(
                "h:mm A"
              ) +
                "-" +
                moment(el.toTime, ["ddd MMM DD YYYY HH:mm:ss"]).format(
                  "h:mm A"
                )}
            </div>
          ));
  }

  function onSave() {
    setLoader(true);
    mutation.mutate();
    handleClose();
    // refetchStats();
    // refetchChargers();
    closeDrawer();
  }

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Edit Charger - {uid}
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ my: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {/* {step === 0 && (
          <Box
            sx={{
              maxWidth: 280,
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">UID</Typography>
              <TextField
                fullWidth
                disabled
                size="small"
                placeholder="UID"
                value={uid}
                onChange={(e: any) => {
                  setInput({ ...input, uid: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Name"
                value={name}
                onChange={(e: any) => {
                  setInput({ ...input, name: e.target.value });
                }}
              />
            </Box>
          </Box>
        )} */}
        {step === 0 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Typography className="label">Usage Type</Typography>
              <RadioGroup
                row
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr 1fr",
                    sm: "repeat(3, 1fr)",
                  },
                }}
                value={usageType}
                onChange={(e: any) => setUsageType(e.target.value)}
              >
                <FormControlLabel
                  value="PUBLIC_PAID"
                  control={<Radio />}
                  label="Public Paid"
                />

                <FormControlLabel
                  value="PUBLIC_FREE"
                  control={<Radio />}
                  label="Public Free"
                />

                {!chargerData?.data?.isRupeeCharger ? (
                  <FormControlLabel
                    value="PRIVATE"
                    control={<Radio />}
                    label="Private"
                  />
                ) : (
                  ""
                )}

                <FormControlLabel
                  value="RESTRICTED_PAID"
                  control={<Radio />}
                  label="Restricted Paid"
                />

                <FormControlLabel
                  value="RESTRICTED_FREE"
                  control={<Radio />}
                  label="Restricted Free"
                />
              </RadioGroup>
            </Box>
            <Box gridColumn={{ sm: "span 2" }}>
              <Typography className="label">Station Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Station Name"
                value={stationName}
                onChange={(e: any) => {
                  setInput({
                    ...input,
                    stationName:
                      e.target.value?.length > 0
                        ? e.target.value.replace(/[^a-zA-Z0-9 ]/g, "")
                        : e.target.value,
                  });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Contact Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Name"
                value={contactName}
                onChange={(e: any) => {
                  setInput({ ...input, contactName: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Contact Phone</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Phone"
                value={phone}
                onChange={(e: any) => {
                  setInput({ ...input, phone: e.target.value });
                }}
                // InputLabelProps={{
                //   shrink: true,
                // }}
                // InputProps={{
                //   startAdornment: (
                //     <InputAdornment position="start">+91</InputAdornment>
                //   ),
                // }}
                // onInput={(e: any) => {
                //   e.target.value = Math.max(0, parseInt(e.target.value))
                //     .toString()
                //     .slice(0, 10);
                // }}
              />
            </Box>

            <Box sx={{ gridColumn: { sm: "span 2" } }}>
              <Typography className="label">Station Address</Typography>
              <TextField
                fullWidth
                size="medium"
                placeholder="Connector Type"
                value={address}
                onChange={(e: any) => {
                  setInput({ ...input, address: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Latitude</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Latitude"
                value={latitude}
                onChange={(e: any) => {
                  setInput({ ...input, latitude: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Longitude</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Longitude"
                value={longitude}
                onChange={(e: any) => {
                  setInput({ ...input, longitude: e.target.value });
                }}
              />
            </Box>
            {!(
              usageType === "PUBLIC_FREE" || usageType === "RESTRICTED_FREE"
            ) && (
              <>
                <Box sx={{ gridColumn: { sm: "span 2" } }}>
                  <Typography className="label">Electricity Cost</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Longitude"
                    value={electricityCost}
                    onChange={(e: any) => {
                      setInput({ ...input, electricityCost: e.target.value });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <Box>
                  <Typography className="label">Base Amount</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Longitude"
                    value={baseAmount}
                    onChange={(e: any) => {
                      setInput({ ...input, baseAmount: e.target.value });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <Box>
                  <Typography className="label">Charge Per Hour</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Longitude"
                    value={chargePerHour}
                    onChange={(e: any) => {
                      setInput({ ...input, chargePerHour: e.target.value });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>{" "}
              </>
            )}
          </Box>
        )}
        {step === 1 && (
          <SetAvailability
            open={open}
            twentyFourSeven={twentyFourSeven}
            days={days}
            setTwentyFourSeven={setTwentyFourSeven}
            setDays={setDays}
          />
        )}
        {step === 2 && (
          <Box
            sx={{
              maxWidth: 350,
              mx: "auto",
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr" },
              gap: 3,
            }}
          >
            <Box mt={2}>
              <Box display="flex" alignItems="center">
                <Typography className="label">Auto Cutoff</Typography>
                <Tooltip title="Value should be in the range of 0 to 250 seconds">
                  <InfoOutlined
                    color="action"
                    fontSize="inherit"
                    sx={{ ml: 0.5, mt: -1.5, cursor: "pointer" }}
                  />
                </Tooltip>
              </Box>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Name"
                type="number"
                value={autoCutoff}
                onChange={(e: any) => {
                  setInput({
                    ...input,
                    autoCutoff:
                      e.target.value > 250
                        ? 250
                        : e.target.value < 0
                        ? 0
                        : e.target.value,
                  });
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end" sx={{ mr: 1 }}>
                      seconds
                    </InputAdornment>
                  ),
                }}
                sx={{ mt: 1 }}
              />
            </Box>
            <Box mt={2}>
              <Box display="flex" alignItems="center">
                <Typography className="label">Power Output</Typography>
                <Tooltip title="Value should be in the range of 0 to 16 Amphere">
                  <InfoOutlined
                    color="action"
                    fontSize="inherit"
                    sx={{ ml: 0.5, mt: -1.5, cursor: "pointer" }}
                  />
                </Tooltip>
              </Box>
              <Box alignItems="center">
                <Box
                  sx={{
                    border: "1px solid #00000040",
                    width: 50,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: 1,
                    mt: 1,
                  }}
                >
                  <Typography sx={{ p: 0.5 }}>{powerOutput}A</Typography>
                </Box>

                <Slider
                  sx={{ mt: 1.5 }}
                  aria-label="Temperature"
                  defaultValue={16}
                  // getAriaValueText={valuetext}
                  value={powerOutput}
                  valueLabelDisplay="auto"
                  step={1}
                  marks
                  min={0}
                  max={16}
                  onChange={(e: any) => {
                    setInput({ ...input, powerOutput: e.target.value });
                  }}
                />
              </Box>
            </Box>
          </Box>
        )}

        {step === 3 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme: any) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  // { header: "Basic Info", onEdit: () => setStep(0) },
                  // { label: "UID", value: uid },
                  // { label: "Name", value: name },
                  // { label: "Company", value: company },

                  { header: "Station Info", onEdit: () => setStep(0) },
                  { label: "Payment Type", value: usageType },
                  { label: "Contact Name", value: contactName },
                  { label: "Contact Phone", value: phone },
                  { label: "Station Name", value: stationName },
                  { label: "Station Address", value: address },
                  { label: "Latitude", value: latitude },
                  { label: "Longitude", value: longitude },
                  {
                    label: "Electricity Cost",
                    value: `₹ ${electricityCost}`,
                  },
                  { label: "Base Amount", value: `₹ ${baseAmount}` },
                  { label: "Charge per Hour", value: `₹ ${chargePerHour}` },
                  { header: "Availability", onEdit: () => setStep(1) },
                  { label: "Sunday", value: returnTime(0) },
                  { label: "Monday", value: returnTime(1) },
                  { label: "Tuesday", value: returnTime(2) },
                  { label: "Wednesday", value: returnTime(3) },
                  { label: "Thursday", value: returnTime(4) },
                  { label: "Friday", value: returnTime(5) },
                  { label: "Saturday", value: returnTime(6) },
                  { header: "Specification", onEdit: () => setStep(2) },
                  { label: "Auto Cutoff", value: `${autoCutoff} seconds` },
                  { label: "Power Output", value: `${powerOutput} A` },
                ].map(({ header, onEdit, label, value }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td>{label}</td>
                          <td className="bold">{value}</td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant="contained"
          color={
            isComplete(step) || step === steps.length - 1
              ? "primary"
              : "inherit"
          }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddDialog;
