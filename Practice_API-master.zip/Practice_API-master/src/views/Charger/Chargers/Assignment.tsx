import { Box, Typography, useTheme } from "@mui/material";
import { Doughnut } from "react-chartjs-2";
import CircularProgress from "@mui/material/CircularProgress";

interface Props {
  totalChargers: number;
  assigned: number;
  unassigned: number;
}

const Assignment: React.FC<Props> = ({
  totalChargers,
  unassigned,
  assigned,
}) => {
  const theme = useTheme();

  const circularProgress = (
    <Box
      sx={{
        flexGrow: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: 180,
        width: 1,
        mb: "3px",
      }}
    >
      <CircularProgress color="primary" />
    </Box>
  );

  return (
    <>
      <Typography variant="h6" mb={12}>
        Charger Assignment
      </Typography>
      {!totalChargers ? (
        circularProgress
      ) : (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            justifyItems: "center",
          }}
        >
          <Box width={190} alignSelf="center" position="relative">
            <Doughnut
              style={{ position: "relative", zIndex: 2 }}
              data={(canvas) => {
                return {
                  datasets: [
                    {
                      data: [assigned, unassigned],
                      backgroundColor: [
                        theme.customColors.greenSecondary,
                        theme.customColors.blueSecondary,
                      ],
                      spacing: 1,
                      hoverOffset: 0,
                      borderWidth: 0,
                      borderRadius: 50,
                      cutout: "80%",
                    },
                  ],
                  labels: ["Assigned Vendors", "Not Assigned"],
                };
              }}
              options={{
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    displayColors: false,
                  },
                },
              }}
            />
            <Box
              sx={{
                zIndex: 1,
                position: "absolute",
                top: 70,
                right: 0,
                left: 0,
                mx: "auto",
                pointerEvents: "none",
                textAlign: "center",
              }}
            >
              <Typography fontSize={28} fontWeight={700} lineHeight="1.2em">
                {totalChargers}
              </Typography>
              <Typography
                sx={{
                  textTransform: "uppercase",
                  fontSize: 14,
                  fontFamily: "Poppins !important",
                }}
              >
                Total Chargers
              </Typography>
            </Box>
          </Box>
          <Box mt={3} ml={3}>
            {[
              {
                label: "Assigned Vendors",
                value: assigned,
                color: theme.customColors.text.greenSecondary,
              },
              {
                label: "Unassigned",
                value: unassigned,
                color: theme.customColors.text.blueSecondary,
              },
            ].map(({ label, value, color }, i) => (
              <Box
                key={i}
                sx={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  // width: 1,
                  pl: 2.75,
                  mb: 2.5,
                  "& .value": {
                    mb: 1,
                    lineHeight: "1.2em",
                    fontSize: 20,
                    fontWeight: 700,
                    color: color,
                    "&:before": {
                      content: '""',
                      position: "absolute",
                      top: 4,
                      left: 0,
                      width: 14,
                      height: 14,
                      bgcolor: color,
                      borderRadius: "2px",
                    },
                  },
                  "& .title": {
                    color: "text.secondary",
                    fontSize: 14,
                    lineHeight: "1.4em",
                  },
                }}
              >
                <span className="value">{value}</span>
                <span className="title">{label}</span>
              </Box>
            ))}
          </Box>
        </Box>
      )}
    </>
  );
};

export default Assignment;
