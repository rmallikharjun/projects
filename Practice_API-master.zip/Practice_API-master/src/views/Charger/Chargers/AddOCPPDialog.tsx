import {
  Add,
  EditOutlined,
  HighlightOff,
  InfoOutlined,

  // InfoOutlined
} from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  Radio,
  RadioGroup,
  // Slider,
  Step,
  StepButton,
  Stepper,
  TextField,
  // Tooltip,
  Typography,
  InputAdornment,
  Tooltip,
} from "@mui/material";
// import InputAdornment from "@mui/material";
import { useState, useEffect } from "react";
import { snackbar, setLoader, authorizedFetch } from "utils";
import ConnectorDialog from "./ConnectorDialog";
import { useMutation } from "react-query";
import { v4 as uuidv4 } from "uuid";
import React from "react";
import SetAvailability from "./SetAvailability";
import moment from "moment";

// import ChargerHealth from "../Overview/ChargerHealth";

interface Props {
  open: boolean;
  handleClose: () => void;
  refetchChargers: () => void;
  refetchStats: () => void;
}

const AddDialog: React.FC<Props> = ({
  open,
  handleClose,
  refetchChargers,
  refetchStats,
}) => {
  const [step, setStep] = useState<number>(0);
  const steps = ["Basic Info", "Station Info", "Availability", "Finish"];
  // const steps = ["Station Info", "Availability", "Specification", "Finish"];

  const [usageType, setUsageType] = useState("");
  const [twentyFourSeven, setTwentyFourSeven] = useState(true);
  const [days, setDays] = useState<any>([]);
  // const [connector, setConnector] = useState(false);

  const [basicInput, setBasicInput] = useState({
    uid: "",
    name: "",
    contactName: "",
    phone: "",
    email: "",
    chargerSerial: "",
    connectorData: [
      {
        id: "1",
        status: "",
        type: "car",
        meterValues: "",
      },
    ],
    RfId: "",
  });
  const [stationInput, setStationInput] = useState({
    stationName: "",
    address: "",
    city: "",
    pincode: "",
    district: "",
    state: "",
    latitude: "",
    longitude: "",
    country: "",
    electricityCost: "",
    baseAmount: "",
    chargePerHour: "",
  });

  function formatDays() {
    let data = [...days];
    data.forEach((el: any) => {
      delete el.id;
      el.fromTime = moment(el.fromTime).format("HH:mm");
      el.toTime = moment(el.toTime).format("HH:mm");
    });
    return data;
  }

  const {
    uid,
    name,
    contactName,
    phone,
    email,
    chargerSerial,
    connectorData,
    RfId,
  } = basicInput;
  const {
    stationName,
    address,
    city,
    pincode,
    district,
    state,
    latitude,
    longitude,
    country,
    electricityCost,
    baseAmount,
    chargePerHour,
  } = stationInput;

  function handleNext() {
    if (step === steps.length - 1) {
      onSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  const disabled = [
    uid,
    name,
    contactName,
    chargerSerial,
    RfId,
    phone,
    email,
    stationName,
    address,
    city,
    pincode,
    district,
    state,
    latitude,
    longitude,
    country,
    electricityCost,
    baseAmount,
    chargePerHour,
    connectorData.join(""),
    usageType,
    days,
    twentyFourSeven,
  ].includes("");

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![
          uid,
          name,
          contactName,
          phone,
          email,
          chargerSerial,
          connectorData.join(""),
          RfId,
        ].includes("");
      case 1:
        return ![
          stationName,
          address,
          city,
          pincode,
          district,
          state,
          latitude,
          longitude,
          country,
          electricityCost,
          baseAmount,
          chargePerHour,
        ].includes("");
      case 2:
        return ![days, twentyFourSeven].includes("");
      default:
        break;
    }
  }

  console.log(basicInput, "baic at 201");

  function returnTime(day: number) {
    return twentyFourSeven
      ? "All Day"
      : days.some((el: any) => el.day === day) === false
      ? "Unavailable"
      : days
          .filter((el: any) => el.day === day)
          .map((el: any) => (
            <div>
              {moment(el.fromTime, ["ddd MMM DD YYYY HH:mm:ss"]).format(
                "h:mm A"
              ) +
                "-" +
                moment(el.toTime, ["ddd MMM DD YYYY HH:mm:ss"]).format(
                  "h:mm A"
                )}
            </div>
          ));
  }

  const url = `http://13.215.47.160:9000/charger/register`;

  const mutation = useMutation(
    `registerCharger`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "test",
          token: "1234",
          Authorization:
            "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI1Y2ZhNDNjNmE3YjExYjAwMDczZjk2NTYiLCJpYXQiOjE2NTAwOTAxMDl9.SS_2FWsTt_Phhw6c81SPZppay4s-8oxy7OGGsRQWVSE",
        },
        body: {
          station: {
            stationName: stationName,
            address: address,
            city: city,
            postalCode: pincode,
            district: district,
            state: state,
            location: {
              latitude: latitude,
              longitude: longitude,
            },
            country: country,
          },
          incharge: {
            name: contactName,
            phoneNumber: phone,
            email: email,
          },
          charger: {
            chargerId: "BOLT_" + uid,
            ocppChargerId: chargerSerial,
            connectors: connectorData,
            idTag: RfId,
            chargerName: name,
            usageType: usageType,
            restrictedFlag:
              usageType === "RESTRICTED_PAID"
                ? uuidv4()
                : usageType === "RESTRICTED_FREE"
                ? uuidv4()
                : "",
            modelId: "OCPP_LEVEL_2",
            vehicleType: ["TWO_WHEELER"],
            chargerStatus: "AVAILABLE",
          },
          availability: {
            days: formatDays(),
            timeZone: "Asia/Calcutta",
            twentyFourSeven: twentyFourSeven,
          },
          specification: {
            firmware: "V00.00.45",
            key: "YebbG4WKfcr0FUPhdDIb8w==",
          },
          paymentDetails: {
            paymentMethodId: "NA",
            tariffMode: "HOURLY",
            acceptedPaymentModes: ["INTEGRATED_PAYMENT_PORTAL"],
            costPerkWh: electricityCost,
            baseAmount: baseAmount,
            chargePerHour: chargePerHour,
          },
        },
      }),
    {
      onSuccess: () => {
        refetchChargers();
        refetchStats();
        snackbar.success(`OCPP Charger Added`);
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error adding ocpp charger`);
      },
    }
  );

  const onSave = () => {
    setLoader(true);
    mutation.mutate();
    handleClose();
  };

  function addConnectors() {
    console.log("clicked");
    let existing = [...basicInput.connectorData];
    console.log(existing, existing[existing.length - 1], "existing");
    let maxId = parseInt(existing[existing.length - 1].id);
    let newObj = {
      id: (maxId + 1).toString(),
      status: "",
      type: "car",
      meterValues: "",
    };
    existing.push(newObj);
    console.log(existing, "existing");
    setBasicInput({ ...basicInput, connectorData: existing });
  }

  useEffect(() => {
    if (!open) {
      setBasicInput({
        uid: "",
        name: "",
        contactName: "",
        phone: "",
        email: "",
        chargerSerial: "",
        connectorData: [
          {
            id: "1",
            status: "",
            type: "car",
            meterValues: "",
          },
        ],
        RfId: "",
      });
      setStationInput({
        stationName: "",
        address: "",
        city: "",
        pincode: "",
        district: "",
        state: "",
        latitude: "",
        longitude: "",
        country: "",
        electricityCost: "",
        baseAmount: "",
        chargePerHour: "",
      });
      setTwentyFourSeven(true);
      setDays([]);
      setStep(0);
      setUsageType("");
    }
  }, [open]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add OCPP Charger
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ my: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>

        {step === 0 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box>
              <Box display="flex" alignItems="center">
                <Typography className="label">Charger UID</Typography>
                <Tooltip title="UID length should be 5 to 8 characters with a mix of Uppercase alphabets and Numbers only">
                  <InfoOutlined
                    fontSize="inherit"
                    sx={{
                      ml: 0.5,
                      mt: -1.7,
                      cursor: "pointer",
                      color: "#00000080",
                    }}
                  />
                </Tooltip>
              </Box>

              <TextField
                fullWidth
                size="small"
                placeholder="UID"
                value={uid}
                onChange={(e: any) => {
                  setBasicInput({
                    ...basicInput,
                    uid: e.target.value,
                  });
                }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start" sx={{ ml: 1 }}>
                      BOLT_
                    </InputAdornment>
                  ),
                }}
                error={!/^([A-Z0-9]){5,8}$/.test(uid)}
              />
            </Box>
            <Box>
              <Typography className="label">Charger Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Charger Name"
                value={name}
                onChange={(e: any) => {
                  setBasicInput({
                    ...basicInput,
                    name: e.target.value,
                  });
                }}
              />
            </Box>
            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Typography className="label">Contact Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Name"
                value={contactName}
                onChange={(e: any) => {
                  setBasicInput({ ...basicInput, contactName: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Contact Phone</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Phone"
                value={phone}
                onChange={(e: any) => {
                  setBasicInput({ ...basicInput, phone: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Contact Email</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Contact Email"
                value={email}
                onChange={(e: any) => {
                  setBasicInput({ ...basicInput, email: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">RFID</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="RFID"
                value={RfId}
                onChange={(e: any) => {
                  setBasicInput({
                    ...basicInput,
                    RfId: e.target.value,
                  });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Charger Serial No.</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Charger Serial No."
                value={chargerSerial}
                onChange={(e: any) => {
                  setBasicInput({
                    ...basicInput,
                    chargerSerial: e.target.value,
                  });
                }}
              />
            </Box>
            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Typography className="label">Connector</Typography>
              <Button onClick={addConnectors}>
                <Add />
              </Button>
            </Box>
            {/* <Box>
              <Typography className="label">Charger Output</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Charger Output"
                value={email}
                onChange={(e: any) => {
                  setBasicInput({ ...basicInput, email: e.target.value });
                }}
              />
            </Box> */}
            <Box
              // width={'100%'}
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              {connectorData.map((sConnector: any) => (
                <ConnectorDialog
                  connectorNumber={parseInt(sConnector.id)}
                  connectorType={sConnector.type}
                  basicInput={basicInput}
                  setBasicInput={setBasicInput}
                />
              ))}
            </Box>
          </Box>
        )}

        {step === 1 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Typography className="label">Usage Type</Typography>
              <RadioGroup
                row
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "1fr 1fr",
                    sm: "repeat(3, 1fr)",
                  },
                }}
                value={usageType}
                onChange={(e: any) => setUsageType(e.target.value)}
              >
                <FormControlLabel
                  value="PUBLIC_PAID"
                  control={<Radio />}
                  label="Public Paid"
                />

                <FormControlLabel
                  value="PUBLIC_FREE"
                  control={<Radio />}
                  label="Public Free"
                />

                <FormControlLabel
                  value="PRIVATE"
                  control={<Radio />}
                  label="Private"
                />

                <FormControlLabel
                  value="RESTRICTED_PAID"
                  control={<Radio />}
                  label="Restricted Paid"
                />

                <FormControlLabel
                  value="RESTRICTED_FREE"
                  control={<Radio />}
                  label="Restricted Free"
                />
              </RadioGroup>
            </Box>

            <Box
              sx={{
                gridColumn: { sm: "span 2" },
              }}
            >
              <Typography className="label">Station Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Station Name"
                value={stationName}
                onChange={(e: any) => {
                  setStationInput({
                    ...stationInput,
                    stationName:
                      e.target.value?.length > 0
                        ? e.target.value.replace(/[^a-zA-Z0-9 ]/g, "")
                        : e.target.value,
                  });
                }}
              />
            </Box>

            <Box sx={{ gridColumn: { sm: "span 2" } }}>
              <Typography className="label">Station Address</Typography>
              <Box
                sx={{
                  maxWidth: 560,
                  mx: "auto",
                  display: "grid",
                  gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                  gap: 2,
                  mt: 2,
                }}
              >
                <Box sx={{ gridColumn: { sm: "span 2" } }}>
                  <Typography fontSize={14} mb={1.5}>
                    Plot No. | Street Name | Landmark
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Plot No. | Street Name | Landmark"
                    value={address}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        address: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    City
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="City"
                    value={city}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        city: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    Pincode
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Pincode"
                    value={pincode}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        pincode: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    District
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="District"
                    value={district}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        district: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    State
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="State"
                    value={state}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        state: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    Latitude
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Latitude"
                    value={latitude}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        latitude: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box>
                  <Typography fontSize={14} mb={1}>
                    Longitude
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Longitude"
                    value={longitude}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        longitude: e.target.value,
                      });
                    }}
                  />
                </Box>
                <Box sx={{ gridColumn: { sm: "span 2" } }}>
                  <Typography fontSize={14} mb={1}>
                    Country
                  </Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Country"
                    value={country}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        country: e.target.value,
                      });
                    }}
                  />
                </Box>
              </Box>
            </Box>

            {!(
              usageType === "PUBLIC_FREE" || usageType === "RESTRICTED_FREE"
            ) && (
              <>
                <Box sx={{ gridColumn: { sm: "span 2" } }}>
                  <Typography className="label">Electricity Cost</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Electricity Cost"
                    value={electricityCost}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        electricityCost: e.target.value,
                      });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <Box>
                  <Typography className="label">Base Amount</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Base Amount"
                    value={baseAmount}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        baseAmount: e.target.value,
                      });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>
                <Box>
                  <Typography className="label">Charge Per Hour</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    placeholder="Charge Per Hour"
                    value={chargePerHour}
                    onChange={(e: any) => {
                      setStationInput({
                        ...stationInput,
                        chargePerHour: e.target.value,
                      });
                    }}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          ₹
                        </InputAdornment>
                      ),
                    }}
                  />
                </Box>{" "}
              </>
            )}
          </Box>
        )}
        {step === 2 && (
          <SetAvailability
            open={open}
            twentyFourSeven={twentyFourSeven}
            days={days}
            setTwentyFourSeven={setTwentyFourSeven}
            setDays={setDays}
          />
        )}

        {step === 3 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme: any) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Basic Info", onEdit: () => setStep(0) },
                  { label: "Charger UID", value: "BOLT_" + uid },
                  { label: "Charger ID", value: name },
                  { label: "Contact Name", value: contactName },
                  { label: "Contact Phone", value: phone },
                  { label: "Contact Email", value: email },

                  { header: "Station Info", onEdit: () => setStep(1) },
                  { label: "Payment Type", value: usageType },

                  { label: "Station Name", value: stationName },
                  {
                    label: "Plot No. | Street Name | Landmark",
                    value: address,
                  },
                  { label: "City", value: city },
                  { label: "Pincode", value: pincode },
                  { label: "District", value: district },
                  { label: "State", value: state },
                  { label: "Latitude", value: latitude },
                  { label: "Longitude", value: longitude },
                  { label: "Country", value: country },
                  {
                    label: "Electricity Cost",
                    value: `₹ ${electricityCost}`,
                  },
                  { label: "Base Amount", value: `₹ ${baseAmount}` },
                  { label: "Charge per Hour", value: `₹ ${chargePerHour}` },
                  { header: "Availability", onEdit: () => setStep(2) },
                  { label: "Sunday", value: returnTime(0) },
                  { label: "Monday", value: returnTime(1) },
                  { label: "Tuesday", value: returnTime(2) },
                  { label: "Wednesday", value: returnTime(3) },
                  { label: "Thursday", value: returnTime(4) },
                  { label: "Friday", value: returnTime(5) },
                  { label: "Saturday", value: returnTime(6) },
                ].map(({ header, onEdit, label, value }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td>{label}</td>
                          <td className="bold">{value}</td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant="contained"
          color={
            isComplete(step) || step === steps.length - 1
              ? "primary"
              : "inherit"
          }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddDialog;
