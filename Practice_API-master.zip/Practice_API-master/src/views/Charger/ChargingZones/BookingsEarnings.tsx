import {
  Box,
  Typography,
  useTheme,
  CircularProgress,
  Paper,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import RangePicker from "components/RangePicker";
import { snackbar } from "utils";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
//import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";
import moment from "moment";

const BookingsEarnings = ({ masterView }: any) => {
  const theme = useTheme();

  // const [chartData, setChartData] = useState<any>(null);

  const [range, setRange] = useState<any>([
    sub(new Date(), { weeks: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  // const bookingsUrl = `${BOLT_URL}/company/bookings?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading, data } = useQuery(
  //   ["getBookings", dateFrom, dateTo, masterView],
  //   () =>
  //     authorizedFetch(bookingsUrl, {
  //       headers: {
  //         master: masterView,
  //       },
  //     }),
  //   {
  //     onError: () => snackbar.error("Error fetching data"),
  //   }
  // );

  // const statsUrl = `${BOLT_URL}/company/stats/all?dateFrom=${dateFrom}&dateTo=${dateTo}`;

  // const { isLoading: statsLoading, data: stats } = useQuery(
  //   ["getAllStats", dateFrom, dateTo],
  //   () => authorizedFetch(statsUrl)
  // );

  const [chartData, setChartData] = useState<any>();

  // const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;
  const url = `https://bolt.dev.revos.in/company/zones/stats?dateFrom=${dateFrom}&dateTo==${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo, masterView],
    () =>
      authorizedFetch(url, {
        headers: {
          master: masterView,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let dataArray = data.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("bookings")) {
            getExisting("bookings").y += cur.totalBookings;
            getExisting("earnings").y += Math.round(
              parseFloat(cur.totalEnergyConsumed)
            );
          } else {
            acc.bookings.push({ x: day, y: cur.totalBookings });
            acc.earnings.push({
              x: day,
              y: Math.round(parseFloat(cur.totalEnergyConsumed)),
            });
          }
          return acc;
        },
        {
          bookings: [],
          earnings: [],
        }
      );
      setChartData(chartData);
    }
  }, [data]);

  console.log("DATA is :", data);

  return (
    <Paper
      sx={{
        width: 1,
        maxWidth: 1,
        gridColumn: { md: "span 8", lg: "span 4" },
        height: { sm: 396 },
        p: { xs: 2, md: 3 },
        overflowX: "auto",
        overflowY: "hidden",
      }}
    >
      <Box
        sx={{
          mb: 2,
          display: { xs: "grid", sm: "flex" },
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Typography variant="h6" sx={{ mr: 1 }}>
          Bookings vs Energy Comsumption
        </Typography>
        <Box sx={{ my: { xs: 1.25, sm: 0 } }}>
          <RangePicker range={range} setRange={setRange} initialRange="7D" />
        </Box>
      </Box>
      <Box
        sx={{
          mb: 3,
          display: "flex",
          alignItems: "center",
          "& .text": {
            position: "relative",
            fontSize: 13,
            lineHeight: "1em",
            color: theme.customColors.greySecondary,
            "&:before": {
              content: '""',
              position: "absolute",
              top: 0,
              left: -18,
              height: 10,
              width: 10,
              backgroundColor: theme.customColors.greenSecondary,
              borderRadius: 1,
            },
          },
          "& .bookings": {
            ml: 2.5,
            "&:before": {
              backgroundColor: theme.customColors.blueSecondary,
            },
          },
        }}
        display="flex"
        alignItems="center"
      >
        {/* <Box display="flex" alignItems="center">
          <span className="text bookings">Bookings</span>
          <Avatar variant="label" sx={{ ml: 1 }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              data?.data?.totalBookings || 0
            )}
          </Avatar>
        </Box>
        <Box display="flex" alignItems="center" ml={4.5}>
          <span className="text earnings">Earnings</span>
          <Avatar variant="label" sx={{ ml: 1 }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              `₹${data?.data?.totalEnergyConsumed?.toFixed(0) || 0}`
            )}
          </Avatar>
        </Box> */}
      </Box>
      <Box
        sx={{
          minWidth: 500,
          height: 260,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexGrow: 1,
        }}
      >
        {isLoading ? (
          <CircularProgress />
        ) : (
          <Line
            data={(canvas) => {
              let labels = (
                chartData?.bookings?.constructor === Array
                  ? chartData.bookings
                  : []
              ).map((el: any) => el.x.split(",")[0]);
              return {
                labels,
                datasets: [
                  {
                    label: "Bookings",
                    data: (chartData?.bookings?.constructor === Array
                      ? chartData.bookings
                      : []
                    ).map((el: any) => el.y),
                    pointBackgroundColor: theme.customColors.blueSecondary,
                    borderColor: theme.customColors.blueSecondary,
                    yAxisID: "yAxis",
                  },
                  {
                    label: "Consumption",
                    data: (chartData?.earnings?.constructor === Array
                      ? chartData.earnings
                      : []
                    ).map((el: any) => el.y),
                    pointBackgroundColor: theme.customColors.greenSecondary,
                    borderColor: theme.customColors.greenSecondary,
                    yAxisID: "yAxis2",
                  },
                ],
              };
            }}
            options={{
              datasets: {
                line: {
                  tension: 0.4,
                  borderWidth: 2,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  pointHoverBackgroundColor: "#fff",
                  pointHoverBorderWidth: 3,
                },
              },
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  usePointStyle: true,
                  // displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                },
                yAxis: {
                  title: {
                    display: true,
                    text: "Bookings",
                    padding: {
                      top: 0,
                      bottom: 15,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  min: 0,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
                yAxis2: {
                  position: "right",
                  title: {
                    display: true,
                    text: "Consumption",
                    padding: {
                      top: 0,
                      bottom: 15,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                    // callback: (label, index, lables) => '₹' + label
                  },
                  min: 0,
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
              },
            }}
          />
        )}
      </Box>
    </Paper>
  );
};

export default BookingsEarnings;
