import { useEffect, useState } from "react";
import {
  Box,
  Paper,
  Typography,
  useTheme,
  CircularProgress,
} from "@mui/material";
import { alpha } from "@mui/system";
import { Line } from "react-chartjs-2";
import { getDarkModePreference, GlobalState, snackbar } from "../../../utils";
import { useSelector } from "react-redux";
import RangePicker from "components/RangePicker";
import { format, sub } from "date-fns";
import { authorizedFetch } from "utils";
import { useQuery } from "react-query";

const Insights = ({ vendors }: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const theme = useTheme();
  const filters = ["Energy", "Bookings", "Earnings", "Users"];

  // const [vendorList, setVendorList] = useState<any>([
  //   { id: "all", label: "All Vendors" },
  // ]);

  const [vendorsChartData, setVendorsChartData] = useState<any>(null);
  //const [selectedVendor, setSelectedVendor] = useState(vendorList[0]);
  const statsFilter = filters[0];
  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const url = `https://bolt.dev.revos.in/company/zones/stats?dateFrom=${dateFrom}&dateTo==${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getzonedata", dateFrom, dateTo],
    () => authorizedFetch(url),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  console.log("zonedata is:", data);
  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let chartData: any = {
        bookings: [],
        earnings: [],
        energy: [],
        users: [],
      };
      // eslint-disable-next-line
      data?.data?.stats?.map((el: any) => {
        let date = format(new Date(el.date), "MMM d, yyyy");
        chartData.bookings.push({ x: date, y: el.totalBookings });
        chartData.earnings.push({ x: date, y: el.totalEarnings });
        chartData.energy.push({ x: date, y: el.totalEnergyConsumed });
        chartData.users.push({ x: date, y: el.totalUsers });
      });

      setVendorsChartData(chartData);
    }
  }, [data]);

  return (
    <Paper
      sx={{
        height: 490,
        p: { xs: 2, md: 3 },
        gridColumn: { lg: "span 4" },
        display: "flex",
        flexDirection: "column",
        width: 900,
      }}
    >
      <Box
        mb={4}
        display="flex"
        flexDirection={{ xs: "column", sm: "row" }}
        justifyContent="space-between"
        alignItems={{ xs: "start", sm: "center" }}
      >
        <Typography
          variant="h6"
          mr={1}
          mt={{ xs: 0.4, sm: 0 }}
          mb={{ xs: 1, sm: 0 }}
        >
          Zone TimeRange Stats
        </Typography>
        <Box
          width={{ xs: 1, sm: "auto" }}
          display="grid"
          alignItems="center"
          justifyItems={{ xs: "center", sm: "end" }}
          gridTemplateColumns={{ xs: "auto", sm: "repeat(3, auto)" }}
          gap={1.5}
        >
          <Box
            gridColumn={{ xs: "span 2", sm: "span 1" }}
            gridRow={{ xs: 1, sm: "unset" }}
          >
            <RangePicker range={range} setRange={setRange} />
          </Box>
        </Box>
      </Box>
      <Box
        flexGrow={1}
        minHeight={0}
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        {isLoading ? (
          <CircularProgress />
        ) : (
          <Line
            data={(canvas) => {
              let color = "#538ADC";
              let labels =
                statsFilter === "Bookings"
                  ? vendorsChartData?.bookings?.map(
                      (el: any) => el.x.split(",")[0]
                    ) || []
                  : statsFilter === "Earnings"
                  ? vendorsChartData?.earnings?.map(
                      (el: any) => el.x.split(",")[0]
                    ) || []
                  : statsFilter === "Energy"
                  ? vendorsChartData?.energy?.map(
                      (el: any) => el.x.split(",")[0]
                    ) || []
                  : statsFilter === "Users"
                  ? vendorsChartData?.users?.map(
                      (el: any) => el.x.split(",")[0]
                    ) || []
                  : [];

              return {
                labels,
                datasets: [
                  {
                    fill: true,
                    data:
                      statsFilter === "Bookings"
                        ? vendorsChartData?.bookings?.map((el: any) => el.y) ||
                          []
                        : statsFilter === "Earnings"
                        ? vendorsChartData?.earnings?.map((el: any) => el.y) ||
                          []
                        : statsFilter === "Energy"
                        ? vendorsChartData?.energy?.map((el: any) => el.y) || []
                        : statsFilter === "Users"
                        ? vendorsChartData?.users?.map((el: any) => el.y) || []
                        : [],
                    borderColor: color,
                    borderWidth: 2,
                    backgroundColor: alpha(
                      theme.customColors.blueSecondary,
                      isDarkMode ? 0.1 : 0.2
                    ),
                    tension: 0.4,
                    pointRadius: 2,
                    pointHoverRadius: 4,
                    pointHoverBackgroundColor: "#fff",
                    pointHoverBorderWidth: 3,
                  },
                ],
              };
            }}
            options={{
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                },
                yAxis: {
                  title: {
                    display: true,
                    text:
                      statsFilter === "Bookings"
                        ? "Bookings"
                        : statsFilter === "Earnings"
                        ? "Earnings (₹)"
                        : statsFilter === "Energy"
                        ? "Energy (kWh)"
                        : "",
                    padding: {
                      top: 0,
                      bottom: 8,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  suggestedMin: 0,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
              },
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
            }}
          />
        )}
      </Box>
    </Paper>
  );
};

export default Insights;
