import {
  EditOutlined,
  HighlightOff,
  PersonAddOutlined,
  FlagOutlined,
} from "@mui/icons-material";
import {
  Box,
  Tabs,
  Tab,
  IconButton,
  Typography,
  DialogContent,
  TextField,
} from "@mui/material";
import Map from "components/Map";
import { useState } from "react";
// import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import {
  drawer,
  getDarkModePreference,
  GlobalState,
  getPermissions,
} from "utils";
import EditChargers from "./EditChargers";
import ChargerHistory from "./ChargerHistory";

interface Props {
  charger: any;
  vendors: any;
  refetchStats: () => void;
  refetchChargers: () => void;
  openTab: number;
}

const DrawerContent: React.FC<Props> = ({
  charger,
  refetchStats,
  refetchChargers,
  openTab,
}) => {
  console.log(charger);
  const { canWrite } = getPermissions("charger:chargers");
  const [tab, setTab] = useState(openTab);
  const [editDialog, setEditDialog] = useState({
    open: false,
    count: 0,
  });

  const drawerState = useSelector((state: GlobalState) => state.global.drawer);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <IconButton />
          </Box>

          <Box display="flex">
            {canWrite && (
              <>
                <IconButton
                  sx={{ mr: 1 }}
                  children={<FlagOutlined />}
                  color="inherit"
                  size="small"
                />
                <IconButton
                  sx={{ mr: 1 }}
                  children={<PersonAddOutlined />}
                  color="inherit"
                  size="small"
                />
              </>
            )}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box pt={2} pr={2} pl={2}>
            <Tabs
              className="dense"
              value={tab}
              onChange={(e: any, tab: any) => {
                console.log(tab, "charger-drawer");
                setTab(tab);
              }}
              variant="scrollable"
            >
              <Tab label="Basic Details" />
              <Tab label="Information" />
              <Tab label="Bookings" />

              <Tab label="Map View" />
              <Tab label="Logs" />
            </Tabs>
          </Box>
          {tab === 0 ? (
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme: any) =>
                        theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& .label": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                        py: 1.125,
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 2.75,
                  },
                },
              }}
            >
              <table className="table">
                <tbody></tbody>
              </table>
              <Box
                style={
                  {
                    // display: "flex",
                    // flexDirection: "column",
                    // height: 500,
                    // width: "100%",
                    // position: "relative",
                    // alignItems: "center",
                    // borderColor:'black',
                    // margin: 3,
                    // border: 1,
                  }
                }
              >
                <DialogContent sx={{ pb: "16px !important" }}>
                  <table className="table">
                    <tbody>
                      <tr className="header">
                        <td colSpan={1}>
                          <span className="label">Zone Info</span>
                          {canWrite && (
                            <IconButton
                              sx={{ ml: 2.5 }}
                              children={<EditOutlined />}
                              color="primary"
                              size="small"
                              onClick={() => {
                                setEditDialog({
                                  open: true,
                                  count: 0,
                                });
                              }}
                            />
                          )}
                        </td>
                      </tr>
                      {/* {zoneDetails.basicInfo} */}
                    </tbody>
                  </table>
                  <Box
                    sx={{
                      maxWidth: { xs: 280, sm: 560 },
                      mx: "auto",
                      py: 3,
                      m: 7,
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                      gap: 3,
                    }}
                  >
                    <Box gridColumn={{ sm: "span 2" }}>
                      <Typography className="label">Zone Name</Typography>
                      <TextField
                        onChange={(e) => e.target.value}
                        value={charger.name}
                        fullWidth
                        id="outlined-required"
                        size="small"
                        placeholder="Name"
                        // defaultValue="Area 1"
                      />
                    </Box>

                    <Box>
                      <Typography className="label">Pincode</Typography>
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[0]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        //  onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>
                    <Box alignSelf="end">
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[1]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        // onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>

                    <Box>
                      {/* <Typography className="label">Pincode</Typography> */}
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[2]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        //  onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>
                    <Box alignSelf="end">
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[3]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        // onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>

                    <Box>
                      {/* <Typography className="label">Pincode</Typography> */}
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[4]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        //  onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>
                    <Box alignSelf="end">
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[5]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        // onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>

                    <Box>
                      {/* <Typography className="label">Pincode</Typography> */}
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[6]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        //  onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>
                    <Box alignSelf="end">
                      <TextField
                        placeholder="Pincode"
                        size="small"
                        value={charger.postalCodes[7]}
                        required
                        fullWidth
                        onChange={(e) => e.target.value}
                        // onChange={(e) => handleChange("name", e.target.value)}
                      />
                    </Box>
                  </Box>

                  <Box
                    sx={{
                      maxWidth: { xs: 280, sm: 560 },
                      mx: "auto",
                      py: 2,
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                      gap: 3,
                    }}
                  ></Box>
                </DialogContent>
              </Box>
            </Box>
          ) : tab === 1 ? (
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme: any) =>
                        theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& .label": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                        py: 1.125,
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 2.75,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Station Info</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 0,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>

                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Owner Info</span>
                      {/* {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 0,
                            });
                          }}
                        />
                      )} */}
                    </td>
                  </tr>

                  <tr className="header">
                    <td colSpan={2}>
                      <span className="label">Availability</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 1,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>

                  <tr className="header" style={{ marginTop: "20px" }}>
                    <td
                      style={{
                        height: "50px",
                        display: "flex",
                        alignItems: "center",
                        marginTop: "10px",
                      }}
                      colSpan={2}
                    >
                      <span className="label">Specifications</span>
                      {canWrite && (
                        <IconButton
                          sx={{ ml: 1.5 }}
                          children={<EditOutlined />}
                          color="primary"
                          size="small"
                          onClick={() => {
                            setEditDialog({
                              open: true,
                              count: 2,
                            });
                          }}
                        />
                      )}
                    </td>
                  </tr>
                </tbody>
              </table>
            </Box>
          ) : tab === 2 ? (
            <Box py={3} px={2.5}></Box>
          ) : tab === 3 ? (
            <Box p={2.5} height={436}>
              <Map
                loading={false}
                type="charger"
                borderRadius={1}
                location={charger?.station?.location}
              />
            </Box>
          ) : (
            <ChargerHistory data={charger} tab={tab} open={drawerState.open} />
          )}
        </Box>
      </Box>

      <EditChargers
        open={editDialog.open}
        closeDrawer={() => drawer.close()}
        handleClose={() => {
          setEditDialog({ open: false, count: 0 });
        }}
        data={charger}
        count={editDialog.count}
        refetchStats={refetchStats}
        refetchChargers={refetchChargers}
      />
    </>
  );
};

// const LineChart: React.FC<{ isBlue?: boolean; data: any[] }> = ({
//   isBlue,
//   data,
// }) => {
//   const isDarkMode = useSelector((state: GlobalState) =>
//     getDarkModePreference(state)
//   );

//   return (
//     <Box
//       sx={{
//         flexGrow: 1,
//         position: "relative",
//         height: 70,
//         width: 1,
//         mb: "3px",
//       }}
//     >
//       <Line
//         height={10}
//         style={{ marginTop: 10 }}
//         data={(canvas) => {
//           const ctx = canvas.getContext("2d");
//           const g = ctx?.createLinearGradient(0, 0, 0, 60);

//           g?.addColorStop(
//             0,
//             isBlue ? "rgba(87, 184, 255, 0.7)" : "rgba(41, 203, 151, 0.6)"
//           );
//           g?.addColorStop(
//             0.5,
//             isBlue ? "rgba(87, 184, 255, 0.4)" : "rgba(41, 203, 151, 0.2)"
//           );
//           g?.addColorStop(
//             1,
//             isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
//           );

//           let color = isBlue ? "rgb(87, 184, 255)" : "rgb(41, 203, 151)";

//           return {
//             // labels: data?.map(el => el.t),
//             datasets: [
//               {
//                 fill: true,
//                 data: data,
//                 borderColor: color,
//                 backgroundColor: g,
//                 tension: 0.4,
//                 pointRadius: 0,
//                 pointHoverRadius: 4,
//                 pointHoverBackgroundColor: "#fff",
//                 pointHoverBorderColor: color,
//                 pointHoverBorderWidth: 3,
//               },
//             ],
//           };
//         }}
//         options={{
//           scales: {
//             xAxis: {
//               display: false,
//               // type: "linear",
//               // type: 'time'
//             },
//             yAxis: {
//               display: false,
//             },
//           },
//           responsive: true,
//           maintainAspectRatio: false,
//           plugins: {
//             legend: {
//               display: false,
//             },
//             tooltip: {
//               caretSize: 0,
//               mode: "index",
//               intersect: false,
//               yAlign: "center",
//               displayColors: false,
//               caretPadding: 16,
//               titleFont: {
//                 weight: "400",
//               },
//               bodyFont: {
//                 weight: "500",
//               },
//             },
//           },
//           layout: {
//             padding: {
//               bottom: 20,
//             },
//           },
//           interaction: {
//             mode: "index",
//             intersect: false,
//           },
//         }}
//       />
//     </Box>
//   );
// };

export default DrawerContent;
