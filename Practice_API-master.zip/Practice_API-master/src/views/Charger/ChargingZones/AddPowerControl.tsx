import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  TextField,
  Grid,
  Slider,
  Typography,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import MuiInput from "@mui/material/Input";
// import InputAdornment from "@mui/material";
import { useState, useEffect } from "react";
import { authorizedFetch, setLoader, snackbar } from "utils";
import { useMutation } from "react-query";
import React from "react";

interface Props {
  open: boolean;
  handleClose: () => void;
  refetchChargers: () => void;
  refetchStats: () => void;
}

const Input = styled(MuiInput)`
  width: 32px;
`;

const AddPower: React.FC<Props> = ({ open, handleClose }) => {
  const [basicInput, setBasicInput] = useState({
    name: "",
    powerOutput: 0,
    autoCutOff: 0,
  });

  const {
    name,
    // powerOutput,autoCutOff
  } = basicInput;

  const [value, setValue] = React.useState<
    number | string | Array<number | string>
  >(16);
  const [timerValue, setTimerValue] = React.useState<
    number | string | Array<number | string>
  >(255);

  const handleSliderChange = (event: Event, newValue: number | number[]) => {
    setValue(newValue);
  };

  const handleTimerChange = (event: Event, newValue: number | number[]) => {
    setTimerValue(newValue);
  };

  // const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setTimerValue(event.target.value === "" ? "" : Number(event.target.value));
  // };

  // const handleTimeSlider = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setTimerValue(event.target.value === "" ? "" : Number(event.target.value));
  // };

  const handleBlur = () => {
    if (value < 0) {
      setValue(0);
    } else if (value > 16) {
      setValue(16);
    }
  };

  const handleTimer = () => {
    if (value < 0) {
      setTimerValue(0);
    } else if (value > 255) {
      setTimerValue(255);
    }
  };

  const url = `https://bolt.dev.revos.in/company/powerOutputControl/add`;

  const addPowerControl = useMutation(
    `addPowerControl`,
    () => {
      console.log("test PowerControl data ");

      return authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          name: basicInput.name,
          powerOutput: basicInput.powerOutput,
          autoCutOff: basicInput.autoCutOff,
        },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("PowerControl Added");
      },
      onError: () => {
        snackbar.error("Error Adding PowerControl");
      },
    }
  );

  useEffect(
    () => {
      if (!open) {
        setBasicInput({
          name: "",
          powerOutput: Number(value),
          autoCutOff: Number(timerValue),
        });
      }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [open]
  );

  const onSave = () => {
    addPowerControl.mutate();
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 650,
          maxHeight: 450,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Power Output Control
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 2,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        >
          <Box gridColumn={{ sm: "span 2" }}>
            <Typography className="label"> Name</Typography>
            <TextField
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, name: e.target.value });
              }}
              value={name}
              fullWidth
              size="small"
              placeholder="Name"
            />
          </Box>

          <Box sx={{ width: 250 }}>
            <Typography className="label"> Current (Amp)</Typography>
            <Grid container spacing={2} alignItems="center">
              <Grid item></Grid>
              <Grid item xs>
                <Slider
                  min={0}
                  max={16}
                  value={typeof value === "number" ? value : 0}
                  onChange={handleSliderChange}
                />
              </Grid>
              <Grid item>
                <Input
                  value={value}
                  size="small"
                  // onChange={handleInputChange}
                  onBlur={handleBlur}
                  onChange={(e: any) => {
                    setBasicInput({
                      ...basicInput,
                      powerOutput: e.target.value,
                    });
                  }}
                />
              </Grid>
            </Grid>
          </Box>

          <Box sx={{ width: 250 }}>
            <Typography className="label"> Timer</Typography>
            <Grid container spacing={2} alignItems="center">
              <Grid item></Grid>
              <Grid item xs>
                <Slider
                  min={0}
                  max={255}
                  value={typeof timerValue === "number" ? timerValue : 0}
                  onChange={handleTimerChange}
                  aria-labelledby="input-slider"
                />
              </Grid>
              <Grid item>
                <Input
                  value={timerValue}
                  size="small"
                  // onChange={handleTimeSlider}
                  onChange={(e: any) => {
                    setBasicInput({
                      ...basicInput,
                      autoCutOff: e.target.timerValue,
                    });
                  }}
                  onBlur={handleTimer}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          color="primary"
          onClick={() => handleClose()}
        >
          Cancel
        </Button>
        <Button variant="contained" color="primary" onClick={onSave}>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddPower;
