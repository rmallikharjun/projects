import { InfoOutlined } from "@mui/icons-material";
import {
  Box,
  Hidden,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Tooltip,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { authorizedFetch, drawer, getPermissions } from "utils";
import DrawerContent from "./DrawerContent";
import moment from "moment";
import { useQuery } from "react-query";
import Search from "../../../components/Search";

const List = ({
  setSearch,
  masterView,
  refetchStats,
  setPage,
  setPageSize,
  chargersLoading,
  refetchChargers,
  page,
  pageSize,
}: any) => {
  const [tab, setTab] = useState(0);
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md") as any);
  const { canWrite } = getPermissions("charger:chargers");
  const [selectedRows, setSelectedRows] = useState<any>([]);

  const url = `https://bolt.dev.revos.in/company/zones`;

  const { data: ZonesData } = useQuery(["getVendors", masterView], () =>
    authorizedFetch(url, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    console.log("Zones data is => ", ZonesData);
  }, [ZonesData]);

  return (
    <>
      <Paper
        sx={{
          width: 1,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            p: { xs: 2, md: 3 },
            pb: 2.75,
            display: { xs: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box display="flex">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab
                label="Charging Zones"
                className="hasCount"
                // sx={{
                //   "&:after": {
                //     content: `"${listData?.data?.count || "-"}"`,
                //   },
                // }}
              />
              {masterView === "testTVS" ? (
                ""
              ) : (
                <Tab
                  label="PowerControl"
                  className="hasCount"
                  // sx={{
                  //   "&:after": {
                  //     content: `"${listData?.data?.count || "-"}"`,
                  //   },
                  // }}
                />
              )}
            </Tabs>
            {/* <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden> */}
          </Box>
        </Box>
        <Table
          px={isMdUp ? 3 : 2}
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={chargersLoading}
          setSelectedRows={setSelectedRows}
          selectedRows={selectedRows}
          selectable={canWrite}
          rows={ZonesData?.data || []}
          rowCount={ZonesData?.data}
          columns={[
            {
              key: "Name",
              label: " Name",
              Render: (row) => <Box>{row.name}</Box>,
            },
            {
              key: "numberOfChargers",
              label: "Number of Chargers",
              Render: (row) => (
                <Box sx={{ py: 2 }}> {row.chargers.length || "-"}</Box>
              ),
            },
            {
              key: "pincode",
              label: " Pincode",
              Render: (row) => <Box sx={{ py: 2 }}>{row.postalCodes[0]}</Box>,
            },
            {
              key: "cousumption",
              label: " Maximum Cosumption",
              Render: (row) => (
                <Box sx={{ py: 2 }}>
                  {row.maxPowerConsumption + " kWh" || "-"}
                </Box>
              ),
            },
            {
              key: "createdAt",
              label: "Created At",
              Render: (row) => (
                <Box>{moment(row.createdAt).format("ddd, MMM DD, YYYY")}</Box>
              ),
            },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme: any) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() =>
                        drawer.open(
                          <DrawerContent
                            charger={row}
                            vendors={ZonesData?.data || []}
                            refetchStats={refetchStats}
                            refetchChargers={refetchChargers}
                            openTab={0}
                          />
                        )
                      }
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default List;
