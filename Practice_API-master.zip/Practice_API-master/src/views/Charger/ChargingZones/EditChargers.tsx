import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  TextField,
  // Tooltip,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { snackbar, setLoader, authorizedFetch } from "utils";
import { useMutation } from "react-query";

import React from "react";

interface Props {
  open: boolean;
  handleClose: () => void;
  data: any;
  count: number;
  refetchStats: () => void;
  closeDrawer: () => void;
  refetchChargers: () => void;
}

type inputData = {
  zoneName: string;
  pincode: number;
  pincodeTwo: number;
  pincodeThree: number;
  pincodeFour: number;
  pincodeFive: number;
  pincodeSix: number;
  pincodeSeven: number;
  pincodeEight: number;
};

const AddDialog: React.FC<Props> = ({ open, handleClose, data }) => {
  const [basicInput, setBasicInput] = useState<inputData>({
    zoneName: data.name,
    pincode: data.postalCodes[0],
    pincodeTwo: data.postalCodes[1],
    pincodeThree: data.postalCodes[2],
    pincodeFour: data.postalCodes[3],
    pincodeFive: data.postalCodes[4],
    pincodeSix: data.postalCodes[5],
    pincodeSeven: data.postalCodes[6],
    pincodeEight: data.postalCodes[7],
  });

  console.log("Output is", basicInput);

  const {
    zoneName,
    pincode,
    pincodeTwo,
    pincodeThree,
    pincodeFour,
    pincodeFive,
    pincodeSix,
    pincodeSeven,
    pincodeEight,
  } = basicInput;

  const url = `https://bolt.dev.revos.in/company/zones/update`;

  const updateZone = useMutation(
    `updateZone`,
    () => {
      console.log("test zone data ");

      return authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          zoneId: "626134ecdb4401410d6f7277",
          name: basicInput.zoneName,
          postalCodes: [
            basicInput.pincode,
            basicInput.pincodeTwo,
            basicInput.pincodeThree,
            basicInput.pincodeFour,
            basicInput.pincodeFive,
            basicInput.pincodeSix,
            basicInput.pincodeSeven,
            basicInput.pincodeEight,
          ],
        },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("Zone updated");
      },
      onError: () => {
        snackbar.error("Error updating Zone");
      },
    }
  );

  const onSave = () => {
    updateZone.mutate();
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 650,
          maxHeight: 450,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Edit Zones
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 2,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        >
          <Box gridColumn={{ sm: "span 2" }}>
            <Typography className="label">Zone Name</Typography>
            <TextField
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, zoneName: e.target.value });
              }}
              value={zoneName}
              fullWidth
              size="small"
              placeholder="Zone name"
            />
          </Box>

          <Box>
            <Typography className="label">Pincode</Typography>
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincode}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincode: e.target.value });
              }}
            />
          </Box>
          <Box alignSelf="end">
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeTwo}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeTwo: e.target.value });
              }}
            />
          </Box>

          <Box>
            {/* <Typography className="label">Pincode</Typography> */}
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeThree}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeThree: e.target.value });
              }}
            />
          </Box>
          <Box alignSelf="end">
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeFour}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeFour: e.target.value });
              }}
            />
          </Box>

          <Box>
            {/* <Typography className="label">Pincode</Typography> */}
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeFive}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeFive: e.target.value });
              }}
            />
          </Box>
          <Box alignSelf="end">
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeSix}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeSix: e.target.value });
              }}
            />
          </Box>

          <Box>
            {/* <Typography className="label">Pincode</Typography> */}
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeSeven}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeSeven: e.target.value });
              }}
            />
          </Box>
          <Box alignSelf="end">
            <TextField
              placeholder="Pincode"
              size="small"
              required
              value={pincodeEight}
              fullWidth
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, pincodeEight: e.target.value });
              }}
            />
          </Box>
        </Box>

        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 2,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        ></Box>
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          color="primary"
          onClick={() => handleClose()}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onSave}
          // disabled={step === steps.length - 1 && disabled}
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddDialog;
