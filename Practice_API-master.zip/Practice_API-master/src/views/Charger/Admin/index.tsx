import {
  Add,
  AddBusinessOutlined,
  Edit,
  PersonAddAlt,
} from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  ListItemIcon,
  Menu,
  MenuItem,
  Paper,
  Tab,
  Tabs,
  Tooltip,
} from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { authorizedFetch, drawer, getPermissions } from "utils";
import { AUTH_URL } from "utils/constants";
import Search from "components/Search";
import InviteDialog from "./components/InviteDialog";
import EditPermsDialog from "./components/EditPermsDialog";
import CompanyInviteDialog from "./components/CompanyInviteDialog";

const Admin = () => {
  const { isSuperAdmin } = getPermissions("charger:admin");
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [tab, setTab] = useState(0);
  const [inviteDialog, setInviteDialog] = useState(false);
  const [companyInviteDialog, setCompanyInviteDialog] = useState(false);
  const [editDialog, setEditDialog] = useState({ open: false, user: {} });

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");

  const employeesUrl = `${AUTH_URL}/company/users?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;

  const {
    isLoading: employeesLoading,
    data: employeesData,
    remove,
    refetch,
  } = useQuery(["getEmployees", page, pageSize, search], () =>
    authorizedFetch(employeesUrl)
  );

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <>
      <InviteDialog
        open={inviteDialog}
        handleClose={() => setInviteDialog(false)}
      />
      <CompanyInviteDialog
        open={companyInviteDialog}
        handleClose={() => setCompanyInviteDialog(false)}
      />
      <EditPermsDialog
        open={editDialog.open}
        handleClose={() => setEditDialog((prev) => ({ ...prev, open: false }))}
        user={editDialog.user}
        refresh={() => {
          remove();
          refetch();
        }}
      />
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab
                label="Members"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${employeesData?.data?.count || "-"}"`,
                  },
                }}
              />
            </Tabs>
          </Box>
          <Box display="flex" alignItems="center">
            <Search
              handleSearch={(value) => {
                setPage(1);
                setSearch(value);
              }}
              persist
              enableClear
            />
            <Button
              sx={{ ml: 1, height: 40, textTransform: "none" }}
              startIcon={<Add />}
              color="primary"
              variant="contained"
              onClick={(e) =>
                isSuperAdmin
                  ? setAnchorEl(e.currentTarget)
                  : setInviteDialog(true)
              }
            >
              Invite
            </Button>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={() => setAnchorEl(null)}
              anchorOrigin={{
                vertical: "top",
                horizontal: "center",
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "center",
              }}
            >
              <MenuItem
                onClick={() => {
                  setInviteDialog(true);
                  setAnchorEl(null);
                }}
              >
                <ListItemIcon
                  children={<PersonAddAlt sx={{ color: "text.primary" }} />}
                />
                Member
              </MenuItem>
              <MenuItem
                onClick={() => {
                  setCompanyInviteDialog(true);
                  setAnchorEl(null);
                }}
              >
                <ListItemIcon
                  children={
                    <AddBusinessOutlined sx={{ color: "text.primary" }} />
                  }
                />
                Company
              </MenuItem>
            </Menu>
          </Box>
        </Box>
        <Table
          idKey="_id"
          serverSidePagination
          rowCount={employeesData?.data?.count || 0}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={employeesLoading}
          rows={employeesData?.data?.users || []}
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => {
                let { firstName, lastName } = row;
                return firstName || lastName
                  ? `${firstName || ""} ${lastName || ""}`
                  : "-";
              },
            },
            { key: "email", label: "Email" },
            { key: "phone", label: "Phone" },
            {
              key: "permissions",
              label: "Permissions",
              Render: (row) => {
                let { permissions } = row;
                let permission = permissions.includes("dashboard:*")
                  ? "Admin"
                  : permissions.includes("dashboard:*:*:READ")
                  ? "Read"
                  : permissions.includes("dashboard:*:*:WRITE")
                  ? "Write"
                  : "Scoped";
                return (
                  <Box display="flex" alignItems="center">
                    {permission}
                    <Tooltip title="Edit">
                      <IconButton
                        sx={{ ml: 1 }}
                        children={<Edit fontSize="small" />}
                        size="small"
                        onClick={() => setEditDialog({ open: true, user: row })}
                      />
                    </Tooltip>
                  </Box>
                );
              },
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default Admin;
