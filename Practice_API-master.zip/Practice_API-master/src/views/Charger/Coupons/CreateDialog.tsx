import { EditOutlined, HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  InputAdornment,
  MenuItem,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";

import TableComponent from "components/Table";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import DesktopDatePicker from "@mui/lab/DesktopDatePicker";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import { useEffect, useState } from "react";
import moment from "moment";
import { useMutation } from "react-query";
import { useQuery as useFetch } from "react-query";
import { authorizedFetch, setLoader, snackbar } from "utils";
import { AUTH_URL } from "utils/constants";
import Search from "components/Search";

interface Props {
  open: boolean;
  handleClose: () => void;
  refetchCoupons: any;
}

type inputData = {
  couponName: string;
  discountPercentage: number;
  discountAmount: number;
  description: string;
};

const CreateDialog: React.FC<Props> = ({
  open,
  handleClose,
  refetchCoupons,
}) => {
  const [step, setStep] = useState<number>(0);
  const steps = ["Basic Details", "User", "Confirmation"];

  const [input, setInput] = useState<inputData>({
    couponName: "",
    discountPercentage: 0,
    discountAmount: 0,
    description: "",
  });

  const { couponName, discountPercentage, discountAmount, description } = input;

  let userGroups = [];
  for (let i = 0; i < 8; i++) {
    userGroups.push({
      id: i,
      name: "Bolt user_Test1234",
      email: "tester@polarity.com",
      phone: "9876543210",
      type: i % 3 === 0 ? "App User" : "Employee",
    });
  }

  // const [offerType, setOfferType] = useState("");
  const [validFrom, setValidFrom] = useState<Date | null>(new Date());
  const [validTill, setValidTill] = useState<Date | null>(new Date());
  const [selectedUser, setSelectedUser] = useState<any>({
    id: "",
    name: "",
    email: "",
    phone: "",
  });

  const handleChangeFrom = (newValue: Date | null) => {
    setValidFrom(newValue);
  };
  const handleChangeTill = (newValue: Date | null) => {
    setValidTill(newValue);
  };

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [search, setSearch] = useState("");

  const disabled = [
    couponName,
    discountPercentage,
    discountAmount,
    validFrom,
    validTill,
    description,
  ].includes("");

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![
          couponName,
          discountPercentage,
          discountAmount,
          validFrom,
          validTill,
          description,
        ].includes("");
      case 1:
        return ![
          selectedUser.id,
          selectedUser.email,
          selectedUser.phone,
        ].includes("");

      default:
        break;
    }
  }

  const appUsersUrl = `${AUTH_URL}/company/appusers?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;

  const { isLoading: appUsersLoading, data: appUsersData } = useFetch(
    ["getAppUsers", page, pageSize, search],
    () => authorizedFetch(appUsersUrl)
  );

  const url = `https://api.revos.in/v2/coupons/create/?token=1234`;

  const mutation = useMutation(
    `addCoupon`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          name: couponName,
          description: description,
          discountPercent: Number(discountPercentage),
          discountAmount: Number(discountAmount),
          availedOn: null,
          validFrom: moment(validFrom).format(),
          validTill: moment(validTill).format(),
          user: {
            id: selectedUser.id,
          },
          apps: [
            {
              id: "60cc34ef290b110007805142",
            },
          ],
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Coupon created`);
        refetchCoupons();
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error creating coupon`);
      },
    }
  );

  function onSave() {
    setLoader(true);
    mutation.mutate();
    refetchCoupons();
    handleClose();
  }

  function handleChange(key: string, value: string) {
    setInput((prevInput: inputData) => ({ ...prevInput, [key]: value }));
  }

  function handleNext() {
    if (step === steps.length - 1) {
      onSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  useEffect(() => {
    if (!open) {
      setStep(0);
      setValidFrom(new Date());
      setValidTill(new Date());
      setInput({
        couponName: "",
        discountPercentage: 0,
        discountAmount: 0,
        description: "",
      });
      setSelectedUser({ id: "", name: "" });
      setSearch("");
    }
  }, [open]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Create New Coupon
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        {/* <Typography mb={5} fontSize={14} color="text.secondary">
          All fields marked with * are required
        </Typography> */}
        <Stepper
          sx={{ mb: 4, mt: 2, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {step === 0 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",

              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 4,
            }}
          >
            <Box sx={{ gridColumn: "span 2" }}>
              <Typography className="label">Coupon Name</Typography>
              <TextField
                fullWidth
                value={couponName}
                size="small"
                placeholder="Name"
                onChange={(e) => {
                  handleChange("couponName", e.target.value);
                }}
              />
            </Box>
            <Box sx={{ gridColumn: "span 2" }}>
              <Typography className="label">Description</Typography>
              <TextField
                fullWidth
                value={description}
                size="small"
                placeholder="Description"
                onChange={(e) => {
                  handleChange("description", e.target.value);
                }}
              />
            </Box>
            {/* <Typography className="header">Discount</Typography> */}
            <Box>
              <Typography className="label">Discount Type</Typography>
              <Select
                // value={age}
                // onChange={handleChange}
                defaultValue="percentage"
                fullWidth
              >
                <MenuItem value="percentage">Percentage</MenuItem>
              </Select>
            </Box>
            <Box alignSelf="end">
              <TextField
                value={discountPercentage}
                type="number"
                size="small"
                placeholder="Value"
                fullWidth
                onChange={(e) => {
                  handleChange("discountPercentage", e.target.value);
                }}
              />
            </Box>
            <Box sx={{ gridColumn: "span 2" }}>
              <Typography className="label">Discount Amount</Typography>
              <TextField
                fullWidth
                value={discountAmount}
                type="number"
                size="small"
                placeholder="Amount"
                InputProps={{
                  startAdornment: (
                    <InputAdornment sx={{ marginLeft: 1 }} position="start">
                      ₹
                    </InputAdornment>
                  ),
                }}
                onChange={(e) => {
                  handleChange("discountAmount", e.target.value);
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Valid From</Typography>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  inputFormat="dd/MM/yyyy"
                  value={validFrom}
                  onChange={handleChangeFrom}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      sx={{
                        width: "100%",
                        "& .MuiIconButton-root": {
                          marginRight: 1,
                        },
                      }}
                    />
                  )}
                />
              </LocalizationProvider>
            </Box>
            <Box>
              <Typography className="label">Valid Till</Typography>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  inputFormat="dd/MM/yyyy"
                  value={validTill}
                  onChange={handleChangeTill}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      sx={{
                        width: "100%",
                        "& .MuiIconButton-root": {
                          marginRight: 1,
                        },
                      }}
                    />
                  )}
                />
              </LocalizationProvider>
            </Box>
            {/* <Box>
              <Typography className="label">Offer Type</Typography>
              <RadioGroup
                row
                sx={{ mb: 2.5, justifyContent: "space-between" }}
                value={offerType}
                onChange={(e) => setOfferType(e.target.value)}
              >
                <FormControlLabel
                  value="oneTime"
                  control={<Radio />}
                  label="One Time"
                />
                <FormControlLabel
                  value="forever"
                  control={<Radio />}
                  label="Forever"
                />
              </RadioGroup>
            </Box> */}
            {/* <Grow in={offerType === "oneTime"}>
              <Box>
                <Typography className="label">Validity</Typography>
                <RangePicker />
              </Box>
            </Grow> */}
          </Box>
        )}
        {step === 1 && (
          <Box>
            <Box
              display="flex"
              alignItems="center"
              justifyContent="space-between"
            >
              <Typography className="label">
                Select{selectedUser.id ? "ed" : ""} User
                {selectedUser.id ? ":" : ""}
              </Typography>
              <Box height="45px">
                <Search
                  handleSearch={(value) => {
                    setPage(1);
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Box>
            <Box
              width="100%"
              height="40px"
              border="1px #99999950 solid"
              borderRadius="5px"
              mb={3}
            >
              <Typography width="100%" height="100%" fontSize={12}>
                {selectedUser.id ? (
                  <Box
                    width="100%"
                    height="100%"
                    display="flex"
                    alignItems="center"
                    justifyContent="space-between"
                    pl={2}
                    pr={5}
                  >
                    <Box>
                      Name : <strong>{selectedUser.name}</strong>
                    </Box>
                    <Box>
                      Email : <strong>{selectedUser.email}</strong>
                    </Box>
                    <Box>
                      Phone : <strong>{selectedUser.phone}</strong>
                    </Box>
                  </Box>
                ) : (
                  <Box
                    height="100%"
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                  >
                    No User Selected
                  </Box>
                )}
              </Typography>
            </Box>

            <TableComponent
              idKey="_id"
              loading={appUsersLoading}
              serverSidePagination
              rowCount={appUsersData?.data?.count || 0}
              height={342}
              px={0}
              rowsPerPage={5}
              small
              rows={appUsersData?.data?.users || []}
              activePage={page}
              activePageSize={pageSize}
              onPageChange={(value) => setPage(value)}
              onPageSizeChange={(value) => setPageSize(value)}
              columns={[
                {
                  key: "name",
                  label: "Name",
                  Render: (row) => (
                    <Box>
                      {row.firstName ? row.firstName + " " + row.lastName : "-"}
                    </Box>
                  ),
                },
                { key: "email", label: "Email" },
                { key: "phone", label: "Phone Number" },

                {
                  key: "action",
                  label: "Action",
                  Render: (row) =>
                    selectedUser.id === row._id ? (
                      <Button
                        variant="action"
                        onClick={() => {
                          setSelectedUser({
                            id: "",
                            name: "",
                            email: "",
                            phone: "",
                          });
                        }}
                      >
                        Remove
                      </Button>
                    ) : (
                      <Button
                        variant="action"
                        onClick={() => {
                          setSelectedUser({
                            id: row._id,
                            name: row.firstName
                              ? row.firstName + " " + row.lastName
                              : "No username found",
                            email: row.email
                              ? row.email
                              : "No user email found",
                            phone: row.phone
                              ? row.phone
                              : "No user phone found",
                          });
                        }}
                      >
                        Select
                      </Button>
                    ),
                },
              ]}
            />
          </Box>
        )}
        {step === 2 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Basic Details", onEdit: () => setStep(0) },
                  { label: "Coupon Name", value: couponName },
                  { label: "Description", value: description },
                  { label: "Discount", value: discountPercentage },
                  { label: "Amount", value: discountAmount },
                  {
                    label: "Validit From",
                    value: moment(validFrom).format("ddd, MMM DD, YYYY"),
                  },
                  {
                    label: "Validit Till",
                    value: moment(validTill).format("ddd, MMM DD, YYYY"),
                  },
                  { header: "User", onEdit: () => setStep(1) },
                  { label: "Name", value: selectedUser.name },
                  { label: "Email", value: selectedUser.email },
                  { label: "Phone", value: selectedUser.phone },
                ].map(({ header, onEdit, label, value }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td className="bold">{label}</td>
                          <td>{value}</td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant={
            isComplete(step) || step === steps.length - 1
              ? "contained"
              : "outlined"
          }
          // color={
          //   isComplete(step) || step === steps.length - 1
          //     ? "primary"
          //     : "inherit"
          // }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateDialog;
