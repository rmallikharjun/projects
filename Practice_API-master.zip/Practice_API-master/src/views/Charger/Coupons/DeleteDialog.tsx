import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";

import { snackbar, setLoader, authorizedFetch } from "utils";

import { useMutation } from "react-query";

const DeleteVendor = ({ open, handleClose, data, refetchCoupons }: any) => {
  const url = `https://api.revos.in/v2/coupons/delete/?token=1234`;

  const mutation = useMutation(
    `deleteCoupon`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          id: data.id,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Coupon deleted`);
        refetchCoupons();
        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error deleting coupon`);
      },
    }
  );
  function confirm() {
    setLoader(true);
    mutation.mutate();
    refetchCoupons();
    handleClose();
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Coupon</DialogTitle>
      <DialogContent className="py-1">
        Are you sure you want delete coupon <b>{data?.name}</b>?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteVendor;
