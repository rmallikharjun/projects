import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { DeleteOutline, EditOutlined, HighlightOff } from "@mui/icons-material";
import { Box, IconButton, Avatar, Typography } from "@mui/material";
import {
  drawer,
  getDarkModePreference,
  GlobalState,
  getPermissions,
} from "utils";
import moment from "moment";
import DeleteDialog from "./DeleteDialog";

type Subscription = {
  id: string | number;
  name: string;
  [key: string]: any;
};

const DrawerContent: React.FC<{
  data: Subscription;
  refetchCoupons: any;
  setEditDialog: any;
}> = ({ data, refetchCoupons, setEditDialog }) => {
  // console.log(data);
  const { canWrite } = getPermissions("charger:chargers");
  const [deleteDialog, setDeleteDialog] = useState(false);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const [table, setTable] = useState([
    { header: "Basic Details" },
    { label: "Description", value: "" },
    { label: "Amount", value: "" },
    { label: "Discount", value: "" },
    { label: "Valid From", value: "" },
    { label: "Valid Till", value: "" },
    { header: "User" },
  ]);

  const [userInfo, setUserInfo] = useState([
    {
      name: "",
      email: "",
      phone: "",
    },
  ]);

  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  useEffect(() => {
    if (data) {
      setTable([
        { header: "Basic Details" },
        { label: "Description", value: `₹ ${data.description}` },
        { label: "Amount", value: `₹ ${data.discountAmount}` },
        { label: "Discount", value: `${data.discountPercent} %` },
        {
          label: "Valid From",
          value: moment(data.validFrom).format("ddd, MMM DD, YYYY"),
        },
        {
          label: "Valid Till",
          value: moment(data.validTill).format("ddd, MMM DD, YYYY"),
        },
        { header: "User" },
      ]);
    }
    setUserInfo([
      {
        name: data.user.firstName
          ? `${data.user.firstName} ${data.user.lastName}`
          : "-",
        email: data.user.email ? data.user.email : "-",

        phone: data.user.phone ? data.user.phone : "-",
      },
    ]);
  }, [data]);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {data.name}
          <Box display="grid" gridTemplateColumns="repeat(3, auto)" gap={1}>
            {/* <IconButton
              children={<PersonAddOutlined />}
              color="inherit"
              size="small"
            /> */}
            <IconButton
              sx={{ ml: 1.5 }}
              children={<EditOutlined />}
              onClick={() => {
                setEditDialog({ open: true, data: data });
              }}
              color="inherit"
              size="small"
            />
            {canWrite && (
              <IconButton
                children={<DeleteOutline />}
                color="inherit"
                size="small"
                onClick={() => setDeleteDialog(true)}
              />
            )}

            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              pt: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(({ header, label, value }, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                        </td>
                      ) : (
                        <>
                          {label && <td className="bold">{label}</td>}
                          {value && <td>{value}</td>}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <Box px={2} pt={9.5}>
              {userInfo.map((user, i) => (
                <Box
                  key={i}
                  sx={{
                    mb: 1.5,
                    p: "10px 20px",
                    display: "grid",
                    gridTemplateColumns: "auto 1fr auto",
                    gap: 2.5,
                    border: "1px solid",
                    borderColor: (theme) => theme.customColors.border,
                    borderRadius: "4px",
                  }}
                >
                  <Avatar sx={{ width: 50, height: 50 }} variant="rounded" />
                  {/* </Avatar> */}
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                    }}
                  >
                    <Typography
                      fontSize={14}
                      fontWeight={500}
                      color={isDarkMode ? "#fff" : "#000"}
                    >
                      {user.name}
                    </Typography>
                    <Typography fontSize={14} color="text.secondary">
                      {user.email}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      alignItems: "end",
                    }}
                  >
                    {/* <Avatar
                      variant="status"
                      className={user.utilized ? "" : "red"}
                    >
                      {user.utilized ? "Utilized" : "Not Utilized"}
                    </Avatar> */}
                    <Typography fontSize={14} color="text.secondary">
                      {user.phone}
                    </Typography>
                  </Box>
                </Box>
              ))}
            </Box>
          </Box>
        </Box>
      </Box>
      <DeleteDialog
        open={deleteDialog}
        handleClose={DeleteHandleClose}
        data={{ id: data.id, name: data.name }}
        refetchCoupons={refetchCoupons}
      />
    </>
  );
};

export default DrawerContent;
