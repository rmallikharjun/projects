import {
  Add,
  DeleteOutline,
  EditOutlined,
  InfoOutlined,
} from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Hidden,
} from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import moment from "moment";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { authorizedFetch, drawer, getPermissions } from "utils";
import CreateDialog from "./CreateDialog";
import DrawerContent from "./DrawerContent";
import DeleteDialog from "./DeleteDialog";
import EditDialog from "./EditDialog";
import Search from "../../../components/Search";

const Coupons = () => {
  const { canWrite } = getPermissions("charger:coupons");
  const [tab, setTab] = useState(0);
  const [tempRow, setTempRow] = useState([]);
  const [createDialog, setCreateDialog] = useState(false);
  const [editDialog, setEditDialog] = useState({
    open: false,
    data: {},
  });
  const [rows, setRows] = useState([]);
  const [deleteDialog, setDeleteDialog] = useState({
    open: false,
    data: {
      id: "",
      name: "",
    },
  });
  // const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  // const open = Boolean(anchorEl);
  // const handleClose = () => setAnchorEl(null);

  const url = `https://api.revos.in/v2/coupons`;
  const {
    isLoading,
    data,
    refetch: refetchCoupons,
  } = useQuery("getVendors", () => authorizedFetch(url));

  useEffect(() => {
    if (data && data?.data?.coupons?.constructor === Array) {
      setRows(data?.data?.coupons);
      setTempRow(data?.data?.coupons);
    }
  }, [data]);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  const handlefunc = (data: any) => {
    console.log(data, "data coming");
    if (data) {
      let searchCoupon = rows.filter((obj: any) =>
        obj.name.toLowerCase().includes(data.toLowerCase())
      );
      setTempRow(searchCoupon);
    } else setTempRow(rows);
  };

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
        {canWrite && (
          <Button
            sx={{ height: 40, textTransform: "none" }}
            startIcon={<Add />}
            color="primary"
            variant="contained"
            onClick={() => setCreateDialog(true)}
          >
            Create New
          </Button>
        )}
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${tempRow.length}"`,
                  },
                }}
              />
            </Tabs>
          </Box>
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search handleSearch={handlefunc} persist enableClear />
              </Box>
            </Hidden>
          </Box>
        </Box>
        <CreateDialog
          open={createDialog}
          handleClose={() => setCreateDialog(false)}
          refetchCoupons={refetchCoupons}
        />

        <Table
          loading={isLoading}
          idKey="id"
          columns={[
            {
              key: "name",
              label: "Coupon Name",
              Render: (row) => (
                <Box display="flex" alignItems="center">
                  <Button
                    size="small"
                    sx={{
                      ml: 0.5,
                      paddingLeft: 2,
                      color: (theme) => theme.customColors.black,
                    }}
                    onClick={() =>
                      drawer.open(
                        <DrawerContent
                          data={row}
                          refetchCoupons={refetchCoupons}
                          setEditDialog={setEditDialog}
                        />
                      )
                    }
                  >
                    {row.name}
                    {/* <InfoOutlined fontSize="small" /> */}
                  </Button>
                </Box>
              ),
            },

            {
              key: "discountPercent",
              label: "Discount",
              Render: (row) => <Box>{row.discountPercent}%</Box>,
            },
            {
              key: "discountAmount",
              label: "Amount",
              Render: (row) => <Box>₹{row.discountAmount}</Box>,
            },
            // { key: "userGroup", label: "User Group" },
            {
              key: "validFrom",
              label: "Valid From",
              format: (value) => moment(value).format("ddd, MMM DD, YYYY"),
            },
            {
              key: "validTill",
              label: "Valid Till",
              format: (value) => moment(value).format("ddd, MMM DD, YYYY"),
            },

            // {
            //   key: "status",
            //   label: "Status",
            //   Render: (row) => (
            //     <Avatar
            //       variant="status"
            //       className={row.status === "Active" ? "" : "red"}
            //     >
            //       {row.status}
            //     </Avatar>
            //   ),
            // },
            ...(canWrite
              ? [
                  {
                    key: "actions",
                    label: "Actions",
                    Render: (row: any) => {
                      return (
                        <Box display="flex">
                          <IconButton
                            size="small"
                            sx={{
                              ml: 0.5,
                              color: (theme) => theme.customColors.action,
                            }}
                            onClick={() =>
                              drawer.open(
                                <DrawerContent
                                  data={row}
                                  refetchCoupons={refetchCoupons}
                                  setEditDialog={setEditDialog}
                                />
                              )
                            }
                          >
                            <InfoOutlined fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            sx={{ color: (theme) => theme.customColors.grey }}
                            onClick={() => {
                              setEditDialog({ open: true, data: row });
                            }}
                          >
                            <EditOutlined fontSize="small" />
                          </IconButton>
                          <IconButton
                            size="small"
                            sx={{ color: (theme) => theme.customColors.grey }}
                            onClick={() => {
                              setDeleteDialog({
                                open: true,
                                data: {
                                  id: row.id,
                                  name: row.name,
                                },
                              });
                            }}
                          >
                            <DeleteOutline fontSize="small" />
                          </IconButton>
                        </Box>
                      );
                    },
                  },
                ]
              : []),
          ]}
          rows={tempRow || []}
          toolbar={() => (
            <>
              <Button startIcon={<DeleteOutline />}>Delete</Button>
            </>
          )}
        />
      </Paper>
      <EditDialog
        open={editDialog.open}
        handleClose={() => setEditDialog({ ...editDialog, open: false })}
        refetchCoupons={refetchCoupons}
        data={editDialog.data}
      />
      <DeleteDialog
        open={deleteDialog.open}
        handleClose={() => {
          setDeleteDialog({ ...deleteDialog, open: false });
        }}
        data={deleteDialog.data}
        refetchCoupons={refetchCoupons}
      />
    </>
  );
};

export default Coupons;
