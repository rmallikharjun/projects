import { Box } from "@mui/material";
import Earnings from "./Earnings";
import Summary from "./Summary";
import TodaysDue from "./TodaysDue";
import PaymentTypeSummary from "./PaymentTypeSummary";

const Dashboard = () => {
  return (
    <Box
      sx={{
        width: 1,
        gap: 3,
        display: "grid",
        gridTemplateColumns: "repeat(8, 1fr)",
        "& > .MuiPaper-root": {
          borderRadius: 2,
          boxShadow: "0 0 4px #1C295A14",
        },
      }}
    >
      <Earnings />
      <Summary />
      <TodaysDue />
      <PaymentTypeSummary />
    </Box>
  );
};

export default Dashboard;
