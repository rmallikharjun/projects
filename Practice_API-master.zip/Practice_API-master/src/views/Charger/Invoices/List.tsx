import { gql, useQuery } from "@apollo/client";
import { AddBoxOutlined, DeleteOutline } from "@mui/icons-material";
import { Avatar, Box, Button, Paper, Tab, Tabs } from "@mui/material";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { drawer } from "utils";
import DrawerContent from "./DrawerContent";
import moment from "moment";

const GET_INVOICES = gql`
  query Invoices($where: InvoiceWhereInput) {
    finance {
      getInvoices(where: $where) {
        id
        number
        createdAt
        status
        payee {
          company {
            name
          }
        }
        payer {
          buyer {
            firstName
            lastName
            phone
            email
          }
        }
        passbook {
          id
          amount
          paymentDate
          dueDate
          status
          type
        }
      }
    }
  }
`;

const List = () => {
  const [tab, setTab] = useState(0);
  const [rows, setRows] = useState({
    all: [],
    pending: [],
    completed: [],
  });

  const { loading, data } = useQuery(GET_INVOICES, {
    variables: {
      where: {
        asset: {
          type: "COMPONENT",
          component: {
            prototype: {
              type: "CHARGING_SOCKET",
            },
          },
        },
      },
    },
  });

  useEffect(() => {
    if (data) {
      let rows = {
        all: data.finance?.getInvoices || [],
        pending: [],
        completed: [],
      };
      rows.pending = rows.all.filter((row: any) => row.status === "PENDING");
      rows.completed = rows.all.filter((row: any) => row.status === "PAID");
      setRows(rows);
    }
  }, [data]);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Paper
      sx={{
        width: 1,
        // p: 3,
        boxShadow: "0 0 4px #1C295A14",
        borderRadius: 2,
      }}
    >
      <Box
        sx={{
          width: "fit-content",
          p: 3,
          pb: 2.75,
          display: "flex",
          alignItems: "center",
        }}
      >
        <Tabs
          className="less-dense"
          value={tab}
          onChange={(e, tab) => setTab(tab)}
        >
          <Tab
            label="All"
            className="hasCount"
            sx={{
              "&:after": {
                content: `"${rows.all.length || "-"}"`,
              },
            }}
          />
          <Tab
            label="Pending"
            className="hasCount"
            sx={{
              "&:after": {
                content: `"${rows.pending.length || "-"}"`,
              },
            }}
          />
          <Tab
            label="Completed"
            className="hasCount"
            sx={{
              "&:after": {
                content: `"${rows.completed.length || "-"}"`,
              },
            }}
          />
        </Tabs>
        {/* <FilterBy /> */}
      </Box>
      <Table
        loading={loading}
        columns={[
          { key: "number", label: "Invoice #" },
          {
            key: "createdAt",
            label: "Created At",
            format: (value) => moment(value).format("MMM DD, YYYY HH:mm"),
          },
          { key: "payer.buyer.phone", label: "Buyer's Phone" },
          {
            key: "passbook",
            label: "Amount",
            format: (passbook) => {
              let amount = 0;
              passbook?.forEach((entry: any) => {
                amount += entry.amount;
              });
              return amount ? `₹${amount}` : "-";
            },
          },
          {
            key: "status",
            label: "Status",
            Render: (row) => (
              <Avatar
                variant="status"
                className={row?.status === "PENDING" ? "red" : ""}
              >
                {row.status}
              </Avatar>
            ),
          },
          {
            key: "actions",
            label: "Actions",
            Render: (row) => (
              <Button
                variant="action"
                onClick={() => drawer.open(<DrawerContent invoice={row} />)}
              >
                View
              </Button>
            ),
          },
        ]}
        rows={tab === 0 ? rows.all : tab === 1 ? rows.pending : rows.completed}
        toolbar={() => (
          <>
            <Button sx={{ mr: 1.5 }} startIcon={<AddBoxOutlined />}>
              Assign Vendor
            </Button>
            <Button startIcon={<DeleteOutline />}>Delete</Button>
          </>
        )}
      />
    </Paper>
  );
};

export default List;
