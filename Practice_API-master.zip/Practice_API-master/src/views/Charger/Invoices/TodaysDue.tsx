import { Paper, Typography, Avatar, Button } from "@mui/material";
import Table from "components/Table";

const TodaysDue = () => {
  let rows = [];

  for (let i = 0; i < 113; i++) {
    rows.push({
      id: i,
      invoice: "FRI05JUN20213840380",
      phone: "9389393839",
      status: "Pending",
      cost: "₹ 1000",
    });
  }
  return (
    <Paper
      sx={{
        gridColumn: "span 5",
        height: 360,
        p: 3,
        display: "grid",
        gap: 2,
        gridTemplateColumns: "1fr",
      }}
    >
      <Typography variant="h6">Today's Due</Typography>
      <Table
        small
        hideDivider
        px={0}
        rowsPerPage={3}
        height={226}
        columns={[
          { key: "invoice", label: "Invoice" },
          {
            key: "status",
            label: "Status",
            Render: (row) => <Avatar variant="status">{row.status}</Avatar>,
          },
          { key: "phone", label: "Buyers Phone No." },

          { key: "cost", label: "Cost" },
          {
            key: "actions",
            label: "Actions",
            Render: (row) => (
              <Button variant="action" onClick={() => {}}>
                View
              </Button>
            ),
          },
        ]}
        rows={rows}
        toolbar={() => <></>}
      />
    </Paper>
  );
};

export default TodaysDue;
