import { Box } from "@mui/material";

import Breadcrumbs from "../../../components/Breadcrumbs";
// import ViewSelector, { View } from "../../../components/ViewSelector";
// import Dashboard from "./Dashboard";
import List from "./List";

const Invoices = () => {
  // const [view, setView] = useState<View>("grid");

  return (
    <>
      <Box
        width={1}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
        {/* <ViewSelector view={view} setView={setView} /> */}
      </Box>
      {/* {view === "grid" ? <Dashboard /> : <List />} */}
      <List />
    </>
  );
};

export default Invoices;
