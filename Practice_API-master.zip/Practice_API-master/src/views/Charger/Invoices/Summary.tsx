import { Box, Paper, Typography, useTheme } from "@mui/material";
import { Doughnut } from "react-chartjs-2";

const Summary = () => {
  const theme = useTheme();
  return (
    <Paper
      sx={{
        gridColumn: "span 3",
        height: 300,
        p: 3,
        display: "grid",

        gridTemplateColumns: "1fr",
      }}
    >
      <Typography variant="h6">Invoice Summary</Typography>
      <Box
        sx={{
          width: 1,
          display: "grid",
          gridTemplateColumns: "2fr 1fr 1fr",
          justifyItems: "center",
        }}
      >
        <Box width={190} alignSelf="center" position="relative">
          <Doughnut
            style={{ position: "relative", zIndex: 2 }}
            data={(canvas) => {
              return {
                datasets: [
                  {
                    data: [60, 40],
                    backgroundColor: [
                      theme.customColors.greenSecondary,
                      theme.customColors.blueSecondary,
                    ],
                    spacing: 1,
                    hoverOffset: 0,
                    borderWidth: 0,
                    borderRadius: 50,
                    cutout: "80%",
                  },
                ],
                labels: ["Available", "Unavailable"],
              };
            }}
            options={{
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  displayColors: false,
                },
              },
            }}
          />
          <Box
            sx={{
              zIndex: 1,
              position: "absolute",
              top: 70,
              right: 0,
              left: 0,
              mx: "auto",
              pointerEvents: "none",
              textAlign: "center",
            }}
          >
            <Typography fontSize={28} fontWeight={700} lineHeight="1.2em">
              100
            </Typography>
            <Typography
              sx={{
                textTransform: "uppercase",
                fontSize: 14,
                fontFamily: "Poppins !important",
              }}
            >
              Total Chargers
            </Typography>
          </Box>
        </Box>
        <Box mt={3} ml={3}>
          {[
            {
              label: "Available",
              value: 60,
              color: theme.customColors.text.greenSecondary,
            },
            {
              label: "Unavailable",
              value: 40,
              color: theme.customColors.text.blueSecondary,
            },
          ].map(({ label, value, color }, i) => (
            <Box
              key={i}
              sx={{
                position: "relative",
                display: "flex",
                flexDirection: "column",
                // width: 1,
                pl: 2.75,
                mb: 2.5,
                "& .value": {
                  mb: 1,
                  lineHeight: "1.2em",
                  fontSize: 20,
                  fontWeight: 700,
                  color: color,
                  "&:before": {
                    content: '""',
                    position: "absolute",
                    top: 4,
                    left: 0,
                    width: 14,
                    height: 14,
                    bgcolor: color,
                    borderRadius: "2px",
                  },
                },
                "& .label": {
                  color: "text.secondary",
                  fontSize: 14,
                  lineHeight: "1.4em",
                },
              }}
            >
              <span className="value">{value}</span>
              <span className="label">{label}</span>
            </Box>
          ))}
        </Box>
        <Box
          sx={{
            "& .text": {
              fontWeight: 500,
              fontSize: 14,
            },
          }}
        >
          <Typography
            className="text"
            mt={3}
            sx={{ color: theme.customColors.text.greenSecondary }}
          >
            ₹758.99
          </Typography>
          <Typography
            className="text"
            mt={6}
            sx={{ color: theme.customColors.text.blueSecondary }}
          >
            ₹458.99
          </Typography>
        </Box>
      </Box>
    </Paper>
  );
};

export default Summary;
