import React from "react";
import { Box, Paper, Typography, Divider } from "@mui/material";
import DatePicker from "../../../components/RangePicker";
import { getDarkModePreference, GlobalState } from "../../../utils";
import { useSelector } from "react-redux";

const Earnings = () => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  return (
    <Paper
      sx={{
        gridColumn: "span 5",
        height: 300,
        p: 3,
      }}
    >
      <Box
        mb={4}
        display="flex"
        alignItems="center"
        justifyContent="space-between"
      >
        <Typography variant="h6">Earnings</Typography>
        <DatePicker />
      </Box>
      <Box display="grid" gridTemplateColumns="3fr 4fr" gap={2}>
        <Box>
          <Box mb={4}>
            <Typography fontSize="2rem" fontWeight={700}>
              ₹ 17,600
            </Typography>
            <Typography
              sx={{
                textTransform: "uppercase",
                color: "text.secondary",
                fontSize: "0.875rem",
              }}
            >
              Net Revenue
            </Typography>
          </Box>
          <Box
            sx={{
              maxWidth: 227,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              ".info": {
                display: "flex",
                flexDirection: "column",
                ".value": {
                  fontSize: "1.5rem",
                  color: "text.primary",
                  fontWeight: 500,
                  mb: 0.5,
                },
                ".label": {
                  fontSize: "0.875rem",
                  color: "text.secondary",
                },
              },
            }}
          >
            <Box className="info">
              <span className="value">300</span>
              <span className="label">Total Invoice</span>
            </Box>
            <Divider flexItem orientation="vertical" sx={{ mx: 1 }} />
            <Box className="info">
              <span className="value">₹ 17,600</span>
              <span className="label">Earnings</span>
            </Box>
          </Box>
        </Box>
        <Box display="grid" gridTemplateColumns="1fr auto">
          {["80%", "65%", "95%"].map((el, i) => (
            <React.Fragment key={i}>
              <Typography gridColumn="span 2" fontSize="14px">
                Kwh
              </Typography>
              <Box mb={2} display="flex" alignItems="center">
                <Box
                  sx={{
                    flexGrow: 1,
                    height: 8,
                    position: "relative",
                    bgcolor: isDarkMode ? "#1A1A1A" : "#D7DBEC",
                    borderRadius: 1,
                    "&:after": {
                      content: '""',
                      width: el,
                      height: 1,
                      position: "absolute",
                      top: 0,
                      borderRadius: 1,
                      bgcolor: "#5BDEB4",
                    },
                  }}
                ></Box>
                <Typography sx={{ ml: 2.25, fontSize: 16, fontWeight: 500 }}>
                  ₹786.50
                </Typography>
              </Box>
            </React.Fragment>
          ))}
        </Box>
      </Box>
    </Paper>
  );
};

export default Earnings;
