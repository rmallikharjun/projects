import { HighlightOff } from "@mui/icons-material";
import { Box, IconButton, Typography, Avatar } from "@mui/material";
import Table from "../../../components/Table";
import { useSelector } from "react-redux";
import { drawer, getDarkModePreference, GlobalState } from "../../../utils";
import moment from "moment";

const DrawerContent = ({ invoice }: any) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  let rows = invoice?.passbook || [];

  let { firstName, lastName } = invoice?.buyer?.payer || {};

  let invoiceInfo = [
    { label: "Invoice", value: invoice?.number },
    { label: "From", value: invoice?.payee?.company?.name || "-" },
    {
      label: "To",
      value:
        firstName || lastName ? `${firstName || ""} ${lastName || ""}` : "-",
    },
  ];

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 2.5,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {invoice?.number}
          <IconButton
            children={<HighlightOff />}
            color="inherit"
            size="small"
            onClick={() => drawer.close()}
          />
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              maxWidth: 405,
              overflow: "hidden",
              mx: 4.5,
              mt: 3.25,
              mb: 3.75,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .first > td": {
                  pt: 0,
                },
                "& .last > td": {
                  pb: 0,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {invoiceInfo.map(({ label, value }, i) => (
                  <tr
                    key={i}
                    className={
                      i === 0
                        ? "first"
                        : i === invoiceInfo.length - 1
                        ? "last"
                        : ""
                    }
                  >
                    <td>{label}</td>
                    <td className="bold">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Box>
          <Box px={2.5}>
            <Typography mb={2} fontWeight={600}>
              Passbook
            </Typography>
            <Table
              px={0}
              height={"100%"}
              rowsPerPage={8}
              hideDivider
              rows={rows}
              columns={[
                {
                  key: "dueDate",
                  label: "Due Date",
                  format: (value) => moment(value).format("MMM DD, YYYY"),
                },
                {
                  key: "amount",
                  label: "Amount",
                  format: (value) => (value ? `₹${value}` : "-"),
                },
                { key: "type", label: "Type" },
                {
                  key: "status",
                  label: "Status",
                  Render: (row) => (
                    <Avatar
                      variant="status"
                      className={row.status === "COMPLETED" ? "" : "red"}
                    >
                      {row.status}
                    </Avatar>
                  ),
                },
              ]}
            />
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default DrawerContent;
