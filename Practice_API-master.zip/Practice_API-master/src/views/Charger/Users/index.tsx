import { Box, Tab, Tabs } from "@mui/material";
import ViewSelector, { View } from "components/ViewSelector";
import { useEffect, useState } from "react";
import List from "./List";
// import UsersTransaction from "./UsersTransaction";
import ActiveUsers from "./ActiveUsers";
import TopUsers from "./TopUsers";
import { drawer, GlobalState } from "utils";

import { useSelector } from "react-redux";

const Overview = () => {
  const [tab, setTab] = useState(0);
  const [view, setView] = useState<View>("grid");
  const companyName = useSelector(
    (state: GlobalState) => state.global.company.name
  );

  useEffect(() => {
    drawer.close();
  }, [tab]);

  return (
    <>
      <Box
        width={1}
        height={40}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box width="fit-content">
          <Tabs value={tab} onChange={(e, value) => setTab(value)}>
            <Tab label="Users" />
            {companyName === "testTVS" ? "" : <Tab label="User Groups" />}
          </Tabs>
        </Box>
        {tab === 0 && <ViewSelector view={view} setView={setView} />}
      </Box>
      {view === "list" || tab === 1 ? (
        <List
          activeView={tab === 0 ? "users" : "user groups"}
          companyName={companyName}
        />
      ) : (
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(6, 1fr)",
            gap: 3,
            "& > .MuiPaper-root": {
              borderRadius: 2,
              boxShadow: "0 0 4px #1C295A14",
            },
            "& > .MuiPaper-root:nth-of-type(-n+2)": {
              boxShadow: "0 0 10px #1C295A14",
            },
          }}
        >
          <ActiveUsers />
          {/* <UsersTransaction /> */}
          <TopUsers />
          {/* <Paper sx={{ height: 370, gridColumn: "span 2", p: 3 }}>
            <Availability />
          </Paper> */}
        </Box>
      )}
    </>
  );
};

export default Overview;
