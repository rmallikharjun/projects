import {
  Box,
  Paper,
  Typography,
  CircularProgress,
  Tab,
  Tabs,
} from "@mui/material";
import Table from "components/Table";
import { useState } from "react";
import RangePicker from "components/RangePicker";
import moment from "moment";
import { BOLT_URL } from "utils/constants";
import { authorizedFetch, snackbar } from "utils";
import { useQuery } from "react-query";
import { format, sub } from "date-fns";

const TopUsers = () => {
  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  const [tab, setTab] = useState(0);

  const userUrl = `${BOLT_URL}/company/stats/user/date?dateFrom=${dateFrom}&dateTo=${dateTo}&orderBy=${
    tab === 0 ? "totalBookings_DESC" : "totalEnergyConsumed_DESC"
  }`;

  const { isLoading: usersLoading, data: usersData } = useQuery(
    ["getUserStatsByDate", dateFrom, dateTo, tab],
    () => authorizedFetch(userUrl),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  return (
    <Paper sx={{ position: "relative", height: 440, gridColumn: "span 3" }}>
      <Box p={3} pb={0}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Typography variant="h6">Top Users</Typography>
          <RangePicker range={range} setRange={setRange} />
        </Box>
      </Box>
      <Box width={355} ml={3} mb={3}>
        <Tabs
          sx={{ "& .MuiButtonBase-root": { fontSize: 12, mb: -5 } }}
          value={tab}
          onChange={(e: any, value: any) => setTab(value)}
        >
          <Tab label="By Bookings" />
          <Tab label="By Energy Consumption" />
        </Tabs>
      </Box>
      {usersLoading ? (
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          flexGrow={1}
          height={250}
        >
          <CircularProgress />
        </Box>
      ) : (
        <Table
          idKey="userId"
          small
          rows={usersData?.data?.slice(0, 15) || []}
          rowsPerPage={3}
          height={250}
          columns={[
            {
              key: "userName",
              label: "Name",
              Render: (row) =>
                row.userName
                  ? row.userName
                  : row.email
                  ? row.email
                  : row.phone
                  ? row.phone
                  : "-",
            },
            { key: "totalBookings", label: "Bookings" },
            {
              key: "lastBooked",
              label: "Last Used",
              format: (value) => moment(value).format("ddd, MMM DD, YYYY"),
            },
            {
              key: "totalEnergyConsumed",
              label: "Energy Used",
              format: (value) => parseFloat(value).toFixed(3) + " kWh",
            },
            {
              key: "totalAmount",
              label: "Cost",
              format: (value) =>
                "₹" + (value === 0 ? value : parseFloat(value).toFixed(3)),
            },
          ]}
        />
      )}
    </Paper>
  );
};

export default TopUsers;
