import React from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { setLoader, snackbar } from "utils";
import { gql, useMutation } from "@apollo/client";

const DELETE_USER_GROUP = gql`
  mutation DeleteUserGroup($where: UserGroupWhereUniqueInput!) {
    userGroup {
      delete(where: $where) {
        id
      }
    }
  }
`;

interface DeleteDialogProps {
  open: boolean;
  handleClose: () => void;
  group: any;
}

const DeleteDialog: React.FC<DeleteDialogProps> = ({
  open,
  handleClose,
  group,
}) => {
  const [deleteUserGroup] = useMutation(DELETE_USER_GROUP, {
    refetchQueries: ["GetUserGroups"],
    onCompleted: () => {
      setLoader(false);
      snackbar.success("Deleted user group");
      handleClose();
    },
    onError: () => {
      setLoader(false);
      snackbar.error("Error deleting user group");
    },
  });

  function handleDelete() {
    setLoader(true);
    deleteUserGroup({
      variables: {
        where: {
          id: group?.id,
        },
      },
    });
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete User Group</DialogTitle>
      <DialogContent className="py-1">
        Are you sure you want to delete "<b>{group?.name}</b>"?
      </DialogContent>
      <DialogActions>
        <Button variant="outlined" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="contained" onClick={handleDelete}>
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteDialog;
