import {
  AttachMoney,
  DeleteOutline,
  EventAvailableOutlined,
  HighlightOff,
  PowerOutlined,
  Timer,
  NotificationAddOutlined,
  AccountBalanceWalletOutlined,
  BoltOutlined,
} from "@mui/icons-material";
import {
  Avatar,
  Box,
  Button,
  IconButton,
  LinearProgress,
  Paper,
  Tab,
  Tabs,
  Typography,
} from "@mui/material";
import TableComponent from "components/Table";
import { format } from "date-fns";
import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { useSelector } from "react-redux";
import {
  authorizedFetch,
  drawer,
  getDarkModePreference,
  getDuration,
  getPermissions,
  GlobalState,
  snackbar,
} from "utils";
import { BOLT_URL, WALLET_URL } from "utils/constants";
import DeleteDialog from "./DeleteDialog";
import NotificationDialog from "./NotificationDialog";
import RefundDialog from "./RefundDialog";
import moment from "moment";
import ConfirmRefund from "./ConfirmRefund";

interface Props {
  type: "user" | "group";
  user?: any;
  group?: {
    [key: string]: any;
  };
}

const DrawerContent: React.FC<Props> = ({ type, user, group }) => {
  const { canWrite } = getPermissions("charger:users");
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const [hasWallet, setHasWallet] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState<any>({
    open: false,
    data: null,
  });
  const [notificationDialog, SetNotificationDialog] = useState<any>({
    open: false,
    data: [],
  });
  const [refundDialog, SetRefundDialog] = useState<any>({
    open: false,
    user: {},
    data: {},
  });

  const [confirmRefundDialog, SetConfirmRefundDialog] = useState<any>({
    open: false,
    data: [],
    user: {},
  });

  const transactionsUrl = `${WALLET_URL}/v1/wallet/getTransactions?customerId=${user?._id}&client=DASHBOARD`;

  const {
    isLoading: transactionLoading,
    data: transactionData,
    refetch: refetchTransactions,
  } = useQuery(["Get Transactions", user?._id], () =>
    authorizedFetch(transactionsUrl)
  );

  const refundsUrl = `${WALLET_URL}/v1/wallet/getRefundRequest?customerId=${user?._id}&client=DASHBOARD`;
  const {
    isLoading: refundsLoading,
    data: refundsData,
    refetch: refetchRefunds,
  } = useQuery(["Get Refunds", user?._id, () => authorizedFetch(refundsUrl)]);

  const walletUrl = `${WALLET_URL}/v1/wallet/getWallet?customerId=${user?._id}&client=DASHBOARD`;
  const { data: walletData, refetch: refetchWallet } = useQuery(
    ["Get Wallet Details", user?._id],
    () => authorizedFetch(walletUrl)
  );

  return (
    <>
      <DeleteDialog
        open={deleteDialog.open}
        handleClose={() => setDeleteDialog({ ...deleteDialog, open: false })}
        group={deleteDialog.data}
      />
      <NotificationDialog
        open={notificationDialog.open}
        handleClose={() =>
          SetNotificationDialog({ ...notificationDialog, open: false })
        }
        data={notificationDialog.data}
      />
      <RefundDialog
        open={refundDialog.open}
        handleClose={() => SetRefundDialog({ ...refundDialog, open: false })}
        data={refundDialog.data}
        user={refundDialog.user}
        refetchTransactions={refetchTransactions}
        refetchWallet={refetchWallet}
      />
      <ConfirmRefund
        open={confirmRefundDialog.open}
        data={confirmRefundDialog.data}
        user={confirmRefundDialog.user}
        handleClose={() => {
          SetConfirmRefundDialog({
            ...confirmRefundDialog,
            open: false,
          });
        }}
        refetchRefunds={refetchRefunds}
      />
      <Box
        key={type === "user" ? user?.id : group?.id}
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box display="flex" alignItems="center">
            {type === "user"
              ? user?.firstName || user?.lastName
                ? `${user?.firstName || ""} ${user?.lastName || ""}`
                : "-"
              : group?.name || "-"}
            {type === "group" && (
              <Box
                sx={{
                  ml: 2.5,
                  px: 1.5,
                  py: 0.5,
                  borderRadius: 0.5,
                  color: "#fff",
                  fontSize: 12,
                  lineHeight: "14px",
                  fontWeight: 500,
                  bgcolor:
                    group?.status === "ACTIVE" ? "success.main" : "error.main",
                }}
              >
                {group?.status}
              </Box>
            )}
          </Box>
          <Box display="flex">
            {type === "group" && canWrite && (
              <>
                {/* <IconButton
                  children={<EditOutlined />}
                  color="inherit"
                  size="small"
                /> */}
                <IconButton
                  sx={{ mr: 1 }}
                  children={<DeleteOutline />}
                  color="inherit"
                  size="small"
                  onClick={() => setDeleteDialog({ open: true, data: group })}
                />
              </>
            )}
            {type === "user" && canWrite && (
              <>
                {hasWallet && (
                  <Button
                    variant="contained"
                    size="small"
                    sx={{ mr: 1 }}
                    onClick={() =>
                      SetRefundDialog({
                        open: true,
                        user: user,
                        data: "",
                      })
                    }
                  >
                    Refund
                  </Button>
                )}
                <IconButton
                  children={<NotificationAddOutlined />}
                  color="inherit"
                  size="small"
                  sx={{ mr: 1 }}
                  onClick={() =>
                    SetNotificationDialog({ open: true, data: user })
                  }
                />
              </>
            )}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Paper sx={{ flexGrow: 1, overflow: "auto", borderRadius: 0 }}>
          {type === "user" ? (
            <UserContent
              user={user}
              SetRefundDialog={SetRefundDialog}
              hasWallet={hasWallet}
              setHasWallet={setHasWallet}
              transactionData={transactionData}
              transactionLoading={transactionLoading}
              confirmRefundDialog={confirmRefundDialog}
              setConfirmRefundDialog={SetConfirmRefundDialog}
              refundsData={refundsData}
              refundsLoading={refundsLoading}
              walletData={walletData}
            />
          ) : (
            <UserGroupContent group={group} />
          )}
        </Paper>
      </Box>
    </>
  );
};

const UserContent: React.FC<{
  user: any;
  SetRefundDialog: React.Dispatch<any>;
  hasWallet: boolean;
  setHasWallet: React.Dispatch<React.SetStateAction<boolean>>;
  transactionData: any;
  transactionLoading: boolean;
  confirmRefundDialog: any;
  setConfirmRefundDialog: React.Dispatch<any>;
  refundsData: any;
  refundsLoading: boolean;
  walletData: any;
}> = ({
  user,
  SetRefundDialog,
  hasWallet,
  setHasWallet,
  transactionData,
  transactionLoading,
  setConfirmRefundDialog,
  refundsLoading,
  refundsData,
  walletData,
}) => {
  const [stats, setStats] = useState<any>(null);

  const [recentTransactions, setRecentTransaction] = useState([]);
  const [refundsList, setRefundsList] = useState([]);
  const [walletBalance, setWalletBalance] = useState(0);

  const [tab, setTab] = useState(0);

  const bookingUrl = `${BOLT_URL}/company/users/bookings?userId=${user?._id}`;

  const { isLoading: bookingsLoading, data: bookingsData } = useQuery(
    ["getUsersBookings", user?._id],
    () =>
      authorizedFetch(bookingUrl, {
        headers: {
          token: 1234,
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  console.log(bookingsData);
  console.log(user);

  useEffect(() => {
    if (walletData) {
      if (walletData.status === 400) {
        setHasWallet(false);
      }
      if (walletData.status === 200) {
        setHasWallet(true);
      }
      setWalletBalance(walletData?.data?.walletBalance);
    }
  }, [walletData, setHasWallet]);

  useEffect(() => {
    if (bookingsData) {
      setStats(bookingsData?.data?.stats);
    } else {
      setStats(null);
    }
  }, [bookingsData]);

  useEffect(() => {
    if (transactionData && transactionData.data) {
      setRecentTransaction(transactionData.data.transactions);
    } else {
      setRecentTransaction([]);
    }
  }, [transactionData]);

  useEffect(() => {
    if (refundsData && refundsData.data) {
      setRefundsList(refundsData.data);
    } else {
      setRefundsList([]);
    }
  }, [refundsData]);

  console.log(bookingsData?.data?.stats);

  return (
    <>
      {bookingsLoading && <LinearProgress />}
      <Box px={2.5} pt={2}>
        <Box
          mb={1.5}
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography variant="h6">Stats</Typography>
          {/* <RangePicker /> */}
        </Box>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 1,
            "& > div": {
              width: 1,
              p: 1.5,
              display: "flex",
              border: 1,
              borderRadius: "3px",
              borderColor: (theme) => theme.customColors.border,
              "& .MuiAvatar-root": {
                mr: 1,
              },
              "& .info": {
                display: "flex",
                flexDirection: "column",
                "& .label": {
                  fontSize: 17,
                  fontWeight: 600,
                  color: "text.primary",
                  lineHeight: "1.15em",
                },
                "& .value": {
                  fontSize: 12,
                  color: "text.secondary",
                },
              },
            },
          }}
        >
          <Box>
            <Avatar variant="icon">
              <EventAvailableOutlined />
            </Avatar>
            <Box className="info">
              <span className="label">{stats?.totalBookings || "-"}</span>
              <span className="value">Bookings</span>
            </Box>
          </Box>
          <Box>
            <Avatar variant="icon">
              <Timer />
            </Avatar>
            <Box className="info">
              <span className="label">
                {stats?.totalBookingDurationInHours
                  ? getDuration(stats?.totalBookingDurationInHours * 60)
                  : "-"}
              </span>
              <span className="value">Booking Duration</span>
            </Box>
          </Box>
          <Box>
            <Avatar variant="icon">
              <AttachMoney />
            </Avatar>
            <Box className="info">
              <span className="label">
                {typeof stats?.totalEarnings === "number"
                  ? "₹" + stats.totalEarnings
                  : "-"}
              </span>
              <span className="value">Earnings</span>
            </Box>
          </Box>
          <Box>
            <Avatar variant="icon">
              <PowerOutlined />
            </Avatar>
            <Box className="info">
              <span className="label">
                {stats?.totalChargingDurationInHours
                  ? getDuration(stats.totalChargingDurationInHours * 60)
                  : "-"}
              </span>
              <span className="value">Charging Duration</span>
            </Box>
          </Box>
          <Box>
            <Avatar variant="icon">
              <BoltOutlined />
            </Avatar>
            <Box className="info">
              <span className="label">
                {typeof stats?.totalEnergyConsumed === "number"
                  ? stats.totalEnergyConsumed.toFixed(3) + " kWh"
                  : "-"}
              </span>
              <span className="value">Consumption</span>
            </Box>
          </Box>
          <Box>
            <Avatar variant="icon">
              <AccountBalanceWalletOutlined />
            </Avatar>
            <Box className="info">
              <span className="label">
                {hasWallet
                  ? typeof walletBalance === "number"
                    ? "₹" + walletBalance
                    : "No Wallet Found"
                  : "No Wallet Found"}
              </span>
              <span className="value">Wallet Balance</span>
            </Box>
          </Box>
        </Box>
      </Box>
      <Box mt={3.75} mb={2} mx={2.5}>
        <Tabs className="dense" value={tab} onChange={(e, tab) => setTab(tab)}>
          <Tab label="Recent Bookings" />
          <Tab label="Recent Transactions" />
          <Tab label="Refund Requests" />
        </Tabs>
      </Box>
      {tab === 0 ? (
        <TableComponent
          px={2.5}
          loading={bookingsLoading}
          rows={bookingsData?.data?.userBookings[0]?.bookings || []}
          columns={[
            {
              key: "chargingStart",
              label: "Start Time",
              format: (value) => format(new Date(value), "MMM dd yyyy, HH:mm"),
            },
            {
              key: "bookingDuration",
              label: "Booking Duration",
              format: (value) => getDuration(value * 60),
            },
            {
              key: "actualDuration",
              label: "Charging Duration",
              Render: (row) => getDuration(row.chargingDuration * 60),
            },
            {
              key: "energyConsumed",
              label: "Energy Utilised",
              format: (value) =>
                typeof value === "number" ? value.toFixed(3) + " kWh" : "-",
            },
            {
              key: "amount",
              label: "Amount",
              format: (value) =>
                typeof value === "number" ? "₹" + value : "-",
            },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={row.bookingStatus === "TERMINATED" ? "red" : ""}
                >
                  {row.bookingStatus}
                </Avatar>
              ),
            },
          ]}
          small
          hideDivider
        />
      ) : tab === 1 ? (
        <TableComponent
          px={2.5}
          loading={transactionLoading}
          rows={recentTransactions}
          columns={[
            {
              key: "action",
              label: "Actions",
              Render: (row) => (
                <Button
                  sx={{ ml: -1 }}
                  onClick={() =>
                    SetRefundDialog({ open: true, data: row, user: user })
                  }
                  disabled={row.type !== "USED_FROM_WALLET"}
                >
                  REFUND
                </Button>
              ),
            },
            {
              key: "c/d",
              label: "C/D",
              Render: (row) => (
                <Avatar variant="status">
                  {row.type === "ADDED_TO_WALLET"
                    ? "Credit"
                    : row.type === "ADDING_TO_WALLET"
                    ? "Credit"
                    : row.type === "USED_FROM_WALLET"
                    ? "Debit"
                    : row.type === "REFUND_TO_WALLET"
                    ? "Credit"
                    : "-"}
                </Avatar>
              ),
            },

            {
              key: "amount",
              label: "Amount",
              format: (value) => `₹ ${value}`,
            },
            {
              key: "timeStamp",
              label: "Date",
              format: (value) => moment(value).format("MMM DD yyyy, hh:mm A"),
            },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={
                    ["TERMINATED", "FAILED"].some((el) =>
                      String(row.status || "").includes(el)
                    )
                      ? "red"
                      : ""
                  }
                >
                  {row.status || "-"}
                </Avatar>
              ),
            },

            {
              key: "type",
              label: "Type",
            },
            {
              key: "id",
              label: "Transaction ID",
            },
            {
              key: "remarks",
              label: "Remarks",
            },
          ]}
          small
          hideDivider
        />
      ) : tab === 2 ? (
        <TableComponent
          px={2.5}
          loading={refundsLoading}
          rows={refundsList}
          columns={[
            {
              key: "action",
              label: "Actions",
              Render: (row) => (
                <Button
                  sx={{ ml: -1 }}
                  onClick={() =>
                    setConfirmRefundDialog({
                      open: true,
                      data: row,
                      user: user,
                    })
                  }
                  disabled={row.status === "COMPLETE"}
                >
                  CONFIRM
                </Button>
              ),
            },

            {
              key: "amount",
              label: "Amount",

              format: (value) => ` ₹ ${value}`,
            },
            {
              key: "timeStamp",
              label: "Date",
              format: (value) => moment(value).format("MMM DD yyyy, hh:mm A"),
            },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={
                    ["TERMINATED", "FAILED"].some((el) =>
                      String(row.status || "").includes(el)
                    )
                      ? "red"
                      : ""
                  }
                >
                  {row.status || "-"}
                </Avatar>
              ),
            },

            {
              key: "bookingId",
              label: "Booking ID",
            },
            {
              key: "remarks",
              label: "Remarks",
            },
          ]}
          small
          hideDivider
        />
      ) : (
        ""
      )}
    </>
  );
};

const UserGroupContent: React.FC<{ group: any }> = ({ group }) => {
  // const [selectedIds, setSelectedIds] = useState<any>([])
  const { canWrite } = getPermissions("charger:users");
  return (
    <Box py={2.5}>
      <TableComponent
        px={2.5}
        small
        selectable={canWrite}
        // setSelectedRows={setSelectedIds}
        rows={group?.users || []}
        columns={[
          {
            key: "name",
            label: "Name",
            Render: (row) => {
              let { firstName, lastName } = row;
              return firstName || lastName
                ? `${firstName || ""} ${lastName || ""}`
                : "-";
            },
          },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
        ]}
        hideDivider
        toolbar={() => <Button startIcon={<DeleteOutline />}>Delete</Button>}
      />
    </Box>
  );
};

export default DrawerContent;
