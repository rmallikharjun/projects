import {
  Avatar,
  Box,
  CircularProgress,
  Paper,
  Tooltip,
  Typography,
  useTheme,
} from "@mui/material";
import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import { snackbar } from "utils";
import { useQuery } from "react-query";
import { authorizedFetch } from "utils";
import { BOLT_URL } from "utils/constants";
import { format, sub } from "date-fns";

import RangePicker from "components/RangePicker";
import { InfoOutlined } from "@mui/icons-material";
import moment from "moment";

const ActiveUsers = () => {
  const theme = useTheme();

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);
  const [chartData, setChartData] = useState<any>(null);

  let dateFrom = format(range[0], "yyyy-MM-dd");
  let dateTo = format(range[1], "yyy-MM-dd");

  // const stats2Url = `${BOLT_URL}/company/stats/all?dateFrom=${dateFrom}&dateTo=${dateTo}`;
  // const { data: stats } = useQuery(["get", dateFrom, dateTo], () =>
  //   authorizedFetch(stats2Url)
  // );

  const bookingsNewUrl = `${BOLT_URL}/company/stats/bookings/date?orderBy=BOOKING_TIME_ASC&dateFrom=${dateFrom}&dateTo=${dateTo}`;

  const { isLoading, data } = useQuery(
    ["getBookingsStatsByDate", dateFrom, dateTo],
    () => authorizedFetch(bookingsNewUrl),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (data?.data?.stats?.constructor === Array) {
      let dataArray = data.data.stats.sort(
        (a: any, b: any) => moment(a.date).valueOf() - moment(b.date).valueOf()
      );
      let chartData = dataArray.reduce(
        (acc: any, cur: any) => {
          let day = moment(cur.date).format("MMM D, yyyy");
          const getExisting = (key: string) =>
            acc[key].find((el: any) => el.x === day);
          if (getExisting("earnings")) {
            getExisting("earnings").y += Math.round(
              parseFloat(cur.totalEarnings)
            );

            getExisting("users").y += cur.totalUsers;
          } else {
            acc.earnings.push({
              x: day,
              y: Math.round(parseFloat(cur.totalEarnings)),
            });

            acc.users.push({ x: day, y: cur.totalUsers });
          }
          return acc;
        },
        {
          earnings: [],
          users: [],
        }
      );
      setChartData(chartData);
    }
  }, [data]);

  return (
    <Paper
      sx={{
        height: 440,
        gridColumn: "span 3",
        p: 3,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box mb={1.5} display="flex" justifyContent="space-between">
        <Typography variant="h6">Users vs Transaction</Typography>
        <RangePicker range={range} setRange={setRange} />
      </Box>
      <Box
        sx={{
          mb: 3,
          display: "flex",
          alignItems: "center",
          "& .text": {
            position: "relative",
            fontSize: 13,
            lineHeight: "1em",
            color: theme.customColors.greySecondary,
            "&:before": {
              content: '""',
              position: "absolute",
              top: 0,
              left: -18,
              height: 10,
              width: 10,
              backgroundColor: theme.customColors.greenSecondary,
              borderRadius: 1,
            },
          },
          "& .bookings": {
            display: "flex",
            alignItems: "center",
            ml: 2.5,
            mr: 1,
            "&:before": {
              backgroundColor: theme.customColors.blueSecondary,
            },
          },
        }}
        display="flex"
        alignItems="center"
      >
        <Box display="flex" alignItems="center">
          <span className="text bookings">
            Users
            <Tooltip title="This user count is total unique users for the given DATE RANGE, the sum of values in the graph might differ as they are number of unique users PER DAY">
              <InfoOutlined
                fontSize="inherit"
                sx={{ ml: 0.5, cursor: "pointer" }}
              />
            </Tooltip>
          </span>
          <Avatar variant="label">
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              data?.data?.totalUsers
            )}
          </Avatar>
        </Box>
        <Box display="flex" alignItems="center" ml={4.5}>
          <span className="text earnings">Transaction (₹)</span>
          <Avatar variant="label" sx={{ ml: 1 }}>
            {isLoading ? (
              <CircularProgress size={13} />
            ) : (
              `₹${data?.data?.totalEarnings?.toFixed(0) || 0}`
            )}
          </Avatar>
        </Box>
      </Box>
      <Box
        sx={{
          flexGrow: 1,
          width: 1,
          minHeight: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {isLoading ? (
          <CircularProgress />
        ) : (
          <Line
            data={(canvas) => {
              let labels = chartData?.earnings?.map(
                (el: any) => el.x.split(",")[0]
              );
              return {
                labels,
                datasets: [
                  {
                    label: "Users",
                    data: chartData?.users?.map((el: any) => el.y),
                    pointBackgroundColor: theme.customColors.blueSecondary,
                    borderColor: theme.customColors.blueSecondary,
                    yAxisID: "yAxis",
                  },
                  {
                    label: "Transaction",
                    data: chartData?.earnings?.map((el: any) => el.y),
                    pointBackgroundColor: theme.customColors.greenSecondary,
                    borderColor: theme.customColors.greenSecondary,
                    yAxisID: "yAxis2",
                  },
                ],
              };
            }}
            options={{
              datasets: {
                line: {
                  tension: 0.4,
                  borderWidth: 2,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  pointHoverBackgroundColor: "#fff",
                  pointHoverBorderWidth: 3,
                },
              },
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  display: false,
                },
                tooltip: {
                  caretSize: 0,
                  mode: "index",
                  intersect: false,
                  yAlign: "center",
                  displayColors: false,
                  caretPadding: 16,
                  titleFont: {
                    weight: "400",
                  },
                  bodyFont: {
                    weight: "500",
                  },
                },
              },
              interaction: {
                mode: "index",
                intersect: false,
              },
              scales: {
                xAxis: {
                  // type: 'time',
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                },
                yAxis: {
                  title: {
                    display: true,
                    text: "Users",
                    padding: {
                      top: 0,
                      bottom: 15,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                  },
                  suggestedMin: 15,
                  suggestedMax: 85,
                  grid: {
                    borderDash: [10],
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
                yAxis2: {
                  position: "right",
                  title: {
                    display: true,
                    text: "Transaction (₹)",
                    padding: {
                      top: 0,
                      bottom: 15,
                    },
                    color: theme.customColors.grey,
                    font: {
                      weight: "500",
                      size: 12,
                    },
                  },
                  ticks: {
                    color: theme.palette.text.secondary,
                    // callback: (label, index, lables) => '₹' + label
                  },
                  suggestedMin: 15,
                  suggestedMax: 85,
                  grid: {
                    display: false,
                    tickWidth: 0,
                    tickLength: 16,
                    drawBorder: false,
                  },
                },
              },
            }}
          />
        )}
      </Box>
    </Paper>
  );
};

export default ActiveUsers;
