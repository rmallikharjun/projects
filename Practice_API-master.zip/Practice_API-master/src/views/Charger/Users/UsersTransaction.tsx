import { alpha } from "@mui/system";
import { Box, Paper, Typography, useTheme } from "@mui/material";
import { useState } from "react";
import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";
import { sub } from "date-fns";
import RangePicker from "components/RangePicker";

const UsersTransaction = () => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const theme = useTheme();

  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  return (
    <Paper
      sx={{
        height: 388,
        gridColumn: "span 3",
        p: 3,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Box mb={3} display="flex" justifyContent="space-between">
        <Typography variant="h6">Active Users (%)</Typography>
        <RangePicker range={range} setRange={setRange} />
      </Box>
      <Box
        sx={{
          flexGrow: 1,
          width: 1,
          minHeight: 0,
        }}
      >
        <Line
          data={(canvas) => {
            let color = "#538ADC";
            let labels = [
              "Oct 1",
              "Oct 2",
              "Oct 3",
              "Oct 4",
              "Oct 5",
              "Oct 6",
              "Oct 7",
              "Oct 8",
              "Oct 9",
              "Oct 10",
            ];

            return {
              labels,
              datasets: [
                {
                  fill: true,
                  data: [50, 25, 20, 75, 50, 80, 70, 80, 15, 37],
                  borderColor: color,
                  borderWidth: 2,
                  backgroundColor: alpha(
                    theme.customColors.blueSecondary,
                    isDarkMode ? 0.1 : 0.2
                  ),
                  tension: 0.4,
                  pointRadius: 0,
                  pointHoverRadius: 4,
                  pointHoverBackgroundColor: "#fff",
                  pointHoverBorderWidth: 3,
                },
              ],
            };
          }}
          options={{
            scales: {
              xAxis: {
                // type: 'time',
                grid: {
                  display: false,
                  tickWidth: 0,
                  tickLength: 16,
                  drawBorder: false,
                },
                ticks: {
                  color: theme.palette.text.secondary,
                },
              },
              yAxis: {
                title: {
                  // display: true,
                  display: false,
                  text: "Users (%)",
                  padding: {
                    top: 0,
                    bottom: 8,
                  },
                  color: theme.customColors.grey,
                  font: {
                    weight: "500",
                    size: 12,
                  },
                },
                ticks: {
                  color: theme.palette.text.secondary,
                },
                suggestedMin: 15,
                suggestedMax: 85,
                grid: {
                  borderDash: [10],
                  tickWidth: 0,
                  tickLength: 16,
                  drawBorder: false,
                },
              },
            },
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false,
              },
              tooltip: {
                caretSize: 0,
                mode: "index",
                intersect: false,
                yAlign: "center",
                displayColors: false,
                caretPadding: 16,
                titleFont: {
                  weight: "400",
                },
                bodyFont: {
                  weight: "500",
                },
              },
            },
            interaction: {
              mode: "index",
              intersect: false,
            },
          }}
        />
      </Box>
    </Paper>
  );
};

export default UsersTransaction;
