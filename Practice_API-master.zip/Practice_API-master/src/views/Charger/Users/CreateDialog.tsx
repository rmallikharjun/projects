import { gql, useMutation, useQuery } from "@apollo/client";
import { EditOutlined, ErrorOutline, HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";
import TableComponent from "components/Table";
import { useState } from "react";
import { setLoader, snackbar } from "utils";

const GET_SUBSCRIPTIONS = gql`
  query Subscriptions {
    subscriptionPolicy {
      getAll {
        id
        name
      }
    }
  }
`;

const GET_PAYMENT_META = gql`
  query PaymentMeta {
    finance {
      getAllPaymentMeta {
        id
        name
        service
        address
      }
    }
  }
`;

const CREATE_USER_GROUP = gql`
  mutation CreateUserGroup($data: UserGroupCreateInput!) {
    userGroup {
      create(data: $data) {
        id
      }
    }
  }
`;

const CreateDialog = ({ open, handleClose }: any) => {
  const [step, setStep] = useState<number>(0);
  const steps = ["Basic Details", "Users", "Pricing", "Confirmation"];
  const [selectedUserIds, setSelectedUserIds] = useState([]);
  type Input = {
    [key: string]: any | { [key: string]: any };
  };
  const inputObj: Input = {
    name: "",
    users: [],
    subscription: "",
    pricing: {
      name: "",
      amountPayable: "",
      paymentMeta: "",
      type: "ONETIME",
    },
  };
  const [input, setInput] = useState({ ...inputObj });
  const { name, subscription, pricing } = input;

  // TODO: fetch users from AUTH_URL

  const { loading: paymentMetaLoading, data: paymentMeta } =
    useQuery(GET_PAYMENT_META);
  const { loading: subscriptionsLoading, data: subscriptions } =
    useQuery(GET_SUBSCRIPTIONS);

  const [createUserGroup] = useMutation(CREATE_USER_GROUP, {
    refetchQueries: ["GetUserGroups"],
    onCompleted: () => {
      setLoader(false);
      snackbar.success("New user group created");
      handleClose();
      setTimeout(() => {
        setInput({
          name: "",
          subscription: "",
          pricing: {
            name: "",
            amountPayable: "",
            paymentMeta: "",
            type: "ONETIME",
          },
        });
      }, 500);
    },
    onError: () => {
      setLoader(false);
      snackbar.error("Error creating user group");
    },
  });

  function handleChange(key: string, value: any) {
    setInput((prevInput) => ({ ...prevInput, [key]: value }));
  }
  function handleNext() {
    if (step === steps.length - 1) {
      handleSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }
  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![name, subscription].includes("");
      case 1:
        return selectedUserIds.length > 0;
      case 2:
        return ![pricing.amountPayable, pricing.paymentMeta].includes("");
      default:
        break;
    }
  }

  function handleSave() {
    setLoader(true);
    let variables = {
      data: {
        name,
        subscriptionPolicy: {
          connect: {
            id: subscription,
          },
        },
        users: {
          connect: selectedUserIds.map((id) => ({ id })),
        },
        pricing: {
          create: {
            ...pricing,
            amountPayable: parseFloat(pricing.amountPayable || 0),
            paymentMeta: {
              connect: {
                id: pricing.paymentMeta.id,
              },
            },
          },
        },
      },
    };
    // console.log("create user group", variables);
    createUserGroup({
      variables,
    });
  }

  const disabled =
    [
      name,
      subscription,
      pricing.amountPayable,
      pricing.paymentMeta,
      pricing.type,
    ].includes("") || selectedUserIds.length === 0;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Create User Group
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent>
        {/* <Typography mb={5} fontSize={14} color="text.secondary">
          All fields marked with * are required
        </Typography> */}
        <Stepper
          sx={{ mb: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i} completed={isComplete(i)}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {step === 0 && (
          <Box
            sx={{
              maxWidth: 280,
              mx: "auto",
              py: 6,
              display: "grid",
              gridTemplateColumns: "1fr",
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Name</Typography>
              <TextField
                value={name}
                onChange={(e) => handleChange("name", e.target.value)}
                fullWidth
                size="small"
                placeholder="Name"
              />
            </Box>
            <Box>
              <Typography className="label">Subscription</Typography>
              {subscriptionsLoading || !subscriptions ? (
                <CircularProgress size={36} />
              ) : (
                <Select
                  value={subscription}
                  onChange={(e) => {
                    handleChange("subscription", e.target.value);
                  }}
                  fullWidth
                >
                  {/* <MenuItem value="new">
                    <ListItemIcon children={<Add />} />
                    <ListItemText>Create New</ListItemText>
                  </MenuItem> */}
                  {(subscriptions?.subscriptionPolicy?.getAll?.constructor ===
                  Array
                    ? subscriptions.subscriptionPolicy.getAll
                    : []
                  ).map((el: any, i: number) => (
                    <MenuItem key={i} value={el.id}>
                      {el.name}
                    </MenuItem>
                  ))}
                </Select>
              )}
            </Box>
          </Box>
        )}
        {step === 1 && (
          <Box>
            {/* TODO: add active view selector (app users/employees) */}
            <TableComponent
              height={325}
              px={0}
              selectable
              selectOnClick
              selectedRows={selectedUserIds}
              setSelectedRows={setSelectedUserIds}
              rowsPerPage={5}
              small
              // loading={activeView === 'app users' ? appUsersLoading : employeesLoading}
              // rows={activeView === 'app users' ? appUsersData?.data?.users || [] : employeesData?.data?.users || []}
              rows={[]}
              columns={[
                {
                  key: "name",
                  label: "Name",
                  Render: (row) => {
                    let { firstName, lastName } = row;
                    return firstName || lastName
                      ? `${firstName || ""} ${lastName || ""}`
                      : "-";
                  },
                },
                { key: "email", label: "Email" },
                { key: "phone", label: "Phone" },
              ]}
            />
          </Box>
        )}
        {step === 2 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 3,
            }}
          >
            <Box>
              <Typography className="label">Name</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Name"
                value={pricing.name}
                onChange={(e) => {
                  handleChange("pricing", { ...pricing, name: e.target.value });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Amount</Typography>
              <TextField
                fullWidth
                size="small"
                placeholder="Amount"
                type="number"
                value={pricing.amount}
                onChange={(e) => {
                  handleChange("pricing", {
                    ...pricing,
                    amountPayable: e.target.value,
                  });
                }}
              />
            </Box>
            <Box>
              <Typography className="label">Payment Meta</Typography>
              {paymentMetaLoading || !paymentMeta ? (
                <CircularProgress size={36} />
              ) : (
                <Select
                  value={
                    pricing.paymentMeta === ""
                      ? pricing.paymentMeta
                      : JSON.stringify(pricing.paymentMeta)
                  }
                  onChange={(e) => {
                    handleChange("pricing", {
                      ...pricing,
                      paymentMeta: JSON.parse(e.target.value),
                    });
                  }}
                  fullWidth
                >
                  {(paymentMeta?.finance?.getAllPaymentMeta?.constructor ===
                  Array
                    ? paymentMeta.finance.getAllPaymentMeta
                    : []
                  ).map((el: any, i: number) => (
                    <MenuItem key={i} value={JSON.stringify(el)}>
                      {el.service === "UPI" ? el.address : el.name}
                    </MenuItem>
                  ))}
                </Select>
              )}
            </Box>
            <Box />
            <Box>
              <Typography className="label">Pricing Type</Typography>
              <RadioGroup
                row
                sx={{ mb: 2.5, justifyContent: "space-between" }}
                value={pricing.type}
              >
                <FormControlLabel
                  value="ONETIME"
                  control={<Radio />}
                  label="One Time"
                />
                {/* <FormControlLabel
                  value="subscription"
                  control={<Radio />}
                  label="Subscription"
                /> */}
              </RadioGroup>
            </Box>
          </Box>
        )}
        {step === 3 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Basic Details", onEdit: () => setStep(0) },
                  { label: "Name", value: name, required: true },
                  {
                    label: "Subscription",
                    value: subscription
                      ? subscriptions.subscriptionPolicy.getAll.find(
                          (el: any) => el.id === subscription
                        ).name
                      : null,
                    required: true,
                  },
                  { header: "Users", onEdit: () => setStep(1) },
                  {
                    label: "Selected Users",
                    value: selectedUserIds.length,
                    required: true,
                  },
                  { header: "Pricing", onEdit: () => setStep(2) },
                  { label: "Name", value: pricing.name },
                  {
                    label: "Amount",
                    value: pricing.amountPayable,
                    required: true,
                  },
                  {
                    label: "Payment Meta",
                    value:
                      pricing.paymentMeta.service === "UPI"
                        ? pricing.paymentMeta.address
                        : pricing.paymentMeta.name,
                    required: true,
                  },
                  { label: "Type", value: pricing.type, required: true },
                ].map(({ header, onEdit, label, value, required }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          <td className="bold">{label}</td>
                          <td>
                            {value ||
                              (required && (
                                <Box display="flex" alignItems="center">
                                  <ErrorOutline
                                    fontSize="small"
                                    color="error"
                                    style={{ marginRight: 8 }}
                                  />
                                  Required
                                </Box>
                              ))}
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant="contained"
          color={
            isComplete(step) || step === steps.length - 1
              ? "primary"
              : "inherit"
          }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CreateDialog;
