import React, { useEffect, useRef, useState } from "react";
import {
  Avatar,
  Box,
  Button,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Tooltip,
} from "@mui/material";
import TableComponent from "components/Table";
import { authorizedFetch, drawer, getPermissions } from "utils";
import DrawerContent from "./DrawerContent";
import { Add, DeleteOutline, InfoOutlined } from "@mui/icons-material";
import { gql, useQuery } from "@apollo/client";
import { useQuery as useFetch } from "react-query";
import { AUTH_URL } from "utils/constants";
import CreateDialog from "./CreateDialog";
import DeleteDialog from "./DeleteDialog";
import Search from "components/Search";

interface Props {
  activeView: "users" | "user groups";
  companyName: string;
}

const GET_USER_GROUPS = gql`
  query GetUserGroups {
    userGroup {
      getAll {
        id
        name
        status
        users {
          id
          firstName
          lastName
          email
          phone
        }
        subscriptionPolicy {
          id
          name
        }
      }
    }
  }
`;

const List: React.FC<Props> = ({ activeView, companyName }) => {
  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <Paper
      sx={{
        width: 1,
        boxShadow: "0 0 4px #1C295A14",
        borderRadius: 2,
      }}
    >
      {activeView === "users" ? (
        <Users companyName={companyName} />
      ) : (
        <UserGroups />
      )}
    </Paper>
  );
};

const Users = ({ companyName }: any) => {
  const firstRender = useRef(true);

  const [tab, setTab] = useState(0);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [search, setSearch] = useState("");

  const appUsersUrl = `${AUTH_URL}/company/appusers?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;
  const employeesUrl = `${AUTH_URL}/company/users?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }&search=${search}`;

  const { isLoading: appUsersLoading, data: appUsersData } = useFetch(
    ["getAppUsers", page, pageSize, search],
    () => authorizedFetch(appUsersUrl),
    { enabled: tab === 0 }
  );

  const { isLoading: employeesLoading, data: employeesData } = useFetch(
    ["getEmployees", page, pageSize, search],
    () => authorizedFetch(employeesUrl),
    { enabled: firstRender.current || tab === 1 }
  );

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    return () => {
      drawer.close();
    };
  }, []);

  useEffect(() => {
    setPage(1);
  }, [tab]);

  return (
    <>
      <Box
        sx={{
          p: 3,
          pb: 2.75,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box width="fit-content" height={40}>
          <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
            <Tab
              label="App Users"
              className="hasCount"
              sx={{
                "&:after": {
                  content: `"${appUsersData?.data?.count || "-"}"`,
                },
              }}
            />
            {companyName === "testTVS" ? (
              ""
            ) : (
              <Tab
                label="Employees"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${employeesData?.data?.count || "-"}"`,
                  },
                }}
              />
            )}
          </Tabs>
        </Box>
        <Search
          handleSearch={(value) => {
            setPage(1);
            setSearch(value);
          }}
          persist
          enableClear
        />
      </Box>
      <TableComponent
        serverSidePagination
        rowCount={
          tab === 0
            ? appUsersData?.data?.count || 0
            : employeesData?.data?.count || 0
        }
        activePage={page}
        activePageSize={pageSize}
        onPageChange={(value) => setPage(value)}
        onPageSizeChange={(value) => setPageSize(value)}
        loading={tab === 0 ? appUsersLoading : employeesLoading}
        rows={
          (tab === 0
            ? appUsersData?.data?.users
            : employeesData?.data?.users) || []
        }
        idKey="_id"
        columns={[
          {
            key: "name",
            label: "Name",
            Render: (row) => {
              let { firstName, lastName } = row;
              return firstName || lastName
                ? `${firstName || ""} ${lastName || ""}`
                : "-";
            },
          },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          {
            key: "actions",
            label: "Actions",
            Render: (row) => (
              <Button
                variant="action"
                onClick={() =>
                  drawer.open(<DrawerContent type="user" user={row} />)
                }
              >
                View
              </Button>
            ),
          },
        ]}
      />
    </>
  );
};

const UserGroups = (usersProps: any) => {
  const { canWrite } = getPermissions("charger:users");
  const [createDialog, setCreateDialog] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState({ open: false, data: null });

  const [userGroups, setUserGroups] = useState([]);

  const { loading, data } = useQuery(GET_USER_GROUPS);

  const [tab, setTab] = useState(0);

  useEffect(() => {
    if (data) {
      setUserGroups(data.userGroup.getAll);
    } else {
      setUserGroups([]);
    }
  }, [data, loading]);

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <>
      <Box
        sx={{
          p: 3,
          pb: 2.75,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box width="fit-content" height={40}>
          <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
            <Tab
              label="All"
              className="hasCount"
              sx={{
                "&:after": {
                  content: `"${userGroups.length || "-"}"`,
                },
              }}
            />
          </Tabs>
        </Box>
        {canWrite && (
          <Button
            sx={{ height: 40, textTransform: "none" }}
            startIcon={<Add />}
            color="primary"
            variant="contained"
            onClick={() => setCreateDialog(true)}
          >
            Create New
          </Button>
        )}
      </Box>
      <CreateDialog
        open={createDialog}
        handleClose={() => setCreateDialog(false)}
        {...usersProps}
      />
      <DeleteDialog
        open={deleteDialog.open}
        handleClose={() => setDeleteDialog({ ...deleteDialog, open: false })}
        group={deleteDialog.data}
      />
      <TableComponent
        loading={loading}
        rows={userGroups}
        columns={[
          { key: "name", label: "Group Name" },
          {
            key: "status",
            label: "Status",
            Render: (row) => (
              <Avatar
                variant="status"
                className={row.status !== "ACTIVE" ? "red" : ""}
              >
                {row.status}
              </Avatar>
            ),
          },
          {
            key: "users",
            label: "Users",
            Render: (row) => (
              <Box display="flex" alignItems="center">
                {row.users.length}
                <IconButton
                  size="small"
                  sx={{
                    ml: 0.5,
                    color: (theme) => theme.customColors.action,
                  }}
                  onClick={() =>
                    drawer.open(<DrawerContent type="group" group={row} />)
                  }
                >
                  <InfoOutlined fontSize="small" />
                </IconButton>
              </Box>
            ),
          },
          {
            key: "subscriptionPolicy",
            label: "Subscription",
            Render: (row) => row.subscriptionPolicy.name,
          },
          ...(canWrite
            ? [
                {
                  key: "actions",
                  label: "Actions",
                  Render: (row: any) => (
                    <Box display="flex">
                      {/* <IconButton
                    size='small'
                    sx={{ color: theme => theme.customColors.grey }}
                  >
                    <EditOutlined fontSize='small' />
                  </IconButton> */}
                      <Tooltip title="Delete User Group">
                        <IconButton
                          size="small"
                          sx={{ color: (theme) => theme.customColors.grey }}
                          onClick={() =>
                            setDeleteDialog({ open: true, data: row })
                          }
                        >
                          <DeleteOutline fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  ),
                },
              ]
            : []),
        ]}
      />
    </>
  );
};

export default List;
