import {
  ErrorOutline,
  FullscreenOutlined,
  HighlightOff,
  KeyboardArrowLeft,
  KeyboardArrowRight,
} from "@mui/icons-material";
import {
  Avatar,
  Box,
  Button,
  Checkbox,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  IconButton,
  ImageList,
  ImageListItem,
  ImageListItemBar,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
  useTheme,
} from "@mui/material";

import React, { useEffect, useState } from "react";
import { useMutation, useQuery } from "react-query";
import SwipeableViews from "react-swipeable-views";
import { authorizedFetch, setLoader, snackbar, getPermissions } from "utils";
import { KYC_URL } from "utils/constants";

const UpdateKYC = ({ user, open, handleClose, refetchKYCList }: any) => {
  const { canWrite } = getPermissions("charger:chargers");

  const [step, setStep] = useState<number>(0);
  const steps = ["Update", "Finish"];
  const [images, setImages] = useState<any>([]);
  const [selectedImages, setSelectedImages] = useState<any>([]);

  const error = images.find((c: any) => c.selected === true) !== 2;
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;
  const [status, setStatus] = useState("APPROVE");
  const [note, setNote] = useState("");
  const [reason, setReason] = useState("");

  const [fullscreenDialog, setFullscreenDialog] = useState({
    open: false,
    images: [],
  });

  const disabledApprove = selectedImages.length !== 2;

  const disabledReject = [note, reason].includes("");

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![selectImagesURL].includes("");
      case 1:
        return ![note, reason].includes("");

      default:
        break;
    }
  }

  const url = `${KYC_URL}/product/${user?.chargerId}`;
  const { isLoading, data } = useQuery(["getKyc", user, open], () =>
    authorizedFetch(url)
  );

  const updateKYCURL = `${KYC_URL}/company/product/handle`;
  const updateMutation = useMutation(
    ["handleProductKyc"],
    () =>
      authorizedFetch(updateKYCURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          productId: user?.chargerId,
          action: status,
          remark: status === "REJECT" ? reason : "KYC Approved",
          internalRemark: note,
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        refetchKYCList();
        snackbar.success(`KYC updated`);
        handleClose();
      },
      onError: () => {
        setLoader(false);
        snackbar.error(`Error updating KYC`);
      },
    }
  );

  const selectImagesURL = `${KYC_URL}/company/product/chargers/select/images`;
  const selectImagesMutation = useMutation(
    ["selectChargerImages"],
    () =>
      authorizedFetch(selectImagesURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          productId: user?.chargerId,
          docs: selectedImages.map(({ name, ...image }: any) => {
            return image;
          }),
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        refetchKYCList();
        snackbar.success(`KYC updated`);
        handleClose();
      },
      onError: () => {
        setLoader(false);
        snackbar.error(`Error updating KYC`);
      },
    }
  );

  const reasonsUrl = `${KYC_URL}/company/product/chargers/remarks`;
  const { isLoading: isReasonsLoading, data: reasons } = useQuery(
    ["remarks"],
    () => authorizedFetch(reasonsUrl)
  );

  const handleImageSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const imageArr = images.map((obj: any) =>
      obj.name === event.target.name
        ? { ...obj, selected: event.target.checked }
        : obj
    );
    setImages(imageArr);
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step: number) => {
    setActiveStep(step);
  };

  const onSave = () => {
    setLoader(true);
    updateMutation.mutate();
    selectImagesMutation.mutate();
    handleClose();
  };

  function handleNextStepper() {
    if (step === steps.length - 1) {
      onSave();
    } else setStep(step + 1);
  }
  function handleBackStepper() {
    setStep(step - 1);
  }

  useEffect(() => {
    if (images) {
      let imagesArr: any = [];
      // eslint-disable-next-line
      images.find((el: any) => {
        if (el.selected === true) {
          imagesArr.push({
            _id: el._id,
            url: el.url,
            selected: true,
            name: el.name,
          });
        }
      });
      setSelectedImages(imagesArr);
    }
  }, [images]);

  useEffect(() => {
    if (data) {
      let imageArr: any = [];
      // eslint-disable-next-line
      data?.data?.documents.map((el: any) => {
        imageArr.push({
          url: el.url,
          _id: el._id,
          selected: el.selected,
          name: `Image No. ${imageArr.length + 1}`,
        });
      });
      setImages(imageArr);
    }
  }, [data]);

  useEffect(() => {
    if (open && user) {
      setStatus(
        user?.status === "APPROVED"
          ? "APPROVE"
          : user?.status === "REJECTED"
          ? "REJECT"
          : "APPROVE"
      );
    }
    if (!open) {
      setActiveStep(0);
      setSelectedImages([]);
      setNote("");
      setStep(0);
      setImages([]);
    }
  }, [open, user]);

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          sx: {
            maxWidth: 800,
            width: 1,
            "& .MuiInputBase-root": {
              fontSize: 14,
              borderRadius: 1,
              p: "3.5px 5px",
            },
          },
        }}
      >
        <DialogTitle
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box display="flex">
            {canWrite ? "Update" : "View"} KYC
            <Divider flexItem orientation="vertical" sx={{ mx: 1.5 }} />
            <Box display="flex" alignItems="center" fontSize={14}>
              {user.chargerId}
              <Avatar
                variant="status"
                className={user.status === "REJECTED" ? "red" : "yellow"}
                sx={{ ml: 2 }}
              >
                {user.status}
              </Avatar>
            </Box>
          </Box>

          <IconButton
            // sx={{ transform: "translate(3px, -3px)" }}
            children={<HighlightOff />}
            onClick={handleClose}
          />
        </DialogTitle>
        <DialogContent sx={{ mt: 3 }}>
          {canWrite && (
            <Stepper
              sx={{ mb: 4, mx: "auto", maxWidth: 500 }}
              activeStep={step}
              nonLinear
              alternativeLabel
            >
              {steps.map((label, i) => (
                <Step key={i}>
                  <StepButton onClick={() => setStep(i)}>{label}</StepButton>
                </Step>
              ))}
            </Stepper>
          )}

          {step === 0 && (
            <>
              <Typography className="label">KYC Documents</Typography>
              {isLoading ? (
                <Box
                  display="flex"
                  justifyContent="center"
                  alignItems="center"
                  height="200px"
                >
                  <CircularProgress size={24} />
                </Box>
              ) : (
                <Box
                  width="100%"
                  height="350px"
                  display="flex"
                  alignItems="center"
                  sx={{ position: "relative" }}
                  mt={3}
                >
                  <Box
                    sx={{
                      position: "absolute",
                      top: 0,
                      left: "auto",
                      right: 0,
                      zIndex: 2,
                    }}
                  >
                    <Button
                      size="medium"
                      onClick={() => {
                        setFullscreenDialog({
                          open: true,
                          images: images,
                        });
                      }}
                    >
                      <FullscreenOutlined
                        sx={{
                          width: 25,
                          // background: "#00000010",
                          borderRadius: 1,
                        }}
                      />
                    </Button>
                  </Box>
                  <Box
                    width="100%"
                    height="100%"
                    sx={{
                      position: "absolute",
                      top: 0,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      zIndex: 1,
                    }}
                  >
                    <Button
                      size="medium"
                      onClick={handleBack}
                      disabled={activeStep === 0}
                    >
                      <KeyboardArrowLeft />
                    </Button>
                    <Button
                      size="small"
                      onClick={handleNext}
                      disabled={activeStep === maxSteps - 1}
                    >
                      <KeyboardArrowRight />
                    </Button>
                  </Box>
                  <SwipeableViews
                    axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                    index={activeStep}
                    onChangeIndex={handleStepChange}
                    enableMouseEvents
                  >
                    {images.map((step: any, index: any) => (
                      <div key={step.label}>
                        {Math.abs(activeStep - index) <= 2 ? (
                          <Box
                            component="img"
                            sx={{
                              height: "350px",
                              display: "block",
                              maxWidth: "100%",
                              maxHeight: "100%",
                              overflow: "hidden",
                              width: "100%",
                              objectFit: "contain",
                            }}
                            src={step.url}
                            alt={" "}
                          />
                        ) : null}
                      </div>
                    ))}
                  </SwipeableViews>
                </Box>
              )}

              {canWrite && (
                <>
                  <Box
                    sx={{
                      mt: 4,
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      className="label"
                      sx={{
                        mb: "0 !important",
                        mr: 2,
                      }}
                    >
                      Select Status
                    </Typography>
                    {isLoading ? (
                      <Box
                        display="flex"
                        justifyContent="center"
                        alignItems="center"
                        height="200px"
                      >
                        <CircularProgress size={24} />
                      </Box>
                    ) : (
                      <RadioGroup
                        row
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                      >
                        <FormControlLabel
                          value="APPROVE"
                          control={<Radio />}
                          label="Approve"
                        />

                        <FormControlLabel
                          value="REJECT"
                          control={<Radio />}
                          label="Reject"
                        />
                      </RadioGroup>
                    )}
                  </Box>
                  {status === "APPROVE" ? (
                    <>
                      <Typography mt={5} className="label">
                        Select 2 Thumbnails
                      </Typography>
                      <ImageList
                        sx={{
                          width: "100%",
                          height: "auto",
                          transform: "translateZ(0)",
                        }}
                        cols={3}
                        rowHeight={"auto"}
                        gap={20}
                      >
                        {images.map((image: any, i: any) => {
                          const cols = 1;
                          const rows = 1;

                          return (
                            <ImageListItem
                              key={image.url}
                              cols={cols}
                              rows={rows}
                              sx={{ mt: 1 }}
                            >
                              <img
                                src={image.url}
                                alt={image.name}
                                loading="lazy"
                              />
                              <ImageListItemBar
                                sx={{
                                  background: "#00000099",
                                  "& .MuiImageListItemBar-title": {
                                    color: "white",
                                  },
                                }}
                                // title={`Image No. ${i + 1}`}
                                position="top"
                                actionIcon={
                                  <FormControl
                                    required
                                    error={error}
                                    component="fieldset"
                                    variant="standard"
                                  >
                                    <FormGroup sx={{ fontColor: "white" }}>
                                      <FormControlLabel
                                        sx={{
                                          "& .MuiTypography-root": {
                                            color: "white",
                                          },
                                        }}
                                        control={
                                          <Checkbox
                                            checked={image.selected}
                                            onChange={handleImageSelection}
                                            name={`Image No. ${i + 1}`}
                                            sx={{
                                              ml: 2,
                                              color: "white",
                                            }}
                                          />
                                        }
                                        label={`Image No. ${i + 1}`}
                                      />
                                    </FormGroup>
                                  </FormControl>
                                }
                                actionPosition="left"
                              />
                            </ImageListItem>
                          );
                        })}
                      </ImageList>
                    </>
                  ) : (
                    <>
                      <Box
                        sx={{
                          my: 3,
                          display: "flex",
                          alignItems: "center",
                        }}
                      >
                        <Typography className="label" mt={1} mr={8}>
                          Reason
                        </Typography>
                        {isReasonsLoading ? (
                          <CircularProgress />
                        ) : (
                          <Select
                            sx={{ width: 277 }}
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            displayEmpty
                          >
                            <MenuItem value="" disabled>
                              <em>Select</em>
                            </MenuItem>
                            {(reasons?.data || []).map((el: any, i: number) => (
                              <MenuItem key={i} value={el}>
                                {el}
                              </MenuItem>
                            ))}
                          </Select>
                        )}
                      </Box>
                      <Typography className="label" mb={1}>
                        Add a Note
                      </Typography>
                      <TextField
                        sx={{
                          width: 1,
                          maxWidth: 400,
                          "& textarea": { p: 1 },
                        }}
                        multiline
                        rows={3}
                        placeholder="Please add a brief note for the reason for rejection..."
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                      />
                    </>
                  )}
                </>
              )}
            </>
          )}
          {step === 1 && (
            <Box
              sx={{
                maxWidth: "100%",
                width: 560,
                mx: "auto",
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      bgcolor: (theme) => theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& span": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 3,
                  },
                },
              }}
            >
              <table className="table">
                <tbody>
                  {[
                    { header: "Selected Status", onEdit: () => setStep(0) },
                    {
                      label: "Status",
                      value: status === "APPROVE" ? "APPROVED" : "REJECTED",
                      required: true,
                    },
                    ...(status === "APPROVE"
                      ? [
                          {
                            header: "Selected Images",
                            onEdit: () => setStep(0),
                            key: "image",
                          },
                          ...(selectedImages.length !== 2
                            ? [
                                {
                                  key: "select-2",
                                },
                              ]
                            : []),
                          ...selectedImages.map((el: any) => ({
                            label: el.name,
                            value: el.url,
                            key: "image",
                          })),
                        ]
                      : [
                          {
                            header: "Note",
                            onEdit: () => setStep(0),
                          },
                          {
                            label: "Reason for Rejection",
                            value: reason,
                            required: true,
                          },
                          {
                            label: "Note",
                            value: note,
                            required: true,
                            key: "note",
                          },
                        ]),
                  ].map(
                    (
                      { header, onEdit, label, value, required, key },
                      i,
                      arr
                    ) => {
                      const isFirst = arr[i - 1]?.header;
                      const isLast = !arr[i + 1] || arr[i + 1].header;

                      return (
                        <tr
                          key={i}
                          className={
                            header
                              ? "header"
                              : `${isFirst ? "first" : ""} ${
                                  isLast ? "last" : ""
                                }`
                          }
                        >
                          {header ? (
                            <td
                              colSpan={2}
                              style={{ display: "flex", alignItems: "center" }}
                            >
                              <span>{header}</span>
                              {/* <IconButton
                                sx={{ ml: 1.5 }}
                                children={<EditOutlined />}
                                color="primary"
                                size="small"
                                onClick={onEdit}
                              /> */}
                            </td>
                          ) : (
                            <>
                              {key === "image" ? (
                                <>
                                  <td>{label}</td>
                                  <td className="bold">
                                    {required &&
                                    ["", null, undefined].includes(value) ? (
                                      <Box display="flex" alignItems="center">
                                        <ErrorOutline
                                          fontSize="small"
                                          color="error"
                                          sx={{ mr: 1 }}
                                        />
                                        Required
                                      </Box>
                                    ) : (
                                      <>
                                        <div
                                          style={{
                                            width: "150px",
                                            maxWidth: "150px",
                                            height: "auto",
                                            objectFit: "contain",
                                          }}
                                        >
                                          <img
                                            style={{
                                              objectFit: "contain",
                                              width: "150px",
                                              height: "auto",
                                            }}
                                            src={value}
                                            alt={label}
                                          />
                                        </div>
                                      </>
                                    )}
                                  </td>
                                </>
                              ) : key === "select-2" ? (
                                <>
                                  {/* <td></td> */}
                                  <td>
                                    <Box display="flex" alignItems="center">
                                      <ErrorOutline
                                        fontSize="small"
                                        color="error"
                                        sx={{ mr: 1 }}
                                      />
                                      Please select 2 images
                                    </Box>
                                  </td>
                                </>
                              ) : (
                                <>
                                  <td>{label}</td>
                                  <td className="bold">
                                    {required &&
                                    ["", null, undefined].includes(value) ? (
                                      <Box display="flex" alignItems="center">
                                        <ErrorOutline
                                          fontSize="small"
                                          color="error"
                                          sx={{ mr: 1 }}
                                        />
                                        Required
                                      </Box>
                                    ) : (
                                      value
                                    )}
                                  </td>
                                </>
                              )}
                            </>
                          )}
                        </tr>
                      );
                    }
                  )}
                </tbody>
              </table>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          {canWrite && (
            <>
              {step !== 0 && (
                <Button variant="outlined" onClick={handleBackStepper}>
                  Back
                </Button>
              )}
              {step === 0 && (
                <Button variant="outlined" onClick={handleClose}>
                  Cancel
                </Button>
              )}
              <Button
                onClick={handleNextStepper}
                variant="contained"
                color={
                  isComplete(step) || step === steps.length - 1
                    ? "primary"
                    : "inherit"
                }
                disableElevation
                disabled={
                  step === steps.length - 1 &&
                  (status === "APPROVE" ? disabledApprove : disabledReject)
                }
              >
                {step === steps.length - 1 ? "Save" : "Next"}
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>
      <FullscreenImage
        open={fullscreenDialog.open}
        handleClose={() => {
          setFullscreenDialog({ ...fullscreenDialog, open: false });
        }}
        images={fullscreenDialog.images}
        activeStep={activeStep}
        handleBack={handleBack}
        handleNext={handleNext}
        handleStepChange={handleStepChange}
        user={user}
      />
    </>
  );
};

const FullscreenImage = ({
  open,
  handleClose,
  activeStep,
  images,
  user,
  handleBack,
  handleNext,
  handleStepChange,
}: any) => {
  const theme = useTheme();

  const maxSteps = images.length;

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      sx={{
        "& .MuiPaper-root": {
          maxWidth: "1200px",
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box>
          KYC Documents:
          <span style={{ marginLeft: 10, fontSize: 14 }}>
            {user?.chargerId}
          </span>
        </Box>

        <IconButton
          sx={{ transform: "translate(8px, -8px)" }}
          children={<HighlightOff />}
          onClick={handleClose}
        />
      </DialogTitle>
      <DialogContent
        sx={{
          mb: 3,
          mt: 1,
        }}
      >
        <Box
          height="75vh"
          display="flex"
          alignItems="center"
          sx={{ position: "relative" }}
        >
          <Box
            width="100%"
            height="100%"
            sx={{
              position: "absolute",
              top: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              zIndex: 1,
            }}
          >
            <Button
              size="medium"
              onClick={handleBack}
              disabled={activeStep === 0}
            >
              <KeyboardArrowLeft />
            </Button>
            <Button
              size="small"
              onClick={handleNext}
              disabled={activeStep === maxSteps - 1}
            >
              <KeyboardArrowRight />
            </Button>
          </Box>
          <SwipeableViews
            axis={theme.direction === "rtl" ? "x-reverse" : "x"}
            index={activeStep}
            onChangeIndex={handleStepChange}
            enableMouseEvents
          >
            {images.map((step: any, index: any) => (
              <div key={step.label}>
                {Math.abs(activeStep - index) <= 2 ? (
                  <Box
                    component="img"
                    sx={{
                      height: "65vh",
                      display: "block",
                      maxWidth: "100%",
                      maxHeight: "100%",
                      overflow: "hidden",
                      width: "100%",
                      objectFit: "contain",
                    }}
                    src={step.url}
                    alt={" "}
                  />
                ) : null}
              </div>
            ))}
          </SwipeableViews>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default UpdateKYC;
