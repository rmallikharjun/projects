// import { gql, useQuery } from "@apollo/client";
// import { DeleteOutline } from "@mui/icons-material";
import { Avatar, Box, Button, Hidden, Paper, Tab, Tabs } from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { authorizedFetch, drawer, snackbar, getPermissions } from "utils";
import { KYC_URL } from "utils/constants";
// import DrawerContent from "./DrawerContent";
import UpdateKYC from "./UpdateKYC";
import { useQuery } from "react-query";
import moment from "moment";
import Search from "../../../components/Search";

// const GET_USERS = gql`
//   query Account {
//     account {
//       me {
//         company {
//           rentalUsers {
//             id
//             firstName
//             lastName
//             email
//             phone
//             kyc {
//               status
//             }
//           }
//         }
//       }
//     }
//   }
// `;

const KYC = () => {
  const { canWrite } = getPermissions("charger:chargers");
  const [tab, setTab] = useState(0);
  const [search, setSearch] = useState("");

  const [tabCounts, setTabCounts] = useState({
    all: 0,
    submitted: 0,
    approved: 0,
    rejected: 0,
  });
  // const { data, loading } = useQuery(GET_USERS);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { all, submitted, approved, rejected } = tabCounts;

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  // useEffect(() => {
  //   if (data) {
  //     let allUsers = data?.account?.me?.company?.rentalUsers || [];
  //     let rows = {
  //       all: [],
  //       approved: [],
  //       pending: [],
  //       rejected: [],
  //       required: [],
  //     };
  //     rows.all = allUsers;
  //     rows.approved = allUsers.filter(
  //       (user: any) => user.kyc?.status === "APPROVED"
  //     );
  //     rows.pending = allUsers.filter(
  //       (user: any) => user.kyc?.status === "PENDING"
  //     );
  //     rows.rejected = allUsers.filter(
  //       (user: any) => user.kyc?.status === "REJECTED"
  //     );
  //     rows.required = allUsers.filter(
  //       (user: any) =>
  //         !["APPROVED", "PENDING", "REJECTED"].includes(user.kyc?.status)
  //     );
  //     setRows(rows);
  //   }
  // }, [data]);

  // const url = `${KYC_URL}/company/product/chargers?tab=${
  //   tab === 0
  //     ? "ALL"
  //     : tab === 1
  //     ? "SUBMITTED"
  //     : tab === 2
  //     ? "REJECTED"
  //     : tab === 3
  //     ? "APPROVED"
  //     : "ALL"
  // }&first=${pageSize}&skip=${pageSize * (page - 1)}`;

  const url = `${KYC_URL}/company/product/chargers?${
    !search
      ? `tab=${
          tab === 0
            ? "ALL"
            : tab === 1
            ? "SUBMITTED"
            : tab === 2
            ? "REJECTED"
            : tab === 3
            ? "APPROVED"
            : "ALL"
        }&first=${pageSize}&skip=${pageSize * (page - 1)}`
      : `first=${pageSize}&skip=${pageSize * (page - 1)}&search=${search}`
  }
  
  `;

  const {
    isLoading,
    data,
    refetch: refetchKYCList,
  } = useQuery(
    ["getChargersKYC", tab, page, pageSize, search],
    () => authorizedFetch(url),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  const statsUrl = `${KYC_URL}/company/product/chargers/stats`;

  const { data: statsData } = useQuery(
    ["getChargerKycStats", tab, data],
    () => authorizedFetch(statsUrl),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  useEffect(() => {
    if (statsData) {
      setTabCounts({
        all: statsData?.data?.totalCount,
        submitted: statsData?.data?.submittedCount,
        approved: statsData?.data?.approvedCount,
        rejected: statsData?.data?.rejectedCount,
      });
    }
  }, [statsData]);

  useEffect(() => {
    setPage(1);
    setPageSize(10);
  }, [tab]);

  const [updateDialog, setUpdateDialog] = useState({ open: false, user: [] });

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs
              className="dense"
              value={tab}
              onChange={(e, tab) => setTab(tab)}
            >
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${all}"`,
                  },
                }}
              />
              <Tab
                label="Submitted"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${submitted}"`,
                  },
                }}
              />
              <Tab
                label="Rejected"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${rejected}"`,
                  },
                }}
              />
              <Tab
                label="Approved"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${approved}"`,
                  },
                }}
              />
            </Tabs>
          </Box>
          <Box display="flex">
            <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden>
          </Box>
          {/* <FilterBy /> */}
        </Box>
        <Table
          loading={isLoading}
          rowCount={data?.data?.count}
          rows={data?.data?.chargers || []}
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          columns={[
            { key: "chargerId", label: "Charger UID" },
            {
              key: "userName",
              label: "Name",
              Render: (row) =>
                row.userName
                  ? row.userName
                  : row.userEmail
                  ? row.userEmail
                  : "-",
            },
            { key: "userEmail", label: "Email" },
            { key: "userPhone", label: "Phone" },
            // { key: "phone", label: "Phone" },
            {
              key: "createdAt",
              label: "Added On",
              Render: (row) => (
                <Box>{moment(row.createdAt).format("ddd, MMM DD, YYYY")}</Box>
              ),
            },
            {
              key: "status",
              label: "Status",
              Render: (row) => (
                <Avatar
                  variant="status"
                  className={
                    row.status === "REJECTED"
                      ? "red"
                      : row.status === "SUBMITTED"
                      ? "yellow"
                      : ""
                  }
                >
                  {row.status}
                </Avatar>
              ),
            },

            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => {
                    setUpdateDialog({ open: true, user: row });
                  }}
                >
                  {canWrite ? "Update" : "View"}
                </Button>
              ),
            },
          ]}
          // toolbar={() => (
          //   <>
          //     <Button startIcon={<DeleteOutline />}>Delete</Button>
          //   </>
          // )}
        />
      </Paper>
      <UpdateKYC
        open={updateDialog.open}
        handleClose={() => {
          setUpdateDialog({ ...updateDialog, open: false });
        }}
        user={updateDialog.user}
        refetchKYCList={refetchKYCList}
      />
    </>
  );
};

export default KYC;
