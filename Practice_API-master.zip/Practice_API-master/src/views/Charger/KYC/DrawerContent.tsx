import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import {
  EditOutlined,
  HighlightOff,
  KeyboardArrowLeft,
  KeyboardArrowRight,
  FullscreenOutlined,
} from "@mui/icons-material";
import {
  Box,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Avatar,
  Typography,
  CircularProgress,
  useTheme,
} from "@mui/material";
import {
  authorizedFetch,
  drawer,
  getDarkModePreference,
  getPermissions,
  GlobalState,
  snackbar,
} from "utils";
// import { gql } from "@apollo/client";
import { useQuery } from "react-query";
import SwipeableViews from "react-swipeable-views";
import { KYC_URL } from "utils/constants";

// const GET_KYC_DOCS = gql`
//   query KYCDocuments($companyId: ID, $userId: ID) {
//     company {
//       get(where: { id: $companyId }) {
//         rentalUsers(where: { id: $userId }) {
//           kyc {
//             associations {
//               kyc {
//                 documents {
//                   id
//                   file {
//                     buffer
//                   }
//                   type
//                   status
//                 }
//               }
//             }
//           }
//         }
//       }
//     }
//   }
// `;

const DrawerContent = ({ user }: any) => {
  const [deleteDialog, setDeleteDialog] = useState(false);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  // const { company } = useSelector((state: GlobalState) => state.global);
  // const [docs, setDocs] = useState([]);
  // const [viewDialog, setViewDialog] = useState({ open: false, doc: null });
  const { canWrite } = getPermissions("charger:chargers");

  let { firstName, lastName } = user;
  // let name =
  //   firstName || lastName ? `${firstName || ""} ${lastName || ""}` : "-";

  let table = [
    { header: "User Details" },
    { label: "Charger UID", value: user?.chargerId },
    { label: "Name", value: user?.userName },
    { label: "Email", value: user?.userEmail },
    { label: "Phone", value: user?.userPhone || "-" },
  ];
  let selectImage = [{ header: "Selected Image" }];

  // const [getDocs, { loading, data }] = useLazyQuery(GET_KYC_DOCS, {
  //   variables: {
  //     userId: user?.id,
  //     companyId: company.id,
  //   },
  // });

  // useEffect(() => {
  //   getDocs();
  // }, [user, getDocs]);

  // useEffect(() => {
  //   if (data) {
  //     let docs =
  //       data.company?.get?.rentalUsers[0]?.kyc?.associations[0]?.kyc
  //         ?.documents || [];
  //     setDocs(docs);
  //   }
  // }, [data]);

  function DeleteHandleClose() {
    setDeleteDialog(false);
  }

  const url = `${KYC_URL}/product/${user?.chargerId}`;

  const { isLoading, data } = useQuery(
    ["getKyc", user],
    () =>
      authorizedFetch(url, {
        headers: {
          token: "39efcnegzzzegc",
        },
      }),
    {
      onError: () => snackbar.error("Error fetching data"),
    }
  );

  console.log(data);

  const [images, setImages] = useState<any>([]);

  useEffect(() => {
    if (data) {
      let imageArr: any = [];
      data?.data?.supportDocuments.map((el: any) => {
        imageArr.push({ url: el.url, id: el._id });
      });
      setImages(imageArr);
    }
  }, [data]);

  console.log(images);

  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step: number) => {
    setActiveStep(step);
  };

  const [updateDialog, setUpdateDialog] = useState({ open: false, user: "" });
  const [fullscreenDialog, setFullscreenDialog] = useState({
    open: false,
    images: [],
  });

  return (
    <>
      {/* <ViewDialog
        open={viewDialog.open}
        handleClose={() => setViewDialog((prev) => ({ ...prev, open: false }))}
        doc={viewDialog.doc}
      /> */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box display="flex" alignItems="center">
            {user.chargerId}
            <Avatar
              variant="status"
              className={user.status === "REJECTED" ? "red" : ""}
              sx={{
                color: user.status === "SUBMITTED" ? "#ffc800" : "",
                background: user.status === "SUBMITTED" ? "#FFFF0030" : "",
                border: user.status === "SUBMITTED" ? "#FFFF0030" : "",
                ml: 2,
              }}
            >
              {user.status}
            </Avatar>
          </Box>
          <Box>
            <Button
              variant="contained"
              size="small"
              onClick={() =>
                setUpdateDialog({
                  open: true,
                  user: user,
                })
              }
              sx={{ mr: 1 }}
            >
              Update Status
            </Button>
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              py: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  position: "relative",
                  "& td": {
                    py: 2,
                    position: "absolute",
                    verticalAlign: "middle",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(({ header, label, value }, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                        </td>
                      ) : (
                        <>
                          {label && <td className="bold">{label}</td>}
                          {value && <td>{value}</td>}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <Box
              sx={{
                mb: 3,
                px: 2,
                py: 1.5,
                width: 1,
                backgroundColor: (theme) => theme.customColors.header,
                borderRadius: "4px",
                fontSize: 16,
                fontWeight: 600,
              }}
            >
              KYC Documents
            </Box>
            {isLoading ? (
              <Box
                display="flex"
                justifyContent="center"
                alignItems="center"
                height="200px"
              >
                <CircularProgress size={24} />
              </Box>
            ) : (
              <Box
                width="100%"
                height="350px"
                display="flex"
                alignItems="center"
                sx={{ position: "relative" }}
              >
                <Box
                  sx={{
                    position: "absolute",
                    top: 0,
                    left: "auto",
                    right: 0,
                    zIndex: 2,
                  }}
                >
                  <Button
                    size="medium"
                    onClick={() => {
                      setFullscreenDialog({
                        open: true,
                        images: images,
                      });
                    }}
                  >
                    <FullscreenOutlined
                      sx={{
                        width: 25,
                        // background: "#00000010",
                        borderRadius: 1,
                      }}
                    />
                  </Button>
                </Box>
                <Box
                  width="100%"
                  height="100%"
                  sx={{
                    position: "absolute",
                    top: 0,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    zIndex: 1,
                  }}
                >
                  <Button
                    size="medium"
                    onClick={handleBack}
                    disabled={activeStep === 0}
                  >
                    <KeyboardArrowLeft />
                  </Button>
                  <Button
                    size="small"
                    onClick={handleNext}
                    disabled={activeStep === maxSteps - 1}
                  >
                    <KeyboardArrowRight />
                  </Button>
                </Box>
                <SwipeableViews
                  axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                  index={activeStep}
                  onChangeIndex={handleStepChange}
                  enableMouseEvents
                >
                  {images.map((step: any, index: any) => (
                    <div key={step.label}>
                      {Math.abs(activeStep - index) <= 2 ? (
                        <Box
                          component="img"
                          sx={{
                            height: "350px",
                            display: "block",
                            maxWidth: "100%",
                            maxHeight: "100%",
                            overflow: "hidden",
                            width: "100%",
                            objectFit: "contain",
                          }}
                          src={step.url}
                          alt={" "}
                        />
                      ) : null}
                    </div>
                  ))}
                </SwipeableViews>
              </Box>
            )}

            <table className="table" style={{ marginTop: 30 }}>
              <tbody>
                {selectImage.map(({ header, label, value }: any, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <>
                          <td colSpan={2}>
                            <span>
                              {header}
                              {canWrite && (
                                <IconButton
                                  sx={{ ml: 1.5, p: 0 }}
                                  children={<EditOutlined />}
                                  color="primary"
                                  size="small"
                                  onClick={() => {
                                    setUpdateDialog({
                                      open: true,
                                      user: "",
                                    });
                                  }}
                                />
                              )}
                            </span>
                          </td>
                        </>
                      ) : (
                        <>
                          {label && <td className="bold">{label}</td>}
                          {value && <td>{value}</td>}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {selectImage.some((obj: any) =>
              Object.keys(obj).includes("label")
            ) ? (
              ""
            ) : (
              <Box mt={9} ml={2} mb={2}>
                <Typography fontSize={15}>No Images Selected Yet</Typography>
              </Box>
            )}

            {/* <Box px={2} display="grid" gap={2.25}>
              {isLoading ? (
                <CircularProgress />
              ) : docs.length > 0 ? (
                docs.map((doc: any, i) => (
                  <Box key={i} display="grid" gridTemplateColumns="1fr auto">
                    <Box
                      sx={{
                        p: 1.75,
                        bgcolor: "background.default",
                        borderRadius: 1,
                        display: "flex",
                        alignItems: "start",
                      }}
                    >
                      <Avatar
                        sx={{
                          width: 60,
                          height: 60,
                          mr: 2,
                          bgcolor: (theme) => theme.customColors.grey,
                          cursor: "zoom-in",
                        }}
                        onClick={() => setViewDialog({ open: true, doc })}
                        variant="rounded"
                      >
                        {doc?.file?.buffer ? (
                          <img
                            src={doc?.file.buffer}
                            width={60}
                            alt="KYC Document"
                          />
                        ) : (
                          <InsertDriveFileOutlined />
                        )}
                      </Avatar>
                      <Box>
                        <Typography
                          mb={1}
                          fontSize={16}
                          fontWeight={500}
                          color={isDarkMode ? "#fff" : "#000"}
                          lineHeight="18px"
                        >
                          {doc.type}
                        </Typography>
                        <Typography
                          mb={1.5}
                          fontSize={14}
                          lineHeight="16px"
                          color="text.secondary"
                        >
                          {doc.description}
                        </Typography>
                        <Box
                          display="flex"
                          alignItems="center"
                          color={
                            doc.status === "APPROVED"
                              ? "success.main"
                              : "error.main"
                          }
                        >
                          {doc.status === "APPROVED" ? (
                            <CheckCircleOutline sx={{ mr: 1, fontSize: 18 }} />
                          ) : (
                            <ErrorOutline sx={{ mr: 1, fontSize: 18 }} />
                          )}
                          <Typography
                            fontSize={12}
                            lineHeight="14px"
                            fontWeight={600}
                            color="inherit"
                          >
                            {doc.status}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                    <Box width={100}>
                      <Box
                        pl={3}
                        width={1}
                        height={1}
                        display="flex"
                        flexDirection="column"
                        justifyContent="space-evenly"
                      >
                        <Button
                          sx={{ width: "fit-content", textTransform: "none" }}
                          color="success"
                        >
                          Approve
                        </Button>
                        <Button
                          sx={{ width: "fit-content", textTransform: "none" }}
                          color="error"
                        >
                          Reject
                        </Button>
                      </Box>
                    </Box>
                  </Box>
                ))
              ) : (
                <Typography color="textSecondary">No documents</Typography>
              )}
            </Box> */}
          </Box>
        </Box>
      </Box>
      <DeleteVendor open={deleteDialog} handleClose={DeleteHandleClose} />
      <FullscreenImage
        open={fullscreenDialog.open}
        handleClose={() => {
          setFullscreenDialog({ ...fullscreenDialog, open: false });
        }}
        images={fullscreenDialog.images}
        smallActiveStep={activeStep}
        user={user}
      />
      <UpdateStatus
        open={updateDialog.open}
        handleClose={() => {
          setUpdateDialog({ ...updateDialog, open: false });
        }}
        user={updateDialog.user}
      />
    </>
  );
};

const FullscreenImage = ({
  open,
  handleClose,
  smallActiveStep,
  images,
  user,
}: any) => {
  const theme = useTheme();

  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step: number) => {
    setActiveStep(step);
  };

  useEffect(() => {
    if (smallActiveStep) {
      setActiveStep(smallActiveStep);
    }
  }, [smallActiveStep]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      sx={{
        "& .MuiPaper-root": {
          maxWidth: "1200px",
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box>
          KYC Documents:
          <span style={{ marginLeft: 10, fontSize: 14 }}>
            {user?.chargerId}
          </span>
        </Box>

        <IconButton
          sx={{ transform: "translate(8px, -8px)" }}
          children={<HighlightOff />}
          onClick={handleClose}
        />
      </DialogTitle>
      <DialogContent
        sx={{
          mb: 3,
          mt: 1,
        }}
      >
        <Box
          height="75vh"
          display="flex"
          alignItems="center"
          sx={{ position: "relative" }}
        >
          <Box
            width="100%"
            height="100%"
            sx={{
              position: "absolute",
              top: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              zIndex: 1,
            }}
          >
            <Button
              size="medium"
              onClick={handleBack}
              disabled={activeStep === 0}
            >
              <KeyboardArrowLeft />
            </Button>
            <Button
              size="small"
              onClick={handleNext}
              disabled={activeStep === maxSteps - 1}
            >
              <KeyboardArrowRight />
            </Button>
          </Box>
          <SwipeableViews
            axis={theme.direction === "rtl" ? "x-reverse" : "x"}
            index={activeStep}
            onChangeIndex={handleStepChange}
            enableMouseEvents
          >
            {images.map((step: any, index: any) => (
              <div key={step.label}>
                {Math.abs(activeStep - index) <= 2 ? (
                  <Box
                    component="img"
                    sx={{
                      height: "65vh",
                      display: "block",
                      maxWidth: "100%",
                      maxHeight: "100%",
                      overflow: "hidden",
                      width: "100%",
                      objectFit: "contain",
                    }}
                    src={step.url}
                    alt={" "}
                  />
                ) : null}
              </div>
            ))}
          </SwipeableViews>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

const ViewDialog = ({ open, handleClose, doc }: any) => {
  return (
    <Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
      <DialogTitle sx={{ display: "flex", justifyContent: "space-between" }}>
        {doc?.type || "KYC Document"}
        <IconButton
          sx={{ transform: "translate(8px, -8px)" }}
          children={<HighlightOff />}
        />
      </DialogTitle>
      <DialogContent className="py-1">
        <img src={doc?.file?.buffer || ""} width="100%" alt="KYC Document" />
      </DialogContent>
    </Dialog>
  );
};

interface DeleteVendorProps {
  open: any;
  handleClose: () => void;
}

const DeleteVendor: React.FC<DeleteVendorProps> = ({ open, handleClose }) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent>
        Are you sure you want to DELETE: <b>Booking</b>?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const UpdateStatus = ({ user, handleClose, open }: any) => {
  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Booking</DialogTitle>
      <DialogContent>
        Are you sure you want to DELETE: <b>Booking</b>?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          // onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DrawerContent;
