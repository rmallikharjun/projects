import { InfoOutlined } from "@mui/icons-material";
import {
  Box,
  Hidden,
  IconButton,
  Paper,
  Tooltip,
  useMediaQuery,
  useTheme,
  Tab,
  Tabs,
} from "@mui/material";
import Table from "components/Table";
import { useEffect, useState } from "react";
import { authorizedFetch, drawer, getPermissions } from "utils";
import DrawerContent from "./DrawerContent";
import moment from "moment";
import { useQuery } from "react-query";
import Search from "../../../components/Search";

const List = ({
  setSearch,
  masterView,
  refetchStats,
  setPage,
  setPageSize,
  chargersLoading,
  refetchChargers,
  page,
  pageSize,
}: any) => {
  const [tab, setTab] = useState(0);
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md") as any);
  const { canWrite } = getPermissions("charger:chargers");
  const [selectedRows, setSelectedRows] = useState<any>([]);

  const url = `https://bolt.dev.revos.in/company/powerOutputControls`;

  const { data: listData } = useQuery(["getList", masterView], () =>
    authorizedFetch(url, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    console.log("listData is => ", listData);
  }, [listData]);

  return (
    <>
      <Paper
        sx={{
          width: 1,
          // p: 3,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            p: { xs: 2, md: 3 },
            pb: 2.75,
            display: { xs: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box display="flex">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab
                label="Charging Zones"
                className="hasCount"
                // sx={{
                //   "&:after": {
                //     content: `"${listData?.data?.count || "-"}"`,
                //   },
                // }}
              />
              {masterView === "testTVS" ? (
                ""
              ) : (
                <Tab
                  label="PowerControl"
                  className="hasCount"
                  // sx={{
                  //   "&:after": {
                  //     content: `"${listData?.data?.count || "-"}"`,
                  //   },
                  // }}
                />
              )}
            </Tabs>
            {/* <Hidden mdDown>
              <Box>
                <Search
                  handleSearch={(value) => {
                    setSearch(value);
                  }}
                  persist
                  enableClear
                />
              </Box>
            </Hidden> */}
          </Box>
        </Box>
        <Table
          px={isMdUp ? 3 : 2}
          serverSidePagination
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={chargersLoading}
          setSelectedRows={setSelectedRows}
          selectedRows={selectedRows}
          selectable={canWrite}
          rows={listData?.data || []}
          rowCount={listData?.data}
          selectOnClick
          columns={[
            // {
            //   key: "ChargerId",
            //   label: " Charger Id",
            //    Render: (row) => <Box>{row?.chargers[0]?.chargerId}</Box>,
            //   //Render: (row) => "Test Data",
            // },
            {
              key: "name",
              label: "Name",
              Render: (row) => <Box sx={{ py: 2 }}> {row?.name || "-"}</Box>,
            },
            {
              key: "Autocutoff Value",
              label: "Autocutoff",
              Render: (row) => (
                <Box sx={{ py: 2 }}>
                  {row?.autoCutOff?.value + " Seconds" || "-"}
                </Box>
              ),
            },
            {
              key: "Power Output",
              label: " Power Output",
              Render: (row) => (
                <Box sx={{ py: 2 }}>
                  {row?.powerOutput?.value + " Amp" || "-"}
                </Box>
              ),
            },
            {
              key: "createdAt",
              label: "Created At",
              Render: (row) => (
                <Box>{moment(row?.createdAt).format("ddd, MMM DD, YYYY")}</Box>
              ),
            },
            {
              key: "updatedAt",
              label: "Updated At",
              Render: (row) => (
                <Box>{moment(row?.updatedAt).format("ddd, MMM DD, YYYY")}</Box>
              ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme: any) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() =>
                        drawer.open(
                          <DrawerContent
                            charger={row}
                            vendors={listData?.data || []}
                            refetchStats={refetchStats}
                            refetchChargers={refetchChargers}
                            openTab={0}
                          />
                        )
                      }
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default List;
