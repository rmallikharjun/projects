import {
  EditOutlined,
  HighlightOff,
  Add,
  DeleteOutline,
} from "@mui/icons-material";
import {
  Box,
  Tabs,
  Tab,
  IconButton,
  Typography,
  DialogContent,
  Button,
} from "@mui/material";
import RangePicker from "components/RangePicker";
import Map from "components/Map";
import { useState, useEffect } from "react";
import AssignChargers from "./AssignChargers";
import DeleteDialog from "./DeleteDialog";
// import { Line } from "react-chartjs-2";
import { useSelector } from "react-redux";
import { sub } from "date-fns";
import {
  drawer,
  getDarkModePreference,
  GlobalState,
  getPermissions,
} from "utils";
import EditChargers from "./EditChargers";
import ChargerHistory from "./ChargerHistory";

interface Props {
  charger: any;
  vendors: any;
  refetchStats: () => void;
  refetchChargers: () => void;
  openTab: number;
}

const DrawerContent: React.FC<Props> = ({
  charger,
  refetchStats,
  refetchChargers,
  openTab,
}) => {
  console.log(charger);
  const { canWrite } = getPermissions("charger:chargers");
  const [tab, setTab] = useState(openTab);
  const [editDialog, setEditDialog] = useState({
    open: false,
    count: 0,
  });
  const [range, setRange] = useState<any>([
    sub(new Date(), { months: 1 }),
    new Date(),
  ]);

  const [controls, setControls] = useState({
    companyInfo: [
      { label: "Name", value: "" },
      { label: "Current(A)", value: "" },
      { label: "Timer", value: "" },
    ],
  });

  useEffect(() => {
    if (charger) {
      setControls({
        companyInfo: [
          { label: "Name", value: charger?.name },
          { label: "Current(A)", value: charger?.powerOutput?.value },
          { label: "Timer", value: charger?.autoCutOff?.value },
        ],
      });
    }
    // eslint-disable-next-line
  }, [charger]);
  console.log("Value is: ", charger?.autoCutOff?.value);

  const [assignChargersDialog, setAssignChargersDialog] = useState(false);

  const drawerState = useSelector((state: GlobalState) => state.global.drawer);
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  const [deleteDialog, setDeleteDialog] = useState({
    open: false,
    id: "",
    name: "",
  });

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <IconButton />
          </Box>

          <Box display="flex">
            {canWrite && (
              <IconButton
                sx={{ mr: 1 }}
                children={<DeleteOutline />}
                color="inherit"
                size="small"
                onClick={() => {
                  setDeleteDialog({
                    open: true,
                    id: "",
                    name: "",
                  });
                }}
              />
            )}
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box pt={2} pr={2} pl={2}>
            <Tabs
              className="dense"
              value={tab}
              onChange={(e: any, tab: any) => {
                console.log(tab, "charger-drawer");
                setTab(tab);
              }}
              variant="scrollable"
            >
              <Tab label="Basic Details" />
              <Tab label="Assigned Chargers" />
              <Tab label="Insights" />
            </Tabs>
          </Box>
          {tab === 0 ? (
            <Box
              sx={{
                px: 3,
                pt: 2.5,
                "& .table": {
                  borderCollapse: "collapse",
                  width: 1,
                  fontSize: 14,
                  lineHeight: "16px",
                  "& td": {
                    py: 1.25,
                    px: 2,
                  },
                  "& .bold": {
                    fontWeight: 500,
                  },
                  "& .header": {
                    px: 2,
                    py: 1,
                    position: "relative",
                    "& td": {
                      position: "absolute",
                      verticalAlign: "middle",
                      backgroundColor: (theme: any) =>
                        theme.customColors.header,
                      width: 1,
                      borderRadius: "4px",
                      fontSize: 16,
                      fontWeight: 600,
                      "& .label": {
                        display: "inline-block",
                        transform: "translateY(1px)",
                        py: 1.125,
                      },
                    },
                  },
                  "& .first > td": {
                    pt: 9,
                  },
                  "& .last > td": {
                    pb: 2.75,
                  },
                },
              }}
            >
              <table className="table">
                <tbody></tbody>
              </table>
              <Box
                style={
                  {
                    // display: "flex",
                    // flexDirection: "column",
                    // height: 500,
                    // width: "100%",
                    // position: "relative",
                    // alignItems: "center",
                    // borderColor:'black',
                    // margin: 3,
                    // border: 1,
                  }
                }
              >
                <DialogContent sx={{ pb: "16px !important" }}>
                  <table className="table">
                    <tbody>
                      <tr className="header">
                        <td colSpan={1}>
                          <span className="label">Power Info</span>
                          {canWrite && (
                            <IconButton
                              sx={{ ml: 2.5 }}
                              children={<EditOutlined />}
                              color="primary"
                              size="small"
                              onClick={() => {
                                setEditDialog({
                                  open: true,
                                  count: 0,
                                });
                              }}
                            />
                          )}
                        </td>
                      </tr>
                      {controls.companyInfo.map(({ label, value }, i) => (
                        <tr
                          key={controls.companyInfo.length + i}
                          className={
                            i === 0
                              ? "first"
                              : i === controls.companyInfo.length - 1
                              ? "last"
                              : ""
                          }
                        >
                          <td>{label}</td>
                          <td className="bold">{value || "Test data"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <Box
                    sx={{
                      maxWidth: { xs: 280, sm: 560 },
                      mx: "auto",
                      py: 3,
                      m: 7,
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                      gap: 3,
                    }}
                  ></Box>

                  <Box
                    sx={{
                      maxWidth: { xs: 280, sm: 560 },
                      mx: "auto",
                      py: 2,
                      display: "grid",
                      gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
                      gap: 3,
                    }}
                  ></Box>
                </DialogContent>
              </Box>
            </Box>
          ) : tab === 1 ? (
            <Box>
              <Box
                width={1}
                sx={{
                  mt: 3,
                  mb: { xs: 1.5, sm: 2.5 },
                  px: 2.5,
                  display: { sm: "flex" },
                  justifyContent: { sm: "space-between" },
                  alignItems: { sm: "center" },
                }}
              >
                <Typography
                  sx={{
                    mb: { xs: 1, sm: 0 },
                    fontSize: 14,
                    color: (theme: any) => theme.customColors.text.grey,
                    "& span": {
                      fontWeight: 500,
                      color: "text.primary",
                    },
                  }}
                >
                  Total Chargers Assigned:{" "}
                  {/* {vendorLoading ? (
                  <CircularProgress size={14} color="inherit" />
                ) : (
                  vendorData?.data?.chargers?.length || "0"
                )} */}
                </Typography>
                {canWrite && (
                  <Button
                    size="small"
                    sx={{ textTransform: "none" }}
                    color="inherit"
                    onClick={() => {
                      setAssignChargersDialog(true);
                    }}
                    startIcon={<Add />}
                    //disabled={vendorLoading}
                  >
                    Assign New
                  </Button>
                )}
              </Box>
              {/* <Table
              small
              loading={vendorLoading}
              selectedRows={selectedRows}
              setSelectedRows={setSelectedRows}
              selectable={canWrite}
              selectOnClick
              rows={vendorData?.data?.chargers || []}
              columns={[
                {
                  key: "chargerId",
                  label: "Charger UID",
                  Render: (row) => (
                    <Box sx={{ py: 2 }}>{row.charger.chargerId}</Box>
                  ),
                },
                {
                  key: "health",
                  label: "Health",
                  Render: (row) => (
                    <Avatar variant="status">{row.charger.health}</Avatar>
                  ),
                },
              ]}
              toolbar={() => (
                <Button
                  startIcon={<DeleteOutline />}
                  onClick={() => {
                    setUnassignChargersDialog({
                      open: true,
                      data: selectedRows,
                    });
                  }}
                >
                  Unassign
                </Button>
              )}
            /> */}
            </Box>
          ) : tab === 2 ? (
            <Box py={3} px={2.5}>
              <Box
                mb={2.5}
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                <Typography fontSize={18} fontWeight={500}>
                  Insights
                </Typography>
                <RangePicker range={range} setRange={setRange} />
              </Box>
              <Box
                sx={{
                  display: "grid",
                  gap: 2,
                  "& > div": {
                    border: 1,
                    bgcolor: isDarkMode ? "background.default" : "#fff",
                    borderColor: (theme: any) => theme.customColors.border,
                    borderRadius: 1,
                    p: 2.5,
                    display: "flex",
                    flexDirection: "column",
                    "& span": {
                      display: "flex",
                      alignItems: "center",
                      "& span": {
                        alignItems: "end",
                      },
                    },
                    "& .value": {
                      fontSize: "1.75rem",
                      fontWeight: 700,
                      lineHeight: "1.75rem",
                    },
                    "& .unit": {
                      ml: 0.75,
                    },
                    "& .title": {
                      ml: 1.5,
                      color: "text.secondary",
                    },
                  },
                }}
              ></Box>
            </Box>
          ) : tab === 3 ? (
            <Box p={2.5} height={436}>
              <Map
                loading={false}
                type="charger"
                borderRadius={1}
                location={charger.station.location}
              />
            </Box>
          ) : (
            <ChargerHistory data={charger} tab={tab} open={drawerState.open} />
          )}
        </Box>
      </Box>

      <AssignChargers
        open={assignChargersDialog}
        // vendor={vendor}
        // existingChargers={vendorData?.data?.chargers || []}
        handleClose={() => {
          setAssignChargersDialog(false);
        }}
      />

      <EditChargers
        open={editDialog.open}
        closeDrawer={() => drawer.close()}
        handleClose={() => {
          setEditDialog({ open: false, count: 0 });
        }}
        data={charger}
        count={editDialog.count}
        refetchStats={refetchStats}
        refetchChargers={refetchChargers}
      />
      <DeleteDialog
        open={deleteDialog.open}
        charger={{ id: charger.id, name: charger.name }}
        handleClose={() => {
          setDeleteDialog({ ...deleteDialog, open: false });
        }}
        // vendor={vendor}
      />
    </>
  );
};

// const LineChart: React.FC<{ isBlue?: boolean; data: any[] }> = ({
//   isBlue,
//   data,
// }) => {
//   const isDarkMode = useSelector((state: GlobalState) =>
//     getDarkModePreference(state)
//   );

//   return (
//     <Box
//       sx={{
//         flexGrow: 1,
//         position: "relative",
//         height: 70,
//         width: 1,
//         mb: "3px",
//       }}
//     >
//       <Line
//         height={10}
//         style={{ marginTop: 10 }}
//         data={(canvas) => {
//           const ctx = canvas.getContext("2d");
//           const g = ctx?.createLinearGradient(0, 0, 0, 60);

//           g?.addColorStop(
//             0,
//             isBlue ? "rgba(87, 184, 255, 0.7)" : "rgba(41, 203, 151, 0.6)"
//           );
//           g?.addColorStop(
//             0.5,
//             isBlue ? "rgba(87, 184, 255, 0.4)" : "rgba(41, 203, 151, 0.2)"
//           );
//           g?.addColorStop(
//             1,
//             isDarkMode ? "rgba(0, 0, 0, 0)" : "rgba(255, 255, 255, 0)"
//           );

//           let color = isBlue ? "rgb(87, 184, 255)" : "rgb(41, 203, 151)";

//           return {
//             // labels: data?.map(el => el.t),
//             datasets: [
//               {
//                 fill: true,
//                 data: data,
//                 borderColor: color,
//                 backgroundColor: g,
//                 tension: 0.4,
//                 pointRadius: 0,
//                 pointHoverRadius: 4,
//                 pointHoverBackgroundColor: "#fff",
//                 pointHoverBorderColor: color,
//                 pointHoverBorderWidth: 3,
//               },
//             ],
//           };
//         }}
//         options={{
//           scales: {
//             xAxis: {
//               display: false,
//               // type: "linear",
//               // type: 'time'
//             },
//             yAxis: {
//               display: false,
//             },
//           },
//           responsive: true,
//           maintainAspectRatio: false,
//           plugins: {
//             legend: {
//               display: false,
//             },
//             tooltip: {
//               caretSize: 0,
//               mode: "index",
//               intersect: false,
//               yAlign: "center",
//               displayColors: false,
//               caretPadding: 16,
//               titleFont: {
//                 weight: "400",
//               },
//               bodyFont: {
//                 weight: "500",
//               },
//             },
//           },
//           layout: {
//             padding: {
//               bottom: 20,
//             },
//           },
//           interaction: {
//             mode: "index",
//             intersect: false,
//           },
//         }}
//       />
//     </Box>
//   );
// };

export default DrawerContent;
