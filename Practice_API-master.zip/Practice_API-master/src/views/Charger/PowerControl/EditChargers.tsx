import { HighlightOff } from "@mui/icons-material";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Slider,
  TextField,
  Grid,
  // Tooltip,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { snackbar, setLoader, authorizedFetch } from "utils";
import { useMutation } from "react-query";
import MuiInput from "@mui/material/Input";
import { styled } from "@mui/material/styles";

import React from "react";

interface Props {
  open: boolean;
  handleClose: () => void;
  data: any;
  count: number;
  refetchStats: () => void;
  closeDrawer: () => void;
  refetchChargers: () => void;
}

const Input = styled(MuiInput)`
  width: 32px;
`;

type inputData = {
  name: string;
  powerOutput: number;
  autoCutOff: number;
};

const AddDialog: React.FC<Props> = ({ open, handleClose, data }) => {
  const [basicInput, setBasicInput] = useState<inputData>({
    name: data.name,
    powerOutput: data.powerOutput,
    autoCutOff: data.autoCutOff,
  });

  console.log("Output is", basicInput);

  const { name, powerOutput } = basicInput;

  const [value, setValue] = React.useState<
    number | string | Array<number | string>
  >(16);
  const [timerValue, setTimerValue] = React.useState<
    number | string | Array<number | string>
  >(255);

  const handleSliderChange = (event: Event, newValue: number | number[]) => {
    setValue(newValue);
  };

  const handleTimerChange = (event: Event, newValue: number | number[]) => {
    setTimerValue(newValue);
  };

  // const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setTimerValue(event.target.value === "" ? "" : Number(event.target.value));
  // };

  // const handleTimeSlider = (event: React.ChangeEvent<HTMLInputElement>) => {
  //   setTimerValue(event.target.value === "" ? "" : Number(event.target.value));
  // };

  const handleBlur = () => {
    if (value < 0) {
      setValue(0);
    } else if (value > 16) {
      setValue(16);
    }
  };

  const handleTimer = () => {
    if (value < 0) {
      setTimerValue(0);
    } else if (value > 255) {
      setTimerValue(255);
    }
  };

  const url = `https://bolt.dev.revos.in/company/powerOutputControl/update
  `;

  const updatePowerControl = useMutation(
    `updatePowerControl`,
    () => {
      console.log("test print data ");

      return authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: {
          _id: "6257e23f419b44677584b2f1",
          powerOutput: basicInput.powerOutput,
          autoCutOff: basicInput.autoCutOff,
        },
      });
    },
    {
      onSuccess: () => {
        setLoader(false);
        snackbar.success("PowerControl updated");
      },
      onError: () => {
        snackbar.error("Error updating PowerControl");
      },
    }
  );

  const onSave = () => {
    updatePowerControl.mutate();
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 650,
          maxHeight: 450,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Edit Power Output Control
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 2,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        >
          <Box gridColumn={{ sm: "span 2" }}>
            <Typography className="label"> Name</Typography>
            <TextField
              onChange={(e: any) => {
                setBasicInput({ ...basicInput, name: e.target.value });
              }}
              value={name}
              fullWidth
              size="small"
              placeholder="Name"
            />
          </Box>

          <Box sx={{ width: 250 }}>
            <Typography className="label"> Current (Amp)</Typography>
            <Grid container spacing={2} alignItems="center">
              <Grid item></Grid>
              <Grid item xs>
                <Slider
                  min={0}
                  max={16}
                  value={typeof value === "number" ? value : 0}
                  onChange={handleSliderChange}
                />
              </Grid>
              <Grid item>
                <Input
                  value={powerOutput}
                  size="small"
                  //onChange={handleInputChange}
                  onBlur={handleBlur}
                  onChange={(e: any) => {
                    setBasicInput({
                      ...basicInput,
                      powerOutput: e.target.value,
                    });
                  }}
                />
              </Grid>
            </Grid>
          </Box>

          <Box sx={{ width: 250 }}>
            <Typography className="label"> Timer</Typography>
            <Grid container spacing={2} alignItems="center">
              <Grid item></Grid>
              <Grid item xs>
                <Slider
                  min={0}
                  max={255}
                  value={typeof timerValue === "number" ? timerValue : 0}
                  onChange={handleTimerChange}
                  aria-labelledby="input-slider"
                />
              </Grid>
              <Grid item>
                <Input
                  value={timerValue}
                  size="small"
                  // onChange={handleTimeSlider}
                  onChange={(e: any) => {
                    setBasicInput({
                      ...basicInput,
                      autoCutOff: e.target.timerValue,
                    });
                  }}
                  onBlur={handleTimer}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>

        <Box
          sx={{
            maxWidth: { xs: 280, sm: 560 },
            mx: "auto",
            py: 2,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
            gap: 3,
          }}
        ></Box>
      </DialogContent>
      <DialogActions>
        <Button
          variant="outlined"
          color="primary"
          onClick={() => handleClose()}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={onSave}
          // disabled={step === steps.length - 1 && disabled}
        >
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddDialog;
