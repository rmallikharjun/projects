import {
  Add,
  // Add,
  // DoDisturbAltOutlined,
  // EventAvailableOutlined,
  // InfoOutlined,
  PowerOutlined,
  Search,
  // TaskAlt,
} from "@mui/icons-material";

import {
  Box,
  // Avatar,
  Paper,
  Button,
  useTheme,
  useMediaQuery,
  Skeleton,
  Typography,
  Tooltip,
} from "@mui/material";
import SearchBox from "components/Search";
import Breadcrumbs from "components/Breadcrumbs";
import ViewSelector, { View } from "components/ViewSelector";
import { useEffect, useState } from "react";
// import Assignment from "./Assignment";
//import Health from "./Health";
// import BookingsEarnings from "./BookingsEarnings";
// import Consumption from "./Consumption";
import List from "./List";
import { authorizedFetch, getPermissions, GlobalState } from "utils";
import { useQuery } from "react-query";
import { BOLT_URL } from "utils/constants";
import { useSelector } from "react-redux";
import AddPower from "./AddPowerControl";

const Loading = () => (
  <Box>
    <Skeleton className="icon" variant="circular" />
    <Box className="info">
      <span className="value">
        <Skeleton height={24} width={50} />
      </span>
      <Typography variant="body2" className="title">
        <Skeleton width={80} />
      </Typography>
    </Box>
  </Box>
);

const Chargers = () => {
  const { canWrite } = getPermissions("charger:vendors");
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));
  const masterView = useSelector(
    (state: GlobalState) => state.global.masterView
  );
  const [view, setView] = useState<View>("grid");
  const [health, setHealth] = useState("");
  const [search, setSearch] = useState("");
  const [searchBox, setSearchBox] = useState(false);
  const [cityList, setCityList] = useState();
  const [addDialog, setAddOCPPDialog] = useState(false);

  const statsUrl = `${BOLT_URL}/company/stats/all?health=${health}`;

  const [chargerDisplay, setChargerDisplay] = useState(0);

  const {
    isLoading,
    data: statsData,
    refetch: refetchStats,
  } = useQuery(["getAllStats", masterView, health], () =>
    authorizedFetch(statsUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  const cityUrl = `${BOLT_URL}/company/stats/city`;
  const { data: cityData } = useQuery(["getCityStats", masterView], () =>
    authorizedFetch(cityUrl, {
      headers: {
        master: masterView,
      },
    })
  );

  useEffect(() => {
    if (cityData && cityData?.data?.constructor === Array) {
      let cityList: any = [];
      // eslint-disable-next-line
      cityData?.data?.map((el: any) => {
        cityList.push({
          type: "name",
          name: el.city,
          count: el.totalChargersInCity,
        });
      });
      cityList.sort((a: any, b: any) =>
        a.count < b.count ? 1 : b.count < a.count ? -1 : 0
      );
      setCityList(cityList);
    }
  }, [cityData]);

  console.log(cityList);

  const [allStats, setAllStats] = useState({
    totalChargers: 0,
    totalBooked: 0,
    totalAvailable: 0,
    chargersAssignedToVendors: 0,
    chargersUnassignedToVendors: 0,
    totalRestrictedChargers: 0,
    healthyChargersCount: 0,
    moderateChargersCount: 0,
    criticalChargersCount: 0,
    damagedChargersCount: 0,
    totalUnavailable: 0,
    totalPrivateChargers: 0,
    totalPublicChargers: 0,
  });

  useEffect(() => {
    if (view === "grid") {
      setHealth("");
    }
  }, [view]);

  useEffect(() => {
    let { stats } = statsData?.data || {};
    if (stats) {
      setAllStats(stats);
    }
  }, [statsData]);

  const {
    totalChargers,
    totalBooked,
    totalAvailable,
    healthyChargersCount,
    moderateChargersCount,
    criticalChargersCount,
    damagedChargersCount,
  } = allStats;

  console.log(allStats);

  // Charger list data:

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [selectedCity, setSelectedCity] = useState<any>("");

  const [healthStatus, setHealthStatus] = useState({
    healthy: false,
    moderate: false,
    critical: false,
    inactive: false,
  });

  const [availability, setAvailability] = useState({
    available: false,
    booked: false,
    unavailable: false,
  });

  const [usageType, setUsageType] = useState({
    restricted: false,
    publicType: false,
    privateType: false,
  });

  const [rupeeCharger, setRupeeCharger] = useState<boolean>(false);

  const { healthy, moderate, critical, inactive } = healthStatus;
  const { available, booked, unavailable } = availability;
  const { restricted, publicType, privateType } = usageType;

  const [filterList, setFilterList] = useState<string[]>([]);

  const chargersUrl = `${BOLT_URL}/company/chargers?${
    !search
      ? `first=${pageSize}&skip=${pageSize * (page - 1)}&health=${
          // eslint-disable-next-line
          (healthy ? "HEALTHY" + " " : "") +
          // eslint-disable-next-line
          (moderate ? "MODERATE" + " " : "") +
          // eslint-disable-next-line
          (critical ? "CRITICAL" + " " : "") +
          // eslint-disable-next-line
          (inactive ? "INACTIVE" + " " : "")
        }&usageType=${
          // eslint-disable-next-line
          (restricted ? "RESTRICTED" + " " : "") +
          // eslint-disable-next-line
          (publicType ? "PUBLIC" + " " : "") +
          // eslint-disable-next-line
          (privateType ? "PRIVATE" + " " : "")
        }&status=${
          // eslint-disable-next-line
          (available ? "AVAILABLE" + " " : "") +
          // eslint-disable-next-line
          (booked ? "BOOKED" + " " : "") +
          // eslint-disable-next-line
          (unavailable ? "UNAVAILABLE" + " " : "")
        }&city=${selectedCity}&rupeeCharger=${rupeeCharger}&tab=${
          ""
          // tab === 0
          //   ? "ALL"
          //   : tab === 1
          //   ? "BOOKED"
          //   : tab === 2
          //   ? "AVAILABLE"
          //   : "RESTRICTED"
        }`
      : `first=${pageSize}&skip=${pageSize * (page - 1)}&search=${search}`
  }`;

  const {
    isLoading: chargersLoading,
    data,
    refetch: refetchChargers,
  } = useQuery(
    [
      "getChargers",
      page,
      pageSize,
      search,
      masterView,
      filterList,
      availability,
      healthStatus,
      usageType,
      selectedCity,
      rupeeCharger,
    ],
    () =>
      authorizedFetch(chargersUrl, {
        headers: {
          master: masterView,
        },
      })
  );
  return (
    <>
      <Box
        width={1}
        mb={{ xs: 2, md: 3 }}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box display="flex" alignItems="center">
          <Breadcrumbs />
          {view !== "grid" ? (
            <Box
              ml={1}
              display="flex"
              alignItems="center"
              sx={{ opacity: 0.4 }}
            >
              {
                // eslint-disable-next-line
                "-" + " " + chargerDisplay
              }
              <PowerOutlined sx={{ width: "18px", mt: "-3px" }} />
            </Box>
          ) : (
            ""
          )}
        </Box>

        {searchBox ? (
          <Box
            sx={{
              height: 40,
              display: "flex",
              alignItems: "center",
            }}
          >
            <SearchBox
              handleSearch={(value) => {
                setSearch(value);
              }}
              persist
              enableClear
              enableClose
              onClose={() => setSearchBox(false)}
            />
          </Box>
        ) : (
          <ViewSelector
            view={view}
            setView={setView}
            extras={
              canWrite || view === "list"
                ? () => {
                    return (
                      <>
                        {canWrite && (
                          <Tooltip title="Add Charging Zone">
                            <Button
                              sx={{ mr: { xs: 1, md: 2 } }}
                              onClick={() => setAddOCPPDialog(true)}
                            >
                              <Add />
                            </Button>
                          </Tooltip>
                        )}
                        {view === "list" && !isMdUp
                          ? () => (
                              <Button
                                sx={{ mr: { xs: 1, md: 2 } }}
                                onClick={() => setSearchBox(true)}
                              >
                                <Search />
                              </Button>
                            )
                          : undefined}
                      </>
                    );
                  }
                : undefined
            }
          />
        )}
      </Box>
      {view === "grid" ? (
        <Box
          sx={{
            width: 1,
            display: "grid",
            gridTemplateColumns: { xs: "1fr", md: "repeat(8, 1fr)" },
            gap: { xs: 2, md: 3 },
            "& .MuiPaper-root": {
              borderRadius: 2,
              boxShadow: "0 0 4px #1C295A14",
            },
            "& .MuiPaper-root:nth-of-type(-n+2)": {
              boxShadow: "0 0 10px #1C295A14",
            },
          }}
        >
          <Paper
            sx={{
              gridColumn: { md: "span 2" },
              width: 1,
              maxWidth: 1,
              overflowX: "auto",
              overflowY: "hidden",
              height: { xs: "auto", md: 430 },
              p: 2,
              display: "grid",
              gridTemplateColumns: {
                xs: "repeat(4, minmax(max-content, 1fr))",
                md: "1fr",
              },
              gap: 2,
              "& > div": {
                p: 2,
                border: 1,
                borderColor: (theme) => theme.customColors.border,
                borderRadius: 1,
                display: "flex",
                "& .icon": {
                  mr: 2,
                  width: 38,
                  height: 38,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  borderRadius: 50,
                },
                "& .info": {
                  display: "flex",
                  flexDirection: "column",
                  "& .value": {
                    fontWeight: 700,
                    fontSize: 28,
                    color: "text.primary",
                    lineHeight: "1em",
                    mb: 0.65,
                  },
                  "& .title": {
                    fontSize: 14,
                    color: "text.secondary",
                  },
                },
              },
            }}
          >
            {/* {isLoading ? (
              <Loading />
            ) : (
              <Box>
                <Avatar variant="icon" className="icon">
                  <PowerOutlined />
                </Avatar>
                <Box className="info">
                  <span className="value">
                    {typeof totalChargers === "number" ? totalChargers : "-"}
                  </span>
                  <span className="title">Total Chargers</span>
                </Box>
              </Box>
            )} */}

            {/* {isLoading ? (
              <Loading />
            ) : (
              <Box>
                <Avatar variant="icon" className="icon">
                  <EventAvailableOutlined />
                </Avatar>
                <Box className="info">
                  <span className="value">
                    {typeof totalBooked === "number" ? totalBooked : "-"}
                  </span>
                  <span className="title">Booked</span>
                </Box>
              </Box>
            )} */}

            {/* {isLoading ? (
              <Loading />
            ) : (
              <Box>
                <Avatar variant="icon" className="icon">
                  <TaskAlt />
                </Avatar>
                <Box className="info">
                  <span className="value">
                    {typeof totalAvailable === "number" ? totalAvailable : "-"}
                  </span>
                  <span className="title">Available</span>
                </Box>
              </Box>
            )} */}
            {isLoading ? (
              <Loading />
            ) : (
              <Box>
                {/* <Avatar variant="icon" className="icon">
                  <DoDisturbAltOutlined />
                </Avatar> */}
                <Box className="info">
                  {/* <span className="value">
                    {typeof totalUnavailable === "number"
                      ? totalUnavailable
                      : "-"}
                  </span> */}
                  {/* <Box display="flex" alignItems="center">
                    <span className="title">Unavailable</span>
                    <Tooltip title="Total Chargers not in their available charging time slots">
                      <InfoOutlined
                        fontSize="inherit"
                        sx={{ ml: 0.5, cursor: "pointer" }}
                      />
                    </Tooltip>
                  </Box> */}
                </Box>
              </Box>
            )}
          </Paper>
          <Box
          // sx={{
          //   gridColumn: { md: "span 6" },
          //   padding: "10px",
          //   margin: "-10px",
          //   width: "auto",
          //   overflowX: "auto",
          //   display: "grid",
          //   gridTemplateColumns: "repeat(2, minmax(auto, 1fr))",
          //   gap: { xs: 2, md: 3 },
          //   "& .MuiPaper-root": {
          //     height: 430,
          //     p: { xs: 2, md: 3 },
          //     // '&:last-of-type': {
          //     //   transform: {
          //     //     xs: 'translateX(16px)',
          //     //     md: 'translateX(24px)'
          //     //   }
          //     // }
          //   },
          // }}
          >
            <Paper>
              {/* <Assignment
                assigned={chargersAssignedToVendors}
                unassigned={chargersUnassignedToVendors}
                totalChargers={totalChargers}
              /> */}
            </Paper>
            {/* <Paper>
              <Health
                totalAvailable={totalAvailable}
                totalBooked={totalBooked}
                totalChargers={totalChargers}
                healthyChargersCount={healthyChargersCount}
                moderateChargersCount={moderateChargersCount}
                criticalChargersCount={criticalChargersCount}
                damagedChargersCount={damagedChargersCount}
              />
            </Paper> */}
          </Box>
          {/* <BookingsEarnings masterView={masterView} />
          <Consumption masterView={masterView} /> */}
        </Box>
      ) : (
        <List
          search={search}
          setSearch={setSearch}
          masterView={masterView}
          refetchStats={refetchStats}
          allStats={allStats}
          cityList={cityList}
          setChargerDisplay={setChargerDisplay}
          setPage={setPage}
          setAvailability={setAvailability}
          setPageSize={setPageSize}
          setSelectedCity={setSelectedCity}
          setUsageType={setUsageType}
          setRupeeCharger={setRupeeCharger}
          setHealthStatus={setHealthStatus}
          setFilterList={setFilterList}
          filterList={filterList}
          data={data}
          chargersLoading={chargersLoading}
          refetchChargers={refetchChargers}
          page={page}
          pageSize={pageSize}
        />
      )}
      <AddPower
        open={addDialog}
        handleClose={() => setAddOCPPDialog(false)}
        refetchStats={refetchStats}
        refetchChargers={refetchChargers}
      />
    </>
  );
};

export default Chargers;
