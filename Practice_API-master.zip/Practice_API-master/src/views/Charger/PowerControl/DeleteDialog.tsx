import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";

import { snackbar, setLoader, authorizedFetch } from "utils";
import { useMutation } from "react-query";

const DeleteVendor = ({ open, handleClose, vendor, charger }: any) => {
  const url = `https://bolt.dev.revos.in/company/powerOutputControl/delete`;

  const mutation = useMutation(
    `deleteCoupon`,
    () =>
      authorizedFetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          stage: "prod",
        },
        body: {
          _id: charger?.id,
        },
      }),
    {
      onSuccess: () => {
        snackbar.success(`Coupon deleted`);

        setLoader(false);
      },
      onError: () => {
        snackbar.error(`Error deleting coupon`);
      },
    }
  );

  console.log("Delete: ", charger?.id);

  function confirm() {
    setLoader(true);
    mutation.mutate();

    handleClose();
  }

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>Delete Power Control</DialogTitle>
      <DialogContent className="py-1">
        Delete <b>{charger?.name}</b>?
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button
          variant="contained"
          color="primary"
          disableElevation
          onClick={confirm}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteVendor;
