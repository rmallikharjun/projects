import { EditOutlined, ErrorOutline, HighlightOff } from "@mui/icons-material";
import DateTimePicker from "@mui/lab/DateTimePicker";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  // InputAdornment,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Step,
  StepButton,
  Stepper,
  TextField,
  Typography,
} from "@mui/material";
import { useState, useEffect } from "react";
import { useMutation } from "react-query";
import { authorizedFetch, GlobalState, setLoader, snackbar } from "utils";

import { AddPhotoAlternate } from "@mui/icons-material";
import moment from "moment";
import { useSelector } from "react-redux";

interface Props {
  open: boolean;
  handleClose: () => void;
  refetchNotifications: any;
}

type inputData = {
  title: string;
  description: string;
  imageUrl: string;
  image: string;
  onClickUrl: string;

  time: [{ startTime: any }, { duration: any }];
  kind: string;
};

const AddPricingDialog: React.FC<Props> = ({
  open,
  handleClose,
  refetchNotifications,
}) => {
  const [step, setStep] = useState(0);
  const steps = ["Notification Info", "Finish"];
  const companyId = useSelector(
    (state: GlobalState) => state.global.company.id
  );

  const [input, setInput] = useState<inputData>({
    title: "",
    description: "",
    imageUrl: "",
    image: "",
    onClickUrl: "",

    time: [{ startTime: "" }, { duration: "" }],
    kind: "",
  });

  const { title, description, imageUrl, onClickUrl, kind } = input;

  const [selectedImage, setSelectedImage] = useState<any>(null);

  function handleChange(key: string, value: string) {
    setInput((prevInput: inputData) => ({ ...prevInput, [key]: value }));
  }

  function handleNext() {
    if (step === steps.length - 1) {
      handleSave();
    } else setStep(step + 1);
  }
  function handleBack() {
    setStep(step - 1);
  }

  function isComplete(step: number) {
    switch (step) {
      case 0:
        return ![
          kind,
          title,
          description,
          selectedImage,
          startTime,
          endTime,
          onClickUrl,
        ].includes("");
      default:
        break;
    }
  }

  const disabled = [
    kind,
    title,
    description,
    selectedImage,
    onClickUrl,
  ].includes("");

  useEffect(() => {
    if (!open) {
      setInput({
        title: "",
        description: "",
        imageUrl: "",
        image: "",
        onClickUrl: "",

        time: [{ startTime: "" }, { duration: "" }],
        kind: "",
      });
      setStep(0);
    }
  }, [open]);

  const [imageType, setImageType] = useState("imageUpload");

  const handleImageType = (event: React.ChangeEvent<HTMLInputElement>) => {
    setImageType((event.target as HTMLInputElement).value);
  };

  const [startTime, setStartTime] = useState<Date | null>(new Date());

  const [endTime, setEndTime] = useState<Date | null>(new Date());

  const handleStartTime = (newValue: Date | null) => {
    setStartTime(newValue);
  };

  const handleEndTime = (newValue: Date | null) => {
    setEndTime(newValue);
  };

  const addURL = `https://notification.dev.revos.in/addtemplate`;

  const addMutation = useMutation(
    "addNotifications",
    () =>
      authorizedFetch(addURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // token: "1234",
        },
        body: {
          title: title,
          description: description,
          image: file,
          imageURL: imageUrl,
          onclickURL: onClickUrl,
          appId: companyId,
          timings: [
            {
              startTime: moment(startTime).toISOString(),
              endTime: moment(endTime).toISOString(),
            },
          ],
          kind: kind,
        },
      }),
    {
      onSuccess: () => {
        setLoader(false);
        refetchNotifications();
        snackbar.success(`Notification Added`);
        handleClose();
      },
      onError: () => {
        setLoader(false);
        snackbar.error(`Error adding notification`);
      },
    }
  );

  const handleSave = () => {
    setLoader(true);
    addMutation.mutate();
    handleClose();
  };

  const [url, setUrl] = useState("");
  const [file, setFile] = useState<any>();

  useEffect(() => {
    if (selectedImage) {
      const objectUrl = URL.createObjectURL(selectedImage);
      setUrl(objectUrl);

      let reader = new FileReader();
      reader.onloadend = () => {
        const image = reader.result;
        setFile(image);
      };

      reader.readAsDataURL(selectedImage);
    }
  }, [selectedImage]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxWidth: 800,
          width: 1,
          "& .MuiInputBase-root": {
            fontSize: 14,
            borderRadius: 1,
            p: "3.5px 5px",
          },
        },
      }}
    >
      <DialogTitle
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "start",
        }}
      >
        Add Notification
        <IconButton
          children={<HighlightOff />}
          color="inherit"
          onClick={handleClose}
          sx={{ transform: "translate(8px, -8px)" }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: "16px !important" }}>
        <Stepper
          sx={{ my: 4, mx: "auto", maxWidth: 534 }}
          activeStep={step}
          nonLinear
          alternativeLabel
        >
          {steps.map((label, i) => (
            <Step key={i}>
              <StepButton onClick={() => setStep(i)}>{label}</StepButton>
            </Step>
          ))}
        </Stepper>
        {step === 0 && (
          <Box
            sx={{
              maxWidth: { xs: 280, sm: 560 },
              mx: "auto",
              py: 2,
              display: "grid",
              gridTemplateColumns: { xs: "1fr", sm: "1fr 1fr" },
              gap: 3,
            }}
          >
            <Box gridColumn={{ sm: "span 2" }}>
              <Typography className="label">Kind</Typography>
              <Select
                fullWidth
                value={kind}
                onChange={(e: any) => {
                  handleChange("kind", e.target.value);
                }}
                displayEmpty
              >
                <MenuItem disabled value="">
                  <em>Select</em>
                </MenuItem>
                {["IMAGE", "TEXT", "IMAGE & TEXT"].map((option, i) => (
                  <MenuItem key={i} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
            </Box>
            {kind === "IMAGE" ? (
              <></>
            ) : (
              <>
                <Box gridColumn={{ sm: "span 2" }}>
                  <Typography className="label">Title</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={title}
                    placeholder="Title"
                    onChange={(e) => {
                      handleChange("title", e.target.value);
                    }}
                  />
                </Box>
                <Box gridColumn={{ sm: "span 2" }}>
                  <Typography className="label">Description</Typography>
                  <TextField
                    fullWidth
                    size="small"
                    value={description}
                    placeholder="Description"
                    onChange={(e) => {
                      handleChange("description", e.target.value);
                    }}
                  />
                </Box>
              </>
            )}

            {kind === "TEXT" ? (
              <></>
            ) : (
              <>
                <Box gridColumn={{ sm: "span 2" }}>
                  <Typography className="label">Image</Typography>
                  <RadioGroup
                    row
                    defaultValue="imageUpload"
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    sx={{
                      mb: -2,
                      "& .MuiTypography-root": {
                        fontSize: 16,
                        fontWeight: 500,
                      },
                    }}
                    onChange={handleImageType}
                  >
                    <FormControlLabel
                      value="imageUpload"
                      control={<Radio checked={imageType === "imageUpload"} />}
                      label="Image Upload"
                    />
                    <FormControlLabel
                      value="imageUrl"
                      control={
                        <Radio
                          checked={imageType === "imageUrl"}
                          sx={{ ml: 5 }}
                        />
                      }
                      label="Image Url"
                    />
                  </RadioGroup>
                </Box>
                {imageType === "imageUrl" && (
                  <Box gridColumn={{ sm: "span 2" }}>
                    <TextField
                      fullWidth
                      size="small"
                      value={imageUrl}
                      placeholder="Image Url"
                      onChange={(e) => {
                        handleChange("imageUrl", e.target.value);
                      }}
                    />
                  </Box>
                )}

                {imageType === "imageUpload" &&
                  (selectedImage ? (
                    <Box
                      gridColumn={{
                        sm: "span 2",
                      }}
                    >
                      <Box
                        sx={{
                          width: "100%",
                          display: "flex",
                          justifyContent: "center",
                        }}
                      >
                        <img
                          style={{
                            width: "auto",
                            height: "300px",
                            maxWidth: "100%",
                            objectFit: "contain",
                          }}
                          alt={url}
                          src={url}
                        />
                      </Box>

                      <Box
                        sx={{ width: "100%", display: "flex", gap: 2, my: 3 }}
                      >
                        <Button
                          sx={{ width: "50%" }}
                          variant="contained"
                          component="label"
                        >
                          Change Image
                          <input
                            type="file"
                            hidden
                            name="myImage"
                            onChange={(event: any) => {
                              setSelectedImage(event.target.files[0]);
                            }}
                          />
                        </Button>
                        <Button
                          onClick={() => {
                            setSelectedImage(null);
                          }}
                          sx={{ width: "50%" }}
                          variant="outlined"
                        >
                          Remove Image
                        </Button>
                      </Box>
                    </Box>
                  ) : (
                    <Box
                      gridColumn={{
                        sm: "span 2",
                      }}
                      sx={{
                        display: "flex",
                        justifyContent: "center",
                        flexDirection: "column",
                        alignItems: "center",
                        my: 5,
                      }}
                    >
                      <Button
                        variant="outlined"
                        sx={{
                          borderRadius: 2,
                          minHeight: 150,
                          minWidth: 150,
                        }}
                        component="label"
                      >
                        <AddPhotoAlternate sx={{ fontSize: 50 }} />
                        <input
                          type="file"
                          hidden
                          name="myImage"
                          onChange={(event: any) => {
                            console.log(event.target.files[0]);
                            setSelectedImage(event.target.files[0]);
                          }}
                        />
                      </Button>
                      <Typography
                        sx={{
                          mt: 2,
                          fontSize: 14,
                          fontWeight: "medium",
                          opacity: 0.6,
                        }}
                      >
                        Upload an Image
                      </Typography>
                    </Box>
                  ))}
              </>
            )}

            <Box>
              <Typography className="label">Start Time</Typography>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DateTimePicker
                  value={startTime}
                  onChange={handleStartTime}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      sx={{
                        "& .MuiIconButton-root": {
                          marginRight: 1,
                        },
                      }}
                    />
                  )}
                />
              </LocalizationProvider>
            </Box>

            <Box>
              <Typography className="label">End Time</Typography>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DateTimePicker
                  value={endTime}
                  onChange={handleEndTime}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      sx={{
                        "& .MuiIconButton-root": {
                          marginRight: 1,
                        },
                      }}
                    />
                  )}
                />
              </LocalizationProvider>
            </Box>

            <Box gridColumn={{ sm: "span 2" }}>
              <Typography className="label">Banner CTA Url</Typography>
              <TextField
                fullWidth
                size="small"
                value={onClickUrl}
                placeholder="Banner CTA Url"
                onChange={(e) => {
                  handleChange("onClickUrl", e.target.value);
                }}
              />
            </Box>
          </Box>
        )}
        {step === 1 && (
          <Box
            sx={{
              maxWidth: 560,
              mx: "auto",
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 1.25,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    bgcolor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {[
                  { header: "Pricing Info", onEdit: () => setStep(0) },
                  { label: "Kind", value: kind, required: true },
                  { label: "Title", value: title, required: true },
                  { label: "Description", value: description, required: true },
                  {
                    label: "Image",
                    value: url,
                    required: true,
                  },
                  // { label: "Start Time", value: startTime, required: true },
                  // { label: "End Time", value: endTime, required: true },
                  // {
                  //   label: "Banner CTA Url",
                  //   value: onClickUrl,
                  //   required: true,
                  // },
                ].map(({ header, onEdit, label, value, required }, i, arr) => {
                  const isFirst = arr[i - 1]?.header;
                  const isLast = !arr[i + 1] || arr[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                          <IconButton
                            sx={{ ml: 1.5 }}
                            children={<EditOutlined />}
                            color="primary"
                            size="small"
                            onClick={onEdit}
                          />
                        </td>
                      ) : (
                        <>
                          {label === "Image" ? (
                            <>
                              <td>{label}</td>
                              <td className="bold">
                                {required &&
                                ["", null, undefined].includes(value) ? (
                                  <Box display="flex" alignItems="center">
                                    <ErrorOutline
                                      fontSize="small"
                                      color="error"
                                      sx={{ mr: 1 }}
                                    />
                                    Required
                                  </Box>
                                ) : (
                                  <img
                                    style={{
                                      width: "auto",
                                      height: "300px",
                                      maxWidth: "100%",
                                      objectFit: "contain",
                                    }}
                                    alt={value}
                                    src={value}
                                  />
                                )}
                              </td>
                            </>
                          ) : (
                            <>
                              <td>{label}</td>
                              <td className="bold">
                                {required &&
                                ["", null, undefined].includes(value) ? (
                                  <Box display="flex" alignItems="center">
                                    <ErrorOutline
                                      fontSize="small"
                                      color="error"
                                      sx={{ mr: 1 }}
                                    />
                                    Required
                                  </Box>
                                ) : (
                                  value
                                )}
                              </td>
                            </>
                          )}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        )}
      </DialogContent>
      <DialogActions>
        {step !== 0 && (
          <Button variant="outlined" onClick={handleBack}>
            Back
          </Button>
        )}
        {step === 0 && (
          <Button variant="outlined" onClick={handleClose}>
            Cancel
          </Button>
        )}
        <Button
          onClick={handleNext}
          variant={
            isComplete(step) || step === steps.length - 1
              ? "contained"
              : "outlined"
          }
          disableElevation
          disabled={step === steps.length - 1 && disabled}
        >
          {step === steps.length - 1
            ? "Save"
            : isComplete(step)
            ? "Next"
            : "Skip"}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AddPricingDialog;
