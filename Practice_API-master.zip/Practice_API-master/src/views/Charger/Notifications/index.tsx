import { Add, InfoOutlined } from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Tab,
  Tabs,
  Tooltip,
} from "@mui/material";
import Breadcrumbs from "components/Breadcrumbs";
import Table from "components/Table";
import moment from "moment";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { authorizedFetch, drawer, getPermissions } from "utils";
import CreateDialog from "./CreateDialog";
import InfoDrawer from "./InfoDrawer";

const Coupons = () => {
  const { canWrite } = getPermissions("charger:notifications");
  const [tab, setTab] = useState(0);
  const [createDialog, setCreateDialog] = useState(false);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const url = `https://notification.dev.revos.in/gettemplates?first=${pageSize}&skip=${
    pageSize * (page - 1)
  }`;
  const {
    isLoading,
    data,
    refetch: refetchNotifications,
  } = useQuery("getNotificatios", () => authorizedFetch(url));

  useEffect(() => {
    return () => {
      drawer.close();
    };
  }, []);

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Breadcrumbs />
      </Box>
      <Paper
        sx={{
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            width: 1,
            p: 3,
            pb: 2.75,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box width="fit-content">
            <Tabs value={tab} onChange={(e, tab) => setTab(tab)}>
              <Tab
                label="All"
                className="hasCount"
                sx={{
                  "&:after": {
                    content: `"${data?.data?.count}"`,
                  },
                }}
              />
            </Tabs>
          </Box>
          {canWrite && (
            <Button
              sx={{ height: 40, textTransform: "none" }}
              startIcon={<Add />}
              color="primary"
              variant="contained"
              onClick={() => setCreateDialog(true)}
            >
              Create New
            </Button>
          )}
        </Box>
        <CreateDialog
          open={createDialog}
          handleClose={() => setCreateDialog(false)}
          refetchNotifications={refetchNotifications}
        />

        <Table
          rowCount={data?.data?.count}
          serverSidePagination={true}
          activePage={page}
          activePageSize={pageSize}
          onPageChange={(value) => setPage(value)}
          onPageSizeChange={(value) => setPageSize(value)}
          loading={isLoading}
          rows={data?.data?.data || []}
          idKey="id"
          columns={[
            {
              key: "kind",
              label: "Type",
            },
            {
              key: "title",
              label: "Title",
            },
            {
              key: "createdAt",
              label: "Created At",
              format: (value) => moment(value).format("ddd, MMM DD, YYYY"),
            },
            {
              key: "startTime",
              label: "Start Time",
              Render: (row) =>
                moment(row?.timing[0]?.startTime).format(
                  "ddd, MMM DD, YYYY, h:mm:ss A"
                ),
            },
            {
              key: "endTime",
              label: "End Time",
              Render: (row) =>
                moment(row?.timing[0]?.endTime).format(
                  "ddd, MMM DD, YYYY, h:mm:ss A"
                ),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <>
                  <Tooltip title="Info">
                    <IconButton
                      size="small"
                      sx={{
                        color: (theme: any) => theme.customColors.grey,
                        mr: 0.5,
                      }}
                      onClick={() => drawer.open(<InfoDrawer data={row} />)}
                      children={<InfoOutlined fontSize="small" />}
                    />
                  </Tooltip>
                </>
              ),
            },
          ]}
        />
      </Paper>
    </>
  );
};

export default Coupons;
