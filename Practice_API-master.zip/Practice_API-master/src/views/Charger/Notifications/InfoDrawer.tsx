import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { HighlightOff } from "@mui/icons-material";
import { Box, IconButton } from "@mui/material";
import { drawer, getDarkModePreference, GlobalState } from "utils";
import moment from "moment";

const InfoDrawer = (data: any) => {
  const [table, setTable] = useState([
    { header: "Basic Details" },
    { label: "Type", value: "" },
    { label: "Title", value: "" },
    { label: "Description", value: "" },
    { label: "Created At", value: "" },
    { label: "Start Time", value: "" },
    { label: "End Time", value: "" },
    { header: "Image Details" },
    { label: "Image", value: "" },
    { label: "Banner CTA Url", value: "" },
  ]);

  console.log(data);

  useEffect(() => {
    if (data) {
      setTable([
        { header: "Basic Details" },
        {
          label: "Type",
          value: data?.data?.kind,
        },
        { label: "Description", value: data?.data?.description },
        {
          label: "Created At",
          value: moment(data?.data?.createdAt).format("MMM DD YYYY, hh:mm a"),
        },
        {
          label: "Start Time",
          value: moment(data?.data?.timing[0]?.startTime).format(
            "MMM DD YYYY, hh:mm a"
          ),
        },
        {
          label: "End Time",
          value: moment(data?.data?.timing[0]?.endTime).format(
            "MMM DD YYYY, hh:mm a"
          ),
        },
        { header: "Image Details" },
        { label: "Image", value: data?.data?.imageUrl },
        { label: "Banner CTA Url", value: data?.data?.onclickURL },
      ]);
    }
  }, [data]);

  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );

  return (
    <>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          height: 1,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            px: 3,
            py: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: isDarkMode ? "#000" : "#03241D",
            fontWeight: 500,
            color: "#fff",
          }}
        >
          {data?.data?.title}
          <Box display="grid" gridTemplateColumns="repeat(2, auto)" gap={1}>
            <IconButton
              children={<HighlightOff />}
              color="inherit"
              size="small"
              onClick={() => drawer.close()}
            />
          </Box>
        </Box>
        <Box flexGrow={1} overflow="auto">
          <Box
            sx={{
              px: 3,
              pt: 2.5,
              "& .table": {
                borderCollapse: "collapse",
                width: 1,
                fontSize: 14,
                lineHeight: "16px",
                "& td": {
                  py: 2,
                  px: 2,
                },
                "& .bold": {
                  fontWeight: 500,
                },
                "& .header": {
                  px: 2,
                  py: 1,
                  position: "relative",
                  "& td": {
                    position: "absolute",
                    verticalAlign: "middle",
                    backgroundColor: (theme) => theme.customColors.header,
                    width: 1,
                    borderRadius: "4px",
                    fontSize: 16,
                    fontWeight: 600,
                    "& span": {
                      display: "inline-block",
                      transform: "translateY(1px)",
                    },
                  },
                },
                "& .first > td": {
                  pt: 9,
                },
                "& .last > td": {
                  pb: 3,
                },
              },
            }}
          >
            <table className="table">
              <tbody>
                {table.map(({ header, label, value }, i) => {
                  const isFirst = table[i - 1]?.header;
                  const isLast = !table[i + 1] || table[i + 1].header;

                  return (
                    <tr
                      key={i}
                      className={
                        header
                          ? "header"
                          : `${isFirst ? "first" : ""} ${isLast ? "last" : ""}`
                      }
                    >
                      {header ? (
                        <td colSpan={2}>
                          <span>{header}</span>
                        </td>
                      ) : (
                        <>
                          <td className="bold">{label}</td>
                          {label === "Image" ? (
                            <td>
                              <img
                                src={value}
                                alt={value}
                                style={{
                                  objectFit: "cover",
                                  width: "300px",
                                  height: "auto",
                                }}
                              />
                            </td>
                          ) : (
                            <td>{value}</td>
                          )}
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default InfoDrawer;
