import { DeleteOutline, Download } from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import Table from "components/Table";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { drawer, GlobalState } from "utils";
import DrawerContent from "./DrawerContent";
import { saveAs } from "file-saver";
import moment from "moment";

const Reports = () => {
  const { vehicleReports, reports, activeSection } = useSelector(
    (state: GlobalState) => state.global
  );

  let isCMS = activeSection === "charger";

  useEffect(() => {
    drawer.open(<DrawerContent isCMS={isCMS} />);
    return () => {
      drawer.close();
    };
    // eslint-disable-next-line
  }, []);

  return (
    <>
      <Box
        width={1}
        mt={0.5}
        mb={3}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Typography variant="h2">Previously Downloaded Reports</Typography>
      </Box>
      <Paper
        sx={{
          pt: 2,
          width: 1,
          boxShadow: "0 0 4px #1C295A14",
          borderRadius: 2,
        }}
      >
        <Table
          px={2}
          rows={isCMS ? reports || [] : vehicleReports || []}
          columns={[
            {
              key: "name",
              label: "Name",
              Render: (row) => (
                <Tooltip title={row.name}>
                  <Typography variant="body2" maxWidth={360} noWrap>
                    {row.name}
                  </Typography>
                </Tooltip>
              ),
            },
            {
              key: "createdAt",
              label: "Created At",
              format: (value) => moment(value).format("MMM DD, YYYY"),
            },
            {
              key: "actions",
              label: "Actions",
              Render: (row) => (
                <Tooltip title="Download Again">
                  <IconButton
                    size="small"
                    sx={{ color: (theme) => theme.customColors.grey }}
                    onClick={() => {
                      saveAs(row.url, row.name);
                    }}
                    children={<Download fontSize="small" />}
                  />
                </Tooltip>
              ),
            },
          ]}
          toolbar={() => (
            <>
              <Button startIcon={<DeleteOutline />}>Delete</Button>
            </>
          )}
        />
      </Paper>
    </>
  );
};

export default Reports;
