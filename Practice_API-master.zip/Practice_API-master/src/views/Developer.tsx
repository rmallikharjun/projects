const Developer = () => {
  return <div>Developer</div>;
};

export default Developer;
