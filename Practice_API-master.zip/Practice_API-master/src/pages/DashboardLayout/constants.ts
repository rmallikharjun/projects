export const drawerWidth = 80;
