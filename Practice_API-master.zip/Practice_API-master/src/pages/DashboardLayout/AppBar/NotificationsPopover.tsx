import { Popover } from "@mui/material";

interface Props {
  anchor: HTMLButtonElement | null;
  setAnchor: Function;
}

const NotificationsPopover: React.FC<Props> = ({ anchor, setAnchor }) => {
  return (
    <Popover
      sx={{
        "& .header": {
          marginLeft: "0.5em",
          fontSize: "1.25em",
          fontWeight: 500,
        },
        "& .MuiPaper-root": {
          boxShadow: (theme) => theme.shadows[3],
          p: (theme) => theme.spacing(1, 1, 0),
          borderRadius: 2,
          // border: theme => '1px solid ' + theme.palette.divider,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minWidth: 280,
          minHeight: 400,
        },
        "& .MuiListItem-root": {
          p: (theme) => theme.spacing(0.75, 1.5),
          borderRadius: 1,
        },
        "& .MuiListItemText-multiline": {
          m: (theme) => theme.spacing(0.5, 0),
        },
      }}
      open={Boolean(anchor)}
      anchorEl={anchor}
      onClose={() => setAnchor(null)}
      anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      // transformOrigin={{ vertical: "top", horizontal: "right" }}
    >
      No new notifications
    </Popover>
  );
};

export default NotificationsPopover;
