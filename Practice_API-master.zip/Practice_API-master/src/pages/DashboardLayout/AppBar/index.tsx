import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { Link } from "react-router-dom";
import {
  Badge,
  Box,
  Hidden,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Popover,
  Tooltip,
} from "@mui/material";
import {
  AccountCircleOutlined,
  Apps,
  CarRental,
  EvStation,
  Menu,
  NotificationsOutlined,
  PrecisionManufacturing,
} from "@mui/icons-material";
import { getDarkModePreference, getEnabledSections, GlobalState } from "utils";
import SearchBox from "./SearchBox";
import AccountPopover from "./AccountPopover";
import NotificationsPopover from "./NotificationsPopover";
import { switchTo } from "actions";
import { subdomain } from "utils/constants";
// import storageManager from "utils/storageManager";

interface Props {
  handleDrawerToggle: () => void;
}

const AppBar: React.FC<Props> = ({ handleDrawerToggle }) => {
  const dispatch = useDispatch();
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const enabledSections = useSelector((state: GlobalState) =>
    getEnabledSections(state)
  );

  const { activeSection } = useSelector((state: GlobalState) => state.global);

  const [sectionAnchor, setSectionAnchor] = useState<HTMLButtonElement | null>(
    null
  );
  const [notificationsAnchor, setNotificationsAnchor] =
    useState<HTMLButtonElement | null>(null);
  const [accountAnchor, setAccountAnchor] = useState<HTMLButtonElement | null>(
    null
  );

  return (
    <Box
      sx={{
        zIndex: 9,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        px: {
          xs: 1.5,
          md: 3,
        },
        py: {
          xs: 1,
          md: 1.75,
        },
        bgcolor: {
          xs: isDarkMode ? "#080808" : "#232728",
          md: "background.paper",
        },
        color: {
          xs: "white",
          md: "inherit",
        },
        boxShadow: "0 1px 4px rgba(21, 34, 50, 0.08)",
      }}
    >
      <Box display="flex" alignItems="center">
        <IconButton
          sx={{ mr: 1.5, display: { md: "none" } }}
          onClick={handleDrawerToggle}
          color="inherit"
        >
          <Menu />
        </IconButton>
        {subdomain.name === "ETO Motors" && (
          <Box
            sx={{
              mr: 1.5,
              ml: 1,
              width: 36,
              height: 36,
              borderRadius: 0.5,
              boxShadow: (theme) => theme.shadows[2],
              bgcolor: "white",
            }}
          >
            <img width="100%" src={subdomain.icon} alt="Company Logo" />
          </Box>
        )}
        <Hidden mdDown>
          <Box ml={1}>
            <SearchBox />
          </Box>
        </Hidden>
      </Box>
      <Box
        display="grid"
        gridTemplateColumns="repeat(3, auto)"
        gap={{ xs: 1, md: 1.5 }}
        alignItems="center"
      >
        {/* <Link to="/developer" style={{ color: "inherit" }}>
          <IconButton color="inherit">
            <Code />
          </IconButton>
        </Link> */}
        <Box>
          <Tooltip title="Switch to...">
            <IconButton
              color="inherit"
              onClick={(e) => setSectionAnchor(e.currentTarget)}
            >
              <Apps />
            </IconButton>
          </Tooltip>
          <Popover
            open={Boolean(sectionAnchor)}
            anchorEl={sectionAnchor}
            onClose={() => setSectionAnchor(null)}
            anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
            transformOrigin={{ vertical: "top", horizontal: "center" }}
            sx={{
              "& .MuiPaper-root": {
                boxShadow: (theme) => theme.shadows[3],
                borderRadius: 2,
              },
              "& .MuiList-root": {
                p: 0.5,
              },
              "& .MuiListItemButton-root": {
                borderRadius: 1.5,
                "&.active": {
                  bgcolor: (theme) => theme.palette.action.selected,
                },
              },
              "& .MuiListItemIcon-root": {
                minWidth: 38,
                color: "text.secondary",
              },
            }}
          >
            <List>
              {enabledSections.includes("retail") && (
                <ListItemButton
                  className={activeSection === "retail" ? "active" : ""}
                  onClick={() => {
                    setSectionAnchor(null);
                    dispatch(switchTo("retail"));
                  }}
                >
                  <ListItemIcon>
                    <PrecisionManufacturing />
                  </ListItemIcon>
                  <ListItemText
                    primary="Retail"
                    secondary="Supply Chain Management"
                  />
                </ListItemButton>
              )}
              {enabledSections.includes("rental") && (
                <ListItemButton
                  className={activeSection === "rental" ? "active" : ""}
                  onClick={() => {
                    setSectionAnchor(null);
                    dispatch(switchTo("rental"));
                  }}
                >
                  <ListItemIcon>
                    <CarRental />
                  </ListItemIcon>
                  <ListItemText
                    primary="Rental"
                    secondary="Vehicle Lease Management"
                  />
                </ListItemButton>
                // <ListItemButton
                //   className={activeSection === "rental" ? "active" : ""}
                //   onClick={() => {
                //     setSectionAnchor(null);
                //     window.open(
                //       `https://dashboard.revos.in/redirect?mode=rental&token=${storageManager.get(
                //         "loginJwt"
                //       )}`,
                //       "_blank"
                //     );
                //     // snackbar.info("Coming soon.");
                //   }}
                // >
                //   <ListItemIcon>
                //     <CarRental />
                //   </ListItemIcon>
                //   <ListItemText
                //     primary="Rental"
                //     secondary="Vehicle Lease Management"
                //   />
                // </ListItemButton>
              )}
              {enabledSections.includes("charger") && (
                <ListItemButton
                  className={activeSection === "charger" ? "active" : ""}
                  onClick={() => {
                    setSectionAnchor(null);
                    dispatch(switchTo("charger"));
                  }}
                >
                  <ListItemIcon>
                    <EvStation />
                  </ListItemIcon>
                  <ListItemText
                    primary="Charger"
                    secondary="Charger Management"
                  />
                </ListItemButton>
              )}
            </List>
          </Popover>
        </Box>
        <Box>
          <Tooltip title="Notifications">
            <IconButton
              onClick={(e) => setNotificationsAnchor(e.currentTarget)}
              color="inherit"
            >
              <Badge color="primary" variant="dot" overlap="circular" invisible>
                <NotificationsOutlined />
              </Badge>
            </IconButton>
          </Tooltip>
          <NotificationsPopover
            anchor={notificationsAnchor}
            setAnchor={setNotificationsAnchor}
          />
        </Box>
        <Box>
          <Tooltip title="Account">
            <IconButton
              onClick={(e) => setAccountAnchor(e.currentTarget)}
              color="inherit"
            >
              <AccountCircleOutlined />
            </IconButton>
          </Tooltip>
          <AccountPopover
            anchor={accountAnchor}
            setAnchor={setAccountAnchor}
            isDarkMode={isDarkMode}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default AppBar;
