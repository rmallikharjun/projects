import { useEffect, useState } from "react";
import { Switch, Route, Redirect, match } from "react-router";
import { useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { commonRoutes, routes } from "routes";
import { Box, Drawer, Hidden } from "@mui/material";
import {
  getDarkModePreference,
  getPermissions,
  GlobalState,
  snackbar,
} from "utils";
import NavigationDrawer from "./NavigationDrawer";
import { drawerWidth } from "./constants";
import { Helmet } from "react-helmet-async";
import AppBar from "./AppBar";
import InfoDrawer from "components/InfoDrawer";
import { logout } from "actions";
import storageManager from "utils/storageManager";

interface Props {
  match: match;
}

const DashboardLayout: React.FC<Props> = ({ match }) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const { user, activeSection, drawer, company } = useSelector(
    (state: GlobalState) => state.global
  );

  const [mobileOpen, setMobileOpen] = useState(false);
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  const location = useLocation();
  const navProps = {
    isDarkMode,
    location: location.pathname,
    handleClose: handleDrawerToggle,
  };

  const dispatch = useDispatch();
  useEffect(() => {
    // for breaking changes (TODO: remove in a few days)
    if (!user.permissions || !storageManager.get("loginJwt")) {
      dispatch(logout());
      snackbar.error("An error occured. Please sign in again.");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const noPaddingComponents = ["/assembly", "/distribution"].includes(
    location.pathname
  );

  return (
    <Box
      sx={{
        width: "100vw",
        height: "100vh",
        display: "grid",
        gridTemplateColumns: { xs: "0 1fr", md: `${drawerWidth}px 1fr` },
        overflow: "hidden",
      }}
    >
      <Helmet>
        <title>Dashboard</title>
      </Helmet>
      <nav style={{ height: "100vh" }}>
        <Hidden mdUp>
          <Drawer
            container={window?.document.body || undefined}
            variant="temporary"
            anchor="left"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            ModalProps={{
              keepMounted: true, // Better open performance on mobile.
            }}
          >
            <NavigationDrawer {...navProps} />
          </Drawer>
        </Hidden>
        <Hidden mdDown>
          <NavigationDrawer {...navProps} />
        </Hidden>
      </nav>
      <Box
        sx={{
          width: 1,
          height: 1,
          minWidth: 0,
          minHeight: 0,
          display: "grid",
          gridTemplateRows: "min-content 1fr",
        }}
      >
        <AppBar handleDrawerToggle={handleDrawerToggle} />
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "minmax(0, 1fr) auto",
            width: 1,
            height: 1,
            overflow: "auto",
          }}
        >
          <Box
            key={location.pathname}
            sx={{
              p: noPaddingComponents ? {} : { xs: 1.5, md: 4 },
              pt: noPaddingComponents ? {} : { xs: 2, md: 3 },
              width: 1,
              height: 1,
              overflow: "auto",
              visibility: {
                xs: drawer.open ? "hidden" : "visible",
                md: "visible",
              },
            }}
          >
            <Switch>
              {activeSection &&
                routes[activeSection]
                  .filter((route) => {
                    let { canRead, isAdmin } = getPermissions(route.id);
                    return route.id.includes("admin") ? isAdmin : canRead;
                  })
                  .map((route, i) => (
                    <Route
                      exact={!route.hasNestedPages}
                      path={
                        company.name === "testTVS" &&
                        [
                          "Chargers",
                          "Vendors",
                          "Subscriptions",
                          "Coupons",
                          "Invoices",
                          "KYC",
                          "Admin",
                        ].includes(route.name)
                          ? "/"
                          : route.path
                      }
                      component={route.component}
                      key={i}
                    />
                  ))}
              {commonRoutes.map((route, i) => (
                <Route
                  exact
                  path={route.path}
                  component={route.component}
                  key={i}
                />
              ))}
              <Redirect to="/" />
            </Switch>
          </Box>
          <InfoDrawer />
        </Box>
      </Box>
    </Box>
  );
};

export default DashboardLayout;
