import { useEffect, useState } from "react";
import { navigationLinks, NavigationLink } from "routes";
import { NavLink } from "react-router-dom";
import { Box, Tooltip, Hidden, IconButton } from "@mui/material";
import { Close } from "@mui/icons-material";
import { drawerWidth } from "./constants";
import { useSelector } from "react-redux";
import { getPermissions, GlobalState } from "utils";
import { ReactComponent as SvgLogo } from "assets/images/logo.svg";
import RevosLogo from "components/BoltLogo";

interface NavProps {
  isDarkMode: boolean;
  location: string;
  handleClose: () => void;
}

const NavigationDrawer: React.FC<NavProps> = ({
  isDarkMode,
  location,
  handleClose,
}) => {
  const { activeSection } = useSelector((state: GlobalState) => state.global);

  const companyName = useSelector(
    (state: GlobalState) => state.global.company.name
  );

  return (
    <Box
      sx={{
        display: "inline-block",
        width: {
          md: drawerWidth,
        },
        position: "sticky",
        height: "100vh",
        overflowY: "auto",
        overflowX: "hidden",
        bgcolor: isDarkMode ? "#080808" : "#232728",
        "::-webkit-scrollbar, ::-webkit-scrollbar-corner": {
          backgroundColor: "#202124",
          width: "10px",
        },
        "::-webkit-scrollbar-thumb": {
          borderRadius: "8px",
          backgroundColor: "#757575",
          minHeight: "24px",
          border: "3px solid #202124",
        },
      }}
    >
      <Hidden mdDown>
        <RevosLogo color="#5CD464" width={50} margin="1.75em auto" />
      </Hidden>
      <Hidden mdUp>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            my: 1.5,
            color: "#eee",
          }}
        >
          <Hidden mdUp>
            <IconButton color="inherit" sx={{ mx: 1.5 }} onClick={handleClose}>
              <Close />
            </IconButton>
          </Hidden>
          <Box
            sx={{
              width: 64,
              color: "#5CD464",
              height: 18,
            }}
          >
            <SvgLogo />
          </Box>
        </Box>
      </Hidden>
      <Box
        id="nav"
        display="grid"
        justifyItems={{ md: "center" }}
        mt={{ xs: 2, md: 3 }}
        mb={2}
      >
        {activeSection &&
          navigationLinks[activeSection]
            ?.filter((link) => {
              let { canRead, isAdmin } = getPermissions(link.id);
              return link.id.includes("admin") ? isAdmin : canRead;
            })
            ?.map((link, i) =>
              companyName === "testTVS" &&
              [
                "Chargers",
                "Vendors",
                "Subscriptions",
                "Coupons",
                "Invoices",
                "KYC",
                "Admin",
              ].includes(link.name) ? (
                ""
              ) : (
                <NavigationItem key={i} location={location} link={link} />
              )
            )}
      </Box>
    </Box>
  );
};

interface NavigationLinkProps {
  location: string;
  link: NavigationLink;
}

const NavigationItem: React.FC<NavigationLinkProps> = ({ location, link }) => {
  const [open, setOpen] = useState(false);
  const collapseHeight = 634;
  const [hideLabels, setHideLables] = useState(
    window.innerHeight <= collapseHeight && window.outerWidth >= 900
  );

  useEffect(() => {
    setOpen(
      location === link.path ||
        (link.path !== "/" && location.startsWith(link.path))
    );
  }, [location, link.path]);

  useEffect(() => {
    function handleResize() {
      setHideLables(
        window.innerHeight <= collapseHeight && window.outerWidth >= 900
      );
    }
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  });

  return (
    <Tooltip title={hideLabels ? link.name : ""} placement="right">
      <Box
        component={NavLink}
        to={link.path}
        sx={{
          display: "flex",
          flexDirection: {
            md: "column",
          },
          alignItems: "center",
          mx: { xs: 1, md: 0 },
          px: { xs: 1.5, md: 0.5 },
          py: { xs: 1.75, md: 1 },
          width: { xs: 200, md: 70 },
          borderRadius: 1,
          color: open ? "#fff" : "rgba(255, 255, 255, 0.5)",
          fontSize: { xs: 14, md: 9 },
          fontWeight: 300,
          textDecoration: "none",
          transition: "100ms",
          userSelect: "none",
          "&:hover": {
            bgcolor: "rgba(255, 255, 255, 0.05)",
          },
          "& svg": {
            width: 24,
            height: 24,
            mb: { md: 0.5 },
            mr: { xs: 3, md: 0 },
          },
        }}
      >
        {open ? link.icon.active : link.icon.default}
        {!hideLabels && link.name}
      </Box>
    </Tooltip>
  );
};

export default NavigationDrawer;
