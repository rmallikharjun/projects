import { ReactElement } from "react";
import { PageID } from "utils/constants";
import {
  AccountTree,
  AccountTreeOutlined,
  AdminPanelSettings,
  AdminPanelSettingsOutlined,
  Assessment,
  AssessmentOutlined,
  AttachMoney,
  Badge,
  BadgeOutlined,
  CarRental,
  CarRentalOutlined,
  ConfirmationNumber,
  ConfirmationNumberOutlined,
  Dashboard,
  DashboardOutlined,
  Description,
  DescriptionOutlined,
  DirectionsBike,
  ElectricBike,
  ElectricBikeOutlined,
  EventAvailable,
  EventAvailableOutlined,
  NotificationAdd,
  NotificationAddOutlined,
  PeopleAlt,
  PeopleAltOutlined,
  Power,
  PowerOutlined,
  EvStation,
  PrecisionManufacturing,
  PrecisionManufacturingOutlined,
  Sell,
  SellOutlined,
  SettingsRemote,
  SettingsRemoteOutlined,
} from "@mui/icons-material";
import BoltIcon from "@mui/icons-material/Bolt";
import Developer from "views/Developer";
import Admin from "views/Common/Admin";
import Reports from "views/Common/Reports";

import Chargers from "views/Charger/Chargers";
import ChargerInvoices from "views/Charger/Invoices";
import Bookings from "views/Charger/Bookings";
import ChargersOverview from "views/Charger/Overview";
import Subscriptions from "views/Charger/Subscriptions";
import Coupons from "views/Charger/Coupons";
import ChargerKYC from "views/Charger/KYC";
import ChargerUsers from "views/Charger/Users";
import Vendors from "./views/Charger/Vendors";
import Notifications from "views/Charger/Notifications";
import Account from "views/Account";
import ChargingZones from "views/Charger/ChargingZones";
import PowerControl from "./views/Charger/PowerControl";
import RetailOverview from "views/Retail/Overview";
import Assembly from "views/Retail/Assembly";
import Distribution from "views/Retail/Distribution";
import SoldVehicles from "views/Retail/SoldVehicles";
import RetailInvoices from "views/Retail/Invoices";
import RetailAdmin from "views/Retail/Admin";
import RentalOverview from "views/Rental/Overview";
import Vehicles from "views/Rental/Vehicles";
import Leases from "views/Rental/Leases";
import RentalUsers from "views/Rental/Users";
import RentalKYC from "views/Rental/KYC";
import RentalTrips from "views/Rental/Trips";
import RemoteControl from "views/Rental/RemoteControl";
// import RentalInvoices from "views/Rental/Invoices";
// import RentalAdmin from "views/Rental/Admin";

export interface NavigationLink {
  name: string;
  path: string;
  icon: {
    default: JSX.Element;
    active: JSX.Element;
  };
}

type Route = {
  id: PageID;
  path: string;
  name: string;
  component: React.ComponentType<any>;
  description: string;
  hasNestedPages?: boolean;
};

type Routes = {
  [key: string]: Route[];
};

export const commonRoutes = [
  {
    path: "/account",
    name: "Account",
    component: Account,
    description: "Your Profile | Company Details",
  },
  {
    path: "/developer",
    name: "Developer",
    component: Developer,
    description: "Developer",
  },
];

export const routes: Routes = {
  retail: [
    {
      id: "retail:overview",
      path: "/",
      name: "Overview",
      component: RetailOverview,
      description: "",
    },
    {
      id: "retail:assembly",
      path: "/assembly",
      name: "Assembly",
      component: Assembly,
      description: "",
    },
    {
      id: "retail:distribution",
      path: "/distribution",
      name: "Distribution",
      component: Distribution,
      description: "",
    },
    {
      id: "retail:soldVehicles",
      path: "/sold-vehicles",
      name: "Sold Vehicles",
      component: SoldVehicles,
      description: "",
      hasNestedPages: true,
    },
    {
      id: "retail:invoices",
      path: "/invoices",
      name: "Invoices",
      component: RetailInvoices,
      description: "",
    },
    {
      id: "retail:reports",
      path: "/reports",
      name: "Reports",
      component: Reports,
      description:
        "Charger Reports | Vendor Reports | Previously Downloaded Reports",
    },
    {
      id: "retail:admin",
      path: "/admin",
      name: "Admin",
      component: RetailAdmin,
      description: "",
    },
  ],
  rental: [
    {
      id: "rental:overview",
      path: "/",
      name: "Overview",
      component: RentalOverview,
      description: "",
    },
    {
      id: "rental:vehicles",
      path: "/vehicles",
      name: "Vehicles",
      component: Vehicles,
      description: "",
      hasNestedPages: true,
    },
    {
      id: "rental:leases",
      path: "/leases",
      name: "Leases",
      component: Leases,
      description: "",
    },
    {
      id: "rental:trips",
      path: "/trips",
      name: "Trips",
      component: RentalTrips,
      description: "",
    },
    {
      id: "rental:users",
      path: "/users",
      name: "Users",
      component: RentalUsers,
      description: "",
    },
    {
      id: "rental:kyc",
      path: "/kyc",
      name: "KYC",
      component: RentalKYC,
      description: "",
    },
    {
      id: "rental:reports",
      path: "/reports",
      name: "Reports",
      component: Reports,
      description:
        "Charger Reports | Vendor Reports | Previously Downloaded Reports",
    },
    {
      id: "rental:remoteControl",
      path: "/remoteControl",
      name: "Asset Control",
      component: RemoteControl,
      description: "",
    },
    // {
    //   id: "rental:invoices",
    //   path: "/invoices",
    //   name: "Invoices",
    //   component: RentalInvoices,
    //   description: "",
    // },
    {
      id: "rental:admin",
      path: "/admin",
      name: "Admin",
      component: Admin,
      description: "",
    },
  ],
  charger: [
    {
      id: "charger:overview",
      path: "/",
      name: "Overview",
      component: ChargersOverview,
      description:
        "Chargers | Top Locations | Insights | New Users | Top Users",
    },
    // { path: "/settings", name: "Settings", component: Home },
    {
      id: "charger:chargers",
      path: "/chargers",
      name: "Chargers",
      component: Chargers,
      description:
        "Charger Availability | Charger Assignment | Bookings vs Earnings | Energy Consumption",
    },
    {
      id: "charger:chargerzones",
      path: "/chargerzones",
      name: "Charger Zones",
      component: ChargingZones,
      description:
        "Charger Availability | Charger Assignment | Bookings vs Earnings | Energy Consumption",
    },
    {
      id: "charger:powerControl",
      path: "/powercontrol",
      name: "Power Control",
      component: PowerControl,
      description:
        "Charger Availability | Charger Assignment | Bookings vs Earnings | Energy Consumption",
    },
    {
      id: "charger:vendors",
      path: "/vendors",
      name: "Vendors",
      component: Vendors,
      description: "Vendors Stats | Vendor Insights",
    },
    {
      id: "charger:bookings",
      path: "/bookings",
      name: "Bookings",
      component: Bookings,
      description: "Bookings Stats | Energy vs Transaction | Earnings",
    },
    {
      id: "charger:subscriptions",
      path: "/subscriptions",
      name: "Subscriptions",
      component: Subscriptions,
      description: "Subscriptions",
    },
    {
      id: "charger:coupons",
      path: "/coupons",
      name: "Coupons",
      component: Coupons,
      description: "Coupons",
    },
    {
      id: "charger:kyc",
      path: "/kyc",
      name: "KYC",
      component: ChargerKYC,
      description: "KYC",
    },
    {
      id: "charger:users",
      path: "/users",
      name: "Users",
      component: ChargerUsers,
      description: "Users | Active Users | Top Users | User Groups",
    },
    {
      id: "charger:reports",
      path: "/reports",
      name: "Reports",
      component: Reports,
      description:
        "Charger Reports | Vendor Reports | Previously Downloaded Reports",
    },
    {
      id: "charger:notifications",
      name: "Notifications",
      path: "/notifications",
      component: Notifications,
      description: "Notifications",
    },
    {
      id: "charger:invoices",
      path: "/invoices",
      name: "Invoices",
      component: ChargerInvoices,
      description: "Invoices",
    },
    {
      id: "charger:admin",
      path: "/admin",
      name: "Admin",
      component: Admin,
      description: "",
    },
  ],
};

type NavLink = {
  id: PageID;
  name: string;
  path: string;
  icon: {
    active: ReactElement;
    default: ReactElement;
  };
};

export const navigationLinks: { [key: string]: NavLink[] } = {
  retail: [
    {
      id: "retail:overview",
      name: "Overview",
      path: "/",
      icon: { active: <Dashboard />, default: <DashboardOutlined /> },
    },
    {
      id: "retail:assembly",
      name: "Assembly",
      path: "/assembly",
      icon: {
        active: <PrecisionManufacturing />,
        default: <PrecisionManufacturingOutlined />,
      },
    },
    {
      id: "retail:distribution",
      name: "Distribution",
      path: "/distribution",
      icon: { active: <AccountTree />, default: <AccountTreeOutlined /> },
    },
    {
      id: "retail:soldVehicles",
      name: "Sold Vehicles",
      path: "/sold-vehicles",
      icon: { active: <Sell />, default: <SellOutlined /> },
    },
    {
      id: "retail:invoices",
      name: "Invoices",
      path: "/invoices",
      icon: { active: <Description />, default: <DescriptionOutlined /> },
    },
    {
      id: "retail:reports",
      name: "Reports",
      path: "/reports",
      icon: { active: <Assessment />, default: <AssessmentOutlined /> },
    },
    {
      id: "retail:admin",
      name: "Admin",
      path: "/admin",
      icon: {
        active: <AdminPanelSettings />,
        default: <AdminPanelSettingsOutlined />,
      },
    },
  ],
  rental: [
    {
      id: "rental:overview",
      name: "Overview",
      path: "/",
      icon: { active: <Dashboard />, default: <DashboardOutlined /> },
    },
    {
      id: "rental:vehicles",
      name: "Vehicles",
      path: "/vehicles",
      icon: { active: <ElectricBike />, default: <ElectricBikeOutlined /> },
    },
    {
      id: "rental:leases",
      name: "Leases",
      path: "/leases",
      icon: { active: <CarRental />, default: <CarRentalOutlined /> },
    },
    {
      id: "rental:trips",
      name: "Trips",
      path: "/trips",
      icon: { active: <DirectionsBike />, default: <DirectionsBike /> },
    },
    {
      id: "rental:users",
      name: "Users",
      path: "/users",
      icon: { active: <PeopleAlt />, default: <PeopleAltOutlined /> },
    },
    {
      id: "rental:kyc",
      name: "KYC",
      path: "/kyc",
      icon: { active: <Badge />, default: <BadgeOutlined /> },
    },
    {
      id: "rental:reports",
      name: "Reports",
      path: "/reports",
      icon: { active: <Assessment />, default: <AssessmentOutlined /> },
    },
    {
      id: "rental:remoteControl",
      name: "Asset Control",
      path: "/remoteControl",
      icon: { active: <SettingsRemote />, default: <SettingsRemoteOutlined /> },
    },
    // {
    //   id: "rental:invoices",
    //   name: "Invoices",
    //   path: "/invoices",
    //   icon: { active: <Description />, default: <DescriptionOutlined /> },
    // },
    {
      id: "rental:admin",
      name: "Admin",
      path: "/admin",
      icon: {
        active: <AdminPanelSettings />,
        default: <AdminPanelSettingsOutlined />,
      },
    },
  ],
  charger: [
    {
      id: "charger:overview",
      name: "Overview",
      path: "/",
      icon: { active: <Dashboard />, default: <DashboardOutlined /> },
    },
    {
      id: "charger:chargers",
      name: "Chargers",
      path: "/chargers",
      icon: { active: <Power />, default: <PowerOutlined /> },
    },
    {
      id: "charger:chargerzones",
      name: "ChargerZones",
      path: "/chargerzones",
      icon: { active: <EvStation />, default: <EvStation /> },
    },
    {
      id: "charger:powerControl",
      name: "PowerControl",
      path: "/powercontrol",
      icon: { active: <BoltIcon />, default: <BoltIcon /> },
    },
    {
      id: "charger:vendors",
      name: "Vendors",
      path: "/vendors",
      icon: { active: <AccountTree />, default: <AccountTreeOutlined /> },
    },
    {
      id: "charger:bookings",
      name: "Bookings",
      path: "/bookings",
      icon: { active: <EventAvailable />, default: <EventAvailableOutlined /> },
    },
    {
      id: "charger:subscriptions",
      name: "Subscriptions",
      path: "/subscriptions",
      icon: { active: <AttachMoney />, default: <AttachMoney /> },
    },
    {
      id: "charger:coupons",
      name: "Coupons",
      path: "/coupons",
      icon: {
        active: <ConfirmationNumber />,
        default: <ConfirmationNumberOutlined />,
      },
    },
    {
      id: "charger:users",
      name: "Users",
      path: "/users",
      icon: { active: <PeopleAlt />, default: <PeopleAltOutlined /> },
    },
    {
      id: "charger:kyc",
      name: "KYC",
      path: "/kyc",
      icon: { active: <Badge />, default: <BadgeOutlined /> },
    },
    {
      id: "charger:reports",
      name: "Reports",
      path: "/reports",
      icon: { active: <Assessment />, default: <AssessmentOutlined /> },
    },
    {
      id: "charger:notifications",
      name: "Notifications",
      path: "/notifications",
      icon: {
        active: <NotificationAdd />,
        default: <NotificationAddOutlined />,
      },
    },
    // {
    //   id: "charger:invoices",
    //   name: "Invoices",
    //   path: "/invoices",
    //   icon: { active: <Description />, default: <DescriptionOutlined /> },
    // },
    {
      id: "charger:admin",
      name: "Admin",
      path: "/admin",
      icon: {
        active: <AdminPanelSettings />,
        default: <AdminPanelSettingsOutlined />,
      },
    },
  ],
};
