import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Hidden,
  Popover,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  useMediaQuery,
  useTheme,
} from "@mui/material";
import StaticDateRangePicker from "@mui/lab/StaticDateRangePicker";
import { DateRange } from "@mui/lab/DateRangePicker";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import { sub } from "date-fns";
import { DateRangeOutlined } from "@mui/icons-material";
import moment from "moment";

interface Props {
  range: DateRange<Date>;
  setRange: (range: DateRange<Date>) => void;
  presets?: string[];
  initialRange?: string;
}

const RangePicker: React.FC<Partial<Props>> = ({
  range,
  setRange,
  presets = ["7D", "1M", "3M", "1Y", "YTD"],
  initialRange,
}) => {
  const theme = useTheme();
  const isMdUp = useMediaQuery(theme.breakpoints.up("md"));

  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [value, setValue] = useState<string | null>(initialRange || "1M");
  const [customRange, setCustomRange] = useState<DateRange<Date>>([null, null]);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  useEffect(() => {
    if (range === null) setValue(null);
  }, [range]);

  function handleChange(newValue: string) {
    setValue(newValue);
    if (!setRange) return;
    if (newValue !== "custom") {
      setRange([
        newValue === "YTD"
          ? new Date(2018, 0, 1)
          : sub(new Date(), {
              ...(newValue === "12H" ? { hours: 12 } : {}),
              ...(newValue === "1D" ? { days: 1 } : {}),
              ...(newValue === "4D" ? { days: 4 } : {}),
              ...(newValue === "7D" ? { days: 7 } : {}),
              ...(newValue === "1M" ? { months: 1 } : {}),
              ...(newValue === "3M" ? { months: 3 } : {}),
              ...(newValue === "1Y" ? { years: 1 } : {}),
            }),
        new Date(),
      ]);
      setCustomRange([null, null]);
      setStartDate("");
      setEndDate("");
    }
  }

  function handleClose(e: any) {
    e.stopPropagation();
    setAnchorEl(null);
    // setCustomRange([null, null])
  }

  return (
    <ToggleButtonGroup
      sx={{
        "& .MuiToggleButton-root": {
          "& > div": {
            fontWeight: 600,
            lineHeight: "1em",
          },
        },
      }}
      exclusive
      size="small"
      color="primary"
      value={value}
      onChange={(e, newValue) => {
        if (newValue) handleChange(newValue);
      }}
    >
      {presets.map((el, i) => (
        <ToggleButton
          key={i}
          value={el}
          sx={el === "YTD" ? { letterSpacing: "-0.025em" } : {}}
        >
          <div>{el}</div>
        </ToggleButton>
      ))}
      <ToggleButton
        disableRipple
        value="custom"
        onClick={(e: any) => {
          e.preventDefault();
          setAnchorEl(e.currentTarget);
        }}
      >
        <DateRangeOutlined sx={{ fontSize: 18 }} />
        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
        >
          <Box>
            <Hidden mdDown>
              <Box
                p={2}
                pb={1}
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                {/* <Typography
                variant="body2"
                sx={{
                  "& b": { fontWeight: 600 },
                  "& span": { color: "text.disabled" },
                }}
              >
                Selected:{" "}
                {customRange[0] ? (
                  <b>{moment(customRange[0]).format("DD/MM/yyyy")}</b>
                ) : (
                  <span className="secondary">dd/mm/yyyy</span>
                )}{" "}
                to{" "}
                {customRange[1] ? (
                  <b>{moment(customRange[1]).format("DD/MM/yyyy")}</b>
                ) : (
                  <span className="secondary">dd/mm/yyyy</span>
                )}
              </Typography> */}
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    "& b": {
                      fontWeight: 600,
                    },
                  }}
                >
                  <b>From</b>
                  <TextField
                    sx={{ ml: 1, mr: 1.5, width: 130 }}
                    size="small"
                    placeholder="dd/mm/yyyy"
                    value={startDate}
                    onChange={(e) => {
                      let input = e.target.value;
                      if (/^[0-9/]*$/.test(input)) {
                        setStartDate(input);
                        let date = input.split("/");
                        if (date.length === 3) {
                          let d = date[0];
                          let m = date[1];
                          let y = date[2];
                          let isValid =
                            d.length === 2 && m.length === 2 && y.length === 4;
                          if (isValid) {
                            setCustomRange((prev) => [
                              new Date(
                                parseInt(y),
                                parseInt(m) - 1,
                                parseInt(d)
                              ),
                              prev[1],
                            ]);
                          }
                        }
                      }
                    }}
                  />
                  <b>To</b>
                  <TextField
                    sx={{ ml: 1, width: 130 }}
                    size="small"
                    placeholder="dd/mm/yyyy"
                    value={endDate}
                    onChange={(e) => {
                      let input = e.target.value;
                      if (/^[0-9/]*$/.test(input)) {
                        setEndDate(input);
                        let date = input.split("/");
                        if (date.length === 3) {
                          let d = date[0];
                          let m = date[1];
                          let y = date[2];
                          let isValid =
                            d.length === 2 && m.length === 2 && y.length === 4;
                          if (isValid) {
                            setCustomRange((prev) => [
                              prev[0],
                              new Date(
                                parseInt(y),
                                parseInt(m) - 1,
                                parseInt(d)
                              ),
                            ]);
                          }
                        }
                      }
                    }}
                  />
                </Box>
                <Box display="flex" alignItems="center">
                  <Button
                    sx={{ mr: 1, height: 36 }}
                    size="small"
                    variant="outlined"
                    onClick={handleClose}
                  >
                    Cancel
                  </Button>
                  <Button
                    sx={{ height: 36 }}
                    variant="contained"
                    size="small"
                    disabled={customRange.includes(null)}
                    onClick={(e) => {
                      e.stopPropagation();
                      setRange && setRange(customRange);
                      setAnchorEl(null);
                      setValue("custom");
                    }}
                  >
                    Continue
                  </Button>
                </Box>
              </Box>
            </Hidden>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <StaticDateRangePicker
                defaultCalendarMonth={sub(new Date(), { months: 1 })}
                disableFuture
                showDaysOutsideCurrentMonth={true}
                calendars={2}
                reduceAnimations
                displayStaticWrapperAs={isMdUp ? "desktop" : "mobile"}
                value={customRange}
                onChange={(newValue) => {
                  setCustomRange(newValue);
                  newValue[0] &&
                    setStartDate(moment(newValue[0]).format("DD/MM/yyyy"));
                  newValue[1] &&
                    setEndDate(moment(newValue[1]).format("DD/MM/yyyy"));
                }}
                renderInput={(startProps, endProps) => (
                  <>
                    <TextField
                      label="a"
                      size="small"
                      sx={{ width: 120 }}
                      {...startProps}
                    />
                    <Box sx={{ mx: 1 }}> to </Box>
                    <TextField
                      label="a"
                      size="small"
                      sx={{ width: 120 }}
                      {...endProps}
                    />
                  </>
                )}
              />
            </LocalizationProvider>
            <Hidden mdUp>
              <Box
                m={2}
                mt={-0.5}
                display="flex"
                alignItems="center"
                justifyContent="right"
              >
                <Button
                  sx={{ mr: 1, height: 36 }}
                  size="small"
                  variant="outlined"
                  onClick={handleClose}
                >
                  Cancel
                </Button>
                <Button
                  sx={{ height: 36 }}
                  variant="contained"
                  size="small"
                  disabled={customRange.includes(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    setRange && setRange(customRange);
                    setAnchorEl(null);
                    setValue("custom");
                  }}
                >
                  Continue
                </Button>
              </Box>
            </Hidden>
          </Box>
        </Popover>
      </ToggleButton>
    </ToggleButtonGroup>
  );
};

export default RangePicker;
