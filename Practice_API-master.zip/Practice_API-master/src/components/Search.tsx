import React, { useState } from "react";
import { Box, IconButton } from "@mui/material";
import { Close, SearchOutlined } from "@mui/icons-material";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";
import { SxProps, Theme } from "@mui/system";

// TODO: toggle case sensitive search

interface Props {
  handleSearch: (input: string) => void;
  id?: string;
  placeholder?: string;
  persist?: boolean;
  enableClear?: boolean;
  enableClose?: boolean;
  enableBorder?: boolean;
  onClose?: () => void;
  sx?: SxProps<Theme>;
  width?: number;
  widthFocused?: number;
}

const Search: React.FC<Props> = ({
  handleSearch,
  id,
  placeholder,
  persist,
  enableClear,
  enableClose,
  enableBorder,
  onClose,
  sx = {},
  width,
  widthFocused,
}) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const [focused, setFocus] = useState(false);
  const [input, setInput] = useState("");
  const [clearButton, setClearButton] = useState(false);

  function handleKeyPress(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && e.currentTarget.value !== "") {
      handleSearch(e.currentTarget.value);
      setClearButton(true);
      if (!persist) setInput("");
    }
  }

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        height: "min-content",
        background: "transparent",
        ...(enableBorder
          ? {
              transition: "all 200ms",
              border: 1,
              borderColor: (theme) =>
                !focused ? theme.customColors.border : "primary.main",
              borderRadius: 1,
              pl: 1,
            }
          : {}),
        "& label": {
          mr: 1.25,
          height: "20px",
          color: (theme) => theme.palette.text.secondary,
          cursor: "text",
        },
        "& input": {
          pt: 0.5,
          fontSize: 14,
          outline: "none",
          border: "none",
          transition: "all 150ms",
          width: focused
            ? widthFocused
              ? widthFocused
              : 120
            : width
            ? width
            : 100,
          bgcolor: "transparent",
          color: isDarkMode ? "white" : "black",
        },
        ...sx,
      }}
    >
      <label htmlFor={id ? id : "searchbar"}>
        <SearchOutlined fontSize="small" />
      </label>
      <input
        id={id ? id : "searchbar"}
        type="text"
        name="search"
        placeholder={placeholder || "Search..."}
        value={input}
        autoComplete="off"
        onFocus={() => {
          setFocus(true);
        }}
        onBlur={() => {
          setFocus(false);
        }}
        onChange={(e) => {
          setInput(e.target.value);
        }}
        onKeyPress={handleKeyPress}
      />
      {enableClear && (
        <IconButton
          sx={{ visibility: clearButton || enableClose ? "visible" : "hidden" }}
          onClick={() => {
            handleSearch("");
            setInput("");
            setClearButton(false);
            onClose && onClose();
          }}
          size="small"
        >
          <Close fontSize="small" />
        </IconButton>
      )}
    </Box>
  );
};

export default Search;
