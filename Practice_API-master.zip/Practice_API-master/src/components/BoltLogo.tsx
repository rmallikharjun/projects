import { ReactComponent as SvgLogo } from "assets/images/logo.svg";

interface LogoProps {
  width: number | string;
  color?: string;
  margin?: string | number;
}

const RevosLogo = ({ color, ...rest }: LogoProps) => {
  return (
    <div
      style={{ color: color || "#61D169", ...rest, cursor: "pointer" }}
      onClick={() => window.open("/", "_self")}
    >
      <SvgLogo />
    </div>
  );
};

export default RevosLogo;
