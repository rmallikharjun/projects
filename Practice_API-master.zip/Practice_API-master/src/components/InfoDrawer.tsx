import { Box } from "@mui/material";
import { useSelector } from "react-redux";
import { GlobalState } from "utils";

const drawerWidth = 550;

const InfoDrawer = () => {
  let drawerState = useSelector((state: GlobalState) => state.global.drawer);

  return (
    <Box
      sx={{
        width: {
          xs: drawerState.open ? "100vw" : 0,
          md: drawerState.open ? drawerWidth : 0,
        },
        boxShadow: "0 0 8px #15223214",
        overflowX: "hidden",
        transition: "200ms",
      }}
    >
      <Box
        sx={{
          width: { xs: 1, md: drawerWidth },
          height: 1,
          backgroundColor: (theme) => theme.palette.background.paper,
        }}
      >
        {drawerState.content}
      </Box>
    </Box>
  );
};

export default InfoDrawer;
