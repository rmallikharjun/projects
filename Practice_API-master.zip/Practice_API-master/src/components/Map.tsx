import { useEffect, useRef, useState } from "react";
import { Box, Skeleton } from "@mui/material";
import { Wrapper } from "@googlemaps/react-wrapper";
// import { GMAPS_API_KEY } from "utils/constants";
import ChargerBookedIcon from "assets/images/charger-booked.svg";
import ChargerBookedHoverIcon from "assets/images/charger-booked-hover.svg";
import ChargerAvailableIcon from "assets/images/charger-available.svg";
import ChargerAvailableHoverIcon from "assets/images/charger-available-hover.svg";
import ChargerPinIcon from "assets/images/charger-pin.svg";
import { useSelector } from "react-redux";
import { getDarkModePreference, GlobalState } from "utils";

import { MarkerClusterer } from "@googlemaps/markerclusterer";

interface MapProps {
  loading: boolean;
  type: "charger" | "points" | "heatmap" | "cluster";
  borderRadius?: number | string;
  dataArray?: any;
  location?: any;
}

const MapComponent: React.FC<MapProps> = ({ borderRadius, ...props }) => {
  return (
    <Box
      sx={{
        position: "relative",
        width: 1,
        height: 1,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: borderRadius ? borderRadius : 0,
        overflow: "hidden",
      }}
    >
      {props.loading ? (
        <Skeleton
          variant="rectangular"
          width="100%"
          height="100%"
          animation="wave"
        />
      ) : (
        <Wrapper
          libraries={["visualization"]}
          apiKey={"AIzaSyBPPkwK8voLg73XR9xvR9xuoKqyfzu7Gac"}
        >
          <GoogleMap {...props} />
        </Wrapper>
      )}
    </Box>
  );
};

const GoogleMap: React.FC<Partial<MapProps>> = ({
  type,
  dataArray,
  location,
}) => {
  const isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  const ref = useRef<HTMLElement | null>(null);

  const [map, setMap] = useState<google.maps.Map | null>(null);

  useEffect(() => {
    setMap(
      new window.google.maps.Map(ref.current as HTMLElement, {
        mapId: isDarkMode ? "116bee00eb35c33a" : "a6ecf3b466dc84ee",
        center:
          type === "charger" && location
            ? { lat: location.latitude, lng: location.longitude }
            : { lat: 12.9716, lng: 77.5946 },
        zoom: type === "charger" ? 15 : 12,
        zoomControl: true,
        streetViewControl: false,
        fullscreenControl: true,
        fullscreenControlOptions: {
          position: google.maps.ControlPosition.LEFT_BOTTOM,
        },
        zoomControlOptions: {
          position: google.maps.ControlPosition.LEFT_BOTTOM,
        },
      })
    );
  }, [type, location, isDarkMode]);

  useEffect(() => {
    if (!map) return;
    if (type === "points" || type === "charger") {
      if (dataArray) {
        let bounds = new google.maps.LatLngBounds();

        let array = dataArray.filter((el: any) =>
          type === "charger"
            ? !(
                el.station.location.latitude === location.latitude &&
                el.station.location.longitude === location.longitude
              )
            : true
        );

        const markers = array.map((charger: any) => {
          let name = charger.id || charger.charger.chargerId;
          let status = charger?.charger?.chargerStatus || "";
          let position = {
            lat: charger.station.location.latitude,
            lng: charger.station.location.longitude,
          };
          let anchor = new google.maps.Point(11, 11);

          let defaultIcon = {
            url: status === "BOOKED" ? ChargerBookedIcon : ChargerAvailableIcon,
            anchor,
          };
          let hoveredIcon = {
            url:
              status === "BOOKED"
                ? ChargerBookedHoverIcon
                : ChargerAvailableHoverIcon,
            anchor,
          };

          const marker = new google.maps.Marker({
            position,
            map,
            icon: defaultIcon,
          });

          const infoWindow = new google.maps.InfoWindow({
            content: name,
            position,
          });

          marker.addListener("click", () => {
            infoWindow.open(marker.get("map"), marker);
          });
          marker.addListener("mouseover", () => {
            marker.setIcon(hoveredIcon);
            infoWindow.open(marker.get("map"), marker);
          });
          marker.addListener("mouseout", () => {
            marker.setIcon(defaultIcon);
            infoWindow.close();
          });

          let latLng = new google.maps.LatLng(position.lat, position.lng);
          bounds.extend(latLng);

          return marker;
        });
        new MarkerClusterer({ map, markers });
        if (array.length > 0) map?.fitBounds(bounds);
      }
    }

    if (type === "charger") {
      new google.maps.Marker({
        position: {
          lat: location?.latitude || 12.99797722402445,
          lng: location?.longitude || 77.63656987220915,
        },
        map,
        icon: {
          url: ChargerPinIcon,
          anchor: new google.maps.Point(29, 58),
        },
      });
    }
  }, [map, isDarkMode, type, dataArray, location]);

  return (
    <Box
      ref={ref}
      sx={{ position: "absolute", width: 1, height: 1, color: "black" }}
    />
  );
};

export default MapComponent;
