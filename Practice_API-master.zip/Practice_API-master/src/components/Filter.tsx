import {
  Search as Searchnew,
  Close,
  FilterAltOutlined,
} from "@mui/icons-material";
import {
  Box,
  IconButton,
  MenuItem,
  Select,
  OutlinedInput,
  FormControl,
  ListItemText,
  Checkbox,
  InputAdornment,
  Typography,
  useTheme,
  SelectChangeEvent,
} from "@mui/material";
import { useEffect, useState } from "react";

interface Props {
  dropdownEntries: any[];
  getDropdownData: (entry: any[]) => void;
  onClose: () => void;
  filterList: any[];
  dropdownHeight: number;
  setFilterList: (value: React.SetStateAction<string[]>) => void;
  entrySearchDialog?: {
    open: boolean;
    input: string;
  };
  setEntrySearchDialog?: React.Dispatch<
    React.SetStateAction<{
      open: boolean;
      input: string;
    }>
  >;
  searchableEntryList?: any[];
  entryList: any;
  count?: boolean;
}

const Filter: React.FC<Props> = ({
  dropdownEntries, //
  getDropdownData, //
  filterList,
  setFilterList,
  entrySearchDialog,
  setEntrySearchDialog,
  searchableEntryList, //
  dropdownHeight,
  onClose,
  entryList,
  count,
}: any) => {
  const theme = useTheme();

  const ITEM_HEIGHT = dropdownHeight;
  const ITEM_PADDING_TOP = 18;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const [filterCount, setFilterCount] = useState<any>(0);

  const handleChangeFilter = (event: SelectChangeEvent<typeof filterList>) => {
    const {
      target: { value },
    } = event;
    setFilterList(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  function handleKeyPress(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && e.currentTarget.value !== "") {
      let res = entryList.filter((o: any) =>
        o.name.toLowerCase().includes(entrySearchDialog.input.toLowerCase())
      );
      getDropdownData(res);
    }
  }

  const removeEntryFromArray = (el: any) => {
    let list = filterList.filter((el2: any) => {
      return el !== el2;
    });
    setFilterList(list);
  };

  const filterHeading = (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
      }}
    >
      <Box display="flex" justifyContent="center" alignItems="top">
        <FilterAltOutlined
          style={{
            width: "18px",
            marginTop: "-1px",
            color: "#00000099",
            marginRight: "5px",
          }}
        />
        Filters
      </Box>

      {filterCount !== 0 ? (
        <Box
          ml={1}
          width={"15px"}
          height={"15px"}
          sx={{
            background: "#3BB89E40",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: 20,
            fontSize: 10,
            fontWeight: "500",
            color: theme.palette.primary.main,
          }}
        >
          {filterCount}
        </Box>
      ) : (
        ""
      )}
    </Box>
  );

  useEffect(() => {
    if (filterList) {
      let newFilter = filterList.filter((el: any) => {
        return el !== undefined;
      });

      setFilterCount(newFilter.length);
    }
  }, [filterList]);

  return (
    <Box display="flex" alignItems="center">
      <FormControl
        sx={{
          width: 250,

          "& .MuiOutlinedInput-root": {},
          "& .MuiModal-root": {
            maxHeight: 500,
          },
          "& .MuiPaper-root": {
            maxHeight: 500,
            background: "black",
          },
        }}
      >
        <Select
          multiple
          displayEmpty
          value={filterList}
          onChange={handleChangeFilter}
          onClose={onClose}
          input={<OutlinedInput />}
          renderValue={(selected) => {
            if (selected.length === 0) {
              return filterHeading;
            } else {
              return filterHeading;
            }
          }}
          MenuProps={MenuProps}
          inputProps={{ "aria-label": "Without label" }}
        >
          {dropdownEntries.map((entry: any) =>
            entry.type === "name" ? (
              <MenuItem
                sx={{ ml: -1.5, height: 2, display: "flex" }}
                key={entry.name}
                value={entry.name}
              >
                <Checkbox checked={filterList.indexOf(entry.name) > -1} />
                <ListItemText
                  primary={
                    <Box display="flex">
                      {entry.name}{" "}
                      {count && entry?.count ? (
                        <Typography
                          sx={{ fontSize: 12, ml: 1, color: "text.disabled" }}
                        >
                          ({entry.count})
                        </Typography>
                      ) : (
                        ""
                      )}
                    </Box>
                  }
                />
              </MenuItem>
            ) : (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  mt: 1,
                  height: 35,
                }}
              >
                {entry.searchable ? (
                  entrySearchDialog.open ? (
                    <OutlinedInput
                      placeholder="Search a City..."
                      size="small"
                      autoFocus
                      fullWidth
                      value={entrySearchDialog.input}
                      onKeyDown={(e) => e.stopPropagation()}
                      onKeyPress={handleKeyPress}
                      sx={{
                        "& .MuiOutlinedInput-input": {
                          fontSize: 12,
                        },
                        mx: 1,
                        borderRadius: 10,
                        zIndex: 10,
                      }}
                      onChange={(e: any) => {
                        setEntrySearchDialog({
                          ...entrySearchDialog,
                          input: e.target.value,
                        });
                      }}
                      endAdornment={
                        <InputAdornment position="end">
                          <IconButton
                            children={<Close style={{ width: "20px" }} />}
                            size="small"
                            onClick={() => {
                              setEntrySearchDialog({ open: false, input: "" });
                              getDropdownData(entryList);
                            }}
                            sx={{ mr: -1.5 }}
                          />
                        </InputAdornment>
                      }
                    />
                  ) : (
                    <>
                      <MenuItem key={entry.name} disabled value={entry.name}>
                        <ListItemText primary={entry.label} />
                      </MenuItem>
                      <Box
                        sx={{
                          mr: 1,
                          width: "30px",
                          height: "30px",
                          background: "#40404015",
                          borderRadius: "20px",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          cursor: "pointer",
                        }}
                        onClick={() => {
                          setEntrySearchDialog({
                            ...entrySearchDialog,
                            open: true,
                          });
                        }}
                      >
                        <Searchnew
                          sx={{
                            width: "20px",
                            color: "#40404099",
                          }}
                        />
                      </Box>
                    </>
                  )
                ) : (
                  <MenuItem key={entry.name} disabled value={entry.name}>
                    <ListItemText primary={entry.label} />
                  </MenuItem>
                )}
              </Box>
            )
          )}
        </Select>
      </FormControl>
      {filterList.length
        ? filterList.map((el: any) => {
            // eslint-disable-next-line
            {
              return el !== undefined ? (
                <Box
                  sx={{
                    fontSize: 13,
                    px: 1,
                    py: 1.8,
                    border: "1px solid #00000020",
                    height: "15px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: "5px",
                    ml: 2,
                  }}
                >
                  {el}
                  <Close
                    sx={{ width: "15px", ml: 1, cursor: "pointer" }}
                    onClick={() => {
                      removeEntryFromArray(el);
                    }}
                  />
                </Box>
              ) : (
                ""
              );
            }
          })
        : ""}
    </Box>
  );
};

export default Filter;
