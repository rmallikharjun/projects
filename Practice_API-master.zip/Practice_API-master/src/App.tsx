import React, { useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Switch, Route, Redirect, withRouter } from "react-router-dom";
import { login, toggleDarkMode, toggleSnackbar } from "./actions";
import { getDarkModePreference, GlobalState, setLoader } from "./utils";
import jwt from "jwt-simple";
import {
  Alert,
  Backdrop,
  Button,
  CircularProgress,
  createTheme,
  CssBaseline,
  Snackbar,
} from "@mui/material";
import { alpha, ThemeProvider } from "@mui/system";
import { StyledEngineProvider } from "@mui/material/styles";

import DashboardLayout from "./pages/DashboardLayout";
import Auth from "./pages/Auth";
import { ExpandMore, KeyboardArrowDown } from "@mui/icons-material";

import { defaults } from "react-chartjs-2";
import storageManager from "utils/storageManager";
defaults.font.family = "Metropolis";

interface CustomTheme {
  customColors: {
    header: string;
    border: string;
    green: string;
    black: string;
    greenSecondary: string;
    blue: string;
    blueSecondary: string;
    yellowSecondary: string;
    orangeSecondary: string;
    redSecondary: string;
    grey: string;
    greySecondary: string;
    action: string;
    text: {
      green: string;
      blue: string;
      greenSecondary: string;
      blueSecondary: string;
      yellowSecondary: string;
      orangeSecondary: string;
      redSecondary: string;
      grey: string;
    };
  };
  customShadows: {
    small: string;
    medium: string;
  };
}
declare module "@mui/material/styles" {
  interface Theme extends CustomTheme {}
  interface ThemeOptions extends CustomTheme {}
}
declare module "@mui/material/Avatar" {
  interface AvatarPropsVariantOverrides {
    icon: true;
    label: true;
    status: true;
  }
}
declare module "@mui/material/Button" {
  interface ButtonPropsVariantOverrides {
    action: true;
  }
}

const App = () => {
  let isDarkMode = useSelector((state: GlobalState) =>
    getDarkModePreference(state)
  );
  let loaderState = useSelector((state: GlobalState) => state.global.loader);
  let snackbarState = useSelector(
    (state: GlobalState) => state.global.snackbar
  );
  const { snackPack, open, messageInfo, actionInfo } = snackbarState;
  const dispatch = useDispatch();

  const setSnackbar = (val: object) => {
    dispatch(toggleSnackbar({ ...snackbarState, ...val }));
  };

  const handleClose = (
    event: Event | React.SyntheticEvent<any, Event>,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }
    setSnackbar({ open: false });
  };

  const handleExited = () => {
    setSnackbar({ messageInfo: undefined });
  };

  useEffect(() => {
    if (snackPack.length && !messageInfo) {
      // Set a new snack when we don't have an active one
      dispatch(
        toggleSnackbar({
          ...snackbarState,
          messageInfo: { ...snackPack[0] },
          snackPack: snackPack.slice(1),
          open: true,
        })
      );
    } else if (snackPack.length && messageInfo && open) {
      // Close an active snack when a new one is added
      dispatch(toggleSnackbar({ ...snackbarState, open: false }));
    }
  }, [snackPack, messageInfo, open, dispatch, snackbarState]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    function setTheme(e: MediaQueryListEvent) {
      dispatch(toggleDarkMode(e.matches));
    }
    mq.addEventListener("change", setTheme);
    return function cleanUp() {
      mq.removeEventListener("change", setTheme);
    };
  }, [dispatch]);

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode: isDarkMode ? "dark" : "light",
          primary: {
            main: "#3CB99E",
          },
          secondary: {
            main: "#57B8FF",
          },
          success: {
            main: "#3CB99E",
          },
          error: {
            main: "#F40D2C",
          },
          common: {
            black: "#3D3D3D",
            white: "#F6F8FB",
          },
          text: {
            primary: isDarkMode ? "#fff" : "#232D42",
            secondary: isDarkMode ? "rgba(255, 255, 255, 0.7)" : "#495057",
          },
          background: {
            default: isDarkMode ? "#1a1a1a" : "#F6F8FB",
            paper: isDarkMode ? "#121212" : "#fff",
          },
          divider: isDarkMode ? "rgba(255, 255, 255, 0.12)" : "#EBEFF2",
        },
        customColors: {
          header: isDarkMode ? "#1a1a1a" : "#F4F7FC",
          border: isDarkMode ? "rgba(255, 255, 255, 0.12)" : "#E6E9F4",
          green: "#28CA96",
          black: "#000000",
          greenSecondary: "#29CB97",
          blue: "#57B8FF",
          blueSecondary: "#1162FB",
          yellowSecondary: "#f5d63d",
          orangeSecondary: "#f7782f",
          redSecondary: "#ed344a",
          grey: isDarkMode ? "rgba(255, 255, 255, 0.5)" : "#8A92A6",
          greySecondary: isDarkMode ? "rgba(255, 255, 255, 0.5)" : "#5A607F",
          action: "#ADB5BD",
          text: {
            green: "#28CA96",
            blue: "#57B8FF",
            greenSecondary: "#68D6A5",
            blueSecondary: "#477BED",
            yellowSecondary: "#f5d63d",
            orangeSecondary: "#f7782f",
            redSecondary: "#ed344a",
            grey: isDarkMode ? "rgba(255, 255, 255, 0.7)" : "#7E84A3",
          },
        },
        customShadows: {
          small: "0 0 4px #1C295A14",
          medium: "0 0 10px #1C295A14",
        },
      }),
    [isDarkMode]
  );

  const customTheme = useMemo(
    () =>
      createTheme({
        ...theme,
        shape: {
          borderRadius: 6,
        },
        typography: {
          h2: {
            fontSize: 20,
            fontWeight: 700,
            color: theme.palette.text.primary,
            letterSpacing: "-0.015em",
          },
          h6: {
            fontSize: 17,
            fontWeight: 700,
          },
        },
        components: {
          MuiTypography: {
            styleOverrides: {
              root: {
                "&.label": {
                  fontWeight: 500,
                  color: isDarkMode ? "#fff" : "#000",
                  marginBottom: 12,
                  lineHeight: "18px",
                },
              },
            },
          },
          MuiCssBaseline: {
            styleOverrides: {
              body: {
                "&::-webkit-scrollbar, & *::-webkit-scrollbar, &::-webkit-scrollbar-corner, & *::-webkit-scrollbar-corner":
                  {
                    backgroundColor: theme.palette.background.default,
                    width: 12,
                    height: 12,
                  },
                "&::-webkit-scrollbar-thumb, & *::-webkit-scrollbar-thumb": {
                  backgroundColor: theme.palette.grey[isDarkMode ? 600 : 500],
                  borderRadius: 8,
                  minHeight: 24,
                  border: "3px solid",
                  borderColor: theme.palette.background.default,
                },
              },
            },
          },
          MuiDialog: {
            styleOverrides: {
              paper: {
                borderRadius: 8,
              },
              root: {
                "& .MuiDialogTitle-root": {
                  padding: 32,
                  paddingBottom: 8,
                  fontSize: 18,
                  fontWeight: 500,
                },
                "& .MuiDialogContent-root": {
                  padding: "0 32px",
                  "& .label": {
                    fontWeight: 500,
                    color: isDarkMode ? "#fff" : "#000",
                    marginBottom: 12,
                    lineHeight: "18px",
                  },
                  "& .header": {
                    fontWeight: 500,
                    lineHeight: "18px",
                    gridColumn: "span 2",
                  },
                  "&.py-1": {
                    padding: "8px 32px",
                  },
                },
                "& .MuiDialogActions-root": {
                  padding: 32,
                  "&.dense": {
                    padding: "0 32px 24px",
                  },
                  "&>:not(:first-of-type)": {
                    marginLeft: 16,
                  },
                  "& .MuiButton-root": {
                    height: 40,
                    minWidth: 90,
                    [theme.breakpoints.up("sm")]: {
                      minWidth: 145,
                    },
                  },
                },
              },
            },
          },
          MuiStep: {
            styleOverrides: {
              root: {
                "& .MuiStepIcon-root": {
                  color: alpha(theme.palette.primary.main, 0.1),
                },
                "& .Mui-active.MuiStepIcon-root": {
                  color: theme.palette.primary.main,
                },
                "& .MuiStepIcon-text": {
                  fill: alpha(theme.palette.primary.main, 0.4),
                },
                "& .Mui-active > .MuiStepIcon-text": {
                  fill: "#fff",
                },
                "& .MuiStepLabel-labelContainer": {
                  color: theme.customColors.grey,
                },
              },
            },
          },
          MuiStepButton: {
            defaultProps: { disableRipple: true },
          },
          MuiStepConnector: {
            styleOverrides: {
              root: {
                "& > span": {
                  borderTop: "2px solid",
                  borderColor: alpha(theme.palette.primary.main, 0.2),
                },
                "&.Mui-active > span, &.Mui-completed > span": {
                  borderColor: theme.palette.primary.main,
                },
              },
            },
          },
          MuiAvatar: {
            variants: [
              {
                props: { variant: "icon" },
                style: {
                  border: "1px solid",
                  borderColor: alpha(theme.palette.primary.main, 0.2),
                  backgroundColor: alpha(theme.palette.primary.main, 0.14),
                  color: theme.customColors.green,
                  [theme.breakpoints.down("sm")]: {
                    width: 32,
                    height: 32,
                    "& .MuiSvgIcon-root": {
                      fontSize: 22,
                    },
                  },
                },
              },
              {
                props: { variant: "label" },
                style: {
                  border: "1px solid",
                  borderColor: alpha(theme.palette.primary.main, 0.2),
                  backgroundColor: alpha(theme.palette.primary.main, 0.14),
                  color: theme.palette.primary.main,
                  fontSize: 12,
                  fontWeight: 600,
                  fontFamily: "Poppins !important",
                  borderRadius: 3,
                  width: "auto",
                  height: "auto",
                  padding: "4px 8px",
                },
              },
              {
                props: { variant: "status" },
                style: {
                  border: "1px solid",
                  borderColor: alpha(theme.palette.primary.main, 0.2),
                  backgroundColor: alpha(theme.palette.primary.main, 0.14),
                  color: theme.palette.primary.main,
                  fontSize: 12,
                  fontWeight: 500,
                  borderRadius: 3,
                  minWidth: 0,
                  width: "fit-content",
                  height: "auto",
                  padding: "4px 12px",
                },
              },
            ],
            styleOverrides: {
              root: {
                "&.red": {
                  borderColor: alpha(theme.palette.error.main, 0.2),
                  backgroundColor: alpha(theme.palette.error.main, 0.14),
                  color: theme.palette.error.main,
                },
                "&.yellow": {
                  borderColor: alpha(theme.palette.warning.main, 0.2),
                  backgroundColor: alpha(theme.palette.warning.main, 0.14),
                  color: theme.palette.warning.main,
                },
                "&.blue": {
                  borderColor: alpha(theme.palette.info.main, 0.2),
                  backgroundColor: alpha(theme.palette.info.main, 0.14),
                  color: theme.palette.info.main,
                },
              },
            },
          },
          MuiSelect: {
            defaultProps: {
              size: "small",
              IconComponent: KeyboardArrowDown,
            },
            styleOverrides: {
              icon: {
                color: theme.palette.text.primary,
              },
            },
          },
          MuiOutlinedInput: {
            styleOverrides: {
              root: {
                "&.MuiSelect-root.primary": {
                  width: 128,
                  fontSize: 14,
                  backgroundColor: theme.palette.background.default,
                  "& fieldset": {
                    borderColor: theme.customColors.border,
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: theme.palette.primary.main,
                  },
                },
              },
            },
          },
          MuiMenuItem: {
            defaultProps: {
              dense: true,
            },
          },
          MuiInputBase: {
            styleOverrides: {
              root: {
                backgroundColor: isDarkMode ? "#212121" : "white",
              },
            },
          },
          MuiButton: {
            styleOverrides: {
              root: {
                boxShadow: "none",
                ":hover": {
                  boxShadow: "none",
                },
                ":focus": {
                  boxShadow: "none",
                },
              },
              containedPrimary: {
                color: "white",
              },
            },
            variants: [
              {
                props: { variant: "action" },
                style: {
                  color: isDarkMode ? theme.palette.secondary.main : "#0058FF",
                  textTransform: "none",
                  fontSize: 14,
                  padding: "4px 8px",
                  minWidth: 0,
                },
              },
            ],
          },
          MuiSnackbar: {
            styleOverrides: {
              root: {
                "& .MuiAlert-root": {
                  boxShadow: theme.shadows[3],
                },
              },
            },
            defaultProps: {
              anchorOrigin: {
                vertical: "top",
                horizontal: "center",
              },
              autoHideDuration: 4000,
            },
          },
          MuiTable: {
            styleOverrides: {
              root: {
                borderCollapse: "collapse",
              },
            },
          },
          MuiTableHead: {
            styleOverrides: {
              root: {
                borderBottom: "7px solid",
                borderColor: isDarkMode
                  ? "#1E1E1E"
                  : theme.palette.background.paper,
                "& th:first-of-type": {
                  borderRadius: "6px 0 0 6px",
                },
                "& th:last-of-type": {
                  borderRadius: "0 6px 6px 0",
                },
              },
            },
          },
          MuiTableBody: {
            styleOverrides: {
              root: {
                "& td:first-of-type": {
                  borderRadius: "6px 0 0 6px",
                },
                "& td:last-of-type": {
                  borderRadius: "0 6px 6px 0",
                },
              },
            },
          },
          MuiTableCell: {
            styleOverrides: {
              root: {
                border: "none",
              },
              body: {
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              },
              head: {
                "&.MuiTableCell-sizeSmall": {
                  fontFamily: "Poppins, sans-serif !important",
                  fontSize: 12,
                },
                fontSize: 13,
                fontWeight: 500,
                textTransform: "uppercase",
                padding: "16px 15px 15px !important",
                backgroundColor: theme.customColors.header,
              },
              sizeSmall: {
                padding: "8px 14px",
              },
              sizeMedium: {
                padding: "16px 12px",
                "&.MuiTableCell-head": {
                  padding: "18px 12px 16px !important",
                },
              },
            },
          },
          MuiTabs: {
            styleOverrides: {
              root: {
                flexGrow: 1,
                minHeight: 35,
                position: "relative",
                "&:after": {
                  content: '""',
                  width: "100%",
                  height: 4,
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  borderRadius: 6,
                  backgroundColor: theme.palette.divider,
                  zIndex: 1,
                },
                "&.dense .MuiTab-root": {
                  padding: "4px 16px",
                },
                "&.less-dense .MuiTab-root": {
                  padding: "4px 24px",
                },
              },
              indicator: {
                height: 4,
                borderRadius: 6,
                zIndex: 2,
              },
            },
          },
          MuiTab: {
            defaultProps: {
              disableRipple: true,
            },
            styleOverrides: {
              root: {
                minWidth: 0,
                minHeight: 0,
                padding: "4px 32px",
                textTransform: "none",
                fontSize: 14,
                fontWeight: 400,
                color: theme.customColors.grey,
                "&.Mui-selected": {
                  fontWeight: 600,
                },
                "&.hasCount": {
                  px: 3,
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "row",
                  lineHeight: "1em",
                  "&:after": {
                    marginLeft: 8,
                    padding: "4px 12px 3px",
                    border: "0.5px solid",
                    borderRadius: "3px",
                    borderColor: alpha(theme.palette.primary.main, 0.2),
                    backgroundColor: alpha(theme.palette.primary.main, 0.14),
                    color: theme.customColors.green,
                    fontSize: 10,
                    lineHeight: "11px",
                    fontWeight: 600,
                  },
                },
              },
            },
          },
          MuiFormControlLabel: {
            styleOverrides: {
              label: {
                fontSize: "0.875rem",
              },
            },
          },
          MuiPagination: {
            defaultProps: {
              color: "primary",
              shape: "rounded",
              size: "small",
              boundaryCount: 2,
              siblingCount: 0,
            },
          },
          MuiPaginationItem: {
            styleOverrides: {
              sizeSmall: {
                height: 28,
                minWidth: 28,
                color: theme.customColors.text.grey,
                "&.Mui-selected": {
                  color: "#fff",
                },
              },
            },
          },
          MuiAccordion: {
            styleOverrides: {
              root: {
                boxShadow: "none",
                borderRadius: theme.shape.borderRadius,
                overflow: "hidden",
                border: `1px solid ${theme.customColors.border}`,
              },
            },
          },
          MuiAccordionSummary: {
            defaultProps: {
              expandIcon: <ExpandMore />,
            },
            styleOverrides: {
              root: {
                backgroundColor: theme.customColors.header,
                // borderBottom: `1px solid ${theme.customColors.border}`,
              },
            },
          },
        },
      }),
    [isDarkMode, theme]
  );

  const isLoggedIn = useSelector((state: GlobalState) =>
    Boolean(state.global.token)
  );

  return (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={customTheme}>
        <CssBaseline />
        <Switch>
          <Route path="/redirect" component={RedirectPage} />
          {isLoggedIn ? (
            <Route path="/" component={DashboardLayout} />
          ) : (
            <Route path="/" component={Auth} />
          )}
          <Redirect to="/" />
        </Switch>
        <Backdrop
          open={loaderState}
          sx={{
            color: "primary.light",
            zIndex: (theme: any) => theme.zIndex.snackbar - 1,
          }}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
        <Snackbar
          key={messageInfo ? messageInfo.key : undefined}
          open={open}
          onClose={handleClose}
          TransitionProps={{ onExited: handleExited }}
          message={messageInfo ? messageInfo.message : undefined}
          {...(actionInfo ? {} : { onClose: handleClose })}
        >
          <Alert
            // onClose={handleClose}
            severity={messageInfo?.type}
            variant={actionInfo ? "outlined" : "filled"}
            sx={
              actionInfo
                ? { bgcolor: (theme: any) => theme.palette.background.paper }
                : {}
            }
            {...(actionInfo
              ? {
                  action: (
                    <Button
                      color="info"
                      sx={{
                        mx: 0.5,
                        transform: "translateY(-1px)",
                        // bgcolor: theme => theme.palette.info.dark,
                        pt: 0.75,
                        px: 1,
                        lineHeight: "1.5em",
                        textTransform: "none",
                      }}
                      size="small"
                      variant="contained"
                      onClick={actionInfo.buttonAction}
                    >
                      {actionInfo.buttonText}
                    </Button>
                  ),
                }
              : { onClose: handleClose })}
          >
            {messageInfo?.message}
          </Alert>
        </Snackbar>
      </ThemeProvider>
    </StyledEngineProvider>
  );
};

const RedirectPage = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    setLoader(true);
    let params = new URLSearchParams(window.location.search);
    let loginJwt = params.get("token") || "";
    if (!loginJwt) {
      setLoader(false);
    } else {
      storageManager.set("loginJwt", loginJwt);
      const userCredentials = jwt.decode(loginJwt, "bolt-secret");
      dispatch(login(userCredentials));
    }
    window.location.assign("/");
    // eslint-disable-next-line
  }, []);

  return <div />;
};

export default withRouter(App);
