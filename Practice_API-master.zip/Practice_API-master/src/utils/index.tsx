import { AlertColor } from "@mui/material";
import {
  toggleDrawer,
  toggleLoader,
  toggleMasterView,
  toggleSnackbar,
} from "actions";
import store from "store";
import { PageID } from "./constants";
import { getBoltToken } from "./request";
import storageManager from "./storageManager";

interface SnackbarMessage {
  type: AlertColor;
  message: string;
  key: number;
}

type DrawerContent = JSX.Element | null;

export interface GlobalState {
  global: {
    [key: string]: any;
    activeSection: string | null;
    token: string | null;
    user: any;
    company: any;
    prefersDarkMode: boolean | null;
    loader: boolean;
    masterView: boolean;
    snackbar: {
      open: boolean;
      snackPack: readonly SnackbarMessage[];
      messageInfo?: SnackbarMessage;
      actionInfo?: {
        buttonText: string;
        buttonAction: () => void;
      };
    };
    drawer: {
      open: boolean;
      content: DrawerContent;
    };
    reports: any[];
    vehicleReports: any[];
  };
}

export type API_METHODS = "GET" | "POST" | "PUT" | "DELETE" | "PATCH";
interface Options {
  method?: API_METHODS;
  headers?: any;
  body?: any;
}

export const authorizedFetch = async (url: string, options?: Options) => {
  let { method, headers, body } = options || {};

  let boltToken = await getBoltToken();

  let newHeaders = {
    ...(headers ? headers : {}),
    token: storageManager?.get("companyToken") || "",
    Authorization: `Bearer ${boltToken}`,
  };

  return fetch(url, {
    ...(method ? { method } : {}),
    headers: newHeaders,
    ...(body ? { body: JSON.stringify(body) } : {}),
  }).then((res) => res.json());
};

export function addQueryParams(url: string, params: { [key: string]: string }) {
  return url.concat(
    "?",
    Object.keys(params)
      .map((key, i) => `${key}=${params[key]}`)
      .join("&")
  );
}

export const getDarkModePreference = (state: GlobalState) => {
  if (state.global.prefersDarkMode === null)
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  else return state.global.prefersDarkMode;
};

export const getMasterView = (state: GlobalState) => {
  return state.global.masterView;
};

export const getPermissions = (pageId: PageID) => {
  let { permissions } = store.getState().global.user;
  let canRead = false,
    canWrite = false,
    isAdmin = false,
    isSuperAdmin = false;

  let section = pageId.split(":")[0];

  if (permissions.includes("dashboard:*")) {
    isSuperAdmin = true;
    isAdmin = true;
    canWrite = true;
    canRead = true;
  } else if (permissions.includes(`dashboard:${section}:*`)) {
    isAdmin = true;
    canWrite = true;
    canRead = true;
  } else if (
    [
      "dashboard:*:*:WRITE",
      `dashboard:${section}:*:WRITE`,
      `dashboard:${pageId}:WRITE`,
    ].some((el) => permissions.includes(el))
  ) {
    canWrite = true;
    canRead = true;
  } else if (
    [
      "dashboard:*:*:READ",
      `dashboard:${section}:*:READ`,
      `dashboard:${pageId}:READ`,
    ].some((el) => permissions.includes(el))
  ) {
    canRead = true;
  }

  return { canRead, canWrite, isAdmin, isSuperAdmin };
};

export const getEnabledSections = (state: GlobalState) => {
  let array: string[] = [];
  let { permissions } = state.global.company;
  if (permissions?.includes("dashboard:*"))
    array = ["retail", "rental", "charger"];
  else {
    if (permissions?.includes("dashboard:retail:*")) array.push("retail");
    if (permissions?.includes("dashboard:rental:*")) array.push("rental");
    if (permissions?.includes("dashboard:charger:*")) array.push("charger");
  }
  return array;
};

export const snackbar = {
  success: createSnackbar("success"),
  info: createSnackbar("info"),
  warning: createSnackbar("warning"),
  error: createSnackbar("error"),
};

export const setLoader = (arg: boolean) => {
  store.dispatch(toggleLoader(arg));
};

export const setMasterView = (arg: boolean) => {
  store.dispatch(toggleMasterView(arg));
};

function createSnackbar(type: string) {
  return (
    message: string,
    options?: { buttonText: string; buttonAction: () => void }
  ) => {
    let snackbarState = store.getState().global.snackbar;
    if (snackbarState?.messageInfo?.message !== "An update is available.")
      store.dispatch(
        toggleSnackbar({
          ...snackbarState,
          snackPack: [
            ...snackbarState.snackPack,
            { type, message, key: new Date().getTime() },
          ],
          ...(options ? { actionInfo: options } : {}),
        })
      );
  };
}

export const drawer = {
  open: (content: DrawerContent) => {
    toggleInfoDrawer({ open: true, content });
  },
  close: () => {
    toggleInfoDrawer({ open: false });
  },
};

function toggleInfoDrawer(arg: any) {
  let drawerState = store.getState().global.drawer;
  store.dispatch(toggleDrawer({ ...drawerState, ...arg }));
}

export function getDuration(minutes: number) {
  if (typeof minutes !== "number" || !minutes) {
    return "0s";
  }
  let s = parseInt((minutes % 1).toFixed(0));
  let m = parseInt((minutes % 60).toFixed(0));
  let h = parseInt(((minutes - m) / 60).toFixed(0));
  return `${h ? h + "h " : ""}${m ? m + "m " : "0m"}${s ? s + "s" : ""}`;
}

export const resolvePath = (object: any, path: string) =>
  path.split(".").reduce((o: any, p) => (o ? o[p] : ""), object);

export const makeCamelCase = (str: string) => {
  let arr = str.toLowerCase().split(/-| /);
  arr.forEach((el, i) => {
    if (i !== 0) arr[i] = el[0]?.toUpperCase() + el.slice(1);
  });
  return arr.join("");
};
