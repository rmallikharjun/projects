import firebase from "firebase/app";
import "firebase/auth";
var config = {
  apiKey: "AIzaSyBK4gJHom3WhHenDqE_Cz6alrirbcuJZkc",
  authDomain: "revmode-98dec.firebaseapp.com",
  databaseURL: "https://revmode-98dec.firebaseio.com",
  projectId: "revmode-98dec",
  storageBucket: "revmode-98dec.appspot.com",
  messagingSenderId: "1014539855897",
};
firebase.initializeApp(config);

export const auth = firebase.auth();
export const storageKey = "KEY_FOR_LOCAL_STORAGE";

export const isAuthenticated = () => {
  return !!auth.currentUser || !!localStorage.getItem(storageKey);
};

export default firebase;
