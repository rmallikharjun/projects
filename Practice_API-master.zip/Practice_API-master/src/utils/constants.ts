import etoLogo from "assets/images/logos/eto-motors.png";

export const GMAPS_API_KEY: string = process.env.REACT_APP_GMAPS_API_KEY || "";
export const AUTH_URL: string = process.env.REACT_APP_AUTH_URL || "";
export const WALLET_URL: string = process.env.REACT_APP_WALLET_URL || "";
export const BOLT_URL: string = process.env.REACT_APP_BOLT_URL || "";
export const GQL_URL: string = process.env.REACT_APP_GQL_URL || "";
export const API_URL: string = process.env.REACT_APP_API_URL || "";
export const DATAFEED_URL: string = process.env.REACT_APP_DATAFEED_URL || "";
export const TRIGGER_URL: string = process.env.REACT_APP_TRIGGER_URL || "";
export const REPORTS_URL: string = process.env.REACT_APP_REPORTS_URL || "";
export const OCPP_URL: string = process.env.REACT_APP_OCPP_URL || "";
export const WEBHOOK_URL: string = process.env.REACT_APP_WEBHOOK_URL || "";
export const NOTIFIER_URL: string = process.env.REACT_APP_NOTIFIER_URL || "";
export const HEALTH_URL: string = process.env.REACT_APP_HEALTH_URL || "";
export const KYC_URL: string = process.env.REACT_APP_KYC_URL || "";
export const HOTFIX_URL: string = process.env.REACT_APP_HOTFIX_URL || "";
export const LEASE_URL: string = process.env.REACT_APP_LEASE_URL || "";
export const RETAIL_URL: string = process.env.REACT_APP_RETAIL_URL || "";
export const ZONES_URL: string = process.env.REACT_APP_ZONES_URL || "";

function getSubdomain(hostname: string) {
  if (["eto.revos.in", "eto.bolt.earth"].includes(hostname))
    return { name: "ETO Motors", icon: etoLogo };
  else return { name: "REVOS", icon: "" };
}

export const subdomain = getSubdomain(window.location.hostname);

export type PageID =
  | "retail:overview"
  | "retail:inventory"
  | "retail:assembly"
  | "retail:distribution"
  | "retail:soldVehicles"
  | "retail:support"
  | "retail:users"
  | "retail:invoices"
  | "retail:kyc"
  | "retail:reports"
  | "retail:admin"
  | "rental:overview"
  | "rental:vehicles"
  | "rental:notifications"
  | "rental:leases"
  | "rental:trips"
  | "rental:users"
  | "rental:kyc"
  | "rental:geoFence"
  | "rental:reports"
  | "rental:invoices"
  | "rental:remoteControl"
  | "rental:admin"
  | "charger:overview"
  | "charger:chargers"
  | "charger:chargerzones"
  | "charger:powerControl"
  | "charger:vendors"
  | "charger:bookings"
  | "charger:subscriptions"
  | "charger:coupons"
  | "charger:users"
  | "charger:kyc"
  | "charger:notifications"
  | "charger:reports"
  | "charger:invoices"
  | "charger:admin";
